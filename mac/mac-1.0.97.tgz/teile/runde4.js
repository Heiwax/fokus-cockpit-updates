/* ---------- 1.0.48 (john 08.11.2026): Locker-Schutz verständlich; 1.0.49: Tagesverlauf in Tageszeiten, Locker „Sperren | Schutz“ ----------
   Steht ganz hinten (nach feinschliff.js). CSS in runde4.css. */

/* ----- Locker › Mehr Schutz: jede Zeile bekommt eine kurze Zweitzeile, damit klar ist, was dahinter steckt ----- */
const R4_ZUS = [[/^Inhaltsschutz/, "Pornos immer zu, dazu Bild-KI und sichere Suche"], [/^Orts-Sperre/, "An Orten wie Gym oder Arbeit ist alles zu"],
  [/^Nachfrage/, "Kurze Pause vor Social Media und Streaming"], [/regelt mit/, "Sperrt von selbst, was dich zu viel Zeit kostet"]];
function r4Zweitzeilen(){
  document.querySelectorAll("#trLockerKarten .tr-karte-kopf, #apSeite .tr-karte-kopf").forEach(kopf => {
    const b = kopf.querySelector("b"); if (!b || kopf.querySelector(".r4-zus")) return;
    const t = R4_ZUS.find(([re]) => re.test(b.deText)); if (t) b.after(el("small","r4-zus", t[1]));
  });
}
(function(){ const tab = document.querySelector('.tab[data-r="locker"]'); if (!tab) return;
  new MutationObserver(() => r4Zweitzeilen()).observe(tab, {childList:true, subtree:true}); r4Zweitzeilen(); })();

/* ----- Werte › Tagesverlauf (1.0.49, john: Fläche/Balken zu unruhig): vier Tageszeiten mit je einem dünnen Strich ----- */
function r4Stunden(){
  const g = typeof r10GeraetDaten === "function" ? r10GeraetDaten() : null;
  return (g ? g.stunden : S.day?.stunden) || null;
}
const R4_ZEITEN = [["Morgen", "6–12 Uhr", [6,12]], ["Mittag", "12–17 Uhr", [12,17]], ["Abend", "17–22 Uhr", [17,22]], ["Nacht", "22–6 Uhr", [22,24,0,6]]];
function r4Verlauf(){
  const box = $("hours"); if (!box) return;
  if (!box.childElementCount) box.classList.remove("r4-zeiten");   // Gerät ohne Daten: leer lassen
  if (!box.querySelector(".stack")) return;   // leer oder schon gezeichnet
  const st = r4Stunden(); if (!st?.length) return;
  const summe = (bereich, k) => { let s = 0; for (let j = 0; j < bereich.length; j += 2) for (let h = bereich[j]; h < bereich[j + 1]; h++) s += st[h]?.[k] || 0; return s; };
  const zeilen = R4_ZEITEN.map(([n, uhr, b]) => ({n, uhr, w:[0,1,2].map(k => summe(b, k))}));
  const max = Math.max(1, ...zeilen.map(z => z.w[0] + z.w[1] + z.w[2]));
  const liste = zeilen.map(z => {
    const ges = z.w[0] + z.w[1] + z.w[2], zeile = el("div","r4-zeile"), name = el("div","r4-zname"), bar = el("div","r4-bar");
    name.append(el("b", null, z.n), el("small", null, z.uhr));
    bar.style.width = (ges / max * 100) + "%";
    ["r4-p","r4-n","r4-a"].forEach((c, k) => { if (z.w[k]){ const i = el("i", c); i.style.flexGrow = z.w[k]; bar.append(i); } });
    const spur = el("div","r4-spur"); spur.append(bar);
    zeile.append(name, spur, el("span","r4-zeit", ges >= 60 ? minText(ges) : "–"));
    return zeile;
  });
  box.classList.add("r4-zeiten");
  box.replaceChildren(...liste);
}
(function(){ const box = $("hours"); if (!box) return; new MutationObserver(() => r4Verlauf()).observe(box, {childList:true}); r4Verlauf(); })();

/* ----- Locker (1.0.49, john: Schutz lag unter allen Gruppen): oben „Sperren | Schutz“ ----- */
function r4Seite(){ return store("r4.lockerSeite") === "schutz" ? "schutz" : "sperren"; }
function r4LockerSeg(){
  const tab = document.querySelector('.tab[data-r="locker"]'); if (!tab) return;
  let seg = $("r4Seg");
  if (!seg){
    seg = el("div","r4-seg"); seg.id = "r4Seg"; seg.setAttribute("role","tablist");
    [["sperren","Sperren"],["schutz","Schutz"]].forEach(([k, t]) => { const b = el("button", null, t); b.type = "button"; b.dataset.k = k; b.setAttribute("role","tab");
      b.addEventListener("click", () => { store("r4.lockerSeite", k); r4LockerSeg(); window.scrollTo({top:0, behavior:"instant"}); }); seg.append(b); });
  }
  if (!seg.isConnected) tab.prepend(seg);   // nur einmal einsetzen; oben hält es CSS (order:-1), andere Teile setzen #lockerBox immer wieder an den Anfang
  const s = r4Seite(); tab.classList.toggle("r4-schutz", s === "schutz");
  seg.querySelectorAll("button").forEach(b => b.setAttribute("aria-selected", String(b.dataset.k === s)));
  // kein Zähler mehr (Gesamttest 09.11.: „3 an“ passte nicht zu „11 Schutz-Ebenen“); jede Zeile zeigt ihren Stand selbst
}
r4LockerSeg();
if (typeof trLockerKarten === "function"){ const _r4Tlk = trLockerKarten; trLockerKarten = async function(...a){ const r = await _r4Tlk.apply(this, a); r4LockerSeg(); return r; }; }
// „PIN eingeben“ auf der Schutz-Seite: erst zu „Sperren“, dort ist das PIN-Feld
document.addEventListener("click", e => { if (e.target.closest(".be-pin") && r4Seite() === "schutz"){ store("r4.lockerSeite", "sperren"); r4LockerSeg(); } }, true);

/* ----- Fokus läuft bis zum Ende (Server lehnt „stop“ ab), Knopf weg ----- */
$("fkStop")?.remove();

/* ----- Panik-Knopf: startet zusätzlich 10 Min Fokus, damit die Ablenker wirklich zu sind (auch wenn das Fenster zugeht) ----- */
if (typeof trPanik === "function"){
  const _r4Panik = trPanik;
  trPanik = function(...a){
    api("api/fokus", {aktion:"start", minuten:10, aufgabe:"Panik-Knopf"}).then(d => { FK.data = d; if (typeof renderFokus === "function") renderFokus(); }).catch(() => {});   // läuft schon ein Fokus: bleibt der
    return _r4Panik.apply(this, a);
  };
}

/* ----- Heute: ohne Porno-Schutz, aber Porno-Versuche diese Woche → Hinweis mit Knopf ----- */
if (typeof trHeroZeichnen === "function"){
  const _r4Hero = trHeroZeichnen;
  trHeroZeichnen = function(h, d){
    const r = _r4Hero.apply(this, arguments);
    const n = d?.sauber?.woche || 0; h.querySelector(".r4-porno")?.remove();
    if (d?.profil?.pornoSchutz === false && n > 0){
      const k = el("div","r4-porno"), b = el("button","ask small","Porno-Schutz einschalten"); b.type = "button";
      b.addEventListener("click", async () => { b.disabled = true; try { await api("api/profil", {ziel:"beides"}); toast("Porno-Schutz ist an."); trLaden(true); } catch (e){ toast(e.message || String(e)); b.disabled = false; } });
      k.append(el("b", null, `Diese Woche ${n}× Porno-Seiten geöffnet`), el("span","k-s","Nicht gesperrt, der Porno-Schutz ist aus. Eingeschaltet sperrt BlockEm Porno-Seiten, Bilder, Apps und Zufalls-Chats. Er lässt sich danach nicht mehr abschalten."), b);
      h.append(k);
    }
    return r;
  };
}

/* ----- 1.0.49 (john 09.11.): Woche/Monat › Tag antippen: Top 3 Produktiv, Neutral, Ablenkung und Öffnungen DIESES Tages; weniger Text ----- */
function r4Kurz(sek){ const m = Math.round((sek || 0) / 60); return m < 60 ? `${m} Min` : `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")} Std`; }
const R4_KATS = [["produktiv","Produktiv","r4-p"], ["neutral","Neutral","r4-n"], ["prokrastination","Ablenkung","r4-a"]];
// eine Liste „Name · Zeit“ mit dünnem Strich, je Kategorie höchstens 3
function r4TopListe(titel, cls, xs, wert){
  const w = el("div","r4-top"); w.append(el("h4", null, titel));
  if (!xs.length){ w.append(el("p","cm-leer","–")); return w; }
  const mx = Math.max(1, ...xs.map(x => x.sek || 0));
  xs.slice(0, 3).forEach(x => { const z = el("div","cm-zeile"), b = el("div","b"), i = el("i", cls); i.style.width = (x.sek || 0) / mx * 100 + "%"; b.append(i);
    z.append(cmKachel(x.name), el("span","n", x.name), el("span","v", wert ? wert(x) : r4Kurz(x.sek)), b); w.append(z); });
  return w;
}
function r4TagApps(d){
  const m = new Map(), gers = d.geraete || [];
  (gers.length ? gers : [{apps:d.apps || []}]).forEach(g => (g.apps || []).forEach(a => {
    if (/launcher|^com\.|^org\.|^android|cockpit|blockem|clear mind/i.test(a.name || "")) return;
    const k = a.name.toLowerCase(), e = m.get(k) || {name:a.name, kat:a.kat, sek:0, oeffnen:0}; e.sek += a.sek || 0; e.oeffnen += a.oeffnen || 0; m.set(k, e); }));
  return [...m.values()];
}
// cmTagZeichnen liegt in clearmind.js in einem Block (von außen nicht ersetzbar): danach umbauen, sobald „Größte Ablenkungen“ auftaucht
function r4TagNach(){
  document.querySelectorAll(".cm-tag").forEach(box => {
    const h = [...box.querySelectorAll("h4")].find(x => /Ablenkungen/.test(x.deText)); if (!h) return;
    const d = CM.tag === TODAY ? S.day : CM.tagDaten?.[CM.tag]; if (!d) return;
    while (h.nextSibling) h.nextSibling.remove(); h.remove();
    const su = d.summe || {}, w = [su.produktiv, su.prokrastination, (su.produktiv || 0) + (su.prokrastination || 0) + (su.neutral || 0)];
    box.querySelectorAll(".cm-kpis b").forEach((x, i) => { if (w[i] != null) x.textContent = r4Kurz(w[i]); });   // „2:30 Std“ statt „2 Std 30 Min“
    const apps = r4TagApps(d);
    R4_KATS.forEach(([k, t, c]) => box.append(r4TopListe(t, c, apps.filter(a => a.kat === k).sort((a, b) => b.sek - a.sek))));
    const oe = apps.filter(a => a.oeffnen).sort((a, b) => b.oeffnen - a.oeffnen);
    if (oe.length) box.append(r4TopListe("Am häufigsten geöffnet", "r4-o", oe.map(a => ({...a, sek:a.oeffnen})), a => `${a.oeffnen}×`));
  });
}
(function(){ const tab = document.querySelector('.tab[data-r="werte"]'); if (!tab) return;
  new MutationObserver(() => { r4TagNach(); r4OeTeil(); }).observe(tab, {childList:true, subtree:true}); r4TagNach(); r4OeTeil(); })();
// „Öffnungen heute“ gehört nur zu Werte › Heute
if (typeof WT_TEILE !== "undefined" && !WT_TEILE[0][2].includes("hOe")) WT_TEILE[0][2].push("hOe");
function r4OeTeil(){ const s = $("r10Werte"), an = (store("cockpit.werteTeil") || "heute") === "heute"; if (s && s.classList.contains("wt-aus") === an) s.classList.toggle("wt-aus", !an); }
// Rückblick (Woche/Monat): drei Zahlen ohne Nebensätze, statt Projekte/Habits/Erledigt die Top 3 je Kategorie
if (typeof renderRueckblick === "function"){
  const _r4Rb = renderRueckblick;
  renderRueckblick = function(){
    const r = _r4Rb.apply(this, arguments), rb = RB.daten, box = $("rbInhalt"); if (!rb || !box) return r;
    const s = rb.summe || {}, top = el("div","r4-rbtop");
    [["Produktiv", s.produktiv, "r4-p"], ["Neutral", s.neutral, "r4-n"], ["Ablenkung", s.prokrastination, "r4-a"]].forEach(([l, v, c]) => {
      const k = el("div", c); k.append(el("span","cm-lbl", l), el("b", null, r4Kurz(v))); top.append(k); });
    box.querySelector(".rb-top")?.replaceWith(top);
    const listen = el("div","r4-rblisten");
    [["produktiv","Produktiv","r4-p"], ["neutral","Neutral","r4-n"], ["ablenkung","Ablenkung","r4-a"]].forEach(([k, t, c]) => listen.append(r4TopListe(t, c, rb[k] || [])));
    box.querySelector(".rb-grid")?.replaceWith(listen);
    box.querySelectorAll(".kon-hint, .rb-ki").forEach(x => x.remove());   // Vault- und KI-Hinweise sind Cockpit-Reste
    return r;
  };
  if (RB.daten) renderRueckblick();
}
document.addEventListener("click", e => { if (e.target.closest("#wtLeiste")) setTimeout(r4OeTeil, 0); });

/* ----- Locker (1.0.49b, john 09.11.): Orte gehören zu „Sperren“, Schutz-Karten mit klaren Namen ----- */
if (typeof lkOffen === "function"){
  const _r4LkOffen = lkOffen;
  lkOffen = function(d){
    const out = _r4LkOffen.call(this, d), leiste = out.find(x => x.classList?.contains("r2-teil")); if (!leiste || leiste.querySelector(".r4-orte-chip") || window.CockpitApp?.play?.()) return out;   // Play-Fassung ohne Orts-Sperre (john 16.11.2026)
    const orte = store("cm.lmTeil") === "orte" && CM.tab !== "frei", n = (TR.daten?.orte || []).length;
    const b = el("button","chip small r4-orte-chip", `Orte ${n}`); b.type = "button"; b.setAttribute("aria-pressed", String(orte));
    b.addEventListener("click", () => { CM.tab = "apps"; store("cm.lmTeil", "orte"); store("cm.lockerTab", "apps"); renderLocker(true); });
    leiste.querySelector('[aria-pressed]:last-child')?.before(b);   // vor „Freischalten“
    if (orte && typeof r10OrteKarte === "function"){
      leiste.querySelectorAll("button:not(.r4-orte-chip)").forEach(x => x.setAttribute("aria-pressed","false"));
      const box = out.find(x => x.classList?.contains("lm-liste"));
      if (box){ box.replaceChildren(r10OrteKarte()); const k = box.querySelector(".r10-orte"); k?.classList.add("r4-orte-hier"); const t = k?.querySelector(".tr-karte-kopf .k-s"); if (t) t.textContent = "An diesen Orten sind Social Media und Streaming zu, egal zu welcher Uhrzeit."; }
      for (let i = out.length - 1; i >= 0; i--) if (out[i].classList?.contains("cm-neu") || (out[i].classList?.contains("r10-filter") && !out[i].classList.contains("r2-teil"))) out.splice(i, 1);
    }
    return out;
  };
}
const R4_NAMEN = [[/^Nachfrage/, "Pause vor dem Öffnen", "Kurz innehalten, bevor Social Media oder Streaming aufgeht"],
  [/regelt mit/, "Automatisch begrenzen", "Nutzt du eine App 3 Tage lang über 1 Std. am Tag, setzt BlockEm ein Limit"]];
function r4SchutzNamen(){
  document.querySelectorAll("#trLockerKarten .tr-karte-kopf").forEach(kopf => {
    const b = kopf.querySelector("b"); if (!b) return;
    const t = R4_NAMEN.find(([re]) => re.test(b.deText));
    if (t){ b.textContent = t[1]; let z = kopf.querySelector(".r4-zus"); if (!z){ z = el("small","r4-zus"); b.after(z); } z.textContent = t[2]; }
    if (!kopf.querySelector('[role="switch"], input[type="checkbox"], .r4-an')) kopf.append(el("span","r4-an","Immer an"));   // ohne Schalter: Stand zeigen
    if (!kopf.querySelector(".tr-ico") && typeof CM_SVG !== "undefined"){ const i = el("span","tr-ico cm-kachel"); i.innerHTML = CM_SVG.shield || ""; kopf.prepend(i); }   // Inhaltsschutz hatte kein Symbol
  });
}
if (typeof trLockerKarten === "function"){ const _r4Tlk2 = trLockerKarten; trLockerKarten = async function(...a){ const r = await _r4Tlk2.apply(this, a); r4SchutzNamen();
  if (store("cm.lmTeil") === "orte" && $("lockerBox")?.querySelector(".r4-orte-hier")) renderLocker(true);   // Ort gespeichert: Liste neu
  return r; }; }
r4SchutzNamen();

/* ----- Locker › Sperren (john 09.11.): große Kacheln statt kleiner Leiste ----- */
const R4_KACHEL = {gruppen:"hash", apps:"phone", zeiten:"clock", orte:"pin", frei:"lock"};
function r4Kacheln(leiste){
  if (!leiste || leiste.classList.contains("r4-kacheln")) return;
  leiste.classList.add("r4-kacheln");
  const keys = ["gruppen","apps","zeiten","orte","frei"], btns = [...leiste.querySelectorAll("button")];
  btns.forEach(b => {
    const m = b.deText.trim().match(/^(.*?)\s+(\d+)$/), name = m ? m[1] : b.deText.trim();
    const k = b.classList.contains("r4-orte-chip") ? "orte" : keys.find(x => ({gruppen:"Gruppen",apps:"Apps",zeiten:"Sperrzeiten",frei:"Freischalten"})[x] === name) || "";
    const i = el("span","r4-k-ico"); i.innerHTML = (typeof CM_SVG !== "undefined" && CM_SVG[R4_KACHEL[k]]) || "";
    b.replaceChildren(i, el("span","r4-k-name", name), ...(m ? [el("span","r4-k-zahl", m[2])] : []));
    if (k === "frei") b.classList.add("r4-k-frei");
    b.setAttribute("aria-label", m ? `${name}: ${m[2]}` : name);
  });
}
if (typeof lkOffen === "function"){
  const _r4LkKacheln = lkOffen;
  lkOffen = function(d){ const out = _r4LkKacheln.call(this, d); r4Kacheln(out.find(x => x.classList?.contains("r2-teil"))); return out; };
}

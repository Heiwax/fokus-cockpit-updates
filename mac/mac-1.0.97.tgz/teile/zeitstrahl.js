/* 21.11.2026 (john): Unter „Regeln verwalten › Sperrzeiten“ ein Zeitstrahl über den Kreisen (0–24 Uhr). Jede Sperrzeit bekommt eine Farbe,
   derselbe Farbton steht als Pfeil im Kreis. Überlappende Zeiten liegen in einer zweiten Bahn. Antippen = wie Kreis antippen.
   Gruppen: Sperrzeiten mit Namen aus der Einrichtung (nur Zeit-Regeln, z. B. „Nachts“) stehen nicht mehr unter Gruppen, sie sind schon Kreise. */
const K_STRAHL_FARBEN = ["var(--accent)", "var(--brown)", "var(--green)", "var(--bar)"];
const K_RUHE_NAMEN = ["Nachts", "Morgens", "Arbeit", "Abends"];
const kMin = t => +t.slice(0, 2) * 60 + +t.slice(3);
function kStrahl(zeiten){
  if (!zeiten.length) return "";
  const bahnen = [], frei = (b, a, e) => b.every(([x, y]) => e <= x || a >= y);
  const html = zeiten.map((r, i) => {
    const a = kMin(r.von), e = kMin(r.bis), st = a < e ? [[a, e, ""]] : [[a, 1440, "weiter"], [0, e, "fort"]];   // über Mitternacht: zwei Stücke, eine Regel
    let n = bahnen.findIndex(b => st.every(([x, y]) => frei(b, x, y))); if (n < 0){ bahnen.push([]); n = bahnen.length - 1; }
    st.forEach(([x, y]) => bahnen[n].push([x, y]));
    return {n, h:st.map(([x, y, k]) => `<button type="button" class="${k} ${K.kreis === r.id ? "offen" : ""}" style="left:${x / 14.4}%;width:${(y - x) / 14.4}%;--z:${K_STRAHL_FARBEN[i % 4]}" data-k-kreis="${kEsc(r.id)}" aria-label="${kEsc((r.gruppe || "Sperrzeit") + " " + r.von + " bis " + r.bis)}"></button>`).join("")};
  });
  const jetzt = new Date(), m = jetzt.getHours() * 60 + jetzt.getMinutes();
  return `<div class="k-strahl"><div class="k-strahl-bahnen">${bahnen.map((_, n) => `<div class="k-strahl-bahn">${html.filter(x => x.n === n).map(x => x.h).join("")}</div>`).join("")}</div>`
    + `<i class="k-strahl-jetzt" style="left:calc(5px + (100% - 10px) * ${m / 1440})"></i>`
    + `<div class="k-strahl-skala">${[0, 6, 12, 18, 24].map(h => `<span style="left:${h / 24 * 100}%">${h}</span>`).join("")}</div></div>`;
}
K_SEITEN.rules = (alt => function(){
  const t = document.createElement("template"); t.innerHTML = alt();
  const zeiten = (K.lk?.regeln || []).filter(r => r.art === "zeit").sort((a, b) => a.von.localeCompare(b.von));   // gleiche Reihenfolge wie die Kreise (kLock)
  const kreise = t.content.querySelector(".k-kreise");
  if (kreise){
    kreise.insertAdjacentHTML("beforebegin", kStrahl(zeiten));
    zeiten.forEach((r, i) => { const p = kreise.querySelector(`[data-k-kreis="${CSS.escape(r.id)}"] .k-pfeil`); if (p){ p.classList.add("k-farbe"); p.style.setProperty("--z", K_STRAHL_FARBEN[i % 4]); } });
  }
  // Gruppen-Reiter: Ruhezeiten aus der Einrichtung (release10.js stSlotsNeu schreibt ihren Namen ins Feld gruppe) sind Sperrzeiten, keine Gruppen.
  // shortcut: erkennt sie am Namen, solange sie nur Zeit-Regeln haben; eine eigene Gruppe „Nachts“ nur mit Sperrzeit verschwindet auch (bleibt über ihren Kreis erreichbar).
  kGruppen().filter(g => K_RUHE_NAMEN.includes(g.name) && g.regeln.every(r => r.art === "zeit")).forEach(g => t.content.querySelector(`.k-gruppe[data-k-gruppe="${CSS.escape(g.key)}"]`)?.remove());
  return t.innerHTML;
})(K_SEITEN.rules);

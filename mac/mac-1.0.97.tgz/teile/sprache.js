/* 24.11. (john): BlockEm auf Deutsch und Englisch. Die Logik bleibt deutsch, nur was auf dem Bildschirm steht, wird übersetzt
   (Wörterbuch teile/sprache-en.json, dasselbe nutzen Java und server.py). Wahl in store("kern.sprache"): "de" | "en" | fehlt = Systemsprache.
   Code, der Text aus der Seite liest und mit Deutsch vergleicht, nimmt el.deText (liefert immer den deutschen Urtext). */
const SPRACHE = (() => { let s = null; try { s = JSON.parse(localStorage.getItem("kern.sprache")); } catch (e) {}
  return s === "de" || s === "en" ? s : (/^de\b/i.test(navigator.language || "de") ? "de" : "en"); })();
document.documentElement.lang = SPRACHE;
try { window.CockpitApp?.sprache?.(SPRACHE); } catch (e) {}
function spracheSetzen(s){   // s: "de" | "en" | null (= wie das System)
  try { s ? localStorage.setItem("kern.sprache", JSON.stringify(s)) : localStorage.removeItem("kern.sprache"); } catch (e) {}
  const neu = s || (/^de\b/i.test(navigator.language || "de") ? "de" : "en");
  try { window.CockpitApp?.sprache?.(neu); } catch (e) {}
  const weiter = () => location.reload();
  if (!window.CockpitApp && typeof api === "function") api("api/einstellungen", {sprache:neu}).then(weiter, weiter); else weiter();
}
const tr = (() => {
  const URTEXT = new WeakMap(), GESETZT = new WeakMap();
  Object.defineProperty(Node.prototype, "deText", {configurable:true, get(){
    if (this.nodeType === 3) return URTEXT.has(this) && GESETZT.get(this) === this.data ? URTEXT.get(this) : this.data;
    let s = ""; const w = document.createTreeWalker(this, NodeFilter.SHOW_TEXT); for (let n = w.nextNode(); n; n = w.nextNode()) s += n.deText; return s; }});
  if (SPRACHE === "de") return s => s;
  let W = {}; try { W = JSON.parse(document.getElementById("spracheEn")?.textContent || "{}"); } catch (e) {}
  const ZAHL = /\d+(?:[.,:]\d+)*/g, PH = "\u0002", EX = new Map(), NX = new Map(), ANF = new Map(), END = new Map(), REST = [];
  const tok = s => s.split(" ")[0].replace(/[„“"'(),.:!?…]/g, ""), tokEnd = s => s.split(" ").pop().replace(/[„“"'(),.:!?…]/g, "");
  for (const [de, en] of Object.entries(W)) {
    if (!/\{\d\}/.test(de)) { EX.set(de, en);
      const zd = de.match(ZAHL), ze = en.match(ZAHL);
      if (zd && ze && zd.join() === ze.join()) NX.set(de.replace(ZAHL, PH), en.replace(ZAHL, PH));
      continue; }
    const teile = de.split(/(\{\d\})/), nr = [];
    const re = new RegExp("^" + teile.map(t => /^\{\d\}$/.test(t) ? (nr.push(+t[1]), "(.*?)") : t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("") + "$");
    if (de.replace(/\{\d\}|\s/g, "").length < 3) continue;   // zu wenig fester Text, würde fast alles treffen
    const m = {re, nr, en, fest:de.replace(/\{\d\}/g, "").length}, a = tok(de), e = tokEnd(de);
    if (a && !a.includes("{")) (ANF.get(a) || ANF.set(a, []).get(a)).push(m);
    else if (e && !e.includes("{")) (END.get(e) || END.set(e, []).get(e)).push(m);
    else REST.push(m);
  }
  const zahlEn = z => /^\d+,\d{1,2}$/.test(z) ? z.replace(",", ".") : z;
  function genau(k){
    let e = EX.get(k); if (e !== undefined) return e;
    const z = []; const kn = k.replace(ZAHL, x => (z.push(x), PH));
    if (z.length && (e = NX.get(kn)) !== undefined) { let i = 0; return e.replace(/\u0002/g, () => zahlEn(z[i++] ?? "")); }
    return undefined;
  }
  for (const l of [...ANF.values(), ...END.values(), REST]) l.sort((x, y) => y.fest - x.fest);
  function muster(k, tiefe = 0){   // das genaueste Muster gewinnt (meister fester Text), Platzhalter werden selbst übersetzt
    let best = null, bt;
    for (const l of [ANF.get(tok(k)), END.get(tokEnd(k)), REST]) for (const m of l || []) {
      if (best && m.fest <= best.fest) break;
      const t = m.re.exec(k); if (t) { best = m; bt = t; break; }
    }
    if (!best) return undefined;
    return best.en.replace(/\{(\d)\}/g, (_, n) => { const g = (bt[best.nr.indexOf(+n) + 1] ?? "").trim(); return genau(g) ?? (tiefe < 2 && g.length > 2 ? muster(g, tiefe + 1) : undefined) ?? g; });
  }
  function tr(s){
    if (s == null) return s; s = String(s);
    const k = s.replace(/\s+/g, " ").trim(); if (!k || !/[A-Za-zÄÖÜäöüß]/.test(k)) return s;
    let e = genau(k); if (e === undefined) e = muster(k); if (e === undefined) e = mehrzeilig(s); if (e === undefined) e = aufzaehlung(k);
    if (e === undefined || e === k) return s;
    return s.match(/^\s*/)[0] + e + s.match(/\s*$/)[0];
  }
  function mehrzeilig(s){   // Toasts/Meldungen aus mehreren Sätzen oder Zeilen: Stück für Stück
    if (!/\n/.test(s.trim())) return undefined;
    const t = s.split(/\n/).map(z => { const k = z.trim(); return k ? (genau(k) ?? muster(k) ?? z) : z; }).join("\n");
    return t === s ? undefined : t;
  }
  function aufzaehlung(k){   // „Social 60 Min, Streaming 120 Min“ / „A · B“: Teil für Teil, wenn kein ganzer Eintrag passt
    const t = k.split(/(, | · )/); if (t.length < 3) return undefined;
    const u = t.map((x, i) => i % 2 ? x : (genau(x) ?? muster(x) ?? x)).join("");
    return u === k ? undefined : u;
  }
  const NICHT = new Set(["SCRIPT","STYLE","TEXTAREA","NOSCRIPT","CODE"]);
  const frei = el => el && !NICHT.has(el.nodeName) && !el.closest?.('[translate="no"],[contenteditable="true"],[contenteditable=""]');
  const freiAttr = el => frei(el.nodeName === "TEXTAREA" ? el.parentElement : el);   // Platzhalter im Textfeld übersetzen, Inhalt nie
  function text(n){
    if (GESETZT.has(n) && GESETZT.get(n) === n.data) return;
    if (!frei(n.parentElement)) return;
    const p = n.parentElement; if (p.nodeName === "OPTION" && !p.hasAttribute("value")) p.setAttribute("value", p.textContent);   // value bleibt deutsch
    const t = tr(n.data); URTEXT.set(n, n.data); GESETZT.set(n, t); if (t !== n.data) n.data = t;
  }
  const ATTR = ["placeholder", "title", "alt", "aria-label", "data-tip"], ATTR_SET = new WeakMap();
  function attr(el, a){
    if (!el.hasAttribute(a) || (a === "aria-label" && el.nodeName === "INPUT") || !freiAttr(el)) return;   // input[aria-label=…] dient als Suchschlüssel
    const v = el.getAttribute(a), alt = ATTR_SET.get(el) || {}; if (alt[a] === v) return;
    const t = tr(v); alt[a] = t; ATTR_SET.set(el, alt); if (t !== v) el.setAttribute(a, t);
  }
  function element(el){
    if (el.nodeType === 3) return text(el);
    if (el.nodeType !== 1 || !freiAttr(el)) return;
    ATTR.forEach(a => attr(el, a));
    if (el.nodeName === "INPUT" && /^(button|submit|reset)$/i.test(el.type) && el.value) { const t = tr(el.value); if (t !== el.value) el.value = t; }
    const w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, {acceptNode: n => n.nodeType === 1 && NICHT.has(n.nodeName) && n.nodeName !== "TEXTAREA" ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT});
    for (let n = w.nextNode(); n; n = w.nextNode()) n.nodeType === 3 ? text(n) : ATTR.forEach(a => attr(n, a));
  }
  element(document.body);
  new MutationObserver(liste => { for (const m of liste) {
    if (m.type === "childList") m.addedNodes.forEach(element);
    else if (m.type === "characterData") text(m.target);
    else if (m.type === "attributes") attr(m.target, m.attributeName);
  } }).observe(document.documentElement, {subtree:true, childList:true, characterData:true, attributes:true, attributeFilter:ATTR});
  for (const f of ["alert", "confirm"]) { const o = window[f]; window[f] = (m, ...r) => o.call(window, tr(m), ...r); }
  const prompt0 = window.prompt; window.prompt = (m, v) => prompt0.call(window, tr(m), v);
  // Datum und Zahlen: "de-DE" wird zu britischem Englisch (Tag vor Monat, 24-Std-Uhr)
  const ort = l => l == null || /^de/i.test(Array.isArray(l) ? l[0] : String(l)) ? "en-GB" : l;
  for (const [o, f] of [[Date.prototype, "toLocaleDateString"], [Date.prototype, "toLocaleTimeString"], [Date.prototype, "toLocaleString"], [Number.prototype, "toLocaleString"]]) {
    const alt = o[f]; o[f] = function(l, opt){ return alt.call(this, ort(l), opt); }; }
  for (const k of ["DateTimeFormat", "NumberFormat", "RelativeTimeFormat", "PluralRules", "ListFormat"]) { const A = Intl[k]; if (!A) continue;
    const N = function(l, o){ return new A(ort(l), o); }; N.prototype = A.prototype; N.supportedLocalesOf = A.supportedLocalesOf; Intl[k] = N; }
  return tr;
})();
setTimeout(() => { if (!window.CockpitApp && typeof api === "function" && store("kern.spracheMac") !== SPRACHE) api("api/einstellungen", {sprache:SPRACHE}).then(() => store("kern.spracheMac", SPRACHE), () => {}); }, 4000);   // Mac-Mitteilungen in derselben Sprache

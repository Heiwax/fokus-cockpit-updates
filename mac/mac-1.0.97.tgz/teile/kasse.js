/* ---------- Bezahlung (john 09.11.2026): BlockEm Pro, fair und ohne Druck ----------
   Nur in der Handy-App (window.CockpitApp.kasse). Kein Pop-up, kein Countdown: eine Zeile unter „Mehr“, ein Blatt zum Selbst-Öffnen,
   ein ruhiger Hinweis auf „Heute“ erst 2 Tage vor Ende oder wenn BlockEm pausiert. Logik und Käufe: Kasse.java. CSS in kasse.css. */
const KA_LISTE = {monat:"4,99 €", jahr:"34,99 €", immer:"69,99 €"};   // Listenpreise, falls Google Play (noch) nichts liefert
const KA_TAG = 86400000;
function kaStand(){ try { return window.CockpitApp?.kasse ? JSON.parse(CockpitApp.kasse()) : null; } catch { return null; } }
const kaRest = k => Math.max(0, Math.ceil((k.ende - Date.now()) / KA_TAG));
const kaDatum = ms => new Date(ms).toLocaleDateString("de-DE", {weekday:"long", day:"numeric", month:"long"});
function kaKurz(k){
  if (k.test) return "Gerade im Test: alles frei";
  if (k.art === "immer") return "Für immer freigeschaltet";
  if (k.art === "abo") return "Pro läuft";
  if (!k.play) return "Entwicklerversion: alles frei";
  if (!k.frei) return "Macht gerade Pause";
  const r = kaRest(k); return r === 1 ? "Noch 1 Tag gratis" : `Noch ${r} Tage gratis`;
}

let kaUhr = 0;
// Aussehen 10.11.2026 (john: Blatt sah schlecht aus): kurzer Brief mit Avatar, Stand als Pille, Jahr als Empfehlung hervorgehoben, Kleingedrucktes als Zeilen.
function kaOeffnen(){
  const k0 = kaStand(); if (!k0) return;
  let d = $("kaDialog");
  if (!d){
    d = el("dialog","mehr-blatt modern ka-blatt"); d.id = "kaDialog"; d.setAttribute("aria-label","BlockEm Pro");
    d.addEventListener("click", e => { if (e.target === d) d.close(); });
    document.body.append(d);
  }
  let alt = "";
  const ico = (z, farbe) => { const i = el("span","es-ico ka-ico", z); i.style.setProperty("--md-ico", farbe); i.setAttribute("aria-hidden","true"); return i; };   // Farben wie MD_FARBE in android.js
  const zeile = (i, titel, klein, fn) => {
    const z = el(fn ? "button" : "div","es-zeile ka-z"); if (fn) { z.type = "button"; z.addEventListener("click", fn); }
    const t = el("span","es-text"); t.append(el("b", null, titel)); if (klein) t.append(el("small", null, klein));
    z.append(i, t); if (fn) z.append(el("span","es-pfeil","›")); return z;
  };
  const karte = (...z) => { const c = el("div","es-karte ka-karte"); c.append(...z); return c; };
  const gruppe = (name, c) => { const g = el("div","es-gruppe"); g.append(el("h3", null, name), c); return g; };
  const zeichnen = () => {
    if (!d.open) return clearInterval(kaUhr);
    const k = kaStand(); if (!k) return;
    const neu = JSON.stringify(k); if (neu === alt) return; alt = neu;
    const zu = el("button","ka-zu","×"); zu.type = "button"; zu.setAttribute("aria-label","Schließen"); zu.addEventListener("click", () => d.close());
    const teile = [el("div","mb-griff"), zu, el("h2", null, "BlockEm Pro")];
    // Stand oben als Pille
    const stand = el("div","ka-stand");
    const pille = el("span","ka-pille" + (k.art || k.test ? " ok" : !k.frei ? " pause" : ""), kaKurz(k));
    stand.append(pille); if (!k.art && !k.test && k.play && k.frei) stand.append(el("small", null, `bis ${kaDatum(k.ende)}`));
    teile.push(stand);
    // Kurzer Brief
    const brief = el("div","ka-brief"), av = el("span","ka-avatar","J"); av.setAttribute("aria-hidden","true");
    const txt = el("div","ka-brief-text");
    if (k.art) txt.append(el("p", null, "Danke, dass du dabei bist. Das bedeutet mir richtig viel."));
    else if (!k.test && k.play && !k.frei) txt.append(el("p", null, "Deine 7 Tage sind rum, deine Sperren machen Pause. Du hast was angefangen. Lass es nicht liegen: Such dir unten aus, was passt, und es geht genau da weiter, wo du aufgehört hast."));
    else txt.append(el("p", null, "Ganz ehrlich vorweg: BlockEm kostet Geld. Du hast 7 Tage, um alles auszuprobieren, ohne Zahlungsdaten. Gib ihm diese Chance. Ich bin mir ziemlich sicher, du merkst, was es mit dir macht."));
    txt.append(el("p","ka-gruss","John, hat BlockEm gebaut"));
    brief.append(av, txt); teile.push(brief);
    if (k.art){
      teile.push(gruppe("Dein Zugang", karte(
        zeile(ico("✓","#D9CBB6"), k.art === "immer" ? "Für immer freigeschaltet" : "Dein Abo läuft", k.art === "immer" ? "Kein Abo, nichts läuft weiter" : "Kündigen jederzeit in Google Play"),
        ...(!k.schutz ? [zeile(ico("🛡","#FFB39B"), "Deinstallier-Schutz wieder einschalten", "Er ging mit der Pause aus", () => CockpitApp.einstellungen?.())] : []),
        ...(k.play ? [zeile(ico("▶","#E6DDCF"), "Abo in Google Play verwalten", null, () => CockpitApp.aboVerwalten())] : []))));
    } else {
      const wahl = el("div","ka-wahl"), kaufbar = k.play && !k.test;
      [["monat","Monat","Monatlich kündbar", ""], ["jahr","Jahr","Jährlich kündbar", "Empfohlen"], ["immer","Für immer","Einmal zahlen, kein Abo", ""]].forEach(([was, t, s, tag]) => {
        const b = el("button","ka-option" + (tag ? " ka-top" : "")); b.type = "button"; b.disabled = !kaufbar;
        const o = el("span","ka-otext"); o.append(el("b", null, t), el("small", null, s));
        if (tag) b.append(el("span","ka-tag", tag));
        b.append(o, el("span","ka-preis", k.preise?.[was] || KA_LISTE[was]));
        b.addEventListener("click", () => CockpitApp.kaufen(was));
        wahl.append(b);
      });
      teile.push(gruppe("Was passt zu dir?", wahl));
      const info = [];
      if (k.test) info.push(zeile(ico("🧪","#E6DDCF"), "Gerade läuft der Test", "Für dich ist alles frei, kaufen geht erst danach"));
      else if (!k.play) info.push(zeile(ico("🛠","#FFB39B"), "Entwicklerversion", "Kaufen geht nur in der Version aus dem Play Store"));
      info.push(zeile(ico("💤","#FFB39B"), "Ohne Pro macht BlockEm nur Pause", "Deine Daten bleiben, nach dem Kauf geht alles sofort weiter"),
        zeile(ico("↩","#FFB39B"), "Kündigen jederzeit", "In Google Play. Die Gratistage kosten nichts, ein Abo verlängert sich, bis du kündigst"));
      if (k.play) info.push(zeile(ico("▶","#E6DDCF"), "Abo in Google Play verwalten", null, () => CockpitApp.aboVerwalten()));
      teile.push(gruppe("Gut zu wissen", karte(...info)));
    }
    if (k.meldung) teile.push(el("p","ort-meldung schlecht", k.meldung));
    d.replaceChildren(...teile);
  };
  if (!d.open) d.showModal();
  zeichnen();   // 21.11.: erst öffnen, sonst brach zeichnen() ab und das Blatt blieb 1,5 s leer
  clearInterval(kaUhr); kaUhr = setInterval(zeichnen, 1500);   // Kauf läuft in Google Play: Stand kommt von selbst
}

// „Mehr“: eine Zeile BlockEm Pro unter der Liste. Über einen Beobachter statt mehrOeffnen zu umhüllen,
// weil der Mehr-Knopf die alte Funktion schon beim Start festhält.
function kaMehrZeile(){
  const d = $("mehrDialog"), liste = d?.querySelector(".mb-liste"), k = liste && !liste.querySelector(".ka-zeile") ? kaStand() : null;
  if (!k) return;
  const b = el("button","mb-zeile ka-zeile"); b.type = "button";
  const i = el("span","mb-icon"); i.innerHTML = '<svg class="ri" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3l2.6 5.6 6 .7-4.5 4.1 1.2 6L12 16.4 6.7 19.4l1.2-6L3.4 9.3l6-.7z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/></svg>';
  const t = el("span","mb-text"); t.append(el("b", null, "BlockEm Pro"), el("small", null, kaKurz(k)));
  b.append(i, t); b.addEventListener("click", () => { d.close(); kaOeffnen(); });
  liste.append(b);
}
function kaMehrBeobachten(){
  const d = $("mehrDialog"); if (!d || d.dataset.ka) return false;
  d.dataset.ka = "1"; new MutationObserver(kaMehrZeile).observe(d, {childList:true}); kaMehrZeile(); return true;
}

// „Heute“: ruhiger Hinweis nur in den letzten 2 Tagen oder wenn pausiert; „Später“ blendet ihn einen Tag aus
function kaHinweis(){
  const tab = document.querySelector('.tab[data-r="heute"]'); if (!tab) return;
  const k = kaStand(), alt = $("kaHinweis");
  const zeigen = k && !k.test && k.play && !k.art && (!k.frei || kaRest(k) <= 2) && !(Date.now() < (store("ka.spaeter") || 0));
  if (!zeigen){ alt?.remove(); return; }
  const h = el("div","ka-hinweis"); h.id = "kaHinweis";
  const txt = el("p", null, k.frei ? (kaRest(k) <= 1 ? "Morgen ist deine Testzeit rum. " : "Noch 2 Tage gratis. ") + "Bleib dran und mach hier direkt weiter."
    : "BlockEm macht gerade Pause. Deine Daten sind sicher. Mach weiter, wo du aufgehört hast.");
  const ja = el("button","ghost small", k.frei ? "Ansehen" : "Weitermachen"); ja.type = "button"; ja.addEventListener("click", kaOeffnen);
  const nein = el("button","ka-link","Später"); nein.type = "button"; nein.addEventListener("click", () => { store("ka.spaeter", Date.now() + KA_TAG); h.remove(); });
  const knoepfe = el("div","ka-knoepfe"); knoepfe.append(ja, nein);
  h.append(txt, knoepfe);
  if (alt) alt.replaceWith(h); else tab.prepend(h);
}

if (window.CockpitApp?.kasse){
  kaHinweis();
  if (!kaMehrBeobachten()){ const mo = new MutationObserver(() => { if (kaMehrBeobachten()) mo.disconnect(); }); mo.observe(document.body, {childList:true}); }
  document.addEventListener("visibilitychange", () => { if (!document.hidden) kaHinweis(); });
}

/* ---------- V1.2: „Jetzt dran“, Abendabschluss, Wochenplan-Vorschlag, freie Zeiten (Kalender), Sperre im Fokus, „Läuft alles?“, Plan gegen Wirklichkeit ---------- */
// Was wie automatisch läuft, steht im Vault in „Browser-App Cockpit – Automatisierung“. Schalter: Reiter „Automatik“ (autoAn).
// Echte Zeit = Fokuszeit mit dieser Aufgabe; antippen = von Hand korrigieren (leer: „⏱ Zeit“ nur, wenn leer=true)
const echtTag = (it, leer) => {
  const hat = it.echt >= 60; if (!hat && !leer) return null;
  const plan = (it.aufwand || it.std || 0) * 3600, text = it.text || it.name;
  const t = el("button", "tag echt-tag" + (hat ? (plan && it.echt > plan * 1.2 ? " warn" : "") : " leer"), hat ? "echt " + minText(it.echt) : "⏱ Zeit");
  t.type = "button";
  t.title = (hat ? (plan ? `Geplant ${stdText(plan / 3600)}, echte Zeit ${minText(it.echt)}` : "Echte Zeit mit dieser Aufgabe") : "Echte Zeit eintragen") + " · antippen zum Ändern";
  if (S.mode !== "lokal" || !text) return t;
  t.addEventListener("click", ev => { ev.preventDefault(); ev.stopPropagation();
    const f = el("form","echt-form"), inp = el("input"), ok = el("button", null, "✓");
    inp.type = "number"; inp.min = "0"; inp.step = "5"; inp.value = hat ? Math.round(it.echt / 60) : ""; inp.placeholder = "Min"; inp.setAttribute("aria-label", "Echte Zeit in Minuten");
    ok.type = "submit"; f.append(inp, el("span","k-s","Min"), ok);
    f.addEventListener("click", e => e.stopPropagation());
    f.addEventListener("submit", async e => { e.preventDefault(); e.stopPropagation(); if (inp.value === "") return; ok.disabled = true;
      try { S.plan = await api("api/echt", {aufgabe:text, minuten:inp.value}); renderPlan(); }
      catch (er){ ok.disabled = false; inp.title = er.message || String(er); inp.classList.add("c-bad"); } });
    t.replaceWith(f); inp.focus(); });
  return t; };

function renderV12(){
  renderJetzt(); renderAbend(); renderWochenplan(); renderKalender(); renderLaeuft(); renderSperre(); renderKalSet(); renderLocker();
}

/* „Jetzt dran“: die eine nächste Aufgabe, mit Fokus starten */
const JETZT = {skip:0};
function renderJetzt(){
  const box = $("jetztBox"); if (!box) return;
  const p = S.plan, lokal = S.mode === "lokal";
  box.hidden = !p || !lokal || !autoAn("jetzt"); if (box.hidden) return;
  const akt = FK.data?.aktiv;
  if (akt){
    const b = el("button","ask small","Zum Fokus"); b.type = "button"; b.addEventListener("click", () => { showTab("fokus"); window.scrollTo(0, 0); });
    const t = el("div","jz-t"); t.append(el("span","k-l","Im Fokus"), el("b","jz-n", akt.aufgabe || akt.projekt || "Freie Fokus-Session"), el("span","k-s", `bis ${hm(akt.planEnde)}`));
    box.replaceChildren(t, b); return;
  }
  const offen = p.heute.filter(t => !t.done);
  let it = offen.length ? offen[JETZT.skip % offen.length] : null, ausVorschlag = false;
  if (!it && !p.heute.length && p.vorschlag?.liste?.length){ it = p.vorschlag.liste[0]; ausVorschlag = true; }
  if (!it){ box.hidden = true; return; }
  const t = el("div","jz-t"), tags = el("span","jz-tags");
  if (it.projekt) tags.append(el("span","tag", it.projekt));
  const std = it.rest ?? it.std; if (std) tags.append(el("span","tag", stdText(std)));
  const e = echtTag(it); if (e) tags.append(e);
  t.append(el("span","k-l", ausVorschlag ? "Vorschlag für jetzt" : "Jetzt dran"), el("b","jz-n", it.text), tags);
  const los = el("button","ask","Fokus starten"), btns = el("div","jz-btns");
  los.type = "button";
  los.addEventListener("click", async () => {
    los.disabled = true;
    if (ausVorschlag){ try { S.plan = await api("api/plan-setzen", {heute:[{text:it.text, projekt:it.projekt}]}); } catch {} }
    const proj = it.projekt && p.projekte.some(x => x.name === it.projekt && x.aktiv) ? it.projekt : null;
    await fkAction({aktion:"start", projekt:proj, aufgabe:it.text, minuten:FK.dur});
    showTab("fokus"); window.scrollTo(0, 0);
  });
  btns.append(los);
  if (!ausVorschlag){
    const ok = el("button","ghost small","Erledigt"); ok.type = "button"; ok.addEventListener("click", () => { ok.disabled = true; toggle(it, true); });
    btns.append(ok);
    if (offen.length > 1){ const n = el("button","ghost small","Andere"); n.type = "button"; n.addEventListener("click", () => { JETZT.skip++; renderJetzt(); }); btns.append(n); }
  }
  box.replaceChildren(t, btns);
}

/* Abendabschluss: ab 19 Uhr, einmal am Tag. Wird er vergessen, bleibt Offenes einfach für morgen in Heute stehen. */
function renderAbend(){
  const box = $("abendBox"); if (!box) return;
  const p = S.plan, a = p?.automatik;
  box.hidden = !p || S.mode !== "lokal" || !autoAn("abend") || NOW.getHours() < 19 || a?.abend === TODAY || !p.heute.length; if (box.hidden) return;
  const fertig = p.heute.filter(t => t.done), offen = p.heute.filter(t => !t.done), raus = new Set();
  const fokus = FK.data?.auswertung?.heute, s = S.day?.summe;
  const kopf = el("div","ab-kopf"); kopf.append(el("b", null, "Tagesabschluss"),
    el("span","k-s", `${fertig.length} von ${p.heute.length} geschafft` + (fokus?.sessions ? ` · ${minText(fokus.produktiv)} echter Fokus` : "") + (s ? ` · ${minText(s.produktiv)} produktiv` : "")));
  const kids = [kopf];
  if (fertig.length) kids.push(el("p","ab-done", fertig.map(t => "✓ " + t.text).join("   ")));
  if (offen.length){
    kids.push(el("p","k-s","Was nicht geschafft ist, bleibt für morgen in Heute. Was nicht mehr dran ist, nimmst du raus (es bleibt im Projekt bzw. in der Woche)."));
    offen.forEach(t => {
      const r = el("div","ab-row"), b = el("button","chip small","Morgen");
      b.type = "button"; b.setAttribute("aria-pressed","true");
      b.addEventListener("click", () => { raus.has(t) ? raus.delete(t) : raus.add(t); const r2 = raus.has(t); b.textContent = r2 ? "Raus aus Heute" : "Morgen"; b.setAttribute("aria-pressed", String(!r2)); });
      r.append(el("span","n", t.text), b); kids.push(r);
    });
  }
  const ok = el("button","ask","Tag abschließen"); ok.type = "button";
  ok.addEventListener("click", async () => {
    ok.disabled = true;
    try {
      for (const t of raus) if (t.id) S.plan = await api("api/loeschen", {art:"zeile", id:t.id, text:t.text});
      S.plan = await api("api/automatik", {abend:true}); renderPlan();
      toast(offen.length - raus.size > 0 ? `Feierabend. ${offen.length - raus.size} ${offen.length - raus.size === 1 ? "Aufgabe wartet" : "Aufgaben warten"} morgen auf dich.` : "Feierabend. Gut gemacht!");
    } catch (e){ ok.disabled = false; alert(e.message || e); }
  });
  const btns = el("div","tp-btns"); btns.append(ok); kids.push(btns);
  box.replaceChildren(...kids);
}

/* Wochenplan kommt fertig: Sonntag für nächste Woche, Montag für diese. Übersprungen = keine Folgen. */
function renderWochenplan(){
  const box = $("wpBox"); if (!box) return;
  const wp = S.plan?.wochenplan; box.hidden = !wp || S.mode !== "lokal"; if (box.hidden) return;
  const wahl = new Set(wp.liste.map((_, i) => i)), ul = el("ul","list"), sub = el("span","k-s");
  const summe = () => wp.liste.filter((_, i) => wahl.has(i)).reduce((a, x) => a + x.std, 0);
  const zeig = () => { sub.textContent = `${wahl.size} Ziele · ${stdText(summe())} · in KW ${wp.kw} hast du ${stdKurz(wp.std)}` + (wp.belegt ? `, davon ${stdText(wp.belegt)} schon verplant` : ""); };
  wp.liste.forEach((x, i) => {
    const li = el("li","item"), cb = document.createElement("input"), t = el("div","t", x.text);
    cb.type = "checkbox"; cb.checked = true; cb.setAttribute("aria-label", x.text);
    cb.addEventListener("change", () => { cb.checked ? wahl.add(i) : wahl.delete(i); ok.disabled = !wahl.size; zeig(); });
    t.append(el("span","tag", x.projekt), el("span","tag", stdText(x.std))); if (x.prio) t.append(el("span", x.prio === "muss" ? "tag on" : "tag", x.prio[0].toUpperCase() + x.prio.slice(1)));
    li.append(cb, t); ul.append(li);
  });
  const ok = el("button","ask","Übernehmen"), selbst = el("button","ghost small","Selbst planen"), weg = el("button","ghost small","Diese Woche nicht");
  [ok, selbst, weg].forEach(b => b.type = "button");
  const senden = async (status, danach) => {
    ok.disabled = selbst.disabled = weg.disabled = true;
    try { S.plan = await api("api/wochenplan", {status, woche: status === "uebernommen" ? wp.liste.filter((_, i) => wahl.has(i)).map(x => ({text:x.text, projekt:x.projekt})) : []});
      renderPlan(); if (status === "uebernommen") toast(`KW ${wp.kw} steht.`); danach?.(); }
    catch (e){ ok.disabled = selbst.disabled = weg.disabled = false; alert(e.message || e); }
  };
  ok.addEventListener("click", () => senden("uebernommen"));
  selbst.addEventListener("click", () => senden("weg", () => openPlaner("woche")));
  weg.addEventListener("click", () => senden("weg"));
  const btns = el("div","tp-btns"); btns.append(ok, selbst, weg); zeig();
  box.replaceChildren(el("b","tp-h", wp.naechste ? `Deine nächste Woche ist vorbereitet (KW ${wp.kw})` : "Deine Woche ist vorbereitet"), sub, ul, btns);
}

/* Freie Zeiten aus dem Kalender (nur anzeigen, Termine sind schon verplant) */
function renderKalender(){
  const box = $("kalFrei"); if (!box) return;
  const k = S.plan?.kalender; box.hidden = !k || S.mode !== "lokal" || !!S.plan?.zeitplan; if (box.hidden) return;
  if (k.fehler){ box.textContent = k.fehler; box.className = "kal-frei c-bad"; return; }
  box.className = "kal-frei";
  box.replaceChildren(el("span","k-l", "Frei laut Kalender"), ...(k.frei.length ? k.frei.map(f => el("span","tag", `${f.von}–${f.bis}`)) : [el("span","k-s","heute nichts mehr frei")]));
  box.title = `${k.termine} ${k.termine === 1 ? "Termin" : "Termine"} heute, gezählt ${k.rahmen}, Lücken ab 30 Min`;
}
function renderKalSet(){
  const box = $("kalSet"); if (!box) return;
  const a = S.plan?.automatik; if (!a || S.mode !== "lokal"){ box.replaceChildren(el("p","empty","Nur in BlockEm auf dem Mac.")); return; }
  const f = el("form","add kal-form"), inp = el("input");
  inp.type = "url"; inp.placeholder = a.kalenderUrl ? "Kalender ist verbunden (neue Adresse zum Ersetzen)" : "Privatadresse im iCal-Format einfügen"; inp.setAttribute("aria-label","Kalender-Adresse im iCal-Format");
  const b = el("button", null, "Speichern"); b.type = "submit"; f.append(inp, b);
  f.addEventListener("submit", async ev => { ev.preventDefault(); b.disabled = true;
    try { S.plan = await api("api/kalender", {url:inp.value}); renderPlan(); toast(inp.value ? "Kalender verbunden." : "Kalender getrennt."); }
    catch (e){ alert(e.message || e); } b.disabled = false; });
  const kids = [f, el("p","hint kon-hint", "Google Kalender am Computer: Einstellungen › dein Kalender › „Kalender integrieren“ › „Privatadresse im iCal-Format“ kopieren und hier einfügen. Die Adresse bleibt nur auf deinem Mac.")];
  if (a.kalenderUrl){ const weg = el("button","ghost small","Kalender trennen"); weg.type = "button";
    weg.addEventListener("click", async () => { S.plan = await api("api/kalender", {url:""}); renderPlan(); toast("Kalender getrennt."); }); kids.push(weg); }
  box.replaceChildren(...kids);
}

/* „Systemcheck“ (früher „Läuft alles?“): Datenquellen und Nacht-Sicherung; im Kopf ein Hinweis, wenn etwas hängt */
function renderLaeuft(){
  const l = S.plan?.laeuft, chip = $("laeuftChip"), box = $("laeuftListe");
  const kaputt = (l || []).filter(x => !x.ok);
  if (chip){ chip.hidden = !l || S.mode !== "lokal" || !kaputt.length; chip.textContent = kaputt.length === 1 ? `⚠ ${kaputt[0].name}` : `⚠ ${kaputt.length} Probleme`; chip.dataset.n = kaputt.length; chip.title = chip.textContent; }
  if (!box) return;
  if (!l){ box.replaceChildren(el("p","empty", S.mode === "lokal" ? "Wird geladen …" : "Nur in BlockEm auf dem Mac.")); return; }
  const rows = l.map(x => { const r = el("div","lf-row"); r.append(el("i", "lf-dot " + (x.ok ? "ok" : "bad")), el("span","n", x.name), el("span","k-s", x.text)); return r; });
  const neu = el("button","ghost small","BlockEm neu starten"); neu.type = "button";
  neu.addEventListener("click", async () => {
    neu.disabled = true; neu.textContent = "Startet neu …";
    try { await api("api/neustart", {}); } catch (e){}
    for (let i = 0; i < 90; i++){ await new Promise(r => setTimeout(r, 1000)); try { const r = await fetch("api/status", {cache:"no-store"}); if (r.ok){ location.reload(); return; } } catch (e){} }
    neu.disabled = false; neu.textContent = "BlockEm neu starten"; toast("BlockEm kommt nicht wieder. Bitte start-cockpit.command doppelklicken.");
  });
  box.replaceChildren(...rows, neu, el("p","hint kon-hint", "Hilft, wenn etwas hängt."));   // 21.11. (john): Sicherung nur noch unter Daten & Export
}

/* Sperre im Fokus: anklicken, was während einer Fokus-Session gesperrt ist */
function renderSperre(){
  const box = $("fkSperre"); if (!box) return;
  const sp = S.plan?.automatik?.sperre; $("fkSperreBox").hidden = !sp || S.mode !== "lokal"; if (!sp) return;
  const an = new Set(sp.an.map(x => x.toLowerCase())), aus = !autoAn("sperre");
  const chips = el("div","chips sp-chips");
  sp.kandidaten.forEach(n => {
    const b = el("button","chip small", n), on = an.has(n.toLowerCase()); b.type = "button"; b.setAttribute("aria-pressed", String(on));
    b.addEventListener("click", async () => { b.disabled = true; try { S.plan = await api("api/sperre", {name:n, an:!on}); renderPlan(); } catch (e){ alert(e.message || e); } });
    chips.append(b);
  });
  const f = el("form","add sp-add"), inp = el("input"), plus = el("button", null, "+");
  inp.placeholder = "Weitere Seite oder App, z. B. Telegram"; inp.setAttribute("aria-label","Weitere Seite oder App sperren"); plus.type = "submit"; plus.setAttribute("aria-label","Hinzufügen");
  f.append(inp, plus);
  f.addEventListener("submit", async ev => { ev.preventDefault(); if (!inp.value.trim()) return; try { S.plan = await api("api/sperre", {neu:inp.value}); renderPlan(); } catch (e){ alert(e.message || e); } });
  const g = FK.data?.aktiv?.gesperrt || [];
  // Erlaubnis prüfen: der Test löst die Abfrage des Mac aus und zeigt, was fehlt
  const test = el("button","ghost small","Sperre testen"); test.type = "button";
  test.addEventListener("click", async () => { test.disabled = true; test.textContent = "Prüft … (Mac fragt evtl. nach Erlaubnis)";
    try { await api("api/sperre", {test:true}); S.plan = await api("api/plan"); renderPlan(); } catch (e){ alert(e.message || e); } });
  const diag = [];
  // In der Handy-App: Sperre auf dem Handy (Bedienungshilfe „BlockEm Fokus-Sperre“) an?
  if (window.CockpitApp?.sperreAktiv){
    const an = window.CockpitApp.sperreAktiv(), r = el("div","lf-row");
    r.append(el("i","lf-dot " + (an ? "ok" : "bad")), el("span","n","Sperre auf diesem Handy"), el("span","k-s", an ? "an" : "aus"));
    diag.push(r);
    if (!an){ const b = el("button","ask small","Am Handy einschalten"); b.type = "button"; b.addEventListener("click", () => handySperreErklaeren()); diag.push(b); }
  }
  // In der Handy-App: Fokus-Stand sofort ans Handy geben, das sperrt dann auch ohne WLAN bis zum Fokus-Ende
  if (window.CockpitApp?.sperreSetzen){
    const a = FK.data?.aktiv, bis = a && !aus ? Date.parse(a.planEnde) : 0;
    try { window.CockpitApp.sperreSetzen(bis > Date.now() ? bis : 0, JSON.stringify(bis > Date.now() ? sp.an : [])); } catch {}
  }
  // Stand der Sperre je Handy: Version und Bedienungshilfe kommen mit jedem Sync (ab App 1.6)
  (sp.geraete || []).forEach(n => {
    const s = sp.handys?.[n], info = sp.infos?.[n] || {}, ok = s != null && s < 90, r = el("div","lf-row");
    const alt = !info.version || parseFloat(info.version) < 1.6;
    const text = ok ? "verbunden" : alt ? `Handy-App ${info.version || "vor 1.6"}: bitte aktualisieren (Knopf „Update“ in der Handy-App)`
      : info.dienst === false ? "Bedienungshilfe „BlockEm Fokus-Sperre“ ist aus"
      : `bereit, sperrt im Fokus auch ohne WLAN${s != null ? ` (zuletzt verbunden vor ${minText(s)})` : ""}`;
    r.append(el("i","lf-dot " + (ok || (!alt && info.dienst) ? "ok" : "bad")), el("span","n", `Sperre auf ${n}`), el("span","k-s", text));
    diag.push(r);
  });
  if (sp.fehler) diag.push(el("p","k-s c-bad", sp.fehler));
  if (sp.test) sp.test.liste.forEach(x => { const r = el("div","lf-row"); r.append(el("i","lf-dot " + (x.ok ? "ok" : "bad")), el("span","n", x.name), el("span","k-s", x.text)); diag.push(r); });
  $("fkSperreSub").textContent = aus ? "ausgeschaltet (Reiter Automatik)" : `${an.size} gesperrt, solange eine Fokus-Session läuft`;
  box.replaceChildren(chips, f, el("p","hint kon-hint", VB.modus === "handy" ? "Öffnest du im Fokus eine gesperrte App oder Seite, schiebt BlockEm sie weg." : "Öffnest du im Fokus eine gesperrte Seite, springt der Tab aufs BlockEm; eine gesperrte App wird ausgeblendet. Fragt der Mac, ob Terminal Safari, Chrome oder „System Events“ steuern darf: erlauben. „Sperre testen“ zeigt, ob alles erlaubt ist."),
    ...(g.length ? [el("p","k-s", "In dieser Session gesperrt: " + g.map(x => `${x.zeit} ${x.name}`).join(", "))] : []), ...diag, ...(VB.modus === "handy" ? [] : [test]));
}

/* ---------- Einstellungen mit Untermenüs (3.1): Übersicht mit Gruppen und Suche, jeder Bereich als eigene Seite ---------- */
// Breit (ab 1000 px): Liste links, offene Seite rechts. Schmal (Handy): erst die Liste, Antippen öffnet die Seite, „‹ Einstellungen“ zurück.
// Adresse: #einstellungen/<seite>. Der frühere Reiter „Automatik“ ist jetzt die Seite „automatik“ (alte Links führen dorthin).
const ES_GRUPPEN = [
  ["Du", [
    {k:"profil", t:"Über dich & dein Tag", s:"Name, Ziele, Tagesrahmen", ico:"👤", farbe:"#5b8def", such:"name ziel datum produktiv budget ablenkung minuten tag rahmen uhrzeit stunden aufgaben pro tag"},
    {k:"aussehen", t:"Aussehen", s:"Hell oder dunkel", ico:"🎨", farbe:"#a46cf0", such:"hell dunkel farbe thema design modus nacht"},
  ]],
  ["Verbindungen", [
    {k:"ki", t:"Deine KI", s:"Claude, ChatGPT, Gemini …", ico:"✦", farbe:"#e0894a", such:"ki claude chatgpt openai gemini mistral openrouter ollama schlüssel api modell abo"},
    {k:"kalender", t:"Kalender", s:"Google, iCloud, Outlook", ico:"📅", farbe:"#e05a5a", such:"termine ical ics google icloud outlook frei platzhalter blöcke"},
    {k:"geraete", t:"Handys & Geräte", s:"Handy verbinden, App-Update", ico:"📱", farbe:"#3fb68b", such:"android pixel handy app verbinden code update aktualisieren nutzung bildschirmzeit geräte rechte schutz deinstallieren"},
  ]],
  ["Fokus & Automatik", [
    {k:"automatik", t:"Automatik", s:"Was von selbst passiert", ico:"⚡", farbe:"#d6a53a", such:"automatik tagesplan mehr machen habits hinweis mitteilung rückblick abend wochenplan zeitleiste mein tag google sicherung schalter"},
    {k:"fokus", t:"Fokus-Sperre", s:"Was im Fokus gesperrt ist", ico:"🔒", farbe:"#4aa3c7", such:"sperre sperren blockieren seiten apps fokus youtube instagram"},
    {k:"locker", t:"Locker", s:"Sperrzeiten, Limits", ico:"⏱", farbe:"#6b7a8c", such:"locker sperre sperrzeiten tageslimit limit pin lockern", reiter:true},
  ]],
  ["Daten & Hilfe", [
    {k:"speicherort", t:"Wo deine Daten liegen", s:"Handy, Computer oder Online-Server", ico:"🗂", farbe:"#7d6bd6", such:"speicherort ort umziehen umzug computer pc windows mac server online handy verbinden mitnehmen sicherung einspielen übernehmen"},
    {k:"daten", t:"Daten & Export", s:"Export, Import, Datenordner", ico:"💾", farbe:"#5f7fa8", such:"daten export zip import datenordner obsidian vault datenschutz sicherung"},
    {k:"status", t:"Systemcheck", s:"Prüfen, ob alles läuft", ico:"🩺", farbe:"#3fb68b", such:"systemcheck check läuft alles status probleme fehler activitywatch sicherung neustart neu starten hilfe läuft"},
    {k:"datenweg", t:"Was dein Gerät verlässt", s:"Datenschutz, kurz und ehrlich", ico:"🛡", farbe:"#7d6bd6", such:"datenschutz privatsphäre daten server verlässt internet screenshots tracking"},
  ]],
];
const ES_DEF = Object.fromEntries(ES_GRUPPEN.flatMap(([, l]) => l.map(x => [x.k, x])));
const ES = {seite:null, gepusht:false};
const esBreit = () => matchMedia("(min-width:1000px)").matches;
const esNorm = t => (t || "").toLowerCase().replace(/ä/g, "ae").replace(/ö/g, "oe").replace(/ü/g, "ue").replace(/ß/g, "ss");

// Kurzer Zustand rechts in der Zeile („Claude (Abo)“, „2 Kalender“, „⚠ 1 Problem“ …)
function esWert(k){
  const p = S.plan || {}, txt = id => ($(id)?.deText || "").trim();
  if (k === "profil") return p.profil?.name || "";
  if (k === "aussehen") return {light:"Hell", dark:"Dunkel"}[store("cockpit.thema")] || "System";
  if (k === "ki") return p.ki?.anbieter ? (p.ki.name || "verbunden") : "nicht verbunden";
  if (k === "kalender") return /verbunden/.test(txt("eiKalSub")) ? txt("eiKalSub") : "keiner";
  if (k === "geraete") { const n = S.phoneInfo?.geraete?.length; return VB.modus === "handy" ? "dieses Handy" : n ? `${n} verbunden` : ""; }
  if (k === "automatik") return txt("autoSub");
  if (k === "fokus") return p.automatik?.sperre ? (autoAn("sperre") ? "an" : "aus") : "";
  if (k === "status") { const kaputt = (p.laeuft || []).filter(x => !x.ok).length; return p.laeuft ? (kaputt ? `⚠ ${kaputt} ${kaputt === 1 ? "Problem" : "Probleme"}` : "alles ok") : ""; }
  if (k === "speicherort") return ORT_ARTEN.find(a => a.k === ortJetzt())?.kurz || "";
  if (k === "daten") return p.profil?.version ? `Version ${p.profil.version}` : "";
  return "";
}

function esListe(){
  const box = $("esListe"); if (!box) return;
  const q = esNorm($("esSuche")?.value.trim());
  const treffer = x => !q || esNorm(`${x.t} ${x.s} ${x.such}`).includes(q);
  const teile = [];
  ES_GRUPPEN.forEach(([name, liste]) => {
    const l = liste.filter(treffer); if (!l.length) return;
    const g = el("div","es-gruppe"), karte = el("div","es-karte");
    g.append(el("h3", null, name), karte);
    l.forEach(x => {
      const b = el("button","es-zeile"); b.type = "button"; b.dataset.k = x.k;
      if (ES.seite === x.k && esBreit()) b.setAttribute("aria-current", "page");
      const ico = el("span","es-ico", x.ico); ico.style.background = x.farbe; ico.setAttribute("aria-hidden", "true");
      const t = el("span","es-text"); t.append(el("b", null, x.t), el("small", null, x.s));
      const w = esWert(x.k), wert = el("span","es-wert" + (/^⚠/.test(w) ? " warn" : ""), w);
      b.append(ico, t, wert, el("span","es-pfeil", x.reiter ? "↗" : "›"));
      b.addEventListener("click", () => esOeffnen(x.k));
      karte.append(b);
    });
    teile.push(g);
  });
  if (!teile.length) teile.push(el("p","empty","Nichts gefunden. Versuch es mit einem anderen Wort, z. B. „Sperre“ oder „Export“."));
  box.replaceChildren(...teile);
  // Seite „Handys & Geräte“ und „Fokus-Sperre“: Hinweise, wenn dort sonst nichts stünde
  const ha = $("esHandyApp");
  if (ha){
    const teil = [];
    if (window.CockpitApp?.einstellungen) teil.push(eiKnopf("Handy-App: Verbindung, Rechte, Schutz", "ask small", () => window.CockpitApp.einstellungen()));
    if (VB.modus === "handy") teil.push(el("p","hint kon-hint","Bildschirmzeit und Sperren laufen direkt auf diesem Handy. Weitere Geräte verbindest du unter Einstellungen › Geräte & Konto."));
    else if ($("phoneBox")?.hidden) teil.push(el("p","empty","Handys verbindest du in BlockEm auf deinem Mac (oder deinem BlockEm-Server): dort steht hier der Code zum Einrichten."));
    ha.replaceChildren(...teil);
  }
  const leer = $("esSperreLeer"); if (leer) leer.hidden = !$("fkSperreBox")?.hidden;
}

function esZeigen(){
  const breit = esBreit();
  if (breit && !ES_DEF[ES.seite]) ES.seite = ES_DEF[store("cockpit.esSeite")] && !ES_DEF[store("cockpit.esSeite")].reiter ? store("cockpit.esSeite") : "profil";
  $("es").classList.toggle("es-offen", !!ES.seite);
  document.querySelectorAll(".es-page").forEach(p => { p.hidden = p.dataset.s !== ES.seite; });
  $("esTitel").textContent = ES_DEF[ES.seite]?.t || "";
  esListe();
  const h = ES.seite ? "#einstellungen/" + ES.seite : "#einstellungen";
  if (location.hash !== h) try { history.replaceState(history.state, "", h); } catch {}
}

function esOeffnen(k){
  const d = ES_DEF[k]; if (!d) return;
  if (d.reiter){ showTab(k); window.scrollTo(0, 0); return; }
  ES.seite = k; store("cockpit.esSeite", k);
  const h = "#einstellungen/" + k;
  // Am Handy eigener Verlaufseintrag, damit „Zurück“ (auch die Android-Taste) wieder zur Liste führt
  try { if (location.hash !== h){ if (!esBreit() && location.hash === "#einstellungen"){ history.pushState(null, "", h); ES.gepusht = true; } else history.replaceState(history.state, "", h); } } catch {}
  showTab("einstellungen");
  window.scrollTo(0, 0);
  if (!esBreit()) $("esTitel")?.focus?.();
}
function esZurueck(){
  if (ES.gepusht && !esBreit()){ ES.gepusht = false; ES.seite = null; try { history.back(); return; } catch {} }
  ES.seite = null; esZeigen(); window.scrollTo(0, 0);
}

// showTab: „automatik“ führt in die Einstellungen; beim Öffnen der Einstellungen zählt die Adresse (#einstellungen/ki)
const _showTabEs = showTab;
showTab = function(r){
  if (r === "automatik"){ ES.seite = "automatik"; r = "einstellungen"; }
  else if (r === "einstellungen"){
    const [a, b] = location.hash.slice(1).split("/");
    if (a === "einstellungen"){ ES.seite = ES_DEF[b] && !ES_DEF[b].reiter ? b : null; if (!ES.seite) ES.gepusht = false; }
    else if (!esBreit()) ES.seite = null;   // vom anderen Reiter kommend: am Handy erst die Übersicht
  }
  _showTabEs(r);
  if (r === "einstellungen") esZeigen();
};
const _renderAutomatikEs = renderAutomatik;
renderAutomatik = function(){ _renderAutomatikEs(); if ($("es")) esListe(); };

$("esZurueck")?.addEventListener("click", esZurueck);
$("esTitel")?.setAttribute("tabindex", "-1");
$("esSuche")?.addEventListener("input", esListe);
$("esSuche")?.addEventListener("keydown", e => {
  if (e.key === "Enter"){ e.preventDefault(); const b = $("esListe").querySelector(".es-zeile"); if (b) b.click(); }
  if (e.key === "Escape"){ e.target.value = ""; esListe(); }
});
document.addEventListener("click", e => { const b = e.target.closest("[data-es]"); if (b) esOeffnen(b.dataset.es); });
try { matchMedia("(min-width:1000px)").addEventListener("change", () => { if (!document.querySelector('.tab[data-r="einstellungen"]').hidden) esZeigen(); }); } catch {}

/* ---------- Vertrauensperson (john 09.11.2026, vor allem für die Play-Fassung) ----------
   Nur in der Handy-App (CockpitApp.begAnfrage). Einladen per Link (Teilen-Menü; die E-Mail trägt die Vertrauensperson selbst ein und bestätigt sie),
   Liste mit Zusage-Stand, Verlauf der Meldungen, und „Ich begleite jemanden“ mit Begleiter-Code. Server: sync-dienst/sync_dienst.py
   (/v1/begleitung, /v1/begleiter). Meldungen beim Abschalten schickt Begleitung.java, nicht diese Datei. CSS in vertrauen.css. */
const VP = {fehler:"", neuLink:null, wegKlick:null, verlauf:false, code:false};
function vpAnfrage(methode, pfad, body, wer){
  try {
    const a = JSON.parse(CockpitApp.begAnfrage(methode, pfad, body ? JSON.stringify(body) : "", wer || ""));
    if (a.status === 200) return a.daten;
    VP.fehler = (a.daten && a.daten.fehler) || a.fehler || "Das ging gerade nicht.";
  } catch { VP.fehler = "Das ging gerade nicht."; }
  return null;
}
const vpZeit = iso => { const d = new Date(iso); return isNaN(d) ? "" : d.toLocaleString("de-DE", {day:"numeric", month:"short", hour:"2-digit", minute:"2-digit"}); };
function vpKnopf(text, klasse, fn){ const b = el("button", klasse, text); b.type = "button"; b.addEventListener("click", fn); return b; }
function vpFeld(id, platz, wert, art){ const i = el("input", "vp-feld"); i.id = id; i.placeholder = platz; i.value = wert || ""; if (art) i.type = art; return i; }
const vpWert = id => ($(id)?.value || "").trim();
function vpTeilen(name, link){ CockpitApp.teilen(`Hey ${name}, ich nutze BlockEm und möchte dich als meine Vertrauensperson. Was das heißt und wie du zusagst, steht hier: ${link}`); }

// Aussehen 10.11.2026 (john: Blatt sah schlecht aus): Stil wie das Einstellungsmenü – Abschnitts-Überschrift, Karte mit Zeilen, Icon-Kreis, wenig Text.
function vpIco(zeichen, farbe){ const i = el("span", "es-ico vp-ico", zeichen); i.style.setProperty("--md-ico", farbe); i.setAttribute("aria-hidden", "true"); return i; }   // Farben wie MD_FARBE in android.js
function vpZeile(ico, titel, klein, rechts, fn){
  const z = el(fn ? "button" : "div", "es-zeile vp-z"); if (fn) { z.type = "button"; z.addEventListener("click", fn); }
  const t = el("span", "es-text"); t.append(el("b", null, titel)); if (klein) t.append(el("small", null, klein));
  z.append(ico, t); if (rechts) z.append(rechts); if (fn) z.append(el("span", "es-pfeil", "›"));
  return z;
}
function vpKarte(...zeilen){ const k = el("div", "es-karte vp-karte"); k.append(...zeilen); return k; }
const vpGruppe = (name, karte) => { const g = el("div", "es-gruppe"); g.append(el("h3", null, name), karte); return g; };
function vpFehlerZeile(text){ return el("p", "ort-meldung schlecht", text); }

function vpEigene(){
  const teile = [];
  const st0 = CockpitApp.begAn() ? vpAnfrage("GET", "/v1/begleitung") : null;
  // Ohne Begleitung, oder mit der stillen (Plan B, ohne Namen): erst erklären, dann Vorname
  if (!CockpitApp.begAn() || (st0 && !st0.name)){
    const kopf = el("div", "vp-hero");
    kopf.append(vpIco("🤝", "#FFB39B"), el("b", null, "Jemand, der es erfährt"),
      el("p", null, "Jemand, dem du vertraust, bekommt Bescheid, wenn du den Schutz abschaltest."));
    teile.push(kopf, vpGruppe("So funktioniert es", vpKarte(
      vpZeile(vpIco("🔔", "#E6DDCF"), "Erfährt nur das Abschalten", "Und wenn du den 48-Std-Ausstieg startest"),
      vpZeile(vpIco("🙈", "#D9CBB6"), "Sieht nie, was du anschaust", "Nur, ob der Schutz an ist"),
      vpZeile(vpIco("⏱", "#FFB39B"), "Dauert 30 Sekunden", "Du schickst einen Link, sie sagt zu"))));
    const f = vpKarte(); f.classList.add("vp-form");
    f.append(vpFeld("vpName", "Dein Vorname (sieht sie)"), vpFeld("vpWarum", "Warum machst du das? (optional)"),
      vpKnopf("Los geht's", "haupt vp-breit", () => {
        if (!vpWert("vpName")) { VP.fehler = "Bitte deinen Vornamen eintragen."; return vpZeichnen(); }
        if (st0) vpAnfrage("POST", "/v1/begleitung/einstellen", {name:vpWert("vpName"), warum:vpWert("vpWarum")});
        else vpAnfrage("POST", "/v1/begleitung/neu", {name:vpWert("vpName"), warum:vpWert("vpWarum")});
        vpZeichnen(); vpKonto(true);
      }));
    teile.push(vpGruppe("Deine Angaben", f),
      el("p", "vp-klein", "Ehrlich gesagt: Dein Vorname, dein Satz sowie Name und (falls angegeben) E-Mail deiner Vertrauensperson liegen unverschlüsselt auf unserem Server in der EU. Löschen geht jederzeit."));
    return teile;
  }
  const st = st0;
  if (!st) { teile.push(vpGruppe("Meine Vertrauensperson", vpKarte(vpZeile(vpIco("📡", "#FFB39B"), "Gerade keine Verbindung", "Meldungen gehen raus, sobald wieder Netz da ist")))); return teile; }
  CockpitApp.begPerson?.(st.personen.some(p => p.bestaetigt));   // für „erfährt es“-Texte in den Einstellungen
  store("vp.person", st.personen.length > 0);
  const zeilen = [];
  if (VP.neuLink){
    const k = el("div", "vp-hero vp-neu");
    k.append(vpIco("📨", "#FFB39B"), el("b", null, `Jetzt ${VP.neuLink.name} den Link schicken`), el("p", null, "Z. B. per WhatsApp oder SMS. Wenn sie zusagt, erscheint hier „dabei“."),
      vpKnopf("Link schicken", "haupt vp-breit", () => vpTeilen(VP.neuLink.name, VP.neuLink.link)));
    teile.push(k);
  }
  st.personen.forEach(p => {
    const pille = el("span", p.bestaetigt ? "vp-ok" : "vp-wartet", p.bestaetigt ? "✓ dabei" : "wartet");
    zeilen.push(vpZeile(vpIco(p.name.slice(0, 1).toUpperCase(), p.bestaetigt ? "#D9CBB6" : "#FFB39B"), p.name,
      p.bestaetigt ? (p.mail ? "Bekommt Nachrichten per E-Mail" : "Nur über das Begleiter-BlockEm") : "Hat den Link noch nicht bestätigt", pille));
    if (!p.bestaetigt && p.link) zeilen.push(vpZeile(vpIco("📨", "#E6DDCF"), "Link noch einmal schicken", null, null, () => vpTeilen(p.name, p.link)));
    zeilen.push(vpZeile(vpIco("✕", "#FFB39B"), VP.wegKlick === p.id ? (p.bestaetigt ? `Sicher? ${p.name} erfährt es` : "Sicher?") : "Entfernen", null, null, () => {
      if (VP.wegKlick !== p.id) { VP.wegKlick = p.id; return vpZeichnen(); }   // zweimal tippen statt confirm() (geht in der App nicht)
      VP.wegKlick = null; vpAnfrage("DELETE", "/v1/begleitung/person/" + p.id); vpZeichnen();
    }));
  });
  if (!st.personen.length){   // john 09.11. 10:38: in der App eine Vertrauensperson (der Server könnte mehr)
    const f = vpKarte(); f.classList.add("vp-form");
    f.append(el("p", "vp-klein", "Jemand, der dich mag und ehrlich nachfragt: Partnerin, Freund, Mentor, Kleingruppe."),
      vpFeld("vpPName", "Vorname der Person"),
      vpKnopf("Einladen", "haupt vp-breit", () => {
        if (!vpWert("vpPName")) { VP.fehler = "Bitte einen Namen eintragen."; return vpZeichnen(); }
        const r = vpAnfrage("POST", "/v1/begleitung/person", {name:vpWert("vpPName")});
        if (r) { VP.neuLink = {name:vpWert("vpPName"), link:r.link}; vpTeilen(VP.neuLink.name, r.link); }
        vpZeichnen();
      }));
    teile.push(vpGruppe("Wen lädst du ein?", f));
  } else teile.push(vpGruppe("Meine Vertrauensperson", vpKarte(...zeilen)));
  const v = st.verlauf, offen = v.filter(x => x.alarm && !x.geklaert).length;
  const vz = vpZeile(vpIco("🕓", "#FFB39B"), "Verlauf", v.length ? `${v.length} Meldungen${offen ? ` · ${offen} offen` : ""}` : "Noch nichts passiert", null, v.length ? () => { VP.verlauf = !VP.verlauf; vpZeichnen(); } : null);
  const liste = [vz];
  if (VP.verlauf) v.slice(0, 30).forEach(x => {
    const z = el("div", "vp-zeile" + (x.alarm ? " vp-alarm" : ""));
    z.append(el("span", null, x.text), el("small", null, vpZeit(x.zeit) + (x.geklaert ? ` · geklärt${x.von ? " mit " + x.von : ""}` : x.alarm ? " · offen" : "")));
    liste.push(z);
  });
  liste.push(vpZeile(vpIco("🗑", "#FFB39B"), VP.wegKlick === "alles" ? "Sicher? Alles weg, deine Vertrauensperson erfährt es" : "Funktion ganz löschen", VP.wegKlick === "alles" ? "Eine offene Sperre auf anderen Geräten bleibt bis zu ihrem Ende" : null, null, () => {
    if (VP.wegKlick !== "alles") { VP.wegKlick = "alles"; return vpZeichnen(); }
    VP.wegKlick = null; vpAnfrage("DELETE", "/v1/begleitung"); vpZeichnen();
  }));
  teile.push(vpGruppe("Mehr", vpKarte(...liste)));
  return teile;
}

function vpBegleiter(){
  const zeilen = [];
  let codes = []; try { codes = JSON.parse(CockpitApp.begleiterCodes()); } catch {}
  codes.forEach(code => {
    const st = vpAnfrage("GET", "/v1/begleiter", null, code);
    if (!st) { zeilen.push(vpZeile(vpIco("📡", "#FFB39B"), "Gerade nicht erreichbar")); return; }
    const offen = st.meldungen.filter(m => m.alarm && !m.geklaert);
    const pille = el("span", offen.length ? "vp-wartet" : "vp-ok", offen.length ? `${offen.length} offen` : "alles ruhig");
    zeilen.push(vpZeile(vpIco(st.name.slice(0, 1).toUpperCase(), offen.length ? "#FFB39B" : "#D9CBB6"), st.name, "Zuletzt gesehen: " + (vpZeit(st.zuletzt) || "noch nie"), pille));
    // john 09.11.: Ohne Internet abgeschaltet und gelöscht kann keine Meldung mehr kommen. Das erfährt die Vertrauensperson ehrlich hier, nicht der Schützling.
    const still = st.zuletzt ? Math.floor((Date.now() - Date.parse(st.zuletzt)) / 86400000) : 0;
    if (still >= 3) zeilen.push(el("p", "vp-klein vp-wartet vp-hinweis", `Seit ${still} Tagen kein Lebenszeichen von ${st.name}s BlockEm. Oft ist es nur ein leerer Akku oder Urlaub. Es kann aber auch heißen, dass BlockEm ohne Internet abgeschaltet oder gelöscht wurde, dann kann keine Meldung mehr kommen. Frag ruhig mal nach.`));
    if (st.pin) zeilen.push(el("p", "vp-klein vp-hinweis", `Deinstallier-PIN von ${st.name}: ${st.pin.slice(0, 5)}-${st.pin.slice(5)}. Nur du kennst sie. Gib sie erst, wenn ihr gesprochen habt und du einverstanden bist. Mit ihr geht der Schutz nach 1 Std aus statt nach 48. Sie gilt einmal, danach steht hier eine neue.`));
    offen.forEach(m => {
      const z = el("div", "vp-zeile vp-alarm");
      z.append(el("span", null, m.text), el("small", null, vpZeit(m.zeit)),
        vpKnopf("Geklärt, wir haben gesprochen", "ghost small", () => { vpAnfrage("POST", "/v1/begleiter/klaeren", {id:m.id}, code); vpZeichnen(); }));
      zeilen.push(z);
    });
    zeilen.push(vpZeile(vpIco("✕", "#FFB39B"), VP.wegKlick === code ? "Sicher? Dann bekommst du nichts mehr" : "Nicht mehr begleiten", null, null, () => {
      if (VP.wegKlick !== code) { VP.wegKlick = code; return vpZeichnen(); }
      VP.wegKlick = null; CockpitApp.begleiterCode(code, false); vpZeichnen();
    }));
  });
  // Code-Eingabe eingeklappt hinter einer Zeile, damit das Blatt ohne Begleiter-Rolle ruhig bleibt
  zeilen.push(vpZeile(vpIco("🔑", "#E6DDCF"), codes.length ? "Noch jemanden begleiten" : "Jemand hat dich gebeten?", "Begleiter-Code von der Zusage-Seite eingeben", null, () => { VP.code = !VP.code; vpZeichnen(); }));
  if (VP.code){
    const f = el("div", "vp-form vp-form-in");
    f.append(vpFeld("vpCode", "Begleiter-Code, z. B. ABCDE-FGH23"),
      vpKnopf("Hinzufügen", "haupt vp-breit", () => { const fe = CockpitApp.begleiterCode(vpWert("vpCode"), true); if (fe) VP.fehler = fe; else VP.code = false; vpZeichnen(); }));
    zeilen.push(f);
  }
  return [vpGruppe("Ich begleite jemanden", vpKarte(...zeilen))];
}

function vpZeichnen(){
  const d = $("vpDialog"); if (!d) return;
  const zu = vpKnopf("×", "ka-zu", () => d.close()); zu.setAttribute("aria-label", "Schließen");
  const teile = [el("div", "mb-griff"), zu, el("h2", null, "Vertrauensperson")];
  const vorher = VP.fehler; VP.fehler = "";   // Fehler aus dem letzten Klick zeigen, dann vergessen
  const inhalt = [...vpEigene(), ...vpBegleiter()];
  const f = vorher || VP.fehler; VP.fehler = "";
  if (f) teile.push(vpFehlerZeile(f));
  d.replaceChildren(...teile, ...inhalt);
}

// Plan B (john 09.11.2026, neu 10:38): Begleitung mit dem BlockEm-Sync-Konto verbinden, damit Laptop/PC mitsperren (server.py sync_begleitung_koppeln).
// Ohne Begleitung (neu installiert oder nie eingerichtet) holt das Handy über das Konto den Schlüssel zur alten oder einer stillen Begleitung.
// So meldet auch die Play-Fassung ohne Vertrauensperson das Abschalten, und Neuinstallieren löscht keine offene Sperre. Ohne Konto passiert nichts.
async function vpKonto(sofort){
  if (!window.CockpitApp?.begToken) return;
  if (!sofort && Date.now() - (store("vp.konto") || 0) < 6 * 3600000) return;
  try {
    const play = !!CockpitApp.play?.();
    if (!CockpitApp.begAn()){
      const h = await api("api/begleitung-konto", {holen:true, play});
      if (!h?.token || !CockpitApp.begTokenSetzen?.(h.token)) return;
      const st = vpAnfrage("GET", "/v1/begleitung"); if (st) { CockpitApp.begPerson?.(st.personen.some(p => p.bestaetigt)); store("vp.person", st.personen.length > 0); }
    }
    const r = await api("api/begleitung-konto", {begleitung:CockpitApp.begToken(), play});
    if (r?.ok) store("vp.konto", Date.now());
  } catch {}
}

// Angebot später statt Pflicht in der Einrichtung (john 09.11. 10:38): Karte auf „Heute“ ab Tag 3, „Später“ geht,
// ein Mal nach 7 Tagen wieder, dann nie mehr von selbst. Danach nur noch über Mehr › Vertrauensperson.
function vpAngebot(){
  const n = $("notice"); if (!n || $("vpAngebot") || store("vp.person")) return;
  if (typeof stFertig === "function" && !stFertig()) return;
  const jetzt = Date.now(), seit = store("vp.seit") || (store("vp.seit", jetzt), jetzt), a = store("vp.angebot") || {n:0, ab:0};
  if (jetzt - seit < 2 * 864e5 || a.n >= 2 || jetzt < a.ab) return;   // Tag 3 = 2 volle Tage nach dem ersten Start mit dieser Datei
  const k = el("div", "vp-karte vp-angebot"); k.id = "vpAngebot";
  const weg = () => k.remove();
  k.append(el("b", null, "🤝 Willst du jemanden dabeihaben?"),
    el("p", "vp-text", "Eine Vertrauensperson erfährt nur, wenn du den Schutz abschaltest. Nie, was du anschaust. Mit jemandem an der Seite hältst du leichter durch. Dauert 30 Sekunden."),
    (() => { const z = el("div", "vp-knoepfe");
      z.append(vpKnopf("Jemanden einladen", "haupt small", () => { store("vp.angebot", {n:2, ab:0}); weg(); vpOeffnen(); }),
        vpKnopf(a.n ? "Nein danke" : "Später", "ghost small", () => { store("vp.angebot", {n:a.n + 1, ab:jetzt + 7 * 864e5}); weg(); }));
      return z; })());
  n.after(k);
}

function vpOeffnen(){
  if (!window.CockpitApp?.begAnfrage) return;
  vpKonto();
  let d = $("vpDialog");
  if (!d){
    d = el("dialog", "mehr-blatt modern ka-blatt vp-blatt"); d.id = "vpDialog"; d.setAttribute("aria-label", "Vertrauensperson");
    d.addEventListener("click", e => { if (e.target === d) d.close(); });
    d.addEventListener("close", () => { VP.neuLink = null; VP.wegKlick = null; VP.verlauf = false; VP.code = false; });
    document.body.append(d);
  }
  vpZeichnen();
  if (!d.open) d.showModal();
}

// „Mehr“: eine Zeile „Vertrauensperson“ (wie kasse.js über einen Beobachter)
function vpMehrZeile(){
  const d = $("mehrDialog"), liste = d?.querySelector(".mb-liste");
  if (!liste || liste.querySelector(".vp-zeile-mehr")) return;
  const b = el("button", "mb-zeile vp-zeile-mehr"); b.type = "button";
  const i = el("span", "mb-icon"); i.textContent = "🤝";
  const t = el("span", "mb-text"); t.append(el("b", null, "Vertrauensperson"), el("small", null, store("vp.person") ? "Verlauf, begleiten" : "Macht den Schutz viel stärker"));
  b.append(i, t); b.addEventListener("click", () => { d.close(); vpOeffnen(); });
  liste.append(b);
}
function vpMehrBeobachten(){
  const d = $("mehrDialog"); if (!d || d.dataset.vp) return false;
  d.dataset.vp = "1"; new MutationObserver(vpMehrZeile).observe(d, {childList:true}); vpMehrZeile(); return true;
}
if (window.CockpitApp?.begAnfrage){
  setTimeout(() => vpKonto(), 8000);   // nach dem Start, wenn Python im Handy bereit ist
  setTimeout(vpAngebot, 3000);
  if (!vpMehrBeobachten()){ const mo = new MutationObserver(() => { if (vpMehrBeobachten()) mo.disconnect(); }); mo.observe(document.body, {childList:true}); }
}

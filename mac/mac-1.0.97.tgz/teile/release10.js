/* ---------- Release 1.0 (03.11.2026, nach limits.js): Limit-Filter, Entfernen nach 24 Std., Nachfrage mit Listen und „Warum?“,
   Werte (Öffnungen, Gründe), Habits-Bereich mit Offline-Momenten und Tagesabschluss, Orts-Sperre, Onboarding in 10 Schritten; 1.0.1: Karte (Leaflet), Regulierung (App sperrt Übernutzung von allein).
   Baut auf tracking.js (TR, trLaden, trInnehalten, trLockerKarten), limits.js (LM, lmGruppen, lkOffen), locker.js (LK, lkAktion).
   Daten: GET /api/tracking (kategorien, warum, oeffnungen, orte, offline), POST /api/innehalten, /api/kategorien, /api/offline, /api/orte, /api/locker.
   CSS in release10.css. Alles nur in der Tracking-App (NUR_TRACKING). */
const R10 = {filter: store("cm.lmFilter") || "alle", offline: null, warumGruende: ["Langeweile", "Stress", "Gewohnheit", "Einsam", "Müde", "Aufschieben"], startHash: (typeof TR !== "undefined" && TR.startHash) || location.hash};
const r10Std = n => n >= 1.5 ? `${Math.round(n)} Std.` : "unter 1 Std.";
const r10Rest = ab => Math.max(0, (ab * 1000 - Date.now()) / 3600000);

if (typeof NUR_TRACKING !== "undefined" && NUR_TRACKING){

/* ===== 1. Limit-Menü: Filter Limits / Sperrzeiten / Apps, Entfernen erst nach 24 Std. ===== */
if (typeof lkOffen === "function" && typeof lmGruppen === "function"){
  const _lkOffen10 = lkOffen;
  lkOffen = function(d){
    const out = _lkOffen10.call(this, d), ent = d.entfernen || {}, sofort = d.sofort;
    if (CM.tab === "frei"){
      // „App Locker ausschalten“ geht immer, wirkt nach 24 Std.; läuft es schon, Abbrechen anbieten
      const unten = out.find(x => x.classList?.contains("lk-unten")), an = unten && [...unten.querySelectorAll("button")].find(b => /App Locker ausschalten/.test(b.deText));
      if (an && !sofort){
        const neu = an.cloneNode(true); an.replaceWith(neu); neu.disabled = false; neu.title = "";
        if (ent._an){ neu.textContent = `Ausschalten abbrechen (wirkt in ${r10Std(r10Rest(ent._an))})`; neu.addEventListener("click", () => lkAktion({an:true})); }
        else { neu.textContent = "App Locker ausschalten (nach 24 Std.)"; neu.addEventListener("click", () => lkAktion({an:false})); }
      }
      return out;
    }
    const box = out.find(x => x.classList?.contains("lm-liste")); if (!box) return out;
    const gruppen = lmGruppen(d.regeln), filter = R10.filter;
    const passt = g => filter === "limits" ? g.regeln.some(r => r.art !== "zeit") : filter === "zeiten" ? g.regeln.some(r => r.art === "zeit") : true;
    if (gruppen.length){
      box.replaceChildren();
      gruppen.filter(passt).forEach(g => {
        box.append(lmKarte(g));
        const weg = g.regeln.filter(r => ent[r.id]);
        if (weg.length){
          const z = el("div","r10-weg"), ab = Math.max(...weg.map(r => ent[r.id]));
          const b = el("button","ghost small","Behalten"); b.type = "button"; b.addEventListener("click", async () => { for (const r of weg){ await lkAktion({loeschenAbbrechen:r.id}); } });
          z.append(el("span", null, `${weg.length === g.regeln.length ? "Wird" : weg.length + " von " + g.regeln.length + " Regeln werden"} in ${r10Std(r10Rest(ab))} entfernt, gilt bis dahin weiter.`), b);
          box.append(z);
        }
      });
      if (!gruppen.some(passt)) box.append(el("p","cm-leer", filter === "zeiten" ? "Noch keine Sperrzeit. Tippe eine App an und füge unter „Sperrzeit“ eine Zeit hinzu." : "Noch kein Limit. Tippe eine App an und schalte Pro Tag, Öffnen oder Am Stück an."));
      const leiste = el("div","chips r10-filter"); leiste.setAttribute("role","group"); leiste.setAttribute("aria-label","Filter");
      [["alle","Apps"],["limits","Limits"],["zeiten","Sperrzeiten"]].forEach(([k, t]) => { const b = el("button","chip small", t); b.type = "button"; b.setAttribute("aria-pressed", String(filter === k));
        b.addEventListener("click", () => { R10.filter = k; store("cm.lmFilter", k); renderLocker(true); }); leiste.append(b); });
      box.before(leiste); out.splice(out.indexOf(box), 0, leiste);
    }
    return out;
  };
  // Entfernen braucht keinen Timer mehr (dafür 24 Std. Wartezeit); das Fenster sagt es dazu
  lmLockert = function(p){
    if (p.loeschen) return false; if (!p.alt) return false;
    const merk = {art:LK.art, apps:LK.apps, tage:LK.tage, geraete:LK.geraete, von:LK.von, bis:LK.bis, min:LK.min, pause:LK.pause}, r = p.regel;
    Object.assign(LK, {art:r.art, apps:new Set(r.apps), tage:new Set(r.tage), geraete:new Set(r.geraete), von:r.von || "", bis:r.bis || "", min:String(r.anzahl ?? r.minuten ?? ""), pause:String(r.pause ?? "")});
    try { return !lkStrenger(p.alt); } finally { Object.assign(LK, merk); }
  };
  const _lmHinweis10 = lmHinweis;
  lmHinweis = function(){
    _lmHinweis10.apply(this, arguments);
    const box = $("lmHinweis"); if (!box || !LM.e || LK.daten?.sofort) return;
    if (lmPlan().some(p => p.loeschen) && !$("lmOk")?.disabled) box.append(el("span","lm-klein","Ausgeschaltete Regeln gelten noch 24 Std. weiter, dann sind sie weg."));
  };
  const _lmZeichnen10 = lmZeichnen;
  lmZeichnen = function(){
    _lmZeichnen10.apply(this, arguments);
    const del = $("lmDialog")?.querySelector(".lm-loeschen"); if (!del || !LM.e || LM.e.neu) return;
    if (!LK.daten?.sofort) del.textContent = "Alle Limits dieser App entfernen (nach 24 Std.)";
    if (del.disabled){ del.disabled = false; del.title = ""; lkZweimal(del, "Wirklich? Sie gelten noch 24 Std.", lmAllesLoeschen); }
  };
}

/* ===== 2. Nachfrage „Brauchst du das gerade wirklich?“: Listen Social Media + Streaming, eigene Apps, „Warum?“ ===== */
if (typeof trInnehaltenKarte === "function"){
  trInnehaltenKarte = function(x){
    const k = el("section","hud tr-karte"), kopf = el("div","tr-karte-kopf"), kat = TR.daten?.kategorien || {social:[], streaming:[]};
    const speichern = async body => { try { const r = await api("api/innehalten", body); TR.daten.innehalten = r.innehalten; setTimeout(() => trLockerKarten(true), 250); toast("Gespeichert."); } catch (e){ toast(e.message || String(e)); return false; } };
    kopf.append(el("span","tr-ico","✋"), el("div", null), trSchalter(x.an, v => speichern({an:v}), "Nachfrage an oder aus"));
    kopf.children[1].append(el("b", null, "Nachfrage"), el("span","k-s","„Brauchst du das gerade wirklich?“ Eine kurze Pause vor Social Media und Streaming, auch in erlaubten Zeiten."));
    k.append(kopf);
    if (!x.an){ k.append(el("p","k-s","Aus. Schalte es ein, dann kommt vor Instagram, TikTok, YouTube und Co. eine kurze Pause.")); return k; }
    const zeile = (titel, ...inh) => { const z = el("label","tr-zeile"); z.append(el("span","k-s", titel), ...inh); return z; };
    const listen = x.kategorien !== false;
    const ls = el("div","tr-zeile r10-listen"); ls.append(el("span","k-s","Listen Social Media und Streaming"), trSchalter(listen, v => speichern({kategorien:v}), "Listen mitnehmen"));
    const social = el("input"); social.value = (kat.social || []).join(", "); social.setAttribute("aria-label","Social Media, mit Komma getrennt");
    const stream = el("input"); stream.value = (kat.streaming || []).join(", "); stream.setAttribute("aria-label","Streaming, mit Komma getrennt");
    const apps = el("input"); apps.value = (x.apps || []).join(", "); apps.placeholder = "z. B. reddit.com, Telegram"; apps.setAttribute("aria-label","Weitere Apps und Seiten");
    const sek = el("input"); sek.type = "number"; sek.min = "3"; sek.max = "120"; sek.value = x.sekunden || 10; sek.setAttribute("aria-label","Sekunden Pause");
    const text = el("textarea"); text.rows = 2; text.value = x.text || ""; text.setAttribute("aria-label","Dein Satz in der Pause");
    const vorl = el("div","chips");
    (typeof TR_VORLAGEN !== "undefined" ? TR_VORLAGEN : []).forEach(([n, t]) => { const b = el("button","chip small", n); b.type = "button"; b.addEventListener("click", () => { text.value = t; }); vorl.append(b); });
    const teilen = v => v.split(",").map(s => s.trim()).filter(Boolean);
    const ok = el("button","ask small","Speichern"); ok.type = "button";
    ok.addEventListener("click", async () => {
      try { const r = await api("api/kategorien", {social:teilen(social.value), streaming:teilen(stream.value)}); TR.daten.kategorien = r.kategorien; } catch (e){ toast(e.message || String(e)); return; }
      await speichern({apps:teilen(apps.value), sekunden:Number(sek.value), text:text.value});
      if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {});
    });
    const test = el("button","ghost small","Ausprobieren"); test.type = "button"; test.addEventListener("click", () => trInnehalten("Instagram", "", {...x, text:text.value, sekunden:Number(sek.value)}));
    const kn = el("div","lk-knoepfe"); kn.append(ok, test);
    k.append(ls);
    if (listen) k.append(zeile("Social Media", social), zeile("Streaming", stream));
    k.append(zeile("Weitere Apps und Seiten", apps), zeile("Pause in Sekunden", sek), zeile("Dein Satz in der Pause", text), vorl, kn);
    return k;
  };
}
// „Lieber nicht“ → „Warum wolltest du drauf?“ (zählt in Werte)
if (typeof trInnehalten === "function"){
  const _trInnehalten10 = trInnehalten;
  trInnehalten = function(w, u, x){
    _trInnehalten10.call(this, w, u, x);
    const d = $("trPause"), alt = d?.querySelector("button.ask"); if (!alt) return;
    const nein = alt.cloneNode(true); alt.replaceWith(nein);
    const zu = () => { d.close(); try { history.replaceState(null, "", "#heute"); } catch {} showTab("heute"); };
    nein.addEventListener("click", () => {
      const chips = el("div","chips r10-warum"), gruende = TR.daten?.warum?.vorgaben || R10.warumGruende;
      gruende.forEach(g => { const b = el("button","chip", g); b.type = "button";
        b.addEventListener("click", async () => { try { const r = await api("api/innehalten", {warum:g, app:w}); if (TR.daten) TR.daten.warum = r.warum; } catch {} zu(); toast("Stark. Bleib dran."); }); chips.append(b); });
      const weiter = el("button","ghost","Überspringen"); weiter.type = "button"; weiter.addEventListener("click", () => { zu(); toast("Stark. Bleib dran."); });
      const kn = el("div","tr-pause-knoepfe"); kn.append(weiter);
      d.replaceChildren(el("span","tr-klein","Stark."), el("h2", null, "Warum wolltest du drauf?"), el("p","tr-pause-text","Ein Tipp reicht. Daraus siehst du in Werte, was dich ans Handy zieht."), chips, kn);
    });
  };
}
// Schutz-Karte: Beta-Satz raus (1.0: Ausschalten nur nach dem Timer)
if (typeof trSchutzKarte === "function"){
  const _trSchutz10 = trSchutzKarte;
  trSchutzKarte = function(x){
    const k = _trSchutz10.call(this, x), s = k.querySelector(".tr-karte-kopf .k-s");
    if (s && /^Beta:/.test(s.textContent)) s.textContent = "Strenger geht sofort, lockern nur nach einer Wartezeit. Die Sperre für Erwachsenen-Seiten bleibt immer an.";
    return k;
  };
}
// Antworten, die das Handy ohne Verbindung gesammelt hat, nachtragen
async function r10WarumSync(){
  const A = window.CockpitApp; if (!A?.warumHolen) return;
  let liste = []; try { liste = JSON.parse(A.warumHolen() || "[]"); } catch { return; }
  if (!liste.length) return;
  try { const r = await api("api/innehalten", {warumListe:liste.map(e => ({warum:e.grund, app:e.app, zeit:e.zeit}))}); if (TR.daten) TR.daten.warum = r.warum; A.warumLeeren(); } catch {}
}
setTimeout(r10WarumSync, 2500);

/* ===== 3. Werte: Öffnungen je App (wie oft, Ø Dauer) und die Gründe aus „Warum?“ ===== */
function r10Dauer(sek){ sek = Math.round(sek || 0); return sek < 60 ? `${sek} s` : `${Math.floor(sek / 60)}:${String(sek % 60).padStart(2, "0")} Min`; }
function r10WerteZeichnen(){
  const tab = document.querySelector('.tab[data-r="werte"]'); if (!tab || !TR.daten) return;
  let sec = $("r10Werte");
  if (!sec){ sec = el("section","hud r10-werte"); sec.id = "r10Werte"; sec.setAttribute("aria-labelledby","hOe"); tab.append(sec); }
  // 1.0.48 (john 08.11.): nur noch heute, ohne Umschalter Heute/7 Tage und ohne „Warum du nicht drauf bist“
  const oe = TR.daten.oeffnungen || {}, zeitraum = "heute";
  const kopf = el("div","r10-kopf"), h = el("h2", null, "Öffnungen heute"); h.id = "hOe";
  kopf.append(h, el("span","k-s","wie oft · Ø pro Mal"));
  const g = typeof r10GeraetDaten === "function" ? r10GeraetDaten() : null, tab2 = el("div","r10-tabelle");
  let liste = (oe[zeitraum] || []).slice(0, 12);
  if (g && zeitraum === "heute") liste = (g.apps || []).filter(a => a.oeffnen && !/launcher|^com\.|^org\.|cockpit|blockem|clear mind/i.test(a.name)).sort((a, b) => b.oeffnen - a.oeffnen).slice(0, 12);
  if (!liste.length) tab2.append(el("p","k-s","Noch keine Öffnungen gezählt. Sobald " + (typeof beNurHandy === "function" && beNurHandy() ? "BlockEm ein paar Stunden mitgezählt hat" : "deine Geräte Daten liefern") + ", steht hier, wie oft jede App aufging und wie lang im Schnitt."));
  liste.forEach(e => { const z = el("div","r10-zeile" + (e.kat === "prokrastination" ? " abl" : "")); z.append(el("span","r10-name", e.name), el("b", null, `${e.oeffnen}×`), el("span","r10-dauer", `Ø ${r10Dauer(e.proOeffnung)}`)); tab2.append(z); });
  sec.replaceChildren(kopf, tab2);
}
if (typeof trLaden === "function"){
  const _trLaden10 = trLaden;
  trLaden = async function(){ const d = await _trLaden10.apply(this, arguments); if (d){ if (typeof r10WerteGeraetLeiste === "function") r10WerteGeraetLeiste(); r10WerteZeichnen(); } return d; };
  document.querySelector('#reiter button[data-r="werte"]')?.addEventListener("click", () => trLaden());
}

/* ===== 7. Werte je Gerät (1.0.2, john 04.11.): Chips Alle / Mac / Handys über den Tageswerten; Tagesverlauf, Liste und Öffnungen folgen ===== */
R10.geraet = store("cm.werteGeraet") || "alle";
function r10GeraetDaten(){ const d = S.day; if (!d || R10.geraet === "alle") return null; return (d.geraete || []).find(g => g.name === R10.geraet) || null; }
function r10WerteGeraetLeiste(){
  const sec = document.querySelector('.tab[data-r="werte"] section[aria-labelledby="hDay"]'); if (!sec) return;
  let box = $("r10GerLeiste"); if (!box){ box = el("div","chips r10-gerleiste"); box.id = "r10GerLeiste"; box.setAttribute("role","group"); box.setAttribute("aria-label","Gerät"); sec.querySelector("h2")?.after(box); }
  const namen = [...new Set([...(S.day?.geraete || []).map(g => g.name), ...(TR.daten?.geraete || [])])];
  if (R10.geraet !== "alle" && !namen.includes(R10.geraet)) R10.geraet = "alle";
  box.replaceChildren(); box.hidden = namen.length < 2; if (box.hidden) return;
  [["alle","Alle Geräte"], ...namen.map(n => [n, n])].forEach(([k, t]) => { const b = el("button","chip small", t); b.type = "button"; b.setAttribute("aria-pressed", String(R10.geraet === k));
    b.addEventListener("click", () => { R10.geraet = k; store("cm.werteGeraet", k); renderDay(); r10WerteZeichnen(); }); box.append(b); });
}
function r10WerteGeraetAnwenden(){
  const d = S.day; if (!d) return; const g = r10GeraetDaten();
  const sec = document.querySelector('.tab[data-r="werte"] section[aria-labelledby="hDay"]'), lbl = $("tAway")?.parentElement?.querySelector(".lbl");
  sec?.querySelectorAll(".meter").forEach(m => m.hidden = !!g);   // Ziel und Budget gelten für alle Geräte zusammen
  if (!g && R10.geraet !== "alle"){ ["tProd","tProk","tAway"].forEach(id => { const e = $(id); if (e) e.textContent = "0 Min"; }); if (lbl) lbl.textContent = "Bildschirm"; $("hours")?.replaceChildren(); r10GeraeteListe(R10.geraet); return; }
  if (!g){ if (lbl) lbl.textContent = typeof beAway === "function" ? beAway() : "Nicht am PC"; r10GeraeteListe(null); return; }
  $("tProd").textContent = minText(g.produktiv || 0); $("tProk").textContent = minText(g.prokrastination || 0);
  if (lbl) lbl.textContent = "Bildschirm"; $("tAway").textContent = minText(g.sek || 0);
  const box = $("hours"); if (box && g.stunden){ box.replaceChildren(); const colors = ["var(--good)","var(--neutral)","var(--bad)","var(--away)"], names = ["Produktiv","Neutral","Prokrastination",""];
    g.stunden.forEach((h, i) => { const st = el("div","stack" + (d.date === TODAY && i === NOW.getHours() ? " now" : "")); st.title = `${pad(i)}:00 – ` + (h.map((v, k) => v && names[k] ? `${names[k]} ${minText(v)}` : "").filter(Boolean).join(", ") || "keine Daten");
      h.forEach((v, k) => { if (v > 0 && k < 3){ const seg = el("i"); seg.style.height = Math.min(100, v / 36) + "%"; seg.style.background = colors[k]; st.append(seg); } }); box.append(st); }); }
  r10GeraeteListe(g.name);
}
function r10GeraeteListe(name){ document.querySelectorAll("#apps details.dev").forEach(det => { const n = det.querySelector("summary b")?.deText; det.hidden = !!name && n !== name; if (name && n === name) det.open = true; }); }
if (typeof renderDay === "function"){ const _renderDay10 = renderDay; renderDay = function(){ const r = _renderDay10.apply(this, arguments); r10WerteGeraetLeiste(); r10WerteGeraetAnwenden(); return r; }; }
if (typeof renderDevices === "function"){ const _renderDevices10 = renderDevices; renderDevices = function(){ const r = _renderDevices10.apply(this, arguments);
  document.querySelectorAll("#apps .app-w").forEach(w => { const n = w.querySelector(".n")?.firstChild?.deText || ""; if (/launcher|^com\.|^org\.|^android/i.test(n)) w.remove(); });   // Launcher und Paketnamen ohne Label raus
  r10GeraeteListe(r10GeraetDaten()?.name || null); return r; }; }

/* ===== 4. Habits-Bereich: eigene Gewohnheiten, Offline-Momente, Frage nach Offline-Zeit, Tagesabschluss ===== */
if (typeof MEHR_REITER !== "undefined" && !MEHR_REITER.some(r => r[0] === "habits")) MEHR_REITER.unshift(["habits", "Habits", "Offline-Momente, eigene Gewohnheiten, Tagesabschluss"]);
function r10Serie(tage){
  const s = new Set(tage || []), d = new Date(); let n = 0;
  const iso = x => `${x.getFullYear()}-${String(x.getMonth() + 1).padStart(2, "0")}-${String(x.getDate()).padStart(2, "0")}`;
  if (!s.has(iso(d))) d.setDate(d.getDate() - 1);
  while (s.has(iso(d)) && n < 400){ n++; d.setDate(d.getDate() - 1); }
  return n;
}
async function r10Offline(body){
  try { R10.offline = body ? await api("api/offline", body) : await api("api/offline"); if (TR.daten) TR.daten.offline = R10.offline; }
  catch (e){ toast(e.message || String(e)); }
  return R10.offline;
}
async function r10HabitsZeichnen(){
  const tab = document.querySelector('.tab[data-r="habits"]'); if (!tab) return;
  let box = $("r10Habits");
  if (!box){ box = el("div","r10-habits"); box.id = "r10Habits"; [...tab.children].forEach(c => c.hidden = true); tab.append(box); }
  const d = R10.offline || await r10Offline(); if (!d){ box.replaceChildren(el("p","k-s","Keine Verbindung.")); return; }
  const heute = new Date().toISOString().slice(0, 10), A = window.CockpitApp;
  const kopf = el("section","hud tr-karte r10-hkopf");
  kopf.append(el("b", null, "Habits"), el("span","k-s","Keine Vorgaben. Warst du länger offline, fragt die App, was du gemacht hast. So entstehen deine Gewohnheiten."));
  const stat = el("div","r10-stat"); stat.append(el("b", null, d.heuteMin ? minText(d.heuteMin * 60) : "0 Min"), el("span","k-s","heute bewusst offline"));
  kopf.append(stat);
  // Habits
  const hl = el("section","hud tr-karte"), ul = el("div","r10-hliste");
  hl.append(el("b", null, "Deine Habits"));
  (d.habits || []).forEach(h => {
    const z = el("div","r10-habit" + ((h.tage || []).includes(heute) ? " an" : "")), serie = r10Serie(h.tage);
    const hak = el("button","r10-hak", (h.tage || []).includes(heute) ? "✓" : ""); hak.type = "button"; hak.setAttribute("aria-label", `${h.name} heute erledigt`);
    hak.addEventListener("click", async () => { await r10Offline({habitErledigt:{id:h.id, an:!(h.tage || []).includes(heute)}}); r10HabitsZeichnen(); });
    const t = el("div","r10-htext"); t.append(el("b", null, h.name), el("span","k-s", serie >= 2 ? `${serie} Tage in Folge` : (h.tage || []).length ? `${(h.tage || []).length}× bisher` : `seit ${h.seit}`));
    const x = el("button","ghost small","✕"); x.type = "button"; x.setAttribute("aria-label", `${h.name} entfernen`);
    lkZweimal(x, "Wirklich?", async () => { await r10Offline({habitWeg:h.id}); r10HabitsZeichnen(); });
    z.append(hak, t, x); ul.append(z);
  });
  if (!(d.habits || []).length) ul.append(el("p","k-s","Noch keiner. Schreib unten auf, was dir offline guttut, zum Beispiel Lesen, Sport oder Draußen."));
  const neu = el("div","r10-neu"), inp = el("input"), plus = el("button","ask small","＋ Habit"); plus.type = "button"; inp.placeholder = "Neuer Habit, z. B. Lesen"; inp.maxLength = 60; inp.setAttribute("aria-label","Neuer Habit");
  const dazu = async () => { const n = inp.value.trim(); if (n.length < 2) return; inp.value = ""; await r10Offline({habit:{name:n}}); r10HabitsZeichnen(); };
  plus.addEventListener("click", dazu); inp.addEventListener("keydown", ev => { if (ev.key === "Enter"){ ev.preventDefault(); dazu(); } });
  neu.append(inp, plus); hl.append(ul, neu);
  // Offline-Momente
  const mo = el("section","hud tr-karte"); mo.append(el("b", null, "Offline-Momente"));
  const ml = el("div","r10-momente"), momente = [...(d.momente || [])].reverse().slice(0, 10);
  if (!momente.length) ml.append(el("p","k-s", "Noch keiner. Trag ein, was du ohne Handy gemacht hast."));
  momente.forEach(m => { const z = el("div","r10-moment"); z.append(el("span","k-s", `${m.tag === heute ? "Heute" : m.tag.slice(8, 10) + "." + m.tag.slice(5, 7) + "."} ${m.zeit} · ${m.min} Min`), el("b", null, m.text || "ohne Notiz")); ml.append(z); });
  const selbst = el("button","ghost small","Moment eintragen"); selbst.type = "button"; selbst.addEventListener("click", () => r10OfflineDialog({min:60, von:""}));
  mo.append(ml, selbst);
  // Einstellungen
  const es = el("section","hud tr-karte r10-einst"), f = d.frage || {}, ab = d.abschluss || {};
  es.append(el("b", null, "Tagesabschluss"));
  const z2 = el("div","tr-zeile r10-listen"); z2.append(el("span","k-s","Abends eine Mitteilung: kurzer Tagesabschluss"), trSchalter(!!ab.an, v => r10Offline({abschluss:{an:v}}).then(r10HabitsZeichnen).then(() => typeof vbSperreAbgleich === "function" && vbSperreAbgleich().catch(() => {})), "Tagesabschluss an oder aus"));
  es.append(z2);
  if (ab.an){
    const zt = el("input"); zt.type = "time"; zt.value = ab.zeit || "21:30"; zt.setAttribute("aria-label","Uhrzeit Tagesabschluss");
    zt.addEventListener("change", () => r10Offline({abschluss:{zeit:zt.value}}).then(() => typeof vbSperreAbgleich === "function" && vbSperreAbgleich().catch(() => {})));
    const jetzt = el("button","ghost small","Tagesabschluss jetzt"); jetzt.type = "button"; jetzt.addEventListener("click", r10AbschlussDialog);
    const zz = el("div","tr-zeile"); zz.append(el("span","k-s","Uhrzeit"), zt, jetzt); es.append(zz);
  }
  box.replaceChildren(kopf, hl, mo, es);
}
if (typeof showTab === "function"){
  const _showTab10 = showTab;
  showTab = function(r){
    if (r !== "habits") return _showTab10.apply(this, arguments);
    // tracking.js leitet Planungs-Reiter auf Heute um; Habits ist in 1.0 wieder ein eigener Bereich
    document.querySelectorAll(".tab").forEach(t => { const neu = t.hidden && t.dataset.r === r; t.hidden = t.dataset.r !== r; if (neu && typeof einblenden === "function") einblenden(t); });
    document.querySelectorAll("#reiter button").forEach(b => b.setAttribute("aria-selected", b.dataset.r === r));
    store("cockpit.reiter", r); try { if (location.hash !== "#habits") history.replaceState(history.state, "", "#habits"); } catch {}
    r10HabitsZeichnen();
  };
  if ((store("cockpit.reiter") || "") === "habits") setTimeout(r10HabitsZeichnen, 200);
}
// Offline-Moment selbst eintragen und Tagesabschluss (#abschluss)
function r10Dialog(id){ let d = $(id); if (!d){ d = el("dialog","tr-pause r10-dialog"); d.id = id; document.body.append(d); } return d; }
async function r10OfflineDialog(f){
  const d = r10Dialog("r10Offline"), daten = R10.offline || await r10Offline() || {habits:[]}, A = window.CockpitApp;
  const chips = el("div","chips r10-warum"), gewaehlt = new Set();
  (daten.habits || []).map(h => h.name).concat(["Lesen","Sport","Draußen","Freunde","Kochen","Lernen"].filter(n => !(daten.habits || []).some(h => h.name === n))).slice(0, 12)
    .forEach(n => { const b = el("button","chip", n); b.type = "button"; b.addEventListener("click", () => { gewaehlt.has(n) ? gewaehlt.delete(n) : gewaehlt.add(n); b.setAttribute("aria-pressed", String(gewaehlt.has(n))); }); chips.append(b); });
  const frei = el("input"); frei.placeholder = "oder eigene Worte"; frei.maxLength = 200; frei.setAttribute("aria-label","Was hast du gemacht?");
  const min = el("input"); min.type = "number"; min.min = "1"; min.max = "1440"; min.value = f.min || 45; min.setAttribute("aria-label","Minuten");
  const ok = el("button","ask","Speichern"), nix = el("button","ghost","Nichts Besonderes"); ok.type = nix.type = "button";
  const kn = el("div","tr-pause-knoepfe"); kn.append(nix, ok);
  const zeile = el("div","tr-zeile r10-listen"); zeile.append(el("span","k-s","Minuten offline"), min);
  d.replaceChildren(el("span","tr-klein","Offline-Moment"), el("h2", null, f.von ? `Du warst ${f.min} Min nicht am Handy.` : "Was hast du offline gemacht?"), el("p","tr-pause-text", f.von ? `Von ${f.von} bis ${f.bis}. Was hast du gemacht?` : "Ein Tipp reicht."), chips, frei, zeile, kn);
  if (!d.open) d.showModal();
  const fertig = () => d.close();
  nix.onclick = fertig;
  ok.onclick = async () => {
    const text = [...gewaehlt].concat(frei.value.trim() ? [frei.value.trim()] : []).join(", ");
    const heute = new Date().toISOString().slice(0, 10);
    await r10Offline({moment:{min:Number(min.value) || f.min || 45, text, von:f.von || ""}});
    for (const n of gewaehlt){ let h = (R10.offline?.habits || []).find(x => x.name === n); if (!h){ await r10Offline({habit:{name:n}}); h = (R10.offline?.habits || []).find(x => x.name === n); } if (h) await r10Offline({habitErledigt:{id:h.id, tag:heute, an:true}}); }
    fertig(); toast("Gespeichert. Das zählt."); if ($("r10Habits")) r10HabitsZeichnen();
  };
}
async function r10AbschlussDialog(){
  const d = r10Dialog("r10Abschluss"), daten = R10.offline || await r10Offline() || {habits:[]}, sum = S.day?.summe, heute = new Date().toISOString().slice(0, 10);
  const bild = sum ? (sum.produktiv || 0) + (sum.prokrastination || 0) + (sum.neutral || 0) : 0;
  const zahlen = el("div","r10-zahlen");
  [[bild ? minText(bild) : "–", "am Bildschirm"], [sum ? minText(sum.prokrastination || 0) : "–", "Ablenkung"], [daten.heuteMin ? `${daten.heuteMin} Min` : "0 Min", "bewusst offline"]]
    .forEach(([z, t]) => { const k = el("div"); k.append(el("b", null, z), el("span","k-s", t)); zahlen.append(k); });
  const chips = el("div","chips r10-warum");
  (daten.habits || []).forEach(h => { const an = (h.tage || []).includes(heute), b = el("button","chip", h.name); b.type = "button"; b.setAttribute("aria-pressed", String(an));
    b.addEventListener("click", async () => { const jetzt = b.getAttribute("aria-pressed") !== "true"; b.setAttribute("aria-pressed", String(jetzt)); await r10Offline({habitErledigt:{id:h.id, an:jetzt}}); }); chips.append(b); });
  const notiz = el("textarea"); notiz.rows = 2; notiz.placeholder = "Ein Satz zum Tag (optional)"; notiz.value = daten.tage?.[heute]?.text || ""; notiz.setAttribute("aria-label","Notiz zum Tag");
  const ok = el("button","ask","Fertig für heute"); ok.type = "button"; const kn = el("div","tr-pause-knoepfe"); kn.append(ok);
  d.replaceChildren(el("span","tr-klein","Tagesabschluss"), el("h2", null, "Wie war dein Tag?"), zahlen, el("p","tr-pause-text", (daten.habits || []).length ? "Was hast du heute geschafft?" : "Lege unter Habits fest, was dir offline guttut."), chips, notiz, kn);
  if (!d.open) d.showModal();
  ok.onclick = async () => { if (notiz.value.trim()) await r10Offline({tag:{text:notiz.value}}); d.close(); toast("Gute Nacht. Morgen ist ein neuer Tag."); };
}
function r10HashPruefen(){
  const h = R10.startHash || location.hash; R10.startHash = "";
  if (h === "#offline"){ try { history.replaceState(null, "", "#habits"); } catch {} }   // 17.11.: Offline-Frage raus (alte Mitteilungen öffnen nur Habits)
  else if (h === "#abschluss"){ try { history.replaceState(null, "", "#habits"); } catch {} r10AbschlussDialog(); }
  else if (h === "#einrichtung"){ try { history.replaceState(null, "", "#heute"); } catch {} ST.vorschau = true; ST.i = 0; ST.offen = false; stOeffnen(); }   // 1.0.1: Vorschau der Einrichtung, verstellt nichts
}
window.addEventListener("hashchange", r10HashPruefen);
setTimeout(r10HashPruefen, 400);

/* ===== 5. Orts-Sperre: Karte im Locker-Reiter (Gym, Arbeit, Uni: dort sind Social Media und Streaming zu) ===== */
function r10OrteKarte(){
  const k = el("section","hud tr-karte r10-orte"), kopf = el("div","tr-karte-kopf"), A = window.CockpitApp, orte = TR.daten?.orte || [];
  kopf.append(el("span","tr-ico","📍"), el("div", null));
  kopf.children[1].append(el("b", null, "Orts-Sperre"), el("span","k-s","Ist das Handy an einem dieser Orte, sind Social Media und Streaming ganz zu, egal welche Uhrzeit. Ohne Dauer-GPS, kaum Akku."));
  k.append(kopf);
  const speichern = async liste => { try { const r = await api("api/orte", {orte:liste}); TR.daten.orte = r.orte; toast("Gespeichert."); trLockerKarten(); if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {}); } catch (e){ toast(e.message || String(e)); } };
  const ul = el("div","r10-orteliste");
  orte.forEach((o, i) => { const z = el("div","r10-ort"), t = el("div"); t.append(el("b", null, o.name), el("span","k-s", `${o.radius} m · ${(o.kategorien || []).map(x => x === "social" ? "Social Media" : "Streaming").join(" + ")}`));
    const x = el("button","ghost small","✕"); x.type = "button"; x.setAttribute("aria-label", `${o.name} entfernen`); lkZweimal(x, "Wirklich?", () => speichern(orte.filter((_, j) => j !== i)));
    z.append(el("span","tr-ico", /gym|sport|fitness/i.test(o.name) ? "🏋️" : /arbeit|büro|office/i.test(o.name) ? "💼" : /uni|schule|hochschule/i.test(o.name) ? "🎓" : "📍"), t, x); ul.append(z); });
  if (!orte.length) ul.append(el("p","k-s","Noch kein Ort."));
  k.append(ul);
  // neuer Ort (1.0.37, john: „sieht maximal billig aus“): großer Knopf, darunter ein Formular in Schritten
  const auf = el("button","fs-ort-neu","＋ Ort hinzufügen"), form = el("div","fs-ort-form"); auf.type = "button"; form.hidden = true;
  const schritt = (n, t) => { const h = el("div","fs-schritt"); h.append(el("i", null, String(n)), el("span", null, t)); return h; };
  const name = el("input"); name.placeholder = "Oder eigener Name"; name.maxLength = 40; name.setAttribute("aria-label","Name des Orts");
  const vorsch = el("div","fs-namen"), VOR = [["Gym","🏋️"],["Arbeit","💼"],["Uni","🎓"],["Schule","🏫"]];
  const vZeichnen = () => vorsch.querySelectorAll("button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.n === name.value.trim())));
  VOR.forEach(([n, ic]) => { const b = el("button"); b.type = "button"; b.dataset.n = n; b.append(el("span", null, ic), n); b.addEventListener("click", () => { name.value = n; vZeichnen(); }); vorsch.append(b); });
  name.addEventListener("input", vZeichnen);
  let radius = 150; const rad = el("div","fs-seg");
  const radZeichnen = () => { rad.querySelectorAll("button").forEach(b => b.setAttribute("aria-pressed", String(+b.dataset.r === radius))); };
  [100, 150, 300, 500].forEach(m => { const b = el("button", null, `${m} m`); b.type = "button"; b.dataset.r = m; b.addEventListener("click", () => { radius = m; radZeichnen(); }); rad.append(b); }); radZeichnen();
  const kat = new Set(["social","streaming"]), kw = el("div","fs-seg");
  [["social","Social Media"],["streaming","Streaming"]].forEach(([x, t]) => { const b = el("button", null, t); b.type = "button"; b.setAttribute("aria-pressed","true"); b.addEventListener("click", () => { kat.has(x) ? (kat.size > 1 && kat.delete(x)) : kat.add(x); b.setAttribute("aria-pressed", String(kat.has(x))); }); kw.append(b); });
  const pos = {lat:null, lon:null}, posText = el("span","fs-pos","Tippe auf die Karte, such die Adresse oder nimm deinen Standort.");
  const gesetzt = () => { posText.textContent = "✓ Standort gesetzt"; posText.classList.add("ok"); };
  const karte = r10Karte(el("div"), pos, gesetzt);
  const hier = r10Hier(pos, (la, lo) => { pos.lat = la; pos.lon = lo; gesetzt(); if (karte._setz) karte._setz(la, lo, true); });
  hier.className = "fs-hier"; hier.textContent = "📍 Ich bin gerade hier";
  const ab = el("button","fs-ab","Abbrechen"), ok = el("button","fs-ok","Ort speichern"); ab.type = ok.type = "button";
  auf.addEventListener("click", () => { form.hidden = false; auf.hidden = true; if (karte._karte) setTimeout(() => karte._karte.invalidateSize(), 250); });
  ab.addEventListener("click", () => { form.hidden = true; auf.hidden = false; });
  ok.addEventListener("click", () => { if (!name.value.trim()) return toast("Bitte einen Namen wählen."); if (pos.lat == null) return toast("Erst den Standort setzen.");
    speichern([...orte, {name:name.value.trim(), lat:pos.lat, lon:pos.lon, radius, kategorien:[...kat]}]); });
  const kn = el("div","fs-ort-knoepfe"); kn.append(ab, ok);
  form.append(schritt(1, "Was für ein Ort?"), vorsch, name, schritt(2, "Wo ist er?"), r10Suche(karte, pos), karte, hier, posText,
    schritt(3, "Wie groß ist der Umkreis?"), rad, schritt(4, "Was ist dort zu?"), kw, kn);
  k.append(auf, form);
  if (A && A.standortStand && A.standortStand() !== "immer" && orte.length) k.append(el("p","k-s c-bad","Standort steht nicht auf „Immer erlauben“: die Orts-Sperre greift dann nur, solange die App offen ist. Android-Einstellungen › Apps › BlockEm › Standort."));
  return k;
}
if (typeof trLockerKarten === "function"){
  const _trLockerKarten10 = trLockerKarten;
  trLockerKarten = async function(){ await _trLockerKarten10.apply(this, arguments); const box = $("trLockerKarten"); if (box && !box.hidden && TR.daten && R10_ORTE()) box.append(r10OrteKarte()); };
}

/* ===== 5b. Karte (Leaflet + OpenStreetMap, nur bei Bedarf geladen) und Regulierung: die App sperrt, was messbar frisst ===== */
function r10Karte(box, pos, fn){
  const lade = () => new Promise((ok, nein) => { if (window.L) return ok(); const c = document.createElement("link"); c.rel = "stylesheet"; c.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"; document.head.append(c);
    const s = document.createElement("script"); s.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"; s.onload = ok; s.onerror = nein; document.head.append(s); });
  box.classList.add("r10-karte"); box.textContent = "Karte lädt …";
  const A = window.CockpitApp, start = (A?.standort?.() || "").split(",").map(Number);
  lade().then(() => {
    box.textContent = ""; const m = L.map(box, {zoomControl:false, attributionControl:false});
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {maxZoom:19}).addTo(m);
    let mk = null; const setz = (la, lo, zoom) => { pos.lat = la; pos.lon = lo; if (mk) mk.setLatLng([la, lo]); else mk = L.marker([la, lo]).addTo(m); if (zoom) m.setView([la, lo], 16); fn && fn(); };
    if (pos.lat != null) { m.setView([pos.lat, pos.lon], 15); setz(pos.lat, pos.lon); }
    else if (start.length === 2 && !isNaN(start[0])) m.setView(start, 14);
    else { m.setView([51.1, 10.4], 5); if (!A && navigator.geolocation) navigator.geolocation.getCurrentPosition(p => m.setView([p.coords.latitude, p.coords.longitude], 14), () => {}); }
    m.on("click", e => setz(e.latlng.lat, e.latlng.lng)); box._setz = setz; box._karte = m; setTimeout(() => m.invalidateSize(), 300);
  }).catch(() => { box.textContent = "Keine Karte (kein Internet). Nutze „Ich bin gerade hier“ oder trage Koordinaten ein."; });
  return box;
}
function r10Suche(box, pos){
  const z = el("div","r10-neu"), inp = el("input"), b = el("button","ghost small","Suchen"); inp.placeholder = "Adresse oder Ort suchen"; inp.setAttribute("aria-label","Adresse suchen"); b.type = "button";
  const los = async () => { const q = inp.value.trim(); if (!q) return; b.disabled = true;
    try { const r = await (await fetch("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=" + encodeURIComponent(q))).json(); if (!r.length) return toast("Nichts gefunden."); if (box._setz) box._setz(+r[0].lat, +r[0].lon, true); else { pos.lat = +r[0].lat; pos.lon = +r[0].lon; toast("Standort gesetzt."); } }
    catch { toast("Suche nicht erreichbar."); } finally { b.disabled = false; } };
  b.addEventListener("click", los); inp.addEventListener("keydown", ev => { if (ev.key === "Enter"){ ev.preventDefault(); los(); } }); z.append(inp, b); return z;
}
function r10Hier(pos, fn){
  const A = window.CockpitApp, b = el("button","ghost small","Ich bin gerade hier"); b.type = "button";
  b.addEventListener("click", () => {
    if (!A?.standort){ if (navigator.geolocation) navigator.geolocation.getCurrentPosition(p => fn(p.coords.latitude, p.coords.longitude), () => toast("Kein Standort. Tippe auf die Karte.")); return; }
    const st = A.standortStand?.() || "immer"; if (st === "keins"){ A.standortRecht(); return toast("Android fragt nach dem Standort. Danach noch einmal tippen."); }
    const s = A.standort() || "", [la, lo] = s.split(",").map(Number); if (!s || isNaN(la)) return toast("Noch kein Standort bekannt. Tippe auf die Karte oder suche die Adresse.");
    fn(la, lo);
  });
  return b;
}
const R10_REGUL_WAHL = [["limit", "⏱", "Limit pro Tag", [["30 Min", {minuten:30}], ["60 Min", {minuten:60}], ["90 Min", {minuten:90}]]],
  ["oeffnen", "🔁", "Öffnungen pro Tag", [["5×", {anzahl:5}], ["10×", {anzahl:10}], ["20×", {anzahl:20}]]],
  ["zeit", "🌙", "Sperrzeit", [["Abends 21–7", {von:"21:00", bis:"07:00"}], ["Nachts 23–7", {von:"23:00", bis:"07:00"}], ["Mo–Fr 9–17", {von:"09:00", bis:"17:00", tage:[0,1,2,3,4]}]]]];
function r10RegulText(e){ return `${e.name}: im Schnitt ${e.minuten >= 60 ? Math.floor(e.minuten / 60) + " Std. " + (e.minuten % 60 ? e.minuten % 60 + " Min" : "") : e.minuten + " Min"} und ${e.oeffnen}× geöffnet am Tag, gemessen an ${e.tage} Tagen.`; }
function r10RegulWahl(e, danach){
  const box = el("div","r10-regul");
  R10_REGUL_WAHL.forEach(([art, ic, t, werte]) => { box.append(el("b","r10-st", `${ic} ${t}`)); const w = el("div","r10-dur drei");
    werte.forEach(([tx, p]) => { const b = el("button", null, tx); b.type = "button"; b.addEventListener("click", async () => { box.querySelectorAll("button").forEach(x => x.disabled = true);
      try { const r = await api("api/regulierung", {app:e.name, art, ...p}); TR.daten.regulierung = r.regulierung; toast(`${e.name} ist jetzt geregelt.`); danach && danach(); if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {}); }
      catch (err){ toast(err.message || String(err)); box.querySelectorAll("button").forEach(x => x.disabled = false); } }); w.append(b); }); box.append(w); });
  return box;
}
function r10RegulKarte(){
  const r = TR.daten?.regulierung || {offen:[], erledigt:[]}, k = el("section","hud tr-karte r10-regulkarte"), kopf = el("div","tr-karte-kopf");
  kopf.append(el("span","tr-ico","⚖️"), el("div", null)); kopf.children[1].append(el("b", null, "BlockEm regelt mit"), el("span","k-s", `Was dich messbar frisst (ab ${r.schwelle?.minuten || 60} Min oder ${r.schwelle?.oeffnen || 20} Öffnungen am Tag, 3 Tage lang), wird gesperrt. Du wählst nur noch, wie.`));
  k.append(kopf);
  r.offen.forEach(e => { const z = el("div","r10-regul-offen"); z.append(el("b", null, r10RegulText(e)), el("span","k-s", `Ohne deine Wahl setzt die App in ${e.fristStd} Std. ein Limit von 60 Min am Tag.`), r10RegulWahl(e, () => trLockerKarten())); k.append(z); });
  if (!r.offen.length) k.append(el("p","k-s", r.erledigt.length ? "Zuletzt geregelt: " + r.erledigt.slice(0, 3).map(e => `${e.name} (${{limit:"Limit", oeffnen:"Öffnungen", zeit:"Sperrzeit"}[e.art] || e.art}${e.auto ? ", automatisch" : ""})`).join(", ") : "Gerade nichts auffällig. Die App schaut jeden Tag nach."));
  return k;
}
async function r10PauseKarte(){
  // Entwickler-Pause (john 04.11.): alle Locker-Regeln bis 07:00 aus, ohne PIN; nur in der Entwicklerversion sichtbar
  const k = el("section","hud tr-karte r10-pause"), kopf = el("div","tr-karte-kopf"); let info = null;
  try { info = await api("api/locker"); } catch {}
  const bis = info?.pauseBis && info.pauseBis * 1000 > Date.now() ? new Date(info.pauseBis * 1000) : null;
  kopf.append(el("span","tr-ico","🧪"), el("div", null)); kopf.children[1].append(el("b", null, "Entwickler: Sperrpause"), el("span","k-s", bis ? `App-Limits und Sperrzeiten sind aus bis ${bis.toLocaleString("de-DE", {weekday:"short", hour:"2-digit", minute:"2-digit"})}, auch am Handy. Bild-KI, Suchfilter und Erwachsenen-Sperre bleiben an.` : "Zum Testen App-Limits und Sperrzeiten aussetzen, ohne PIN. Bild-KI, Suchfilter und Erwachsenen-Sperre bleiben an. Nur in der Entwicklerversion."));
  const b = el("button", bis ? "ghost small" : "ask small", bis ? "Pause beenden" : "Sperren bis morgen 07:00 aus"); b.type = "button";
  b.addEventListener("click", async () => { const t = new Date(); if (!bis){ t.setDate(t.getDate() + (t.getHours() >= 7 ? 1 : 0)); t.setHours(7, 0, 0, 0); }
    try { await api("api/locker", {pauseBis: bis ? 0 : Math.round(t.getTime() / 1000)}); toast(bis ? "Pause beendet, Regeln gelten wieder." : "Sperren aus bis 07:00."); trLockerKarten(); if (typeof renderLocker === "function") renderLocker(true); if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {}); } catch (e){ toast(e.message || String(e)); } });
  k.append(kopf, b); return k;
}
if (typeof trLockerKarten === "function"){
  const _trLockerKarten10b = trLockerKarten;
  trLockerKarten = async function(){ await _trLockerKarten10b.apply(this, arguments); const box = $("trLockerKarten"); if (box && !box.hidden && TR.daten){ box.prepend(r10RegulKarte()); if (TR.daten.entwickler) box.prepend(await r10PauseKarte()); } };
}

/* ===== 6. Onboarding (ersetzt die Planungs-Einrichtung in der Tracking-App). Überarbeitet 1.0.1 nach johns Rückmeldung:
   Ziele nur noch, was wirklich sperrt; eigene Apps je Liste; Nachfrage als ganze Zeile; eigene Limits (Social höchstens 90 Min);
   mehrere und eigene Sperrzeiten; Orte mit Karte; eigene Habits; „Lockern“ erklärt. Öffnungen pro App nicht mehr hier. ===== */
const ST = {i:0, geschlecht:"", porno:true, pornoGewaehlt:false, ziele:new Set(["social","stream"]), apps:null, nachfrage:true, limSocial:60, limStream:120, limSpiele:60, eigenSocial:false, eigenStream:false, eigenSpiele:false,
  slots:null, slotOffen:null, neuFeld:null, listen:null, orte:[], ortNeu:null, karteBox:null, habits:new Set(), habitsEigen:[], abend:false, abendZeit:"21:30", warte:15, pin:"", offen:false};
// 17.11.2026 (john): Ruhezeiten als antippbare Kreise, jede mit eigener Uhrzeit und Auswahl, was dann zu ist.
// ohne/nur = Vorgabe, welche Gruppen die Zeit trifft (Arbeitszeit sperrt keine Arbeits-Apps, „Abends“ ist für den Feierabend gedacht).
const stSlotsNeu = () => [{k:"nacht", ic:"moon", name:"Nachts", von:"23:00", bis:"07:00", tage:null, an:true}, {k:"morgen", ic:"aufgang", name:"Morgens", von:"07:00", bis:"09:00", tage:null},
  {k:"arbeit", ic:"work", name:"Arbeit", von:"09:00", bis:"17:00", tage:[0,1,2,3,4], ohne:["arbeit"]}, {k:"abend", ic:"sun", name:"Abends", von:"20:00", bis:"23:00", tage:null, nur:["arbeit"]}];
ST.slots = stSlotsNeu();
// Ziel, Titel der Gruppe, Symbol, Kachel-Titel, Kachel-Unterzeile. Spiele und Arbeit (john 17.11.) sind normale Locker-Regeln mit Gruppen-Namen,
// bewusst NICHT in den Kategorien des Servers: dort hingen sonst Nachfrage und Automatik auch an Arbeits-Apps.
const ST_GRUPPEN = [["social","Social Media","phone","Scrollen","Insta, TikTok …"],["stream","Streaming","play","Streaming","YouTube, Netflix …"],["spiele","Spiele","game","Zocken","Handy-Spiele"],["arbeit","Arbeit","work","Arbeit","Mails nach Feierabend"]];
const ST_ARBEIT = ["Gmail","Outlook","Slack","Teams","Zoom","LinkedIn","Xing","Notion","Trello","Asana","Jira"];
const ST_SOCIAL_MAX = 90;
R10.ST = ST;   // für Tests erreichbar
function stFertig(){ return store("cockpit.start10") === "fertig" || !!S.plan?.profil?.eingerichtet; }
// Play-Fassung ohne Standort-Recht (john 16.11.2026): Orts-Sperre ausblenden, bis sie nachgereicht wird
function R10_ORTE(){ return !window.CockpitApp?.play?.(); }
const stRechteOffen = () => { const r = handyRechte(); return [r.nutzung, r.sperre, r.schutz || TR.daten?.entwickler].filter(x => !x).length; };
// 17.11.2026 (john): Einrichtung neu, ein Gedanke pro Bildschirm. Orte und Wartezeit zum Lockern stehen später unter Sperre.
function stSchritte(){
  const handy = VB.inApp && VB.modus === "handy" && !!window.CockpitApp, abl = ST.ziele.size > 0, frag = ["social","stream","spiele"].some(z => ST.ziele.has(z));
  return [
    {name:"Willkommen", bau:stWillkommen, knopf:"Los geht's"},
    {name:"Ablauf", bau:stAblauf, knopf:"Alles klar"},
    {name:"Ziel", bau:stZiele, sperre:() => !ST.gsGewaehlt, sperrText:"Erst Mann oder Frau wählen"},   // 1.0.48 (john 08.11.): Pflicht, Design und Schutz hängen daran
    // Nachfrage und Tageslimit gibt es nicht für Arbeits-Apps (john 17.11.): wer nur „Arbeit“ wählt, überspringt beide
    ...(abl ? [{name:"Ablenker", bau:stAblenker}, ...(frag ? [{name:"Nachfrage", bau:stNachfrage}, {name:"Limits", bau:stLimits}] : []), {name:"Sperrzeiten", bau:stZeiten}] : []),
    handy ? {name:"Schutz", bau:stRechte, knopf:"Fertig einrichten", sperre:() => stRechteOffen() > 0, get sperrText(){ const n = stRechteOffen(); return n === 1 ? "Noch 1 Schritt" : `Noch ${n} Schritte`; }}
      : {name:"Schutz vor dir selbst", bau:stSchutz, knopf:"Fertig einrichten"},
    {name:"Fertig", bau:stFertigSeite, knopf:"Zur App"},
  ];
}
function stOeffnen(){
  if (ST.offen) return; ST.offen = true;
  let d = $("stDialog");
  if (!d){ d = el("dialog","tr-pause r10-start modern"); d.id = "stDialog"; d.addEventListener("cancel", e => e.preventDefault()); document.body.append(d); }
  trLaden(true).then(() => stZeichnen());
  stZeichnen(); if (!d.open) d.showModal();
}
function stZeichnen(){
  const d = $("stDialog"); if (!d) return;
  const schritte = stSchritte(), s = schritte[Math.min(ST.i, schritte.length - 1)], y = d.querySelector(".r10-sinhalt")?.scrollTop || 0;
  if (ST.vorschau && s.sperre && s.name === "Schutz"){ s.sperre = null; }
  const kopf = el("div","r10-skopf"), bar = el("div","r10-dots"); schritte.forEach((_, j) => bar.append(el("i", j <= ST.i ? "an" : "")));
  bar.setAttribute("role","img"); bar.setAttribute("aria-label", `Schritt ${Math.min(ST.i, schritte.length - 1) + 1} von ${schritte.length}`);
  kopf.append(bar);
  const inhalt = el("div","r10-sinhalt"); inhalt.append(...[].concat(s.bau()));
  const fuss = el("div","r10-sfuss"), gesperrt = s.sperre && s.sperre();
  if (ST.i){ const z = el("button","ghost","‹"); z.type = "button"; z.setAttribute("aria-label","Zurück"); z.addEventListener("click", () => { ST.i--; stZeichnen(); }); fuss.append(z); }
  if (s.zweit){ const z = el("button","ghost", s.zweit); z.type = "button"; z.addEventListener("click", () => { ST.i++; stZeichnen(); }); fuss.append(z); }
  const w = el("button","ask", gesperrt ? s.sperrText : s.knopf || "Weiter"); w.type = "button"; w.disabled = !!gesperrt;
  w.addEventListener("click", () => { if (ST.i >= schritte.length - 1) return stAbschliessen(); ST.i++; stZeichnen(); });
  fuss.append(w);
  if (ST.vorschau){ const x = el("button","r10-vende","Vorschau beenden"); x.type = "button"; x.addEventListener("click", () => { d.close(); ST.offen = false; ST.vorschau = false; }); const v = el("div","r10-vzeile"); v.append(el("span","k-s","Nur Vorschau: es wird nichts gespeichert."), x); kopf.append(v); }
  d.replaceChildren(kopf, inhalt, fuss); inhalt.scrollTop = y;
  if (ST.karteBox?._karte) setTimeout(() => ST.karteBox._karte.invalidateSize(), 250);
}
// 17.11.2026: Linien-Symbole statt Emojis. Namen aus CM_SVG (clearmind.js) oder von hier, alles andere bleibt Text (alte Emoji-Aufrufe).
const R10_SVG = {hand:'<path d="M8 13V5a1.5 1.5 0 0 1 3 0v6m0-7a1.5 1.5 0 0 1 3 0v7m0-5a1.5 1.5 0 0 1 3 0v8a6 6 0 0 1-6 6h-1a6 6 0 0 1-5-3l-3-5a1.5 1.5 0 0 1 2.5-1.5L8 13"/>',
  lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>', chart:'<path d="M4 20V10m6 10V4m6 16v-7m4 7H2"/>',
  regler:'<path d="M4 6h10m4 0h2M4 12h4m4 0h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
  aufgang:'<path d="M3 17a9 9 0 0 1 18 0M12 8V5M5 10 3.5 8.5M19 10l1.5-1.5M2 20h20"/>', plus:'<path d="M12 5v14M5 12h14"/>'};
const stIc = k => { const s = el("span","ic"), h = R10_SVG[k] ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${R10_SVG[k]}</svg>` : window.CM_SVG?.[k];
  if (h) s.innerHTML = h; else s.textContent = k; return s; };
const stOpt = (an, ic, t, s, fn, fest) => { const b = el("button","r10-opt" + (an ? " an" : "")); b.type = "button"; b.setAttribute("aria-pressed", String(!!an)); if (fest) b.setAttribute("aria-disabled","true");
  const tx = el("span"); tx.append(el("b", null, t), el("small", null, s)); b.append(stIc(ic), tx, el("span","hk")); if (fn && !fest) b.addEventListener("click", fn); return b; };
const stGruppe = (...k) => { const g = el("div","r10-gruppe"); g.append(...k); return g; };
const stFest = (ic, t, s, w) => { const b = el("div","r10-opt r10-fest"), tx = el("span"); tx.append(el("b", null, t), el("small", null, s)); b.append(el("span","ic", ic), tx, el("span","pill", w)); return b; };
const stWahl = (werte, akt, fn, text) => { const w = el("div","r10-dur"); werte.forEach(v => { const b = el("button", v === akt ? "an" : "", text(v)); b.type = "button"; b.addEventListener("click", () => { fn(v); stZeichnen(); }); w.append(b); }); return w; };
const stZeile = (b, s) => { const z = el("div","r10-zeile"); z.append(el("b", null, b), el("span","k-s", s)); return z; };
const stChips = (liste, menge, fn) => { const c = el("div","chips"); liste.forEach(n => { const b = el("button","chip", n); b.type = "button"; b.setAttribute("aria-pressed", String(menge.has(n)));
  b.addEventListener("click", () => { menge.has(n) ? menge.delete(n) : menge.add(n); b.setAttribute("aria-pressed", String(menge.has(n))); fn && fn(); }); c.append(b); }); return c; };
// 1.0.13: App-Symbole in den Ablenker-Chips (wie im ersten Entwurf), Kachel aus clearmind.js
const stIcons = c => { if (typeof cmKachel === "function") c.querySelectorAll(".chip").forEach(b => { const n = b.deText; b.classList.add("r10-appchip"); b.prepend(cmKachel(n)); }); return c; };
const stNeu = (platz, fn) => { const z = el("div","r10-neu"), inp = el("input"), b = el("button","ghost small","＋"); inp.placeholder = platz;
  if (stInstalliert()?.size){ const vor = el("div","r10-vor");   // Vorschläge: Apps auf diesem Handy, als Chips im App-Stil (john 17.11.: das Auswahlfeld des Systems sah fremd aus)
    inp.addEventListener("input", () => { const q = inp.value.trim().toLowerCase(); vor.replaceChildren(...(q ? ST_INST_N.filter(n => n.toLowerCase().includes(q)).slice(0, 6) : []).map(n => { const c = el("button","chip", n); c.type = "button"; c.addEventListener("click", () => { inp.value = ""; fn(n); }); return c; })); });
    z.append(vor); }
  inp.maxLength = 40; inp.setAttribute("aria-label", platz); b.type = "button"; b.setAttribute("aria-label","Hinzufügen");
  const los = () => { const n = inp.value.trim(); if (n.replace(/[^\p{L}\p{N}_]/gu, "").length < 3) return toast("Mindestens 3 Buchstaben."); inp.value = ""; fn(n); }; b.addEventListener("click", los); inp.addEventListener("keydown", ev => { if (ev.key === "Enter"){ ev.preventDefault(); los(); } }); z.append(inp, b); return z; };
const stJaNein = (paare, akt, fn) => { const w = el("div","r10-jn"); paare.forEach(([v, t]) => { const b = el("button", null, t); b.type = "button"; b.setAttribute("aria-pressed", String(v === akt)); b.addEventListener("click", () => fn(v)); w.append(b); }); return w; };
function stWillkommen(){
  const logo = el("div","r10-logo","B"); logo.setAttribute("aria-hidden","true");
  const info = (ic, t) => { const r = el("div","r10-opt r10-info"); r.append(stIc(ic), el("b", null, t)); return r; };
  const konto = el("button","r10-link","Ich habe schon ein Konto"); konto.type = "button"; konto.addEventListener("click", () => { ST.neu = false; ST.i = 1; stZeichnen(); });
  // 24.11. (john): Sprache wird gleich am Anfang gefragt. Vorgewählt ist die Sprache des Geräts; die andere lädt die Seite neu.
  const sprache = stJaNein([["de","Deutsch"],["en","English"]], SPRACHE, v => v === SPRACHE ? (store("kern.sprache", v), stZeichnen()) : spracheSetzen(v));
  sprache.translate = false;
  const sk = el("div","r10-sprache"); sk.append(el("b","r10-st","Sprache · Language"), sprache); sk.translate = false;
  return [logo, el("h2","r10-mitte","Hol dir deine Zeit zurück."), sk, info("shield","Sperrt, was dich runterzieht"), info("hand","Fragt nach, bevor du scrollst"), info("lock","Deine Daten bleiben bei dir"), konto];
}
function stAblauf(){
  const s = (ic, t, u) => { const r = el("div","r10-fs"), tx = el("span"); tx.append(el("b", null, t), el("small", null, u)); r.append(stIc(ic), tx); return r; };
  const f = el("div","r10-fluss"); f.append(s("phone","Du wählst","Was dir die Zeit klaut"), s("regler","Du stellst ein","Wie viel okay ist und wann Ruhe ist"), s("shield","BlockEm passt auf","Auch wenn du mal schwach wirst"));
  return [el("h2", null, "Du sagst an. BlockEm zieht mit."), el("p","tr-pause-text","Drei Schritte, dann läuft's:"), f, el("p","tr-pause-text","Dauert 2 Minuten. Kannst du alles später ändern.")];
}
function stZiele(){
  const t = v => { ST.ziele.has(v) ? ST.ziele.delete(v) : ST.ziele.add(v); ST.apps = null; stZeichnen(); };
  // john 05.11.: Geschlecht wählt nur vor, „Pornos“ ist eine Wahl. john 17.11.2026: ohne Porno-Schutz wird nichts gesperrt, nur gezählt.
  const gs = stJaNein([["m","Mann"],["w","Frau"]], ST.gsGewaehlt === true ? ST.geschlecht : null, k => { ST.geschlecht = k; ST.gsGewaehlt = true; if (!ST.pornoGewaehlt) ST.porno = true; stZeichnen(); });
  const k = (an, ic, titel, u, fn) => { const b = el("button","r10-k"); b.type = "button"; b.setAttribute("aria-pressed", String(!!an)); b.append(stIc(ic), el("b", null, titel), el("small", null, u)); b.addEventListener("click", fn); return b; };
  const g = el("div","r10-big"); g.append(k(ST.porno, "shield", "Pornos", ST.porno ? "Voller Schutz" : "Aus, nur zählen", () => { ST.porno = !ST.porno; ST.pornoGewaehlt = true; stZeichnen(); }),
    ...ST_GRUPPEN.map(([z, , ic, titel, u]) => k(ST.ziele.has(z), ic, titel, u, () => t(z))));
  return [el("h2", null, "Was willst du loswerden?"), gs, el("b","r10-st","Tipp an, was passt"), g];
}
function stRechte(){
  const A = window.CockpitApp, r = handyRechte();
  // john 17.11.: Haken kommt von selbst, sobald man aus den Android-Einstellungen zurück ist (kein „Neu prüfen“ mehr)
  ST.rAlt = JSON.stringify(r);
  if (!ST.rUhr) ST.rUhr = setInterval(() => { const d = $("stDialog"); if (!d?.open){ clearInterval(ST.rUhr); ST.rUhr = null; return; }
    if (ST.offen && d.querySelector(".r10-rechte") && JSON.stringify(handyRechte()) !== ST.rAlt) stZeichnen(); }, 1000);
  const zeile = (ok, ic, t, s, fn) => { const b = el("button","r10-opt" + (ok ? " an" : "")); b.type = "button"; const tx = el("span"); tx.append(el("b", null, t), el("small", null, s));
    b.append(stIc(ic), tx, el("span","pill" + (ok ? " ok" : ""), ok ? "✓" : "Erlauben")); if (ok) b.setAttribute("aria-disabled","true"); else b.addEventListener("click", fn); return b; };
  const g = el("div","r10-rechte");
  g.append(zeile(r.nutzung, "chart", "Nutzung sehen", "Zeigt, wo deine Zeit hingeht", () => A.nutzungErlauben()),
    zeile(r.sperre, "shield", "Sperre erlauben", "Damit zu auch zu bleibt", () => handySperreErklaeren()),   // Prüfung 09.11.: Play verlangt die Erklärung vor den Bedienungshilfen
    // direkt die Android-Abfrage statt der langen Einstellungsseite; ältere App-Hülle ohne schutzAn(): bisheriger Weg
    zeile(r.schutz, "lock", "Löschen erschweren", A.play?.() ? "Stolperstein gegen schnelles Löschen" : "Löschen geht dann erst nach 48 Std", () => A.schutzAn ? A.schutzAn() : A.einstellungen()));
  return [el("h2", null, "Fast durch. Jetzt scharf schalten."), el("p","tr-pause-text","Dreimal antippen. Android fragt jeweils kurz nach."), g, el("p","k-s r10-mitte", `${3 - stRechteOffen()} von 3 erledigt`)];
}
// 1.0.47: Am Handy nur Apps zeigen, die installiert sind. Die übrigen bleiben ausgewählt (ihre Websites werden weiter gesperrt) und stehen eingeklappt darunter.
let ST_INST, ST_INST_N = [];
function stInstalliert(){
  if (ST_INST === undefined){ ST_INST = null; try { if (window.CockpitApp?.apps){ ST_INST_N = [...new Set(JSON.parse(CockpitApp.apps()).map(String))].sort((a, b) => a.localeCompare(b)); ST_INST = new Set(ST_INST_N.map(n => n.toLowerCase())); } } catch {} }
  return ST_INST;
}
function stInstListe(liste){
  const inst = stInstalliert(); if (!inst || !inst.size) return [stIcons(stChips(liste, ST.apps))];
  const da = liste.filter(n => inst.has(n.toLowerCase()) || ST.eigene?.has(n)), rest = liste.filter(n => !da.includes(n));
  const out = [da.length ? stIcons(stChips(da, ST.apps)) : el("p","k-s", liste.length ? "Keine davon auf diesem Handy." : "Nichts gefunden. Füg deine selbst dazu.")];
  if (rest.length){ const w = el("details","more"); w.append(el("summary", null, `＋ ${rest.length} weitere`), stIcons(stChips(rest, ST.apps))); out.push(w); }
  return out;
}
// App-Liste je Ziel: Social/Streaming aus den Kategorien, Spiele meldet das Handy (Android-Kategorie „Spiel“), Arbeit aus der Vorgabe (nur Installiertes)
function stListe(z){
  const k = TR.daten?.kategorien || (TR.daten = {...(TR.daten || {}), kategorien:{social:[], streaming:[]}}).kategorien;
  if (z === "social") return k.social ||= [];
  if (z === "stream") return k.streaming ||= [];
  if (!ST.listen){ const inst = stInstalliert(); let sp = []; try { sp = [...new Set(JSON.parse(window.CockpitApp?.spiele?.() || "[]").map(String))].slice(0, 30); } catch {}
    ST.listen = {spiele:sp, arbeit:ST_ARBEIT.filter(n => !inst?.size || inst.has(n.toLowerCase()))}; }
  return ST.listen[z];
}
const stGruppenAn = () => ST_GRUPPEN.filter(([z]) => ST.ziele.has(z));
function stAblenker(){
  const gr = stGruppenAn();
  if (!ST.apps) ST.apps = new Set(gr.flatMap(([z]) => stListe(z)));
  const out = [el("h2", null, "Was klaut dir die Zeit?"), el("p","tr-pause-text","Tipp an, was dabei ist.")];
  gr.forEach(([z, titel]) => { const liste = stListe(z), teile = stInstListe(liste);
    out.push(el("b","r10-st", titel), ...teile);
    if (ST.neuFeld === z) return out.push(stNeu("App oder Website", n => { let x = liste.find(y => y.toLowerCase() === n.toLowerCase()); if (!x){ liste.push(n); x = n; } ST.apps.add(x); (ST.eigene ||= new Set()).add(x); ST.neuFeld = null; stZeichnen(); }));
    const b = el("button","chip r10-plus","＋ Eigene"); b.type = "button"; b.addEventListener("click", () => { ST.neuFeld = z; stZeichnen(); });
    teile[0].classList.contains("chips") ? teile[0].append(b) : out.push(b); });
  return out;
}
function stNachfrage(){
  // Vorschau wie die echte Pause am Handy (Innehalten.java): schwarzer Grund, violetter Kreis, weißer Knopf „Lieber nicht“
  const app = [...(ST.apps || [])].find(a => !stListe("arbeit").includes(a)) || "Instagram", sek = TR.daten?.innehalten?.sekunden || 10, pv = el("div","r10-pv"); pv.setAttribute("aria-hidden","true");
  pv.append(el("span","r10-pv-o", `Kurz innehalten vor ${app}`), el("b","r10-pv-k", String(sek)), el("p", null, "Brauchst du das gerade wirklich?"), el("span","r10-pv-w","Lieber nicht"), el("small", null, `Weiter zu ${app} (${sek})`));
  return [el("h2", null, "Kurze Pause vor dem Öffnen?"), el("p","tr-pause-text","So sieht die Nachfrage aus:"), pv, stJaNein([[true,"Ja, einschalten"],[false,"Nein"]], ST.nachfrage, v => { ST.nachfrage = v; stZeichnen(); })];
}
function stLimitWahl(werte, akt, eigen, max, setz, setzEigen){
  const w = el("div","r10-dur"); werte.forEach(v => { const b = el("button", !eigen && v === akt ? "an" : "", v < 60 ? v + " Min" : (v / 60 + " Std.").replace(".5", ",5")); b.type = "button"; b.addEventListener("click", () => { setz(v); setzEigen(false); stZeichnen(); }); w.append(b); });
  const e = el("button", eigen ? "an" : "", "Eigene"); e.type = "button"; e.addEventListener("click", () => { setzEigen(true); stZeichnen(); }); w.append(e);
  const out = [w];
  if (eigen){ const z = el("div","r10-neu"), inp = el("input"); inp.type = "number"; inp.inputMode = "numeric"; inp.min = 5; inp.max = max; inp.step = 5; inp.value = akt; inp.setAttribute("aria-label","Minuten pro Tag");
    inp.addEventListener("input", () => { const v = Math.round(+inp.value || 0); if (v > max){ inp.value = max; toast(`Höchstens ${max} Minuten.`); } setz(Math.max(5, Math.min(max, v || 5))); }); z.append(inp, el("span","k-s", `Minuten am Tag, höchstens ${max}`)); out.push(z); }
  return out;
}
function stLimits(){
  const out = [el("h2", null, "Tageslimits festlegen"), el("p","tr-pause-text","Zeit pro Tag. Danach sind die Apps bis zum nächsten Tag gesperrt.")];
  if (ST.ziele.has("social")) out.push(stZeile("Social Media", "max. 1,5 Std."), ...stLimitWahl([30, 60, 90], ST.limSocial, ST.eigenSocial, ST_SOCIAL_MAX, v => ST.limSocial = v, v => ST.eigenSocial = v));
  if (ST.ziele.has("stream")) out.push(stZeile("Streaming", ""), ...stLimitWahl([60, 120, 180], ST.limStream, ST.eigenStream, 300, v => ST.limStream = v, v => ST.eigenStream = v));
  if (ST.ziele.has("spiele")) out.push(stZeile("Spiele", ""), ...stLimitWahl([30, 60, 120], ST.limSpiele, ST.eigenSpiele, 300, v => ST.limSpiele = v, v => ST.eigenSpiele = v));
  if (ST.ziele.has("arbeit")) out.push(el("p","k-s","Arbeits-Apps haben kein Tageslimit. Für die stellst du gleich Ruhezeiten ein."));
  return out;
}
const stZeitText = (von, bis) => `${von.replace(/:00$/, "")}–${bis.replace(/:00$/, "")} Uhr`;
const stTageText = t => !t || t.length === 7 ? "täglich" : t.join(",") === "0,1,2,3,4" ? "Mo–Fr" : t.join(",") === "5,6" ? "Sa–So" : t.map(i => ["Mo","Di","Mi","Do","Fr","Sa","So"][i]).join(" ");
// Welche Gruppen eine Ruhezeit trifft: eigene Wahl, sonst die Vorgabe der Zeit (nur/ohne), sonst alle gewählten
function stSlotWas(s){
  const gr = stGruppenAn().map(g => g[0]);
  if (s.was) return gr.filter(z => s.was.includes(z));
  const nur = gr.filter(z => s.nur?.includes(z)), ohne = gr.filter(z => !s.ohne?.includes(z));
  return nur.length ? nur : s.ohne ? ohne : gr;   // Arbeitszeit bei nur „Arbeit“: trifft nichts, statt Arbeits-Apps zu sperren
}
function stZeiten(){
  const gr = stGruppenAn(), min = t => +t.slice(0, 2) * 60 + +t.slice(3), tl = el("div","r10-tl");
  ST.slots.forEach(s => { const b = el("button","r10-tp" + (s.an ? " an" : "") + (s.an && ST.slotOffen === s.k ? " offen" : "")); b.type = "button"; b.setAttribute("aria-pressed", String(!!s.an));
    b.append(stIc(s.ic), el("b", null, s.name), el("small", null, s.an ? stZeitText(s.von, s.bis).replace(" Uhr","") : "aus"));
    b.addEventListener("click", () => { ST.slotOffen = s.an && ST.slotOffen === s.k ? null : s.k; s.an = true; stZeichnen(); }); tl.append(b); });
  const neu = el("button","r10-tp"); neu.type = "button"; neu.append(stIc("plus"), el("b", null, "Eigene"), el("small", null, " "));
  neu.addEventListener("click", () => { if (ST.slots.length >= 8) return toast("Mehr Zeiten legst du später unter Sperre an."); const k = "e" + Date.now(); ST.slots.push({k, ic:"clock", name:"Eigene", von:"12:00", bis:"13:00", tage:null, an:true, eigen:true}); ST.slotOffen = k; stZeichnen(); }); tl.append(neu);
  const bar = el("div","r10-tag"); bar.setAttribute("aria-hidden","true");
  ST.slots.filter(s => s.an).forEach(s => { const a = min(s.von), b = min(s.bis); (a < b ? [[a, b]] : [[a, 1440], [0, b]]).forEach(([x, y]) => { const i = el("i"); i.style.left = x / 14.4 + "%"; i.style.width = (y - x) / 14.4 + "%"; bar.append(i); }); });
  const skala = el("div","r10-skala"); ["0","6","12","18","24 Uhr"].forEach(t => skala.append(el("span", null, t)));
  const out = [el("h2", null, "Sperrzeiten festlegen"), el("p","tr-pause-text","Wähle, wann die Apps gesperrt sind. Jede Zeit lässt sich anpassen."), tl, bar, skala];
  const s = ST.slots.find(x => x.an && x.k === ST.slotOffen); if (!s) return out;
  const f = el("div","r10-zeitneu r10-slot"), von = el("input"), bis = el("input"); von.type = bis.type = "time"; von.value = s.von; bis.value = s.bis; von.setAttribute("aria-label","Von"); bis.setAttribute("aria-label","Bis");
  const zeit = () => { if (!von.value || !bis.value || von.value === bis.value) return toast("Bitte eine Zeit von–bis wählen."); s.von = von.value; s.bis = bis.value; stZeichnen(); };
  von.addEventListener("change", zeit); bis.addEventListener("change", zeit);
  const vb = el("div","r10-listen"); vb.append(von, el("span","k-s","bis"), bis);
  const tage = el("div","chips"); [["Täglich", null], ["Mo–Fr", [0,1,2,3,4]], ["Sa–So", [5,6]]].forEach(([t, w]) => { const b = el("button","chip small", t); b.type = "button"; b.setAttribute("aria-pressed", String(JSON.stringify(s.tage) === JSON.stringify(w))); b.addEventListener("click", () => { s.tage = w; stZeichnen(); }); tage.append(b); });
  f.append(el("b", null, s.name), vb, tage);
  if (gr.length > 1){ const was = stSlotWas(s), c = el("div","chips"), chip = (t, an, fn) => { const b = el("button","chip small", t); b.type = "button"; b.setAttribute("aria-pressed", String(an)); b.addEventListener("click", fn); c.append(b); };
    chip("Alles", was.length === gr.length, () => { s.was = gr.map(g => g[0]); stZeichnen(); });
    gr.forEach(([z, titel]) => chip(titel, was.length < gr.length && was.includes(z), () => { const n = was.length === gr.length ? [z] : was.includes(z) ? was.filter(x => x !== z) : [...was, z]; if (!n.length) return toast("Mindestens eine Gruppe."); s.was = n; stZeichnen(); }));
    f.append(el("b","r10-st","Was ist dann zu?"), c); }
  const aus = el("button","r10-link", s.eigen ? "Diese Zeit löschen" : "Diese Zeit ausschalten"); aus.type = "button";
  aus.addEventListener("click", () => { if (s.eigen) ST.slots = ST.slots.filter(x => x !== s); else s.an = false; ST.slotOffen = null; stZeichnen(); });
  f.append(aus); out.push(f); return out;
}
function stOrte(){
  const out = [el("h2", null, "Wo willst du frei sein?"), el("p","tr-pause-text","Hier sind Social Media und Streaming immer gesperrt. Tippe auf die Karte oder nutze deinen Standort.")];
  ST.orte.forEach((o, i) => { const z = stOpt(true, /gym|sport|fitness/i.test(o.name) ? "🏋️" : /arbeit|büro|office/i.test(o.name) ? "💼" : /uni|schule/i.test(o.name) ? "🎓" : "📍", o.name, `${o.radius} m Umkreis`, () => { ST.orte.splice(i, 1); stZeichnen(); }); z.querySelector(".hk").textContent = "✕"; out.push(z); });
  if (!ST.ortNeu){ const b = el("button","ghost small", ST.orte.length ? "＋ Weiterer Ort" : "＋ Ort hinzufügen"); b.type = "button"; b.addEventListener("click", () => { ST.ortNeu = {name:"", lat:null, lon:null, radius:150}; ST.karteBox = null; stZeichnen(); }); out.push(b); return out; }
  const n = ST.ortNeu, name = el("input"); name.placeholder = "Name, z. B. Gym"; name.maxLength = 40; name.value = n.name; name.setAttribute("aria-label","Name des Orts"); name.addEventListener("input", () => n.name = name.value);
  const chips = el("div","chips"); [["Gym","🏋️"],["Arbeit","💼"],["Uni","🎓"],["Schule","🏫"]].forEach(([t, i]) => { const b = el("button","chip small", `${i} ${t}`); b.type = "button"; b.addEventListener("click", () => { name.value = t; n.name = t; }); chips.append(b); });
  const stand = el("span","k-s", n.lat != null ? "Standort gesetzt." : "Noch kein Standort: auf die Karte tippen, suchen oder „Ich bin gerade hier“.");
  const setz = (la, lo) => { n.lat = la; n.lon = lo; stand.textContent = "Standort gesetzt."; if (ST.karteBox?._setz && ST.karteBox._marker !== "x") ST.karteBox._setz(la, lo, true); };
  if (!ST.karteBox) ST.karteBox = r10Karte(el("div"), n, () => { stand.textContent = "Standort gesetzt."; });
  const hier = r10Hier(n, setz);
  const rad = el("div","chips"); rad.append(el("span","k-s","Umkreis")); [100, 150, 300, 500].forEach(m => { const b = el("button","chip small", `${m} m`); b.type = "button"; b.setAttribute("aria-pressed", String(n.radius === m)); b.addEventListener("click", () => { n.radius = m; rad.querySelectorAll("button").forEach(x => x.setAttribute("aria-pressed", String(x === b))); }); rad.append(b); });
  const ok = el("button","ask small","Ort speichern"), ab = el("button","ghost small","Abbrechen"); ok.type = ab.type = "button";
  ok.addEventListener("click", () => { if (!n.name.trim()) return toast("Bitte einen Namen angeben."); if (n.lat == null) return toast("Erst den Standort setzen."); ST.orte.push({name:n.name.trim(), lat:n.lat, lon:n.lon, radius:n.radius, kategorien:["social","streaming"]}); ST.ortNeu = null; ST.karteBox = null; stZeichnen(); });
  ab.addEventListener("click", () => { ST.ortNeu = null; ST.karteBox = null; stZeichnen(); });
  const kn = el("div","r10-neu"); kn.append(ok, ab);
  out.push(chips, name, r10Suche(ST.karteBox, n), ST.karteBox, hier, stand, rad, kn); return out;
}
function stHabits(){
  const alle = ["Lesen","Sport","Draußen","Freunde","Kochen","Musik","Beten","Lernen", ...ST.habitsEigen];
  const ab = stOpt(ST.abend, "🌙", "Abends kurz zurückblicken", "Eine Mitteilung, 30 Sekunden", () => { ST.abend = !ST.abend; stZeichnen(); });
  const out = [el("h2", null, "Was machst du gern offline?"), el("p","tr-pause-text","Warst du länger offline, fragt die App kurz nach, höchstens 2× am Tag."),
    stChips(alle, ST.habits), stNeu("Eigenes Habit, z. B. Gitarre", n => { if (!alle.some(x => x.toLowerCase() === n.toLowerCase())) ST.habitsEigen.push(n); ST.habits.add(alle.find(x => x.toLowerCase() === n.toLowerCase()) || n); stZeichnen(); }),
    el("b","r10-st","Tagesabschluss"), ab];
  if (ST.abend) out.push(stWahl(["20:00","21:30","22:30"], ST.abendZeit, v => ST.abendZeit = v, v => v));
  return out;
}
function stSchutz(){
  // john 05.11.: keine Locker-PIN mehr, Schutz ist der Timer vor dem Lockern
  return [el("h2", null, "Schutz vor deinem Impuls"),
    el("p","tr-pause-text","Strenger geht sofort. Lockern beantragst du, 12 Stunden später kannst du 2 Stunden lang ändern. Dann ist der Impuls längst vorbei."),
    stGruppe(stFest("⏳", "Wartezeit zum Lockern", "Danach 2 Std. Zeit zum Ändern", "12 Std.")),
    stGruppe(stFest("🗑", "Regel entfernen", "Erst nach 24 Std. Wartezeit, sie gilt bis dahin weiter", "24 Std."),
      ST.porno ? stFest("🛡", "Pornos und Nacktbilder", "Lassen sich nie lockern", "Immer") : "",
      stFest("⚖️", "Was dich messbar frisst", "Sperrt die App von allein, du wählst nur noch wie", "Auto"))];
}
// Nachfrage gibt es nur, wenn Social, Streaming oder Spiele gewählt sind (nie vor Arbeits-Apps)
const stFragAn = () => ST.nachfrage && ["social","stream","spiele"].some(z => ST.ziele.has(z));
function stZeitenAlle(){ return ST.slots.filter(s => s.an).map(s => ({von:s.von, bis:s.bis, tage:s.tage, name:s.eigen ? "" : s.name, was:stSlotWas(s)})).filter(z => z.was.length); }
// 1.0.50: „36 Ablenker“ zählte auch nicht installierte Apps. Jetzt: Apps auf diesem Handy, der Rest wirkt als Website und auf anderen Geräten.
function stAblenkerText(){
  const alle = [...(ST.apps || [])], inst = stInstalliert();
  if (!inst || !inst.size) return `${alle.length} Ablenker`;
  const da = alle.filter(n => inst.has(String(n).toLowerCase()) || ST.eigene?.has(n)).length;
  return `${da} ${da === 1 ? "App" : "Apps"} auf diesem Handy`;
}
function stFertigSeite(){
  const z = (i, t, s) => { const r = el("div","r10-opt r10-wert"); r.append(stIc(i), el("b", null, t), el("span","r10-wert-s", s)); return r; };
  const zt = stZeitenAlle().map(x => stZeitText(x.von, x.bis) + (x.tage ? ` (${stTageText(x.tage)})` : "")).join(", ") || "keine";
  return [el("h2", null, "Alles bereit."), el("p","tr-pause-text","Das richtet die App jetzt ein. Ändern kannst du alles jederzeit unter „Sperre“."),
    stGruppe(z("shield", "Pornos", ST.porno ? "gesperrt" : "nur gezählt"), z("phone", stAblenkerText(), stFragAn() ? "mit Nachfrage, ihre Websites auch gesperrt" : "ihre Websites auch gesperrt"),
    z("clock", "Limits", [ST.ziele.has("social") && `Social ${Math.min(ST.limSocial, ST_SOCIAL_MAX)} Min`, ST.ziele.has("stream") && `Streaming ${ST.limStream} Min`, ST.ziele.has("spiele") && `Spiele ${ST.limSpiele} Min`].filter(Boolean).join(", ") || "keine"),
    z("moon", "Ruhezeiten", zt),
    z("hourglass", "Lockern", "12 Std. Wartezeit, Entfernen 24 Std."))];
}
async function stAbschliessen(){
  const d = $("stDialog"), ok = d?.querySelector(".r10-sfuss .ask"); if (ok){ ok.disabled = true; ok.textContent = "Richte ein …"; }
  if (ST.vorschau){ d?.close(); ST.offen = false; ST.vorschau = false; toast("Vorschau beendet, nichts verstellt."); return; }
  if (!ST.apps) ST.apps = new Set();
  const k = TR.daten?.kategorien || {social:[], streaming:[]}, apps = [...ST.apps];
  // Gruppen: Streaming, Spiele, Arbeit nach ihren Listen, alles Übrige (auch eigene Einträge unter Social) zählt als Social Media
  const inG = z => ST.ziele.has(z) ? apps.filter(a => stListe(z).includes(a)) : [], g = {stream:ST.ziele.has("stream") ? apps.filter(a => (k.streaming || []).includes(a)) : [], spiele:inG("spiele"), arbeit:inG("arbeit")};
  g.social = apps.filter(a => !g.stream.includes(a) && !g.spiele.includes(a) && !g.arbeit.includes(a));
  const stream = g.stream, social = g.social;
  try {
    await api("api/kategorien", {social, streaming:stream});   // nur Social/Streaming: Arbeits-Apps und Spiele kommen nie in die Kategorien (sonst Nachfrage/Automatik)
    await api("api/innehalten", {an:stFragAn(), kategorien:true, ...(g.spiele.length ? {apps:g.spiele} : {})});   // Nachfrage auch vor Spielen, nicht vor Arbeits-Apps
    await api("api/profil", {ziel:ST.porno ? (ST.ziele.size ? "beides" : "porno") : "fokus", geschlecht:ST.geschlecht, einrichtung:true});
    for (const n of ST.habits) await api("api/offline", {habit:{name:n}});
    await api("api/offline", {abschluss:{an:ST.abend, zeit:ST.abendZeit}, frage:{an:ST.habits.size > 0}});   // 1.0.47: Habits nicht mehr in der Einrichtung, Offline-Frage erst wenn man sie unter Mehr › Habits einschaltet
    if (ST.orte.length) await api("api/orte", {orte:ST.orte});
    let r = await api("api/locker", {}); const token = r.token;
    const regel = async x => { r = await api("api/locker", {token, regel:x}); };
    if (social.length) await regel({art:"limit", apps:social, minuten:Math.min(ST.limSocial, ST_SOCIAL_MAX), gruppe:"Social Media"});
    if (ST.limStream && stream.length) await regel({art:"limit", apps:stream, minuten:ST.limStream, gruppe:"Streaming"});
    if (g.spiele.length) await regel({art:"limit", apps:g.spiele, minuten:ST.limSpiele, gruppe:"Spiele"});
    for (const z of stZeitenAlle()){ const za = z.was.flatMap(x => g[x]); if (za.length) await regel({art:"zeit", apps:za, von:z.von, bis:z.bis, tage:z.tage || [0,1,2,3,4,5,6], gruppe:z.name || ""}); }   // 1.0.48: Sperrzeit mit Namen
    await api("api/locker", {token, schliessen:true});
    try { await api("api/einstellungen", {eingerichtet:true}); } catch {}
    store("cockpit.start10", "fertig");
    if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {});
    d?.close(); ST.offen = false; toast("Fertig eingerichtet. Du schaffst das."); trLaden(true);
    // 1.0.14: welche Geräte, merkt sich das Handy (nur Handy = keine Computer-Schalter); PIN neu laden, sonst steht „noch keine PIN“ bis zum Neustart
    // 17.11.: keine Geräte-Frage mehr in der Einrichtung, darum cockpit.geraete nicht schreiben (sonst gilt jedes Handy als „nur Handy“)
    if (typeof lkLaden === "function") setTimeout(lkLaden, 600); else if (typeof renderLocker === "function") setTimeout(() => renderLocker(true), 600);
    if (typeof kLaden === "function") kLaden(true).then(() => typeof kZeichnen === "function" && kZeichnen()).catch(() => {});   // 23.11.: „Heute“ zeigte bis zum Neustart „Noch keine Tageslimits“
  } catch (e){ toast(e.message || String(e)); if (ok){ ok.disabled = false; ok.textContent = "Nochmal versuchen"; } }
}
// 21.11.2026 (john): alte Planungs-Einrichtung (einrichtung.js) entfernt, nur noch diese Einrichtung
// setTimeout: in der App läuft der erste renderPlan (gespeicherter Stand) schon, bevor const ST oben angelegt ist
function einrichtungPruefen(){ if (S.mode !== "lokal" || stFertig()) return; setTimeout(() => { if (!stFertig() && !ST.offen) stOeffnen(); }, 0); }


/* ===== 8. Sync-Wege in der Einrichtung (04.11.2026): Welche Geräte nutzt du? Mehrere → BlockEm Sync oder Google Drive. QR-Teil in sync-wege.js. ===== */
Object.assign(ST, {neu:true, mehr:false, geraete:{handy:1, mac:0, windows:0, tablet:0}, weg:"sync", kontoOk:false, kEmail:"", kPw:"", swFehler:""});
const stMehrere = () => { const g = ST.geraete; return !!ST.mehr || g.handy + g.mac + g.windows + g.tablet > 1; };
const _swStSchritte = stSchritte;
stSchritte = function(){
  const alle = _swStSchritte(), i = alle.findIndex(s => s.name === "Willkommen");
  const geraete = {name:"Geräte", bau:stGeraete};
  if (!ST.neu) return [alle[i], {...geraete, sperre:() => true, sperrText:"Erst oben anmelden"}, ...alle.slice(i + 1)];   // beitreten: nach dem Verbinden fertig
  const extra = [geraete];
  if (stMehrere()) extra.push({name:"Abgleich", bau:stAbgleich, sperre:() => !ST.kontoOk && SW_WEG_DA(), sperrText:"Erst Konto anlegen"});
  alle.splice(i + 1, 0, ...extra);
  return alle;
};
const SW_WEG_DA = () => ST.weg === "drive" ? !!SYNC.st?.driveDa : !!SYNC.st?.dienstDa;
function stGeraete(){
  if (!SYNC.st) api("api/sync").then(r => { SYNC.st = r; stZeichnen(); }).catch(() => {});
  const zaehler = (k, ic, t) => { const z = el("div","r10-opt sw-zahl"), tx = el("span"); tx.append(el("b", null, t)); const w = el("div","r10-dur");
    const n = ST.geraete[k], minus = el("button", null, "−"), wert = el("b","sw-n", String(n)), plus = el("button", null, "+"); minus.type = plus.type = "button";
    minus.setAttribute("aria-label", t + " weniger"); plus.setAttribute("aria-label", t + " mehr");
    minus.addEventListener("click", () => { ST.geraete[k] = Math.max(k === "handy" ? 1 : 0, n - 1); stZeichnen(); });
    plus.addEventListener("click", () => { ST.geraete[k] = Math.min(5, n + 1); stZeichnen(); });
    w.append(minus, wert, plus); z.append(el("span","ic", ic), tx, w); return z; };
  const neu = stOpt(ST.neu, "✨", "Nein, ich bin neu", "Einrichten und loslegen", () => { ST.neu = true; ST.i = 0; stZeichnen(); });
  const schon = stOpt(!ST.neu, "🔗", "Ja, ich habe schon ein Konto", "Auf diesem Gerät anmelden", () => { ST.neu = false; SW.kp = null; stZeichnen(); });
  if (!ST.neu) return [el("h2", null, "Hast du schon ein BlockEm-Konto?"), neu, schon, ...stBeitreten()];
  // 1.0.18 (john: „muss meine Mutter können“): zwei klare Antworten statt Zähler, bei mehreren nur noch antippen, welche
  const mehr = stMehrere();
  const out = [el("h2", null, "Hast du schon ein BlockEm-Konto?"), neu, schon, el("b","r10-st","Wo willst du BlockEm nutzen?"),
    stOpt(!mehr, "📱", "Nur auf diesem Handy", "Am einfachsten. Kein Konto nötig, geht auch ohne Internet.", () => { ST.mehr = false; ST.geraete = {handy:1, mac:0, windows:0, tablet:0}; stZeichnen(); }),
    stOpt(mehr, "🔗", "Auf mehreren Geräten", "Zum Beispiel auch am Computer oder Tablet. Dafür legst du gleich ein Konto an.", () => { ST.mehr = true; stZeichnen(); })];
  if (mehr){
    const chips = el("div","chips");
    [["handy","Noch ein Handy"],["tablet","Tablet"],["mac","Mac"],["windows","Windows-PC"]].forEach(([k, t]) => {
      const an = k === "handy" ? ST.geraete.handy > 1 : ST.geraete[k] > 0, c = el("button","chip", t); c.type = "button"; c.setAttribute("aria-pressed", String(an));
      c.addEventListener("click", () => { ST.geraete[k] = k === "handy" ? (an ? 1 : 2) : (an ? 0 : 1); stZeichnen(); }); chips.append(c); });
    out.push(el("b","r10-st","Welche noch? (Antippen, was passt)"), chips);
  }
  return out;
}
// Neues Gerät tritt einem bestehenden Konto bei. 1.0.18 (john: „voll kompliziert“): einfach mit E-Mail und Passwort anmelden, QR/Code nur noch als Option
// 1.0.50: Wer sich mit einem bestehenden Konto anmeldet, übersprang die Rechte (Bedienungshilfe, Nutzungszugriff, Deinstallier-Schutz),
// die Sperre lief dann auf dem neuen Handy gar nicht. Jetzt kommt nach dem Anmelden dieselbe Rechte-Seite wie bei neuen Nutzern.
function stRechteNachAnmelden(){
  const d = $("stDialog"), fertig = r => r.nutzung && r.sperre && (r.schutz || TR.daten?.entwickler);
  if (!d || !VB.inApp || VB.modus !== "handy" || !window.CockpitApp?.rechte || fertig(handyRechte())) return false;
  let alt = "";
  const zeichnen = () => {
    if (!d.open) return clearInterval(uhr);
    const r = handyRechte(), neu = JSON.stringify(r); if (neu === alt) return; alt = neu;
    const inhalt = el("div","r10-sinhalt"), fuss = el("div","r10-sfuss"), ok = fertig(r);
    inhalt.append(...stRechte());
    const w = el("button","ask", ok ? "Fertig einrichten" : "Erst alle drei Pflicht-Zeilen"); w.type = "button"; w.disabled = !ok;
    w.addEventListener("click", () => { clearInterval(uhr); d.close(); });
    fuss.append(w); d.replaceChildren(inhalt, fuss);
  };
  const uhr = setInterval(zeichnen, 1500); zeichnen();
  if (!d.open) d.showModal();
  return true;
}
// 1.0.50: Passwort vergessen in der Einrichtung: Notfall-Code (bekommt man beim Anlegen des Kontos) + neues Passwort.
function stPasswortVergessen(fertig){
  const box = el("details","more st-vergessen"), code = el("input"), pw = el("input"), meld = el("p","k-s");
  code.placeholder = "Notfall-Code"; code.autocomplete = "off"; code.setAttribute("aria-label","Notfall-Code");
  pw.type = "password"; pw.placeholder = "Neues Passwort (mind. 10 Zeichen)"; pw.autocomplete = "new-password"; pw.setAttribute("aria-label","Neues Passwort");
  const b = eiKnopf("Passwort neu setzen", "ask small", async () => {
    b.disabled = true; meld.textContent = "Setze das Passwort, das dauert bis zu 30 Sekunden …";
    try { const r = await api("api/sync", {aktion:"notfall", email:ST.kEmail, code:code.value, passwort:pw.value, adresse:SYNC.st?.adresse || "", geraet:gkName()});
      SYNC.st = r; if (VB.modus === "handy") await ortSpeichernHandy(); await loadLocal().catch(() => {}); toast(r.hinweis || "Neues Passwort gesetzt."); return fertig(); }
    catch (e){ meld.textContent = e.message || String(e); b.disabled = false; } });
  box.append(el("summary", null, "Passwort vergessen?"), el("p","k-s","Oben die E-Mail eintragen, dazu deinen Notfall-Code. Ohne ihn lässt sich das Konto nicht öffnen, weil nur du den Schlüssel hast. Dann bleibt nur ein neues Konto („Nein, ich bin neu“)."), code, pw, b, meld);
  return box;
}
// 1.0.50: Neues Handy ohne Konto: Datei aus „Daten exportieren“ einspielen. Nur in der Einrichtung, damit eine alte Datei später keine Regeln lockert.
function stDateiEinspielen(fertig){
  const box = el("details","more st-datei"), inp = el("input"), meld = el("p","k-s");
  inp.type = "file"; inp.accept = ".zip,application/zip"; inp.setAttribute("aria-label","Sicherungsdatei wählen");
  const b = eiKnopf("Einspielen", "ask small", async () => {
    const f = inp.files?.[0]; if (!f){ meld.textContent = "Erst die Datei wählen."; return; }
    b.disabled = true; meld.textContent = "Spiele ein …";
    try { const b64 = await new Promise((ok, nein) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(",")[1] || ""); r.onerror = () => nein(new Error("Datei nicht lesbar")); r.readAsDataURL(f); });
      await api("api/umzug", {zip:b64}); if (VB.modus === "handy") await ortSpeichernHandy(); await loadLocal().catch(() => {}); toast("Deine Daten sind da."); return fertig(); }
    catch (e){ meld.textContent = e.message || String(e); b.disabled = false; } });
  box.append(el("summary", null, "Kein Konto, aber eine Sicherungsdatei?"), el("p","k-s","Die Datei aus „Daten exportieren“ (Einstellungen › Daten & Export) vom alten Handy."), inp, b, meld);
  return box;
}
function stBeitreten(){
  const out = [];
  if (SYNC.st?.driveDa){   // Google Drive nur zeigen, wenn es freigeschaltet ist
    const wahl = el("div","sw-zwei");
    [["sync","BlockEm-Konto"],["drive","Google Drive"]].forEach(([k, t]) => { const b = el("button","chip", t); b.type = "button"; b.setAttribute("aria-pressed", String(ST.weg === k)); b.addEventListener("click", () => { ST.weg = k; SW.kp = null; stZeichnen(); }); wahl.append(b); });
    out.push(el("b","r10-st","Womit hast du dich angemeldet?"), wahl);
  } else ST.weg = "sync";
  if (!SW_WEG_DA()){ out.push(el("p","ort-meldung", ST.weg === "drive" ? "Google Drive wird gerade bei Google freigeschaltet." : "BlockEm Sync geht mit dem Marktstart online.")); return out; }
  // 17.11. (john): nach dem Anmelden erst „Was nutzt du hier noch?“, dann (Handy) die Rechte
  const fertig = async () => { try { await api("api/einstellungen", {eingerichtet:true}); } catch {} store("cockpit.start10", "fertig"); ST.offen = false; stHierApps(() => { if (!stRechteNachAnmelden()) $("stDialog")?.close(); });
    toast("Verbunden. Deine Regeln gelten jetzt auch hier."); trLaden(true); if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {}); };
  if (ST.weg === "drive" && !SYNC.st?.driveAngemeldet){ out.push(stGoogleKnopf()); return out; }
  const art = ST.weg === "drive" ? "drive" : "dienst";
  if (art === "drive" || SW.kp){   // Ohne Passwort: QR-Code oder Code vom anderen Gerät
    if (!SW.kp) SW.kp = {modus:"zeigen", art};
    out.push(kpNeuesGeraet(art, fertig));
    if (art === "dienst") out.push(eiKnopf("Zurück zur Anmeldung","ghost small", () => { kpStop(); SW.kp = null; stZeichnen(); }));
    return out;
  }
  const email = el("input"), pw = el("input"); email.type = "email"; email.placeholder = "E-Mail"; email.autocomplete = "email"; email.value = ST.kEmail; email.setAttribute("aria-label","E-Mail");
  pw.type = "password"; pw.placeholder = "Passwort"; pw.autocomplete = "current-password"; pw.value = ST.kPw; pw.setAttribute("aria-label","Passwort");
  email.addEventListener("input", () => ST.kEmail = email.value); pw.addEventListener("input", () => ST.kPw = pw.value);
  const b = el("button","ask", ST.swFehler === "…" ? "Melde an, das dauert bis zu 30 Sekunden …" : "Anmelden"); b.type = "button"; b.disabled = ST.swFehler === "…";
  b.addEventListener("click", async () => { ST.swFehler = "…"; stZeichnen();
    try { const r = await api("api/sync", {aktion:"anmelden", email:ST.kEmail, passwort:ST.kPw, adresse:SYNC.st?.adresse || "", geraet:gkName()}); SYNC.st = r; ST.swFehler = ""; ST.kPw = "";
      if (VB.modus === "handy") await ortSpeichernHandy(); await loadLocal().catch(() => {}); return fertig(); } catch (e){ ST.swFehler = e.message || String(e); } stZeichnen(); });
  pw.addEventListener("keydown", e => { if (e.key === "Enter"){ e.preventDefault(); b.click(); } });
  out.push(el("p","tr-pause-text","Melde dich mit deinem BlockEm-Konto an. Deine Regeln und Daten kommen dann mit."), email, pw, b);
  if (ST.swFehler && ST.swFehler !== "…") out.push(el("p","ort-meldung schlecht", ST.swFehler));
  out.push(eiKnopf("Ohne Passwort: mit QR-Code oder Code vom anderen Gerät","ghost small", () => { SW.kp = {modus:"zeigen", art:"dienst"}; stZeichnen(); }),
    stPasswortVergessen(fertig), stDateiEinspielen(fertig));
  return out;
}
function stGoogleKnopf(){
  const b = el("button","ask", ST.swFehler === "…" ? "Warte auf Google …" : "Mit Google anmelden"); b.type = "button";
  b.addEventListener("click", async () => { ST.swFehler = "…"; stZeichnen();
    try { const r = await swDriveLogin(""); SYNC.st = r.an !== undefined ? r : await api("api/sync"); ST.swFehler = ""; } catch (e){ ST.swFehler = e.message || String(e); }
    stZeichnen(); });
  const f = el("div"); f.append(b, el("p","k-s","Nimm auf allen Geräten dasselbe Google-Konto. BlockEm sieht nur seinen eigenen versteckten Ordner."));
  if (ST.swFehler && ST.swFehler !== "…") f.append(el("p","ort-meldung schlecht", ST.swFehler));
  return f;
}
// Erstes Gerät bei mehreren Geräten: Weg wählen und Konto anlegen
function stAbgleich(){
  const st = SYNC.st || {};
  const out = [el("h2", null, "Deine Geräte verbinden"), el("p","tr-pause-text","Jedes Gerät läuft auch offline. Abgeglichen wird verschlüsselt, nur du kannst es lesen.")];
  if (ST.kontoOk){ out.push(stOpt(true, "✓", "Verbunden", ST.weg === "drive" ? `Google Drive (${st.email || ""})` : `BlockEm Sync (${st.email || ""})`, null, true));
    if (SYNC.code) out.push(el("b","r10-st","Dein Notfall-Code"), el("p","k-s","Dein einziger Weg zurück, falls du das Passwort vergisst. Abfotografieren oder aufschreiben."), el("p","sync-code", SYNC.code));
    out.push(el("p","k-s","Auf deinen anderen Geräten meldest du dich einfach mit dieser E-Mail und deinem Passwort an.")); return out; }
  if (st.driveDa) out.push(stOpt(ST.weg === "sync", "🔒", "BlockEm-Konto", "Mit E-Mail und Passwort. Server in der EU, wir sehen nichts.", () => { ST.weg = "sync"; stZeichnen(); }),
    stOpt(ST.weg === "drive", "☁️", "Mein Google Drive", "Mit Google anmelden. Wir speichern gar nichts.", () => { ST.weg = "drive"; stZeichnen(); }));
  else { ST.weg = "sync"; out.push(el("b","r10-st","Leg dein BlockEm-Konto an"), el("p","k-s","Mit E-Mail und Passwort. Damit meldest du dich später auf den anderen Geräten an.")); }
  if (!SW_WEG_DA()){ out.push(el("p","ort-meldung", (ST.weg === "drive" ? "Google Drive wird gerade bei Google freigeschaltet." : "BlockEm Sync geht mit dem Marktstart online.") + " Bis dahin läuft alles auf diesem Handy. Verbinden kannst du später unter Einstellungen › Geräte & Konto.")); return out; }
  if (ST.weg === "drive"){
    if (!st.driveAngemeldet) { out.push(stGoogleKnopf()); return out; }
    const b = el("button","ask","In Google Drive anfangen"); b.type = "button";
    b.addEventListener("click", async () => { try { SYNC.st = await api("api/sync", {aktion:"driveStart"}); ST.kontoOk = !!SYNC.st.an; ST.swFehler = ""; } catch (e){ ST.swFehler = e.message || String(e); } stZeichnen(); });
    out.push(el("p","k-s", `Angemeldet als ${st.email}.`), b); if (ST.swFehler) out.push(el("p","ort-meldung schlecht", ST.swFehler)); return out;
  }
  const email = el("input"), pw = el("input"); email.type = "email"; email.placeholder = "E-Mail"; email.autocomplete = "email"; email.value = ST.kEmail; email.setAttribute("aria-label","E-Mail");
  pw.type = "password"; pw.placeholder = "Passwort, mindestens 10 Zeichen"; pw.autocomplete = "new-password"; pw.value = ST.kPw; pw.setAttribute("aria-label","Passwort");
  email.addEventListener("input", () => ST.kEmail = email.value); pw.addEventListener("input", () => ST.kPw = pw.value);
  const b = el("button","ask", ST.swFehler === "…" ? "Erzeuge die Schlüssel …" : "Konto anlegen"); b.type = "button"; b.disabled = ST.swFehler === "…";
  b.addEventListener("click", async () => { ST.swFehler = "…"; stZeichnen();
    try { const r = await api("api/sync", {aktion:"registrieren", email:ST.kEmail, passwort:ST.kPw, adresse:st.adresse || "", geraet:gkName()}); SYNC.st = r; SYNC.code = r.notfallCode || null; ST.kontoOk = !!r.an; ST.swFehler = ""; ST.kPw = "";
      if (VB.modus === "handy") await ortSpeichernHandy(); } catch (e){ ST.swFehler = e.message || String(e); } stZeichnen(); });
  out.push(email, pw, b, el("p","k-s","Hast du schon ein Konto? Geh ganz an den Anfang zurück und tipp auf „Ich habe schon ein Konto“."));
  if (ST.swFehler && ST.swFehler !== "…") out.push(el("p","ort-meldung schlecht", ST.swFehler));
  return out;
}
// Fertig-Seite: die anderen Geräte nennen
const _swStFertigSeite = stFertigSeite;
stFertigSeite = function(){
  const out = _swStFertigSeite();
  if (!stMehrere()) return out;
  out.push(el("b","r10-st","Deine anderen Geräte"), ST.kontoOk ? gkWeg(true) : el("p","k-s","Verbinden kannst du sie, sobald der Abgleich online ist: Einstellungen › Geräte & Konto."));
  return out;
};

/* ===== 9. Ablauf (17.11.2026, john: ein Gedanke pro Bildschirm statt 4 voller Seiten) =====
   Neu: der Ablauf aus Abschnitt 6 ohne Geräte-Seite (mehrere Geräte später unter Einstellungen › Geräte & Konto).
   „Ich habe schon ein Konto“ auf dem ersten Bildschirm: Anmelden, danach dieselbe Rechte-Seite. */
const _st10Schritte = stSchritte;
// 18.11.2026 (john: „mehrere Geräte fehlt komplett“): vor dem Schutz die Frage, wo BlockEm noch laufen soll; bei mehreren gleich das Konto
stSchritte = function(){
  if (!ST.neu) return _st10Schritte().slice(0, 3);
  const alle = _swStSchritte(), i = alle.findIndex(s => s.name.startsWith("Schutz"));
  alle.splice(i, 0, {name:"Geräte", bau:stWoNutzen}, ...(stMehrere() ? [{name:"Abgleich", bau:stAbgleich, sperre:() => !ST.kontoOk && SW_WEG_DA(), sperrText:"Erst Konto anlegen"}] : []));
  return alle;
};
function stWoNutzen(){
  if (!SYNC.st) api("api/sync").then(r => { SYNC.st = r; stZeichnen(); }).catch(() => {});
  const mehr = stMehrere(), hier = VB.modus === "handy" ? "diesem Handy" : "diesem Gerät";
  const out = [el("h2", null, "Wo soll BlockEm aufpassen?"),
    stOpt(!mehr, "phone", "Nur auf " + hier, "Kein Konto nötig. Weitere Geräte gehen auch später.", () => { ST.mehr = false; ST.geraete = {handy:1, mac:0, windows:0, tablet:0}; stZeichnen(); }),
    stOpt(mehr, "plus", "Auch auf anderen Geräten", "Handy, Tablet, Mac oder Windows-PC. Die Regeln gelten dann überall zusammen.", () => { ST.mehr = true; stZeichnen(); })];
  if (mehr) out.push(el("b","r10-st","So geht's"), gkWeg(false), el("p","k-s","Das Konto legst du im nächsten Schritt an."));
  return out;
}

/* ===== 10. Neues Gerät (17.11.2026, john): wer sich mit bestehendem Konto anmeldet (Mac, zweites Handy), sagt, was er hier noch nutzt.
   Kommt nur zu bestehenden Regeln dazu (mehr Apps = strenger, braucht keinen Timer), nie lockerer. Vor Arbeits-Apps keine Nachfrage. ===== */
const ST_SPIELE_PC = ["Steam","Epic Games","Battle.net","Minecraft","Roblox","League of Legends","Fortnite","EA app","Ubisoft Connect","GOG Galaxy"];   // Mac/PC erkennen Spiele nicht von selbst
const ST_LIM_STD = {social:60, stream:120, spiele:60};
const stUni = (a, b) => { const out = [...(a || [])], k = new Set(out.map(x => String(x).toLowerCase())); (b || []).forEach(x => { if (!k.has(String(x).toLowerCase())){ k.add(String(x).toLowerCase()); out.push(x); } }); return out; };
function stHierApps(danach){
  let d = $("stDialog"); if (!d){ d = el("dialog","tr-pause r10-start modern"); d.id = "stDialog"; d.addEventListener("cancel", e => e.preventDefault()); document.body.append(d); }
  const handy = VB.modus === "handy" && !!window.CockpitApp, H = ST.hier = {regeln:null, eigen:{}, listen:{}, laeuft:false};
  ST.ziele = new Set(); ST.apps = new Set(); ST.listen = null; ST.eigene = new Set(); ST.neuFeld = null; ST.offen = true;   // offen: trLaden legt sonst den Regel-Dialog darüber
  const weiter = () => { ST.hier = null; ST.offen = false; ST.ziele = new Set(); ST.apps = null; ST.listen = null; ST.eigene = new Set(); ST.neuFeld = null; danach(); };   // Einrichtung findet ihren Anfangszustand wieder
  const drin = n => (H.regeln || []).some(r => (r.apps || []).some(a => String(a).toLowerCase() === String(n).toLowerCase()));
  const zeichnen = () => {
    const y = d.querySelector(".r10-sinhalt")?.scrollTop || 0, inhalt = el("div","r10-sinhalt"), fuss = el("div","r10-sfuss");
    const k = (an, ic, titel, u, fn) => { const b = el("button","r10-k"); b.type = "button"; b.setAttribute("aria-pressed", String(!!an)); b.append(stIc(ic), el("b", null, titel), el("small", null, u)); b.addEventListener("click", fn); return b; };
    const g = el("div","r10-big"); g.append(...ST_GRUPPEN.map(([z, , ic, titel]) => k(ST.ziele.has(z), ic, titel, z === "arbeit" ? "Ohne Nachfrage" : handy ? "Auf diesem Handy" : "Auf diesem Gerät",
      () => { ST.ziele.has(z) ? ST.ziele.delete(z) : ST.ziele.add(z); stZeichnenHier(); })));
    inhalt.append(el("h2", null, "Was nutzt du auf diesem Gerät noch?"), el("p","tr-pause-text","Deine Regeln sind schon da. Tipp an, was hier noch dazukommt. Es wird nur strenger, nie lockerer."), g);
    stGruppenAn().forEach(([z, titel]) => {
      let basis = stListe(z); if (z === "spiele" && !handy && !basis.length) basis = ST.listen.spiele = [...ST_SPIELE_PC];
      const liste = H.listen[z] = stUni(basis.filter(n => !drin(n) && String(n).replace(/[^\p{L}\p{N}_]/gu, "").length >= 3), H.eigen[z]), teile = stInstListe(liste);
      inhalt.append(el("b","r10-st", titel), ...teile);
      if (ST.neuFeld === z) return inhalt.append(stNeu("App oder Website", n => { (H.eigen[z] ||= []).push(n); ST.eigene.add(n); ST.apps.add(n); ST.neuFeld = null; stZeichnenHier(); }));
      const b = el("button","chip r10-plus","＋ Eigene"); b.type = "button"; b.addEventListener("click", () => { ST.neuFeld = z; stZeichnenHier(); });
      teile[0].classList.contains("chips") ? teile[0].append(b) : inhalt.append(b);
    });
    if (ST.ziele.size) inhalt.append(el("p","k-s","Was schon in deinen Regeln steht, gilt hier sowieso und taucht nicht mehr auf."));
    const nichts = el("button","ghost","Nichts davon"); nichts.type = "button"; nichts.addEventListener("click", weiter);
    const ok = el("button","ask", H.laeuft ? "Nehme dazu …" : "Dazunehmen"); ok.type = "button"; ok.disabled = H.laeuft;
    ok.addEventListener("click", async () => { if (!stHierWahl().length) return toast("Tipp erst an, was du hier nutzt."); H.laeuft = true; zeichnen();
      try { await stHierSpeichern(); toast("Dazugenommen. Gilt jetzt auf allen Geräten."); weiter(); } catch (e){ H.laeuft = false; toast(e.message || String(e)); zeichnen(); } });
    fuss.append(nichts, ok); d.replaceChildren(inhalt, fuss); inhalt.scrollTop = y;
  };
  H.zeichnen = zeichnen;
  api("api/locker").then(r => { H.regeln = r.regeln || []; if (ST.hier === H) zeichnen(); }).catch(() => { H.regeln = []; });
  if (typeof trLaden === "function") Promise.resolve(trLaden(true)).then(() => { if (ST.hier === H){ ST.listen = null; zeichnen(); } }).catch(() => {});   // Listen des Kontos statt der Vorgaben dieses Geräts
  zeichnen(); if (!d.open) d.showModal();
}
const stZeichnenHier = () => ST.hier?.zeichnen();
// Gewählte Apps je Gruppe (eine App zählt nur zur ersten Gruppe, in deren Liste sie steht)
function stHierWahl(){
  const H = ST.hier, frei = new Set([...ST.apps].map(a => String(a).toLowerCase())), out = [];
  stGruppenAn().forEach(([z, titel]) => { const apps = (H.listen[z] || []).filter(a => frei.delete(String(a).toLowerCase())); if (apps.length) out.push([z, titel, apps]); });
  return out;
}
async function stHierSpeichern(){
  const wahl = stHierWahl(), t = await api("api/tracking");
  let r = await api("api/locker", {}); const token = r.token, regeln = r.regeln || [];
  const regel = async x => { r = await api("api/locker", {token, regel:x}); };
  const neu = z => wahl.find(w => w[0] === z)?.[2] || [], k = t.kategorien || {};
  // Kategorien und Nachfrage: alte Listen zuerst, damit die Kürzung im Server (40 bzw. 30) nie etwas Bestehendes wegnimmt
  if (neu("social").length || neu("stream").length) await api("api/kategorien", {social:stUni(k.social, neu("social")), streaming:stUni(k.streaming, neu("stream"))});
  if (neu("spiele").length) await api("api/innehalten", {apps:stUni(t.innehalten?.apps, neu("spiele"))});
  // Regeln, die für alle Geräte gelten (geraete leer); auf andere Geräte beschränkte Regeln würden hier nicht greifen
  const alle = regeln.filter(x => !(x.geraete || []).length), dazu = new Map();
  const merke = (x, apps) => dazu.set(x, stUni(dazu.get(x), apps));
  for (const [z, titel, apps] of wahl){
    const lims = alle.filter(x => x.art === "limit" && x.gruppe === titel), lim = lims.find(x => (x.apps || []).length < 60) || lims[0];
    if (z !== "arbeit"){ if (lim) merke(lim, apps); else await regel({art:"limit", apps, minuten:ST_LIM_STD[z], gruppe:titel}); }
    // Ruhezeiten: dieselben, die schon Apps dieser Gruppe sperren; sonst „Nachts“ (gilt in der Einrichtung für alles)
    const bekannt = new Set(stUni(lim?.apps, z === "social" ? k.social : z === "stream" ? k.streaming : z === "arbeit" ? ST_ARBEIT : []).map(a => String(a).toLowerCase()));
    let zeiten = alle.filter(x => x.art === "zeit" && (x.apps || []).some(a => bekannt.has(String(a).toLowerCase())));
    if (!zeiten.length && z === "arbeit"){ await regel({art:"zeit", apps, von:"20:00", bis:"07:00", tage:[0,1,2,3,4,5,6], gruppe:"Feierabend"}); continue; }
    if (!zeiten.length) zeiten = alle.filter(x => x.art === "zeit" && x.gruppe === "Nachts");
    zeiten.forEach(x => merke(x, apps));
  }
  for (const [x, apps] of dazu){
    if (x.konsum){   // 19.11.: Konsum-Ruhezeit: x.apps ist die wirksame Liste; nur echt Neues kommt zu „Zusätzlich sperren“ (extra)
      const drin = new Set(x.apps.map(a => String(a).toLowerCase())), neu = apps.filter(a => !drin.has(String(a).toLowerCase()));
      if (neu.length){ const {extra, ...rein} = x; await regel({...rein, apps:stUni(extra || [], neu).slice(0, 60)}); }
      continue;
    }
    const zus = stUni(x.apps, apps);
    if (zus.length <= 60) await regel({...x, apps:zus});   // gleiche id, mehr Apps: der Server sieht das als strenger
    else { const {id, ...kopie} = x; await regel({...kopie, apps:zus.slice(x.apps.length, x.apps.length + 60)}); }   // voll: zweite Regel mit denselben Werten
  }
  await api("api/locker", {token, schliessen:true});
  if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {});
  if (typeof lkLaden === "function") setTimeout(lkLaden, 600);
}

}   // Ende NUR_TRACKING
// 23.11. (john): Start-Decke (index.html) weg, sobald die Einrichtung offen ist oder der Kern mit fertigem Stand steht; bei Startfehler sofort, sonst spätestens nach 20 s
(function beDecke(){
  const d = document.getElementById("beDecke"); if (!d) return;
  const t0 = Date.now();
  const iv = setInterval(() => {
    const kern = document.documentElement.classList.contains("kern") && document.getElementById("kern")?.childElementCount > 0;
    const fehler = document.querySelector("#vbStart button");
    if ($("stDialog")?.open || fehler || (kern && S.mode === "lokal" && S.plan && stFertig()) || Date.now() - t0 > 20000){ clearInterval(iv); d.remove(); }
  }, 50);
})();

/* ---------- Sperre-Seite (john 17.11.2026): Reiter heißt „Sperre“, oben „Jetzt“ als Kacheln frei/zu je Gruppe (Variante A),
   unten „Deine Zeiten“ als Kreise, Orte erstmal weg. Fokus: Kategorien zum Antippen über den einzelnen Apps.
   Nur angleichen: alle bisherigen Teile (Gruppen, Apps, Sperrzeiten, Freischalten, Schutz) bleiben, wie sie sind. ---------- */
if (typeof beNurTr === "function" && beNurTr()){

// Reiter unten und in den Einstellungen: „Locker“ → „Sperre“ (interne Namen bleiben „locker“)
function s17Namen(){
  document.querySelectorAll("nav button, nav a").forEach(b => {
    const w = document.createTreeWalker(b, NodeFilter.SHOW_TEXT); let t;
    while ((t = w.nextNode())) if (t.nodeValue.trim() === "Locker") t.nodeValue = t.nodeValue.replace("Locker", "Sperre");
  });
}
s17Namen(); setTimeout(s17Namen, 800);
if (typeof ES_GRUPPEN !== "undefined") ES_GRUPPEN.forEach(([, l]) => l.forEach(x => { if (x.k === "locker") x.t = "Sperre"; }));

const S17_ARBEIT = ["gmail","outlook","slack","teams","zoom","linkedin","xing","notion","trello","asana","jira"];
const s17Min = t => { const [h, m] = String(t || "0:0").split(":").map(Number); return h * 60 + (m || 0); };
const s17Uhr = m => `${String(Math.floor(m / 60) % 24).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
const s17Kurz = (t = "00:00") => String(+String(t).split(":")[0]) + (String(t).split(":")[1] !== "00" ? ":" + String(t).split(":")[1] : "");
const s17Ico = n => { const k = /nacht/i.test(n) ? "moon" : /morgen/i.test(n) ? "sun" : /arbeit/i.test(n) ? "work" : /abend/i.test(n) ? "moon" : "clock";
  const i = el("span","s17-ico"); i.innerHTML = (typeof CM_SVG !== "undefined" && CM_SVG[k]) || ""; return i; };
// Gilt eine Zeit-Regel heute zu dieser Minute? (wie locker_zeit_aktiv: über Mitternacht zählt der Vortag)
function s17ZeitAn(r, tag, min){
  const v = s17Min(r.von), b = s17Min(r.bis), tage = r.tage?.length ? r.tage : [0,1,2,3,4,5,6];
  if (v === b) return false;
  if (v < b) return tage.includes(tag) && min >= v && min < b;
  return (tage.includes(tag) && min >= v) || (tage.includes((tag + 6) % 7) && min < b);
}
// Gruppen aus den Regeln: Limits mit Gruppen-Namen, Arbeit aus den Sperrzeiten (hat kein Limit)
function s17Gruppen(regeln){
  const g = new Map();
  regeln.filter(r => r.art === "limit" && r.gruppe).forEach(r => { const x = g.get(r.gruppe) || {name:r.gruppe, apps:[], limit:{gesperrt:false}};
    x.apps.push(...r.apps.map(a => a.toLowerCase())); x.limit.gesperrt ||= !!r.gesperrt; g.set(r.gruppe, x); });
  const arbeit = [...new Set(regeln.filter(r => r.art === "zeit").flatMap(r => r.apps.map(a => a.toLowerCase())).filter(a => S17_ARBEIT.includes(a)))];
  if (arbeit.length && !g.has("Arbeit")) g.set("Arbeit", {name:"Arbeit", apps:arbeit});
  return [...g.values()];
}
// Stand einer Gruppe jetzt: zu (Limit voll oder Sperrzeit läuft) oder frei, und bis wann
function s17Stand(gr, zeiten, jetzt){
  const tag = (jetzt.getDay() + 6) % 7, min = jetzt.getHours() * 60 + jetzt.getMinutes();
  const trifft = zeiten.filter(r => r.apps.some(a => gr.apps.includes(a.toLowerCase())));
  if (gr.limit?.gesperrt) return {zu:true, text:"Limit erreicht, bis morgen"};
  // Minute für Minute bis 24 Std. weiter: wann wechselt der Zustand?
  const zuBei = m => trifft.some(r => s17ZeitAn(r, (tag + Math.floor(m / 1440)) % 7, m % 1440));
  const zu = trifft.some(r => r.gesperrt);   // „jetzt zu“ sagt der Server (Erziehung, Geräte); die Uhr nur für „bis wann“
  if (zuBei(min) !== zu) return {zu, text: zu ? "gerade gesperrt" : "gerade frei"};   // Server weicht von der Uhr ab (z. B. andere Geräte)
  for (let m = min + 1; m < min + 1440; m++) if (zuBei(m) !== zu) return {zu, text:`bis ${s17Uhr(m % 1440)} Uhr`};
  return {zu, text: zu ? "den ganzen Tag" : "den ganzen Tag"};
}
function s17Jetzt(d){
  if (d && d.an === false) return null;   // Sperre ganz aus: keine Kacheln
  const regeln = (d?.regeln || []).filter(r => r.apps?.length), zeiten = regeln.filter(r => r.art === "zeit"), gr = s17Gruppen(regeln);
  if (!gr.length) return null;
  const jetzt = new Date(), box = el("section","s17-jetzt");
  box.append(el("b","s17-st", `Jetzt, ${s17Uhr(jetzt.getHours() * 60 + jetzt.getMinutes())}`));
  const g = el("div","s17-kacheln");
  gr.forEach(x => { const s = s17Stand(x, zeiten, jetzt), k = el("div","s17-k" + (s.zu ? " zu" : ""));
    k.append(el("small", null, s.zu ? "Zu" : "Frei"), el("b", null, x.name), el("span", null, s.text)); g.append(k); });
  box.append(g);
  return box;
}
// „Deine Zeiten“: jede Sperrzeit als Kreis (gleiche Gruppierung wie die Sperrzeiten-Liste), Antippen öffnet sie zum Bearbeiten
function s17Zeiten(d){
  const gr = typeof szGruppen === "function" ? szGruppen(d?.regeln) : [];
  const box = el("section","s17-zeiten"), reihe = el("div","s17-kreise");
  box.append(el("b","s17-st","Deine Zeiten"));
  gr.forEach(g => { const name = typeof szName === "function" ? szName(g) : (g.name || "Ruhe"), b = el("button","s17-kreis" + (g.regeln.some(r => r.gesperrt) ? " an" : "")); b.type = "button";
    b.append(s17Ico(name), el("b", null, name), el("small", null, `${s17Kurz(g.von)}–${s17Kurz(g.bis)}`));
    b.setAttribute("aria-label", `${name} ${g.von} bis ${g.bis}`); b.addEventListener("click", () => szAuf(g)); reihe.append(b); });
  const neu = el("button","s17-kreis neu"); neu.type = "button"; neu.append(el("span","s17-ico","+"), el("b", null, "Neu"), el("small", null, " "));
  neu.setAttribute("aria-label","Neue Sperrzeit"); neu.addEventListener("click", () => szAuf(null)); reihe.append(neu);
  box.append(reihe);
  return box;
}
// john 17.11. („zu überladen“): wie Variante A nur drei Reiter Zeiten | Gruppen | Apps, je Reiter ein Teil. Die alten Kacheln bleiben unsichtbar als Schalter.
const S17_REITER = [["zeiten","Zeiten",/^Sperrzeiten/],["gruppen","Gruppen",/^Gruppen/],["apps","Apps",/^Apps/]];
if (typeof lkOffen === "function"){
  const _s17LkOffen = lkOffen;
  lkOffen = function(d){
    if (store("cm.lmTeil") === "orte") store("cm.lmTeil", "gruppen");   // Orte erstmal weg (john 17.11.); Daten bleiben
    let out = _s17LkOffen.call(this, d);
    const leiste = out.find(x => x.classList?.contains("r2-teil")); if (!leiste) return out;
    leiste.querySelector(".r4-orte-chip")?.remove();
    const knopf = re => [...leiste.querySelectorAll("button")].find(b => re.test(b.deText.trim()));
    const aktiv = S17_REITER.find(([, , re]) => knopf(re)?.getAttribute("aria-pressed") === "true")?.[0] || (knopf(/^Freischalten/)?.getAttribute("aria-pressed") === "true" ? "frei" : "gruppen");
    leiste.classList.add("s17-versteckt");
    const seg = el("div","s17-seg"); seg.setAttribute("role","tablist");
    S17_REITER.forEach(([k, t, re]) => { const b = el("button", null, t); b.type = "button"; b.setAttribute("role","tab"); b.setAttribute("aria-selected", String(k === aktiv));
      b.addEventListener("click", () => knopf(re)?.click()); seg.append(b); });
    const frei = el("button","s17-frei", aktiv === "frei" ? "‹ Zurück" : "Etwas freischalten"); frei.type = "button";
    frei.addEventListener("click", () => (aktiv === "frei" ? knopf(/^Gruppen/) : knopf(/^Freischalten/))?.click());
    if (aktiv === "zeiten"){   // Zeiten: nur was gerade frei ist und die Kreise (Bearbeiten über die Kreise)
      out = out.filter(x => !x.classList?.contains("lm-liste") && !x.classList?.contains("cm-neu"));
      const jetzt = s17Jetzt(d); out.splice(out.indexOf(leiste) + 1, 0, ...(jetzt ? [jetzt] : []), s17Zeiten(d));
    }
    out.splice(out.indexOf(leiste), 0, seg);
    out.push(frei);
    return out;
  };
}

// Fokus: „Was ist zu?“ als Kategorien über den einzelnen Apps (Alles, Social, Streaming, Spiele). Antippen schaltet alle Apps der Kategorie.
// john 17.11.2026 (1.0.70): Umschalten ging am Handy nicht (ältere Server kennen {liste} nicht) → s17Schalten prüft das Ergebnis und schaltet sonst einzeln.
// Dazu: Apps getrennt nach „auf diesem Handy“ und „nicht installiert“, und „Gilt für“ (Geräte).
const S17_FK = {warte:false, inst:undefined, auf:false, laeuft:false};
function s17Inst(){   // Namen der installierten Apps (klein) oder null, wenn das Gerät sie nicht meldet (Computer, Browser)
  if (S17_FK.inst === undefined){ S17_FK.inst = null; try { if (window.CockpitApp?.apps) S17_FK.inst = new Set(JSON.parse(CockpitApp.apps()).map(x => String(x).toLowerCase())); } catch {} }
  return S17_FK.inst?.size ? S17_FK.inst : null;
}
async function s17Schalten(namen, an){
  const ist = () => new Set((S.plan?.automatik?.sperre?.an || []).map(x => x.toLowerCase()));
  const kand = new Set((S.plan?.automatik?.sperre?.kandidaten || []).map(x => x.toLowerCase()));
  const offen = () => namen.filter(n => ist().has(n.toLowerCase()) !== an);
  if (!offen().length) return;
  S.plan = await api("api/sperre", {liste:namen, an});
  for (const n of offen()) S.plan = await api("api/sperre", an ? (kand.has(n.toLowerCase()) ? {name:n, an:true} : {neu:n}) : {name:n, an:false});   // älterer Server: einzeln
}
async function s17Tipp(box, fn){   // ein Tipp nach dem anderen, danach neu zeichnen
  if (S17_FK.laeuft) return; S17_FK.laeuft = true;
  box?.querySelectorAll("button").forEach(x => x.disabled = true);
  try { await fn(); } catch (e){ toast(e.message || String(e)); }
  finally { S17_FK.laeuft = false; $("cmFkSperre")?.querySelector(".s17-fk")?.remove(); renderPlan(); }
}
function s17FokusKat(){
  const sp = $("cmFkSperre"), s = S.plan?.automatik?.sperre; if (!sp || !s || sp.querySelector(".s17-fk")) return;
  if (S.mode !== "lokal" || (typeof autoAn === "function" && !autoAn("sperre"))) return;   // wie cmFokus: dann gibt es nichts zu schalten
  if (!TR.daten?.kategorien && !S17_FK.warte){ S17_FK.warte = true; if (typeof trLaden === "function") trLaden();   // Kategorien kommen erst mit den Tracking-Daten: bis 10 s nachsehen, dann einmal neu zeichnen
    let n = 0; const t = setInterval(() => { if (TR.daten?.kategorien || ++n > 20){ clearInterval(t); if (TR.daten?.kategorien){ $("cmFkSperre")?.querySelector(".s17-fk")?.remove(); s17FokusKat(); } } }, 500); }
  const k = TR.daten?.kategorien || {}, spiele = (LK.daten?.regeln || []).filter(r => r.gruppe === "Spiele").flatMap(r => r.apps);
  const ok = a => String(a).replace(/[^\p{L}\p{N}_]/gu, "").length >= 3;   // kürzere Namen nimmt die Sperre nicht (sonst Müll unter „Weitere Apps“)
  const kat = [["Social", k.social || []], ["Streaming", k.streaming || []], ["Spiele", spiele]].map(([t, l]) => [t, l.filter(ok)]).filter(([, l]) => l.length);
  const alleApps = [...new Map([...(s.kandidaten || []), ...kat.flatMap(([, l]) => l)].filter(ok).map(a => [a.toLowerCase(), a])).values()];
  if (alleApps.length) kat.unshift(["Alles", alleApps]);
  if (!kat.length) return;
  const an = new Set((s.an || []).map(x => x.toLowerCase())), box = el("div","s17-fk"), chips = el("div","chips");
  kat.forEach(([t, l]) => { const alle = l.every(a => an.has(a.toLowerCase())), b = el("button","chip", t); b.type = "button"; b.setAttribute("aria-pressed", String(alle));
    b.addEventListener("click", () => { b.setAttribute("aria-pressed", String(!alle)); s17Tipp(box, () => s17Schalten(l, !alle)); });
    chips.append(b); });
  chips.setAttribute("role","group"); chips.setAttribute("aria-label","Was möchtest du sperren?");   // 19.11. (john): zwei klar getrennte Fragen
  box.append(el("p","cm-fk-titel","Was möchtest du sperren?"), chips);
  // Gilt für: alle Geräte (Standard) oder nur gewählte. Nur wenn der Server es kann und es mehr als ein Gerät gibt.
  const ger = s.alleGeraete || [], gilt = s.gilt || [];
  if (ger.length > 1){
    const gc = el("div","chips"), setzen = liste => s17Tipp(box, async () => { S.plan = await api("api/sperre", {geraete:liste}); });
    const alle = el("button","chip","Alle Geräte"); alle.type = "button"; alle.setAttribute("aria-pressed", String(!gilt.length)); alle.addEventListener("click", () => setzen([])); gc.append(alle);
    ger.forEach(g => { const da = gilt.includes(g), b = el("button","chip", g); b.type = "button"; b.setAttribute("aria-pressed", String(da));
      b.addEventListener("click", () => { const neu = da ? gilt.filter(x => x !== g) : [...gilt, g]; setzen(neu.length === ger.length ? [] : neu); }); gc.append(b); });
    gc.classList.add("s17-geraete"); gc.setAttribute("role","group"); gc.setAttribute("aria-label","Auf welchen Geräten?");
    box.append(el("p","cm-fk-titel","Auf welchen Geräten?"), gc);
  }
  sp.prepend(box);
}
// Einzelne Apps: erst die auf diesem Handy, darunter eingeklappt die nicht installierten (ihre Websites sperrt der Fokus trotzdem)
function s17FokusListe(){
  const sp = $("cmFkSperre"), s = S.plan?.automatik?.sperre, liste = sp?.querySelector(".cm-fk-liste"), inst = s17Inst();
  if (!liste || !s || !inst || liste.dataset.s17 || S.mode !== "lokal" || (typeof autoAn === "function" && !autoAn("sperre"))) return;
  if (typeof CM !== "undefined" && !CM.fkAlle && typeof cmFokus === "function"){ CM.fkAlle = true; cmFokus(); return; }   // ganze Liste samt Feld „Weitere Seite oder App“
  liste.dataset.s17 = "1";
  const an = new Set((s.an || []).map(x => x.toLowerCase())), eigen = new Set((s.eigene || []).map(x => x.toLowerCase()));
  const namen = [...new Map([...(s.kandidaten || []), ...(s.an || [])].map(n => [n.toLowerCase(), n])).values()];
  const k = TR.daten?.kategorien || {}, ausKat = new Set([...(k.social || []), ...(k.streaming || [])].map(x => String(x).toLowerCase()));   // über „Alles“ dazugekommen ≠ selbst eingetragen
  const hier = n => { const x = n.toLowerCase(); return inst.has(x) || (x === "twitter" && inst.has("x")) || (eigen.has(x) && !ausKat.has(x)); };
  const da = namen.filter(hier), rest = namen.filter(n => !hier(n));
  const kachel = n => { const on = an.has(n.toLowerCase()), z = el("div","cm-zeile r2-kachel" + (on ? "" : " aus")); z.setAttribute("role","button"); z.tabIndex = 0; z.setAttribute("aria-pressed", String(on));
    z.append(typeof cmKachel === "function" ? cmKachel(n) : "", el("span","n", n));
    const tipp = () => { if (S17_FK.laeuft) return; z.classList.toggle("aus", on); s17Tipp(null, () => s17Schalten([n], !on)); };
    z.addEventListener("click", tipp); z.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " "){ e.preventDefault(); tipp(); } }); return z; };
  const neu = da.length ? da.map(kachel) : [el("p","cm-leer","Keine dieser Apps ist auf diesem Handy.")];
  if (rest.length){
    const d = el("details","s17-rest"), innen = el("div","cm-fk-liste r2-kacheln"); innen.dataset.s17 = "1"; d.open = S17_FK.auf;
    d.addEventListener("toggle", () => { S17_FK.auf = d.open; });
    innen.append(...rest.map(kachel));
    d.append(el("summary", null, `${rest.length} weitere, nicht installiert`), el("p","k-s","Nicht auf diesem Handy. Ihre Websites sperrt der Fokus trotzdem, wenn sie an sind."), innen);
    neu.push(d);
  }
  liste.replaceChildren(...neu);
}
(function(){
  const tab = document.querySelector('.tab[data-r="fokus"]'); if (!tab) return;
  new MutationObserver(() => {
    const sp = $("cmFkSperre"); if (sp && !sp.querySelector(".s17-fk")) s17FokusKat();
    s17FokusListe();
    sp?.querySelectorAll(".cm-fk-titel").forEach(t => { if (t.deText === "Im Fokus gesperrt") t.textContent = s17Inst() ? "Auf diesem Handy" : "Dazu einzelne Apps"; });
    const st = $("fkStart"), idle = $("fkIdle"); if (st && idle && idle.lastElementChild !== st) idle.append(st);   // Entwurf 5: „Fokus starten“ ganz unten
  }).observe(tab, {childList:true, subtree:true});
})();


// Schutz-Reiter: dazu die Zeile „Löschen erschweren“ (john 17.11.: alle Schutz-Einstellungen an einem Ort). Nur am Handy, Antippen führt zu den Handy-Rechten.
function s17Loeschen(){
  const box = $("trLockerKarten"); if (!box || !VB.inApp || !window.CockpitApp?.rechte || box.querySelector(".s17-loeschen")) return;
  const an = !!handyRechte().schutz, k = el("section","hud tr-karte s17-loeschen"), kopf = el("div","tr-karte-kopf"), tx = el("div"), i = el("span","tr-ico cm-kachel");
  i.innerHTML = (typeof CM_SVG !== "undefined" && CM_SVG.lock) || "";
  tx.append(el("b", null, "Löschen erschweren"), el("small","r4-zus", window.CockpitApp.play?.() ? "Stolperstein gegen schnelles Löschen" : "Löschen geht erst nach 48 Std."));
  kopf.append(i, tx, el("span","r4-an", an ? "An" : "Einschalten")); k.append(kopf);
  k.style.cursor = "pointer"; k.addEventListener("click", () => an ? (typeof esOeffnen === "function" && esOeffnen("geraete")) : (window.CockpitApp.schutzAn ? window.CockpitApp.schutzAn() : window.CockpitApp.einstellungen?.()));
  box.append(k);
}
// Oben im Schutz-Reiter: „Schutz läuft, x von y an“ (Entwurf, john 17.11.: Schutz-Liste „top“)
function s17SchutzKopf(){
  const box = $("trLockerKarten"); if (!box) return;
  box.querySelector(".s17-schutzkopf")?.remove();
  const karten = [...box.querySelectorAll(":scope > section")].filter(k => !k.hidden && getComputedStyle(k).display !== "none"), an = karten.filter(k => { const sw = k.querySelector('.tr-karte-kopf [role="switch"]');
    return sw ? sw.getAttribute("aria-checked") === "true" : !/Einschalten|Aus$/.test(k.querySelector(".r4-an")?.deText || ""); }).length;
  const kopf = el("div","s17-schutzkopf"), i = el("span","s17-schild"), tx = el("div");
  i.innerHTML = (typeof CM_SVG !== "undefined" && CM_SVG.shield) || "";
  tx.append(el("b", null, an === karten.length ? "Schutz läuft" : "Schutz läuft teilweise"), el("span", null, `${an} von ${karten.length} an`));
  kopf.append(i, tx); box.prepend(kopf);
}
// Die Schutz-Karten werden an mehreren Stellen neu gezeichnet: darum nach jeder Änderung prüfen, ob Kopf und Zeile da sind
(function(){
  const tab = document.querySelector('.tab[data-r="locker"]'); if (!tab) return;
  let dran = false;
  new MutationObserver(() => { if (dran) return; const box = $("trLockerKarten"); if (!box || box.querySelector(".s17-schutzkopf")) return;
    dran = true; try { s17Loeschen(); s17SchutzKopf(); } catch {} dran = false; }).observe(tab, {childList:true, subtree:true});
})();
document.addEventListener("visibilitychange", () => { if (!document.hidden){ $("trLockerKarten")?.querySelector(".s17-loeschen")?.remove(); try { s17Loeschen(); s17SchutzKopf(); } catch {} } });   // Stand nach Rückkehr aus Android

}

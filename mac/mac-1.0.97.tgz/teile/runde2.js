/* ---------- Runde 2 (05.11.2026, johns Durchgang durch die App, nach android.js) ----------
   Einstellungen: Locker, Fokus-Sperre und Automatik raus (Locker hat den eigenen Reiter, die Fokus-Sperre steht jetzt im Fokus-Reiter,
   Automatik braucht niemand). „Handy-App“ öffnet am Handy direkt die Rechte- und Schutz-Seite statt erst eines Knopfs.
   Fokus: gesperrte Apps als Kacheln, die Sperr-Einstellungen klappen im Fokus-Reiter auf. CSS in runde2.css. */
if (typeof ES_GRUPPEN !== "undefined" && typeof beNurTr === "function" && beNurTr()){
  const raus = new Set(["locker", "fokus", "automatik", "daten"]);
  ES_GRUPPEN.forEach(g => { g[1] = g[1].filter(x => !raus.has(x.k)); });
  ES_GRUPPEN.splice(0, ES_GRUPPEN.length, ...ES_GRUPPEN.filter(g => g[1].length));
  if (window.CockpitApp?.einstellungen && typeof ES_DEF !== "undefined" && ES_DEF.geraete) Object.assign(ES_DEF.geraete, {t:"Rechte & Schutz am Handy", s:"Bedienungshilfe, Deinstallier-Sperre, Updates", reiter:true});
}
if (typeof esOeffnen === "function"){
  const _esOeffnenR2 = esOeffnen;
  esOeffnen = function(k){
    if (k === "geraete" && window.CockpitApp?.einstellungen){ window.CockpitApp.einstellungen(); return; }
    if (k === "fokus" && typeof beNurTr === "function" && beNurTr()){ showTab("fokus"); return; }
    if (k === "automatik" && typeof beNurTr === "function" && beNurTr()){ showTab("fokus"); return; }
    return _esOeffnenR2.apply(this, arguments);
  };
}

/* ----- Fokus: Sperr-Einstellungen im Fokus-Reiter (aufklappbar), Apps als Kacheln ----- */
function r2FokusEinst(auf){
  const sp = $("cmFkSperre"), box = $("fkSperreBox"); if (!sp || !box) return;
  let det = $("r2FkEinst");
  if (!det){ det = el("details","r2-fk-einst"); det.id = "r2FkEinst"; det.append(el("summary", null, "Einstellungen zur Sperre")); }
  if (det.parentElement !== sp.parentElement || det.previousElementSibling !== sp) sp.after(det);
  if (box.parentElement !== det) det.append(box);
  box.hidden = false;
  if (auf){ det.open = true; det.scrollIntoView({behavior:"smooth", block:"start"}); }
}
function r2FokusKacheln(){
  const sp = $("cmFkSperre"); if (!sp) return;
  // Einschalten direkt hier statt über Einstellungen › Automatik
  const ein = [...sp.querySelectorAll(".cm-mehr")].find(b => /einschalten/.test(b.deText));
  if (ein){ const neu = ein.cloneNode(true); ein.replaceWith(neu);
    neu.addEventListener("click", async () => { try { S.plan = await api("api/automatik", {schalter:{sperre:true}}); renderPlan(); toast("Sperre im Fokus: an"); } catch (e){ toast(e.message || String(e)); } }); }
  const liste = sp.querySelector(".cm-fk-liste"); if (!liste || liste.classList.contains("r2-kacheln")) return;
  liste.classList.add("r2-kacheln");
  liste.querySelectorAll(".cm-zeile").forEach(z => {
    const b = z.querySelector(".cm-an"); if (!b) return;
    z.classList.add("r2-kachel"); z.classList.toggle("aus", b.classList.contains("aus"));
    z.setAttribute("role","button"); z.tabIndex = 0;
    z.addEventListener("click", ev => { if (ev.target !== b) b.click(); });
  });
  sp.querySelector(".ghost.small")?.remove();   // „Alle Einstellungen zur Sperre“: steht jetzt direkt darunter
}
if (typeof cmFokus === "function" && typeof beNurTr === "function" && beNurTr()){
  const _cmFokusR2 = cmFokus;
  cmFokus = function(...a){ const r = _cmFokusR2.apply(this, a); try { r2FokusKacheln(); $("r2FkEinst")?.remove(); } catch {} return r; };   // john 05.11.: Einstellungen darunter doppelt, raus
  if (typeof fkDurChips === "function"){ const _f = fkDurChips; fkDurChips = function(...a){ const r = _f.apply(this, a); cmFokus(); return r; }; }
  if (typeof renderSperre === "function"){ const _r = renderSperre; renderSperre = function(...a){ const r = _r.apply(this, a); cmFokus(); return r; }; }
  cmFokus();
}

/* ----- Habits: oben eine Karte (offline heute + deine Habits), dann Offline-Momente, Einstellungen eingeklappt -----
   r10HabitsZeichnen liegt im Block von release10.js (async, nicht global), darum nach jedem Zeichnen über einen Beobachter umbauen. */
function r2HabitsOrdnen(box){
  const kopf = box.querySelector(":scope > .r10-hkopf"), hl = [...box.children].find(k => k !== kopf && /Deine Habits/.test(k.querySelector(":scope > b")?.deText || ""));
  if (kopf && hl){ kopf.classList.add("r2-hkarte"); hl.querySelector(":scope > b")?.remove(); kopf.append(...hl.childNodes); hl.remove(); }
  const es = box.querySelector(":scope > .r10-einst");
  if (es){
    const det = el("details","hud tr-karte r2-heinst"); det.open = !!R2.habitsEinstAuf;
    det.addEventListener("toggle", () => R2.habitsEinstAuf = det.open);
    det.append(el("summary", null, "Einstellungen: Tagesabschluss"));
    es.querySelector(":scope > b")?.remove(); es.classList.remove("hud","tr-karte");
    es.replaceWith(det); det.append(es);
  }
}
const R2 = {habitsEinstAuf:false};
(function(){
  const tab = document.querySelector('.tab[data-r="habits"]'); if (!tab) return;
  new MutationObserver(() => { const box = $("r10Habits"); if (box && (box.querySelector(":scope > .r10-einst") || box.querySelectorAll(":scope > .tr-karte:not(.r2-heinst)").length > 2)) r2HabitsOrdnen(box); })
    .observe(tab, {childList:true, subtree:true});
})();

/* ----- Locker: Gruppen und einzelne Apps (john 05.11.) -----
   Eine Gruppe hat einen Namen (Regel-Feld „gruppe“) und gemeinsame Limits für viele Apps. Alte Regeln ohne Namen, deren Apps
   größtenteils in der Liste Social Media bzw. Streaming stehen, zählen als diese Gruppe. Eine Gruppe nimmt beim Speichern
   alle Apps ihrer Regeln zusammen (das macht sie nur strenger). Oben im Locker: „Gruppen | Einzelne Apps“. */
const R2_GRUPPEN = [["Social Media","social"],["Streaming","streaming"]];
function r2GruppeVon(r){
  if (r.gruppe) return r.gruppe;
  const kat = TR.daten?.kategorien || {}, a = r.apps.map(x => x.toLowerCase()); if (a.length < 3) return "";
  for (const [name, k] of R2_GRUPPEN){ const l = (kat[k] || []).map(x => x.toLowerCase()); if (a.filter(x => l.includes(x)).length * 2 > a.length) return name; }
  return "";
}
if (typeof lmGruppen === "function"){
  lmGruppen = function(regeln){
    const g = new Map();
    (regeln || []).forEach(r => { const name = r2GruppeVon(r), k = name ? "g:" + name.toLowerCase() : lmSchluessel(r.apps);
      if (!g.has(k)) g.set(k, {apps:[], regeln:[], name});
      const e = g.get(k); r.apps.forEach(a => { if (!e.apps.some(x => x.toLowerCase() === a.toLowerCase())) e.apps.push(a); }); e.regeln.push(r); });
    return [...g.values()];
  };
}
if (typeof lmKarte === "function"){
  const _lmKarteR2 = lmKarte;
  lmKarte = function(g){
    const k = _lmKarteR2.call(this, g);
    if (g.name){ const b = k.querySelector(".lm-titel b"); if (b) b.textContent = g.name; k.classList.add("r2-gruppe");
      const f = k.querySelector(".lm-fuss"); if (f) f.textContent = `${g.apps.length} Apps · ` + f.textContent; }
    return k;
  };
}
if (typeof lmAuf === "function"){
  const _lmAufR2 = lmAuf;
  lmAuf = function(g){
    _lmAufR2.call(this, g);
    if (!LM.e) return;
    LM.e.gruppe = g ? (g.name || "") : null;      // null = neu, noch nicht gewählt: Gruppe oder eine App?
    if (g?.name) LM.e.appsZeigen = false;
    if (g && !g.name) LM.e.einzeln = true;
    lmZeichnen();
  };
}
if (typeof lmPlan === "function"){
  const _lmPlanR2 = lmPlan;
  lmPlan = function(){
    const plan = _lmPlanR2.apply(this, arguments), name = LM.e?.gruppe || "";
    plan.forEach(p => { if (p.regel) p.regel.gruppe = name; });
    // Name neu oder geändert: auch unveränderte Regeln mit dem Namen speichern
    if (LM.e) LM.e.alt.forEach(a => { if ((a.gruppe || "") !== name && !plan.some(p => p.regel?.id === a.id || p.loeschen === a.id)){
      const {gesperrt, pauseBis, verbraucht, geoeffnet, ...rein} = a; plan.push({regel:{...rein, apps:[...LM.e.apps], gruppe:name}, alt:a}); } });
    return plan;
  };
}
// Kopf im Bearbeiten-Fenster: bei Neu erst „Gruppe oder eine App?“, bei Gruppen ein Namensfeld mit Vorschlägen
function r2GruppeKopf(){
  const e = LM.e, d = $("lmDialog"), body = d?.querySelector(".lm-body"); if (!e || !body || body.querySelector(".r2-gwahl")) return;
  const s = el("section","lm-abschnitt r2-gwahl");
  if (e.neu && e.gruppe === null){
    s.append(el("b", null, "Was willst du begrenzen?"));
    const z = el("div","lm-schnell r2-zwei");
    const g = el("button", null, "Eine Gruppe"), a = el("button", null, "Eine App"); g.type = a.type = "button";
    g.addEventListener("click", () => { e.gruppe = ""; e.appsZeigen = true; lmZeichnen(); });
    a.addEventListener("click", () => { e.gruppe = ""; e.einzeln = true; lmZeichnen(); });
    z.append(g, a); s.append(z, el("span","lm-klein","Gruppe: mehrere Apps teilen sich ein Limit, z. B. alle Social-Media-Apps zusammen 60 Min am Tag."));
    body.replaceChildren(s); d.querySelector(".lm-dfuss")?.setAttribute("hidden", ""); return;
  }
  d.querySelector(".lm-dfuss")?.removeAttribute("hidden");
  if (e.einzeln && !e.gruppe) return;
  const titel = d.querySelector(".lm-dkopf .lm-titel b"); if (titel && e.gruppe) titel.textContent = `${e.gruppe} · ${e.apps.size} Apps`;
  s.append(el("b", null, "Name der Gruppe"));
  const inp = el("input"); inp.value = e.gruppe || ""; inp.placeholder = "z. B. Social Media"; inp.maxLength = 40; inp.setAttribute("aria-label","Name der Gruppe");
  inp.addEventListener("input", () => { e.gruppe = inp.value.trim(); lmHinweis(); });
  s.append(inp);
  if (e.neu){
    const z = el("div","lm-schnell"), kat = TR.daten?.kategorien || {};
    R2_GRUPPEN.forEach(([name, k]) => { const b = el("button", e.gruppe === name ? "an" : "", name); b.type = "button";
      b.addEventListener("click", () => { e.gruppe = name; (kat[k] || []).forEach(x => e.apps.add(x)); lmZeichnen(); }); z.append(b); });
    s.append(z, el("span","lm-klein","Antippen füllt die Gruppe mit den passenden Apps. Darunter kannst du Apps dazu- oder abwählen."));
  }
  body.prepend(s);
}
if (typeof lmZeichnen === "function"){
  const _lmZeichnenR2 = lmZeichnen;
  lmZeichnen = function(){ const r = _lmZeichnenR2.apply(this, arguments); try { r2GruppeKopf(); } catch {} return r; };
}
if (typeof lmHinweis === "function"){
  const _lmHinweisR2 = lmHinweis;
  lmHinweis = function(){ const r = _lmHinweisR2.apply(this, arguments), e = LM.e, ok = $("lmOk");
    if (e && ok && e.neu && !e.einzeln && e.gruppe !== null && !e.gruppe){ ok.disabled = true; $("lmHinweis")?.prepend(el("span","lm-klein","Gib der Gruppe einen Namen.")); }
    return r; };
}
// Locker-Liste: oben „Gruppen | Einzelne Apps“ statt „Apps / Limits / Sperrzeiten“
if (typeof lkOffen === "function"){
  const _lkOffenR2 = lkOffen;
  lkOffen = function(d){
    const out = _lkOffenR2.call(this, d), box = out.find(x => x.classList?.contains("lm-liste")); if (!box || CM.tab === "frei") return out;
    for (let i = out.length - 1; i >= 0; i--) if (out[i].classList?.contains("r10-filter")) out.splice(i, 1);
    const gruppen = lmGruppen(d.regeln), ent = d.entfernen || {};
    const teil = {gruppen:gruppen.filter(g => g.name), apps:gruppen.filter(g => !g.name)};
    let tab = store("cm.lmTeil") || (teil.gruppen.length ? "gruppen" : "apps");
    if (tab === "zeiten" && typeof szListe === "function"){   // 1.0.37: eigener Bereich „Sperrzeiten“ (feinschliff.js)
      for (let i = out.length - 1; i >= 0; i--) if (out[i].classList?.contains("r10-filter")) out.splice(i, 1);
      box.replaceChildren(...szListe(d));
      const alt = out.find(x => x.classList?.contains("cm-neu"));
      if (alt){ const n = el("button","cm-neu","＋ Sperrzeit"); n.type = "button"; n.addEventListener("click", () => szAuf(null)); out[out.indexOf(alt)] = n; }
      return out;
    }
    if (!teil[tab]) tab = "gruppen";
    const leiste = el("div","chips r10-filter r2-teil"); leiste.setAttribute("role","group"); leiste.setAttribute("aria-label","Gruppen oder einzelne Apps");
    [["gruppen","Gruppen"],["apps","Einzelne Apps"]].forEach(([k, t]) => { const b = el("button","chip small", `${t} ${teil[k].length}`); b.type = "button"; b.setAttribute("aria-pressed", String(tab === k));
      b.addEventListener("click", () => { store("cm.lmTeil", k); renderLocker(true); }); leiste.append(b); });
    box.replaceChildren();
    teil[tab].forEach(g => { box.append(lmKarte(g));
      const weg = g.regeln.filter(r => ent[r.id]); if (weg.length) box.append(el("div","r10-weg", `${weg.length === g.regeln.length ? "Wird" : weg.length + " Regeln werden"} bald entfernt, gilt bis dahin weiter.`)); });
    if (!teil[tab].length) box.append(el("p","cm-leer", tab === "gruppen" ? "Noch keine Gruppe. Tippe unten auf „＋ Begrenzen“ und wähle „Eine Gruppe“." : "Noch keine einzelne App begrenzt."));
    box.before(leiste); out.splice(out.indexOf(box), 0, leiste);
    const neu = out.find(x => x.classList?.contains("cm-neu")); if (neu) neu.textContent = "＋ Begrenzen";
    return out;
  };
}
// Aussehen: in 1.0 nur Dunkel (john 05.11.), Auswahl kommt mit dem hellen Look zurück
if (typeof ES_GRUPPEN !== "undefined" && typeof beNurTr === "function" && beNurTr()){
  ES_GRUPPEN.forEach(g => { g[1] = g[1].filter(x => x.k !== "aussehen"); });
  ES_GRUPPEN.splice(0, ES_GRUPPEN.length, ...ES_GRUPPEN.filter(g => g[1].length));
}
// cmFokus ruft sich in clearmind.js selbst auf („Weitere Apps …“), am Wrapper vorbei: dann kam kurz die alte Liste.
// Darum zusätzlich nach jedem Neuzeichnen der Sperr-Liste Kacheln bauen.
(function(){
  const tab = document.querySelector('.tab[data-r="fokus"]'); if (!tab || typeof beNurTr !== "function" || !beNurTr()) return;
  new MutationObserver(() => { const l = $("cmFkSperre")?.querySelector(".cm-fk-liste"); if ((l && !l.classList.contains("r2-kacheln")) || $("r2FkEinst")){ r2FokusKacheln(); $("r2FkEinst")?.remove(); } })
    .observe(tab, {childList:true, subtree:true});
})();

/* ----- Schutz: zwei Reiter (john 05.11.): „Einstellbar“ (Schalter, Bild-KI) und „Was blockiert wird“ (nur ansehen, alles was gerade wirkt) ----- */
if (typeof trSchutzKarte === "function"){
  const _trSchutzR2 = trSchutzKarte;
  trSchutzKarte = function(x){
    const k = _trSchutzR2.call(this, x), kopf = k.querySelector(".tr-karte-kopf"); if (!kopf) return k;
    const immer = k.querySelector(".tr-immer"), einst = el("div","r2-sch-einst"), aktiv = el("div","r2-sch-aktiv");
    const namen = [...(immer?.querySelectorAll(".tr-fest b") || [])].map(b => b.deText);
    // eingeschaltete Schalter dazu
    k.querySelectorAll(".tr-schutz-zeile:not(.tr-fest)").forEach(z => { const sw = z.querySelector('[role="switch"]'); const t = z.querySelector("b")?.deText; if (sw?.getAttribute("aria-checked") === "true" && t) namen.push(t); });
    if (x.liste !== false) namen.unshift("Erwachsenen-Seiten (rund 973.000), auch im Inkognito-Tab");
    namen.forEach(n => { const z = el("div","r2-sch-zeile"); z.append(el("span","r2-haken","✓"), el("span", null, n)); aktiv.append(z); });
    aktiv.prepend(el("p","k-s","Das ist gerade an. Ansehen geht immer, hier lässt sich nichts ausschalten."));
    [...k.children].forEach(c => { if (c === kopf) return; if (c === immer || (c.classList?.contains("tr-immer-titel"))) { c.remove(); return; } einst.append(c); });
    const tab = store("cm.schutzTab") || "einst", leiste = el("div","chips r10-filter r2-sch-tabs"); leiste.setAttribute("role","group");
    const zeigen = t => { einst.hidden = t !== "einst"; aktiv.hidden = t !== "aktiv"; leiste.querySelectorAll("button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.t === t))); store("cm.schutzTab", t); };
    [["einst","Einstellbar"],["aktiv","Was blockiert wird"]].forEach(([t, txt]) => { const b = el("button","chip small", txt); b.type = "button"; b.dataset.t = t; b.addEventListener("click", () => zeigen(t)); leiste.append(b); });
    // Profil (john 05.11.): Porno-Schutz oder Fokus. Hochschalten sofort, zurück nur mit Timer (Server prüft)
    const pr = TR.daten?.profil;
    if (pr){
      const z = el("div","tr-schutz-zeile r2-profil"), tx = el("div");
      const frau = pr.geschlecht === "w", wer = frau ? "Frau, " : pr.geschlecht === "m" ? "Mann, " : "";
      tx.append(el("b", null, "Profil: " + wer + (pr.pornoSchutz ? "Porno-Schutz" : "Fokus")),
        el("span","k-s", pr.pornoSchutz ? "Alles gegen Pornos ist fest an." : "Fürs weniger Doomscrollen. Porno-Seiten werden nur gezählt, nicht gesperrt."));
      z.append(tx);
      // john 05.11.: Mann/Frau ist nach der Einrichtung fest (kein Umschalter mehr). Frauen-Profil: kein „Zu Fokus wechseln“.
      if (!pr.pornoSchutz){   // john 05.11. 18:51: auch bei Männern kein „Zu Fokus wechseln“
        const b = el("button", pr.pornoSchutz ? "ghost small" : "ask small", pr.pornoSchutz ? "Zu Fokus wechseln" : "Porno-Schutz einschalten"); b.type = "button";
        b.addEventListener("click", async () => { try { await api("api/profil", {ziel: pr.pornoSchutz ? "fokus" : "beides"}); toast(pr.pornoSchutz ? "Profil: Fokus." : "Porno-Schutz ist an."); trLaden(true); }
          catch (e){ toast(e.message || String(e)); } });
        z.append(b);
      }
      if (TR.daten?.entwickler && pr.geschlecht){   // john 16.11.: nur Entwicklerversion darf Mann/Frau wechseln (Server prüft ENTWICKLER)
        const g = frau ? "m" : "w", b = el("button", "ghost small", frau ? "Zu Mann wechseln" : "Zu Frau wechseln"); b.type = "button";
        b.addEventListener("click", async () => { try { await api("api/profil", {geschlecht: g}); trLaden(true); } catch (e){ toast(e.message || String(e)); } });
        z.append(b);
      }
      einst.prepend(z);
    }
    k.append(leiste, einst, aktiv); zeigen(tab);
    return k;
  };
}

/* ----- Runde 3 (eigener Durchgang 05.11.) ----- */
// Locker: eine Leiste „Gruppen | Einzelne Apps | Freischalten“ statt zwei übereinander
function r2LockerLeiste(d){
  const gruppen = lmGruppen(d.regeln || []), n = {gruppen:gruppen.filter(g => g.name).length, apps:gruppen.filter(g => !g.name).length,
    zeiten:typeof szGruppen === "function" ? szGruppen(d.regeln || []).length : 0};
  const akt = CM.tab === "frei" ? "frei" : (store("cm.lmTeil") || (n.gruppen ? "gruppen" : "apps"));
  const leiste = el("div","chips r10-filter r2-teil"); leiste.setAttribute("role","group");
  [["gruppen", `Gruppen ${n.gruppen}`],["apps", `Apps ${n.apps}`],["zeiten", `Sperrzeiten ${n.zeiten}`],["frei","Freischalten"]].forEach(([k, t]) => {
    const b = el("button","chip small", t); b.type = "button"; b.setAttribute("aria-pressed", String(akt === k));
    b.addEventListener("click", () => { if (k === "frei") CM.tab = "frei"; else { CM.tab = "apps"; store("cm.lmTeil", k); } store("cm.lockerTab", CM.tab); renderLocker(true); }); leiste.append(b); });
  return leiste;
}
if (typeof lkOffen === "function"){
  const _lkOffenR3 = lkOffen;
  lkOffen = function(d){
    const out = _lkOffenR3.call(this, d);
    for (let i = out.length - 1; i >= 0; i--) if (out[i].classList?.contains("r2-teil")) out.splice(i, 1);
    const neu = r2LockerLeiste(d), tabs = out.findIndex(x => x.classList?.contains("cm-tabs"));
    out.splice(tabs >= 0 ? tabs + 1 : 0, 0, neu);
    return out;
  };
}
// Werte › Woche: Legende unter den Balken
(function(){
  const tab = document.querySelector('.tab[data-r="werte"]'); if (!tab) return;
  new MutationObserver(() => { const w = $("week"); if (!w) return;
    document.querySelectorAll(".r2-legende").forEach(x => { if (x.previousElementSibling !== w) x.remove(); });   // #week wird umgehängt
    if (w.nextElementSibling?.classList.contains("r2-legende")) return;
    const l = el("div","r2-legende");
    [["Produktiv","var(--cm-v)"],["Neutral","rgba(255,255,255,.18)"],["Ablenkung","var(--r2-abl)"]].forEach(([t, c]) => { const s = el("span"), i = el("i"); i.style.background = c; s.append(i, t); l.append(s); });
    w.after(l); }).observe(tab, {childList:true, subtree:true});
})();
// Mehr-Blatt: Einstellungen enthalten keine Sperren mehr
if (typeof MEHR_REITER !== "undefined") MEHR_REITER.forEach(m => { if (m[0] === "einstellungen") m[2] = "Profil, Handy-App, Konto, Systemcheck"; });
// Gruppen erkennen braucht die Listen aus /api/tracking (kommen oft nach dem Locker): danach den Locker neu zeichnen
if (typeof trLaden === "function"){
  const _trLadenR3 = trLaden;
  trLaden = async function(...a){ const r = await _trLadenR3.apply(this, a); try { if (LK.daten?.offen && !$("lmDialog")?.open) renderLocker(true); } catch {} return r; };
}

/* ----- Frauen-Profil: helles Weiß-Rosa (frau.css), Klasse an <html>, beim Start aus dem letzten Stand ----- */
function r2FrauLook(){ const w = TR.daten?.profil?.geschlecht === "w"; document.documentElement.classList.toggle("r2-frau", w); store("cm.frau", w); }
if (store("cm.frau")) document.documentElement.classList.add("r2-frau");
if (typeof trLaden === "function"){ const _trLadenFrau = trLaden; trLaden = async function(...a){ const r = await _trLadenFrau.apply(this, a); try { r2FrauLook(); } catch {} return r; }; }

/* ----- Fokus: eigene Dauer mit −/+ (john 05.11.), in 5-Minuten-Schritten, 5 bis 240 Min ----- */
function r2FokusEigene(){
  const dur = $("fkDur"); if (!dur || dur.nextElementSibling?.classList.contains("r2-fk-eigen")) return;
  const z = el("div","r2-fk-eigen"), minus = el("button", null, "−"), plus = el("button", null, "+"), t = el("span", null, "Eigene Dauer");
  minus.type = plus.type = "button"; minus.setAttribute("aria-label","5 Minuten weniger"); plus.setAttribute("aria-label","5 Minuten mehr");
  const setzen = d => { FK.dur = Math.max(5, Math.min(240, Math.round((FK.dur + d) / 5) * 5)); store("cockpit.fokusMin", FK.dur); fkDurChips(); };
  minus.addEventListener("click", () => setzen(-5)); plus.addEventListener("click", () => setzen(5));
  z.append(minus, t, plus); dur.after(z);
}
(function(){
  const tab = document.querySelector('.tab[data-r="fokus"]'); if (!tab) return;
  new MutationObserver(() => r2FokusEigene()).observe(tab, {childList:true, subtree:true}); r2FokusEigene();
})();
setTimeout(() => { try { if (TR.daten) r2FrauLook(); } catch {} }, 2500);   // erstes Laden lief evtl. vor diesem Teil

/* ---------- Oberfläche aufgeräumt (john 11.11.2026): Inhaltsschutz nur noch mit Bild-KI-Einstellungen, Fokus-Profil mit einem Knopf
   zum Porno-Schutz, „Automatisch begrenzen“ mit Erklärung, „Reels, Shorts und Explore“ zieht nach Sperren um.
   Nur Anzeige: kein Schalter bekommt neue Rechte, der Server prüft weiter alles (Timer zum Lockern, Profil).
   Die Entwicklerversion bleibt, wie sie war (john schaltet dort alles frei). ---------- */
const KL_PORNO = ["bilder","texte","zeichnungen","kiBegleiter","geschichten","vpn","inApps","webcam","nurStore"];   // kommt mit dem Porno-Schutz dazu (server.py schutz_immer)
const KL_NAMEN = {bilder:"Bild-KI in Social Media", texte:"Erotische Texte", zeichnungen:"Hentai und Zeichnungen", kiBegleiter:"KI-Begleiter",
  geschichten:"Geschichten und Audio", vpn:"VPN-Erkennung", inApps:"Erwachsenes in Apps", webcam:"Zufalls-Chats", nurStore:"Nur Apps aus dem Play Store"};

const KL_OFFEN = {};   // was aufgeklappt ist, bleibt es über das Neuzeichnen nach jedem Speichern hinweg (nur bis zum Neuladen)
function klAuf(titel, name){
  const d = el("details","kx-auf kx-" + name); d.append(el("summary", null, titel)); d.open = !!KL_OFFEN[name];
  d.addEventListener("toggle", () => { KL_OFFEN[name] = d.open; });
  return d;
}

/* Bild-KI-Regel je Art (john 18.11.2026: „in einem Untermenü, das sieht niemand“): offen als Karte, zwei Knöpfe statt Auswahlliste.
   Die Knöpfe stellen nur die vorhandene Auswahlliste aus tracking.js um, gespeichert wird wie bisher (bildRegeln). */
function klRegeln(r){
  r.classList.add("kx-regelbox");
  const t = r.querySelector(":scope > b"), u = r.querySelector(":scope > .k-s");
  if (t) t.textContent = "Wann greift die Bild-KI ein?";
  if (u) u.textContent = "Nacktheit immer sofort. Beim Rest wählst du selbst.";
  r.querySelectorAll(".tr-zeile").forEach(z => {
    const sel = z.querySelector("select"); if (!sel) return;
    const wahl = el("div","kx-wahl"); wahl.setAttribute("role","group"); wahl.setAttribute("aria-label", sel.getAttribute("aria-label") || "");
    [["weg","Sofort","schon beim 1. Bild"],["zweiter","Beim 2. Mal","2. Bild in 15 Sek."]].forEach(([v, name, sub]) => {
      const b = el("button","fs-modus-k" + (sel.value === v ? " an" : "")); b.type = "button"; b.setAttribute("aria-pressed", String(sel.value === v));
      b.append(el("b", null, name), el("span", null, sub));
      b.addEventListener("click", e => { e.preventDefault(); if (sel.value === v) return; sel.value = v; sel.dispatchEvent(new Event("change")); });
      wahl.append(b);
    });
    sel.hidden = true; z.className = "kx-regel"; z.append(wahl);   // nicht mehr tr-zeile: android.js macht dort aus jedem Knopf eine Pille
  });
  r.append(el("p","kx-regelfuss","Ein Mann mit freiem Oberkörper gilt als okay."));
  return r;
}

function klSchutz(k, x){
  const einst = k.querySelector(".r2-sch-einst"), aktiv = k.querySelector(".r2-sch-aktiv"), leiste = k.querySelector(".r2-sch-tabs"), hero = k.querySelector(".fs-hero");
  if (!einst || !aktiv || !leiste || !hero || TR.daten?.entwickler) return k;
  k.classList.add("kx-schutz");
  x = x || TR.daten?.schutz || {};
  const porno = (x.profil || TR.daten?.profil)?.pornoSchutz !== false;   // Profil kommt mit dem Schutz vom Server (schutz_handy)
  const zeile = key => einst.querySelector(`.tr-schutz-zeile[data-key="${key}"]`);
  // Kopf: ein Satz. Die Liste „Was blockiert wird“ klappt beim Tippen auf die Karte auf, der Umschalter fällt weg.
  const satz = k.querySelector(".tr-karte-kopf .k-s");
  if (satz) satz.textContent = porno ? "Der Grundschutz ist immer an und lässt sich nicht ausschalten." : "Der Porno-Schutz ist aus. Porno-Seiten werden nur gezählt, nicht gesperrt.";
  [...aktiv.querySelectorAll(".r2-sch-zeile")].forEach(z => { if (/^✓?\s*Bild-KI: Sicher-Modus/.test(z.deText)) z.remove(); });   // ein Modus, keine Schutz-Ebene
  const n = aktiv.querySelectorAll(".r2-sch-zeile").length, tx = hero.querySelector("div:not(.fs-schild)");
  if (tx){ tx.querySelector("b").textContent = `${n} Schutz-Ebene${n === 1 ? "" : "n"} aktiv`; tx.querySelector("span").textContent = "Antippen: was alles gesperrt ist"; }
  leiste.hidden = true; einst.hidden = false; aktiv.hidden = !KL_OFFEN.liste;
  hero.setAttribute("role", "button"); hero.tabIndex = 0; hero.setAttribute("aria-expanded", String(!aktiv.hidden)); hero.classList.toggle("kx-offen", !aktiv.hidden); hero.append(el("span","kx-pfeil","›"));
  const klapp = () => { aktiv.hidden = !aktiv.hidden; KL_OFFEN.liste = !aktiv.hidden; hero.setAttribute("aria-expanded", String(!aktiv.hidden)); hero.classList.toggle("kx-offen", !aktiv.hidden); };
  hero.addEventListener("click", klapp); hero.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " "){ e.preventDefault(); klapp(); } });
  hero.after(aktiv);
  einst.querySelector(".r2-profil")?.remove();   // der Knopf steht jetzt in der Karte unten
  zeile("kurzvideos")?.remove();                 // kein Schutz: steht unter Sperren (klKurzvideos)

  const oben = [];
  const modus = einst.querySelector(".fs-modus"), video = zeile("bilderVideo"), regeln = einst.querySelector(".tr-bildregeln");
  if (porno){
    // Einstellbar bleibt nur die Bild-KI, weil sie noch lernt
    const titel = el("div","kx-titel","Bild-KI"); titel.append(el("span","kx-beta","Beta")); oben.push(titel);
    if (modus){ modus.querySelector("b").textContent = "Wie genau soll sie schauen?"; modus.querySelector(":scope > div > .k-s")?.remove(); oben.push(modus); }
    if (video){ video.querySelector("b").textContent = "Auch auf YouTube, Netflix und Twitch"; video.querySelector(".k-s").textContent = "Die Bild-KI schaut dort mit. Netflix zeigt oft nur Schwarz, dann sieht sie nichts."; oben.push(video); }
    oben.push(el("p","kx-hinweis","Die Bild-KI lernt noch und liegt manchmal daneben."));
    if (regeln) oben.splice(1, 0, klRegeln(regeln));   // john 18.11.: nicht mehr zugeklappt, gleich oben unter „Bild-KI“
  } else {
    // Fokus-Profil: statt einzelner Schalter eine Karte mit einem Knopf. Was schon an ist, bleibt unter „Weitere Einstellungen“ sichtbar.
    // Bild-KI-Zeilen nur weg, wenn sie aus sind: was an ist, muss erreichbar bleiben (Ausschalten nach dem Timer)
    if (!x.bilderVideo) video?.remove();
    if (!x.bilder){ modus?.remove(); regeln?.remove(); }
    KL_PORNO.forEach(key => { if (!x[key]) zeile(key)?.remove(); });
    const karte = el("div","kx-porno"), liste = el("div","kx-chips"), knopf = el("button","ask cm-violett kx-knopf","Porno-Schutz einschalten"); knopf.type = "button";
    KL_PORNO.forEach(key => liste.append(el("span", null, KL_NAMEN[key])));
    const tun = async () => { knopf.disabled = true;
      try { await api("api/profil", {ziel:"beides"}); } catch (e){ toast(e.message || String(e)); knopf.disabled = false; return; }
      toast("Porno-Schutz ist an.");
      if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {});   // am Handy sofort scharf, nicht erst beim nächsten Abgleich
      try { await trLockerKarten(); } catch {}   // lädt neu und zeichnet auch die offene Seite neu
    };
    typeof lkZweimal === "function" ? lkZweimal(knopf, "Sicher? Er bleibt dann an", tun) : knopf.addEventListener("click", tun);
    karte.append(el("b", null, "Auch Schutz vor Pornos?"), el("p", null, "Ein Knopf schaltet alles dazu:"), liste, knopf,
      el("small", null, "Einmal an, bleibt er an. Zurück zum Fokus-Profil geht dann nicht mehr."));
    oben.push(karte);
  }
  // Alles Übrige (DNS, Computer, Ausnahmen): zugeklappt
  const rest = [...einst.children].filter(c => !oben.includes(c) && !oben.some(o => o.contains(c)));
  einst.replaceChildren(...oben);
  if (rest.length){ const d = klAuf("Weitere Einstellungen", "mehr"); d.append(...rest); einst.append(d); }
  return k;
}
if (typeof trSchutzKarte === "function"){
  const klSchutzAlt = trSchutzKarte;
  trSchutzKarte = function(x){ return klSchutz(klSchutzAlt.call(this, x), x); };
}

/* „Automatisch begrenzen“: Stand oben, darunter in drei Schritten, wie es läuft. Offene Entscheidungen (r10-regul-offen) bleiben, wie sie sind.
   r10RegulKarte steht in release10.js in einem if-Block und lässt sich von hier nicht ersetzen, darum wird die fertige Karte nach dem Zeichnen umgebaut. */
function klRegul(){
  if (TR.daten?.entwickler) return;
  document.querySelectorAll(".r10-regulkarte:not(.kx-regul)").forEach(k => {
    const r = TR.daten?.regulierung || {offen:[], erledigt:[]}, min = r.schwelle?.minuten || 60, oft = r.schwelle?.oeffnen || 20;
    k.classList.add("kx-regul");
    const satz = k.querySelector(".tr-karte-kopf .k-s"); if (satz) satz.textContent = "BlockEm merkt selbst, was dir zu viel Zeit frisst, und setzt dort eine Grenze.";
    const zus = k.querySelector(".tr-karte-kopf .r4-zus"); if (zus) zus.textContent = "Setzt von selbst eine Grenze, wo dir Social Media oder Streaming zu viel Zeit frisst";
    const alt = k.querySelector(":scope > p.k-s");   // „Gerade nichts auffällig“ oder „Zuletzt geregelt: …“
    if (alt){
      const stand = el("div","kx-stand"), tx = el("div"), leer = !r.erledigt?.length;
      tx.append(el("b", null, leer ? "Gerade nichts auffällig" : "Zuletzt begrenzt"), el("span", null, leer ? "BlockEm schaut jeden Tag nach." : alt.deText.replace(/^Zuletzt geregelt:\s*/, "")));
      stand.append(el("i", null, "✓"), tx); alt.replaceWith(stand);
    }
    const wie = el("div","kx-wie"); wie.append(el("b","kx-titel","So funktioniert es"));
    // Zahlen wie server.py REGUL_STD / regul_kandidaten: Schnitt der letzten 3 Tage, nur Social Media und Streaming, 48 Std. Frist, dann 60 Min
    [["BlockEm zählt mit", "Wie lange und wie oft du Social Media und Streaming am Tag öffnest."],
     ["Zu viel in den letzten 3 Tagen", `Im Schnitt ab ${min} Minuten oder ${oft}-mal Öffnen am Tag.`],
     ["Die App bekommt eine Grenze", "Du wählst, wie: Tageslimit, Zahl der Öffnungen oder Sperrzeit. Wählst du 48 Stunden lang nicht, setzt BlockEm 60 Minuten am Tag."]]
      .forEach(([t, u], i) => { const s = el("div","kx-schritt"), d = el("div"); d.append(el("b", null, t), el("span", null, u)); s.append(el("i", null, String(i + 1)), d); wie.append(s); });
    k.append(wie);
  });
}
if (typeof trLockerKarten === "function"){
  const klTlkAlt = trLockerKarten;
  trLockerKarten = async function(...a){ const r = await klTlkAlt.apply(this, a); try { klRegul(); } catch {} return r; };
}

/* „Reels, Shorts und Explore sperren“ unter Sperren (john: kein Schutz, sondern eine Sperre). Gleicher Schalter, gleiche Server-Regel (Ausschalten nur nach dem Timer). */
function klKurzvideos(){
  const box = $("locker"), x = TR.daten?.schutz; if (!box) return;
  if (box.querySelector(".kx-kurz [data-laeuft]")) return;   // gerade angetippt: nicht mit dem alten Stand neu bauen
  box.querySelector(".kx-kurz")?.remove();
  const neu = box.querySelector(".cm-neu"); if (!neu || !x || TR.daten?.entwickler) return;   // nur in den Listen-Ansichten, nicht bei „Freischalten“
  const z = el("div","tr-schutz-zeile kx-kurz"), tx = el("div");
  tx.append(el("b", null, "Reels, Shorts und Explore sperren"), el("span","k-s","In den Apps und im Browser. Der Rest der App bleibt offen."));
  z.append(tx, trSchalter(!!x.kurzvideos, async v => { try { const r = await api("api/schutz", {kurzvideos:v}); TR.daten.schutz = r.schutz; toast("Gespeichert."); if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {}); } catch (e){ toast(e.message || String(e)); return false; } }, "Reels, Shorts und Explore sperren"));
  neu.after(z);
}
if (typeof renderLocker === "function" && typeof trSchalter === "function"){
  const klLockerAlt = renderLocker;
  renderLocker = function(...a){ const r = klLockerAlt.apply(this, a); try { klKurzvideos(); } catch {} return r; };
}

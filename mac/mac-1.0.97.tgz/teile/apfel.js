/* ---------- BlockEm 1.0.20: Locker, Werte und Einstellungen im Apple-Stil (john 04.11.: „wie ein Chef-Designer von Apple“) ----------
   Regeln: eine Ebene (gruppierte Listen, keine Kästen in Kästen), Zeilen mit Symbol, Titel, Wert und Pfeil,
   Unterseiten öffnen sich als eigene Seite mit „‹ Zurück“ statt aufzuklappen. Heute und Fokus bleiben unverändert.
   Aussehen in apfel.css, alles nur in der Tracking-App (html.nur-tracking). */
const AP = {karte:null, titel:"", platz:null, scroll:0};
const apAn = () => document.documentElement.classList.contains("nur-tracking");

/* ----- Locker: Regeln als Listenzeilen (statt Karte mit vier Kästchen) ----- */
function apRegelZeilen(){
  document.querySelectorAll("#locker .lm-karte:not([data-ap])").forEach(k => {
    k.dataset.ap = "1";
    const teile = [...k.querySelectorAll(".lm-wert:not(.aus)")].map(w => {
      const l = w.querySelector("span, small")?.deText.trim() || "", v = w.querySelector("b")?.deText.trim() || "";
      return v && v !== "–" ? (l ? `${l} ${v}` : v) : "";
    }).filter(Boolean);
    const fuss = k.querySelector(".lm-fuss")?.deText.trim();
    if (fuss) teile.push(fuss);
    const z = el("span","ap-zus", teile.join(" · "));
    (k.querySelector(".lm-titel") || k).append(z);
  });
}

/* ----- Locker: Schutz, Nachfrage, „regelt mit“, Orts-Sperre öffnen als eigene Seite ----- */
function apSeiteBox(){
  let s = $("apSeite"); if (s) return s;
  s = el("div","ap-seite"); s.id = "apSeite"; s.hidden = true;
  const kopf = el("div","ap-seite-kopf"), zur = el("button","ap-zurueck","‹ Locker"); zur.type = "button";
  zur.addEventListener("click", () => history.state?.apSeite ? history.back() : apSchliessen());
  kopf.append(zur);
  const t = el("h1","ap-seite-titel"); t.id = "apSeiteTitel";
  const inhalt = el("div","ap-seite-inhalt"); inhalt.id = "apSeiteInhalt";
  s.append(kopf, t, inhalt); document.body.append(s);
  return s;
}
function apTitel(k){ return (k.querySelector(".tr-karte-kopf b")?.deText || "").trim(); }
function apOeffnen(k){
  const s = apSeiteBox(); AP.scroll = window.scrollY;
  AP.titel = apTitel(k); $("apSeiteTitel").textContent = AP.titel;
  apEinsetzen(k);
  s.hidden = false; s.scrollTop = 0; document.documentElement.classList.add("ap-seite-offen");
  try { history.pushState({...(history.state || {}), apSeite:1}, ""); } catch {}
}
function apEinsetzen(k){
  if (AP.karte && AP.karte !== k && AP.platz?.parentNode){ AP.karte.classList.add("cm-zu"); AP.platz.replaceWith(AP.karte); }
  AP.platz = document.createComment("ap"); k.replaceWith(AP.platz);
  AP.karte = k; k.classList.remove("cm-zu"); k.classList.add("ap-offen");
  $("apSeiteInhalt").replaceChildren(k);
}
function apSchliessen(){
  const s = $("apSeite"); if (!s || s.hidden) return;
  if (AP.karte){ AP.karte.classList.add("cm-zu"); AP.karte.classList.remove("ap-offen"); if (AP.platz?.parentNode) AP.platz.replaceWith(AP.karte); }
  AP.karte = AP.platz = null; AP.titel = "";
  s.hidden = true; document.documentElement.classList.remove("ap-seite-offen");
  window.scrollTo({top:AP.scroll, behavior:"instant"});
}
// Nach jedem Neuzeichnen (z. B. Schalter umgelegt): offene Seite mit der frischen Karte füllen
function apAuffrischen(){
  if (!AP.titel || $("apSeite")?.hidden) return;
  const neu = [...document.querySelectorAll("#trLockerKarten .tr-karte")].find(k => apTitel(k) === AP.titel);
  if (!neu) return;
  const y = $("apSeite").scrollTop;
  AP.karte = null; AP.platz = null;   // die alte Karte gibt es nicht mehr
  apEinsetzen(neu); $("apSeite").scrollTop = y;
}
window.addEventListener("popstate", () => apSchliessen());
document.addEventListener("click", e => {
  if (!apAn()) return;
  const kopf = e.target.closest("#trLockerKarten .tr-karte-kopf"); if (!kopf) return;
  if (e.target.closest("button:not(.cm-pfeil), input, label, a, select, textarea")) return;   // Schalter im Kopf bleiben Schalter
  e.preventDefault(); e.stopPropagation();
  apOeffnen(kopf.closest(".tr-karte"));
}, true);
if (typeof trLockerKarten === "function"){
  const _apTlk = trLockerKarten;
  trLockerKarten = async function(...a){ const r = await _apTlk.apply(this, a); if (apAn()){ apAuffrischen(); apGruppenTitel(); } return r; };
}
// Überschriften über den Gruppen (wie in iOS-Einstellungen)
function apGruppenTitel(){
  const box = $("trLockerKarten"); if (!box || box.previousElementSibling?.classList.contains("ap-gruppe-titel")) return;
  box.before(el("p","ap-gruppe-titel","Mehr Schutz"));
}
if (apAn()){
  new MutationObserver(() => apRegelZeilen()).observe(document.body, {childList:true, subtree:true});
  apRegelZeilen();
}

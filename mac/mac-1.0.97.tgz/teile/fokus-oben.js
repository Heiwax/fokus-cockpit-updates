/* 19.11.2026: Fokus-Seite ruhiger (john). Oben die Start-Karte (fokus-oben.css ordnet Kristall, −/+, Dauer, Start an),
   darunter zwei Zeilen wie auf Weg: „Was ist zu?“ und „Auswertung“, die beim Antippen aufklappen. Die Inhalte bleiben dieselben
   Elemente (#cmFkSperre, #fkAusBox) mit ihrer Logik; sie werden nur in die Klappen umgehängt. */
const FO = {offen:store("fo.offen") || {}};
function foZeile(key, ico, titel, panelInhalt){
  const z = el("button","fo-zeile"), p = el("div","fo-panel"), wert = el("span","fo-wert");
  z.type = "button"; z.dataset.fo = key; p.id = "foPanel-" + key; z.setAttribute("aria-controls", p.id);
  z.append(el("span","fo-ico", ico), el("span", null, titel), wert, el("span","fo-pfeil","›"));
  const setze = an => { p.hidden = !an; z.setAttribute("aria-expanded", String(an)); };
  setze(!!FO.offen[key]);
  z.addEventListener("click", () => { const an = p.hidden; setze(an); FO.offen[key] = an; store("fo.offen", FO.offen); });
  if (panelInhalt) p.append(panelInhalt);
  return [z, p];
}
function foWerte(){
  const l = $("foListe"); if (!l) return;
  const pressed = [...document.querySelectorAll("#cmFkSperre .s17-fk button[aria-pressed=true], #cmFkSperre .s17-fk .chip.an")].map(b => b.deText.trim());
  const apps = document.querySelectorAll("#cmFkSperre .r2-kachel:not(.aus)").length;
  const zu = pressed.includes("Alles") ? "Alles" : [...pressed, ...(apps ? [`${apps} App${apps === 1 ? "" : "s"}`] : [])].join(", ") || "Nichts gewählt";
  const a = FK.data?.auswertung, aus = a?.heute?.sessions ? `Heute ${minText(a.heute.produktiv)}` : a?.woche?.sessions ? `Woche ${minText(a.woche.produktiv)}` : "Noch keine";
  const set = (k, t) => { const w = l.querySelector(`[data-fo="${k}"] .fo-wert`); if (w && w.deText !== t) w.textContent = t; };
  set("zu", zu); set("aus", aus);
}
function foBauen(){
  const tab = document.querySelector('.tab[data-r="fokus"]'), box = $("fokusBox"); if (!tab || !box) return;
  let l = $("foListe");
  if (!l){ l = el("section","fo-liste"); l.id = "foListe"; l.append(...foZeile("zu", "🔒", "Was ist zu?"), ...foZeile("aus", "📊", "Auswertung")); }
  if (l.parentElement !== box || l.nextElementSibling) box.append(l);   // in #fokusBox, damit die Chip-/Kachel-Stile (#fokusBox …) weiter greifen
  const sp = $("cmFkSperre"), pz = $("foPanel-zu"); if (sp && sp.parentElement !== pz) pz.append(sp);
  const au = $("fkAusBox"), pa = $("foPanel-aus"); if (au && au.parentElement !== pa) pa.append(au);
  foWerte();
}
(function(){
  const tab = document.querySelector('.tab[data-r="fokus"]'); if (!tab) return;
  let wartet = false;
  new MutationObserver(() => { if (wartet) return; wartet = true; requestAnimationFrame(() => { wartet = false; foBauen(); }); }).observe(tab, {childList:true, subtree:true, attributes:true, attributeFilter:["aria-pressed","class"]});
  foBauen();
})();

/* ---------- Geräte & Konto (1.0.18, john 04.11.2026: „voll kompliziert, das zu verbinden“) ----------
   Eine Seite statt fünf Speicherorte: oben das Konto, darunter deine Geräte. Ein weiteres Gerät meldet sich einfach mit E-Mail + Passwort an,
   QR-Code / 12-Zeichen-Code nur noch als Option „Ohne Passwort verbinden“. Google Drive, eigener Computer, Online-Server unter „Andere Wege“
   (dann die alte Seite aus speicherort.js + sync-wege.js). Sonderfälle (Handy hängt am Mac, Drive aktiv, Dienst nicht erreichbar) zeigen auch die alte Seite. */
const GK = {art:"anmelden", alt:false, kontoGeholt:false, email:"", pw:"", code:""};
function gkName(){
  try { const n = window.CockpitApp?.geraet?.(); if (n) return String(n).slice(0, 40); } catch {}
  return SYNC.name || SYNC.st?.geraetName || (VB.modus === "handy" ? "Handy" : /Win/.test(navigator.platform) ? "Windows-PC" : "Mac");
}
const gkAlteSeite = () => { const st = SYNC.st, jetzt = ortJetzt();
  return GK.alt || !st || !st.dienstDa || (VB.inApp && jetzt !== "handy") || (st.art === "drive" && st.an); };

// 18.11.2026 (john: „wird nirgendwo erklärt“): derselbe Weg in der Einrichtung und unter Geräte & Konto
function gkWeg(hatKonto){
  const ol = el("ol","gk-weg");
  [...(hatKonto ? [] : [["Konto anlegen", "Einmal, mit E-Mail und Passwort."]]),
    ["BlockEm auf dem anderen Gerät installieren", "Handy, Tablet, Mac oder Windows-PC."],
    ["Dort „Ich habe schon ein Konto“ antippen", "Gleiche E-Mail, gleiches Passwort. Deine Regeln kommen mit."]]
    .forEach(([t, s]) => { const li = el("li"); li.append(el("b", null, t), el("small", null, s)); ol.append(li); });
  return ol;
}

const _gkRender = renderSpeicherort;
renderSpeicherort = function(){
  const box = $("ortBox"); if (!box || !S.plan) return;
  if (ortJetzt() !== "server"){ const i = ORT_ARTEN.findIndex(a => a.k === "server"); if (i >= 0) ORT_ARTEN.splice(i, 1); }   // john 04.11.: keinen Online-Server mehr
  box.classList.remove("gk");
  if (gkAlteSeite()){
    _gkRender();
    if (GK.alt) box.prepend(eiKnopf("‹ Zurück zu Geräte & Konto","ghost small gk-zurueck", () => { GK.alt = false; ORT.wahl = null; kpStop(); SW.kp = null; renderSpeicherort(); }));
    return;
  }
  const st = SYNC.st, jetzt = ortJetzt(), teile = [];
  box.classList.add("gk");
  if (SYNC.code){ teile.push(syncDetail(el("div","ort-detail"), jetzt, VB.inApp)); box.replaceChildren(...teile); return; }   // Notfall-Code genau einmal zeigen
  if (st.an) teile.push(...gkKonto(st, jetzt)); else teile.push(...gkAnmelden(st, jetzt));
  if (ORT.meldung) teile.push(el("p", "ort-meldung " + (ORT.meldung.gut ? "gut" : "schlecht"), ORT.meldung.text));
  if (ORT.laeuft) teile.push(el("p","ort-laeuft", ORT.laeuft));
  const andere = el("details","more gk-andere");
  andere.append(el("summary", null, "Andere Wege"), el("p","k-s", st.an ? "Alles nur auf diesem Gerät, ohne Konto."
    : "Alles nur auf diesem Gerät" + (swEntw() ? " oder der Mac als Zentrale (nur Entwicklerversion)." : ".")),
    eiKnopf("Andere Wege zeigen","ghost small md-text", () => { GK.alt = true; ORT.wahl = null; ORT.meldung = null; renderSpeicherort(); }));
  teile.push(andere);
  box.replaceChildren(...teile);
  if (VB.inApp && window.CockpitApp?.entwicklerReset){ if (swEntw() || swEntwFrei()) box.append(swEntwReset()); else swEntwTipp(box); }
};

// Angemeldet: Konto, Geräte, neues Gerät dazu
function gkKonto(st, jetzt){
  const out = [], k = el("div","gk-karte");
  k.append(el("h3","ort-h","Dein Konto"), el("p", null, st.email || ""),
    el("p","k-s", (st.proBis ? `Pro bis ${new Date(st.proBis).toLocaleDateString("de-DE")} · ` : "") + `abgeglichen ${syncZeit(st.zuletzt)}`));   // john 05.11.: aufgeräumt, das Gerät steht unten in der Liste
  if (st.fehler) k.append(el("p","ort-meldung schlecht", st.fehler));
  k.append(eiKnopf(ORT.laeuft ? "…" : "Jetzt abgleichen","ghost small md-text", () => syncAktion({aktion:"jetzt"}, "Gleiche ab …")));
  // 18.11.2026 (john: „macht keinen Sinn, warum es dort ist“): kein Knopf „Apps dazunehmen“ mehr hier. Die Frage kommt direkt nach dem Anmelden, weitere Apps später unter Sperre.
  out.push(k);
  const g = el("div","gk-karte");
  g.append(el("h3","ort-h","Deine Geräte"));
  if (!SYNC.konto && !GK.kontoGeholt){ GK.kontoGeholt = true; api("api/sync", {aktion:"konto"}).then(r => { SYNC.st = r; SYNC.konto = r.konto || null; renderSpeicherort(); }).catch(() => {}); }
  if (SYNC.konto?.geraete?.length){
    const ul = el("ul","sync-geraete");
    SYNC.konto.geraete.forEach(x => {
      const li = el("li"); li.append(el("span", null, x.name + (x.dieses ? " (dieses Gerät)" : "")), el("span","k-s", "zuletzt " + syncZeit(x.zuletzt)));
      if (!x.dieses) li.append(eiKnopf("Entfernen","ghost small md-text", () => { if (confirm(`„${x.name}“ abmelden? Das Gerät behält seine Daten und Sperren, gleicht aber nicht mehr ab.`)) syncAktion({aktion:"geraetEntfernen", id:x.id}, "Entferne …").then(() => { GK.kontoGeholt = false; SYNC.konto = null; renderSpeicherort(); }); }));
      ul.append(li);
    });
    g.append(ul);
  } else g.append(el("p","k-s","Lade …"));
  out.push(g);
  const n = el("div","gk-karte");
  n.append(el("h3","ort-h","Neues Gerät dazu"),
    gkWeg(true));
  const kp = kpBereich(); kp.querySelector("summary").textContent = "Ohne Passwort verbinden (QR-Code oder Code)";
  n.append(kp); out.push(n);
  // Passwort ändern, Abmelden, Konto löschen: aus der bisherigen Seite übernehmen
  const tmp = el("div"); _swSyncDetail(tmp, jetzt, VB.inApp);
  tmp.querySelectorAll(":scope > details.more").forEach(d => { if (!d.classList.contains("kp-bereich")) out.push(d); });
  return out;
}

// Nicht angemeldet: anmelden (Standard), neues Konto, Passwort vergessen
function gkAnmelden(st, jetzt){
  const out = [], k = el("div","gk-karte");
  k.append(el("p","k-s gk-jetzt", jetzt === "handy" ? "Gerade liegt alles nur auf diesem Handy." : "Gerade liegt alles auf diesem Computer."),
    el("h3","ort-h","BlockEm auf mehreren Geräten"),
    el("p", null, "Mit einem Konto gelten deine Regeln auf allen Geräten. Verschlüsselt, wir können nichts lesen."), gkWeg(false));
  out.push(k);
  const f2 = el("div","gk-karte");
  if (st.abgemeldet) f2.append(el("p","ort-meldung schlecht","Dieses Gerät wurde abgemeldet, zum Beispiel weil das Passwort neu gesetzt wurde. Bitte melde dich neu an."));
  const arten = el("div","chips"); arten.setAttribute("role","group");
  [["anmelden","Ich habe ein Konto"],["neu","Neues Konto"]].forEach(([k, t]) => {
    const c = el("button","chip", t); c.type = "button"; c.setAttribute("aria-pressed", String(GK.art === k || (k === "anmelden" && GK.art === "notfall")));
    c.addEventListener("click", () => { GK.art = k; ORT.meldung = null; renderSpeicherort(); }); arten.append(c);
  });
  f2.append(arten);
  const f = el("form","ort-form");
  const [ze, ie] = syncFeld("E-Mail","email", GK.email || st.email,"du@beispiel.de", v => GK.email = v); ie.autocomplete = "email"; f.append(ze);
  if (GK.art === "notfall"){ const [z] = syncFeld("Notfall-Code","text", GK.code,"XXXXX-XXXXX-…", v => GK.code = v); f.append(z); }
  const [zp, ip] = syncFeld(GK.art === "anmelden" ? "Passwort" : "Neues Passwort","password","", GK.art === "anmelden" ? "" : "mindestens 10 Zeichen", v => GK.pw = v);
  if (GK.art !== "anmelden") ip.autocomplete = "new-password";
  f.append(zp);
  f.append(el("p","k-s", GK.art === "neu" ? "Danach bekommst du einen Notfall-Code. Er ist der einzige Weg zurück, wenn du dein Passwort vergisst. 7 Tage gratis, danach gehört das Konto zu Pro."
    : GK.art === "notfall" ? "Mit dem Notfall-Code setzt du ein neues Passwort. Alle anderen Geräte werden abgemeldet und brauchen das neue Passwort."
    : "Was schon auf diesem Gerät liegt, bleibt erhalten."));
  const ok = el("button","ask", ORT.laeuft || (GK.art === "neu" ? "Konto anlegen" : GK.art === "notfall" ? "Neues Passwort setzen" : "Anmelden")); ok.type = "submit"; ok.disabled = !!ORT.laeuft;
  f.append(ok);
  f.addEventListener("submit", e => {
    e.preventDefault(); const pw = GK.pw; GK.pw = "";
    syncAktion({aktion: GK.art === "neu" ? "registrieren" : GK.art, adresse: st.adresse || "", email: GK.email || st.email, passwort: pw, code: GK.code, geraet: gkName()},
      VB.modus === "handy" ? "Erzeuge die Schlüssel, das dauert im Handy bis zu 30 Sekunden …" : "Erzeuge die Schlüssel …").then(() => { GK.kontoGeholt = false; SYNC.konto = null; renderSpeicherort();
        if (GK.art === "anmelden" && SYNC.st?.an && typeof stHierApps === "function") stHierApps(() => $("stDialog")?.close()); });   // 17.11.: auch hier (Mac mit fertiger Einrichtung) fragen, was man hier noch nutzt
  });
  f2.append(f);
  const unten = el("div","sw-zwei");
  if (GK.art !== "neu") unten.append(eiKnopf(GK.art === "notfall" ? "Doch normal anmelden" : "Passwort vergessen?","ghost small md-text", () => { GK.art = GK.art === "notfall" ? "anmelden" : "notfall"; renderSpeicherort(); }));
  f2.append(unten); out.push(f2);
  // Ohne Passwort: QR-Code oder Code vom anderen Gerät
  const ohne = el("details","more gk-karte"); ohne.open = SW.kp?.art === "dienst";
  ohne.append(el("summary", null, "Ohne Passwort verbinden (QR-Code oder Code)"));
  ohne.addEventListener("toggle", () => { if (ohne.open && SW.kp?.art !== "dienst"){ SW.kp = {modus:"zeigen", art:"dienst"}; renderSpeicherort(); } else if (!ohne.open && SW.kp){ kpStop(); SW.kp = null; } });
  if (SW.kp?.art === "dienst") ohne.append(kpNeuesGeraet("dienst"));
  out.push(ohne);
  return out;
}

/* ---------- App Locker: feste Sperrzeiten und Tageslimits, Einstellungen nur mit PIN (Locker-Reiter) ---------- */
const LK = {daten:null, token:"", art:"zeit", tage:new Set([0,1,2,3,4]), geraete:new Set(), geladen:0, apps:new Set(), extra:[], von:"09:00", bis:"17:00", min:"30", pause:"30", neuePin:"", bearbeiten:null};
const LK_TAGE = ["Mo","Di","Mi","Do","Fr","Sa","So"];
// Fenster-Titel und Systemkram gehören nicht zu den Vorschlägen oben, sie landen unter „Weitere Fenster“
const LK_SYSTEM = ["loginwindow","pixel launcher","einstellungen","unbekannt","finder","terminal","rechner","google play-dienste","google play store","neuer tab","alarmy","kalender","fotos","systemeinstellungen"];
async function lkLaden(){ try { LK.daten = await api("api/locker" + (LK.token ? "?token=" + LK.token : "")); if (!LK.daten.offen) LK.token = ""; } catch {} LK.geladen = Date.now(); renderLocker(true); }
async function lkAktion(body){
  LK.fehler = "";
  try { const r = await api("api/locker", {...body, token:LK.token}); LK.token = r.token || ""; LK.daten = r; if (r.neuePin) LK.neuePin = r.neuePin; renderLocker(true); return true; }
  catch (e){ LK.fehler = e.message || String(e); renderLocker(true); try { alert(LK.fehler); } catch {} return false; }
}
function lkTageText(t){
  t = [...(t || [])].sort();
  if (t.length === 7) return "täglich";
  if (t.join() === "0,1,2,3,4") return "Mo–Fr";
  if (t.join() === "5,6") return "am Wochenende";
  return t.map(i => LK_TAGE[i]).join(", ");
}
function lkRegelText(r){
  const wo = r.geraete?.length ? r.geraete.join(", ") : "alle Geräte";
  if (r.art === "bis") return r.satz || `bis ${r.endeText} (abgelaufen)`;
  if (r.art === "sitzung") return `höchstens ${r.minuten} Min am Stück, dann ${r.pause} Min Pause (${lkTageText(r.tage)}) · ${wo}`;
  if (r.art === "oeffnen") return `höchstens ${r.anzahl}-mal am Tag öffnen (${lkTageText(r.tage)}) · ${wo}`;
  return r.art === "zeit" ? `${lkTageText(r.tage)} von ${r.von} bis ${r.bis} gesperrt · ${wo}` : `höchstens ${r.minuten} Min am Tag (${lkTageText(r.tage)}) · ${wo}`;
}
function lkPinGruppen(p){ return String(p).replace(/(\d{4})(?=\d)/g, "$1 "); }
function lkPinForm(text, knopf, feld, neu){
  const f = el("form","add lk-pin"), feldNeu = t => { const i = el("input"); i.type = "password"; i.inputMode = "numeric"; i.autocomplete = "off"; i.placeholder = t; i.setAttribute("aria-label", t); return i; };
  const inp = feldNeu(text), b = el("button", null, knopf); b.type = "submit";
  // Neue PIN: zweites Feld statt prompt(), weil prompt/alert in der Handy-App nichts anzeigen
  const noch = neu ? feldNeu("Noch einmal") : null;
  f.append(...[inp, noch, b].filter(Boolean));
  f.addEventListener("submit", async ev => { ev.preventDefault(); const v = inp.value.replace(/\D/g, ""); if (!v) return;
    if (noch && noch.value.replace(/\D/g, "") !== v){ LK.fehler = "Die beiden PINs sind nicht gleich."; renderLocker(true); return; }
    b.disabled = true; await lkAktion({[feld]: v}); b.disabled = false; });
  return f;
}
function renderLocker(erzwingen){
  const box = $("locker"); if (!box) return;
  if (!erzwingen && box.contains(document.activeElement)) return;   // nicht beim Tippen neu zeichnen
  $("lockerBox").hidden = S.mode !== "lokal"; if (S.mode !== "lokal") return;
  if (!LK.daten || Date.now() - LK.geladen > 60000){ if (!LK.laedt){ LK.laedt = true; lkLaden().finally(() => LK.laedt = false); } if (!LK.daten) return; }
  const d = LK.daten, teile = [];
  $("lockerSub").textContent = !d.pinGesetzt && !d.ohnePin ? "noch keine PIN" : !d.an ? "ausgeschaltet" : `${d.anzahl} Regel${d.anzahl === 1 ? "" : "n"}`;
  if (LK.neuePin){ box.replaceChildren(lkNeuePin()); return; }
  if (window.CockpitApp?.ios){   // iPhone: Regeln fürs iPhone legt man in der App an (Apple verrät keine App-Namen), Mac-Regeln gelten dort nicht
    const b = el("button","ask small","Sperrzeiten und Limits auf diesem iPhone …"); b.type = "button";
    b.addEventListener("click", () => window.CockpitApp.sperreEinrichten());
    teile.push(el("p","hint kon-hint","Für dieses iPhone wählst du Apps und Regeln in Apples Dialog. Die Regeln hier unten gelten für Mac und Android-Handys."), b);
  }
  if (d.offline) teile.push(el("p","hint kon-hint","Ohne Verbindung zum Mac: Du kannst den Locker trotzdem öffnen und ändern. Die Änderungen gelten sofort auf diesem Handy und gehen zum Mac, sobald er wieder erreichbar ist."));
  if (LK.fehler) teile.push(el("p","k-s c-bad", LK.fehler));
  if (d.jetzt?.length) teile.push(el("p","k-s c-bad", "Gerade gesperrt: " + d.jetzt.join(" · ")));
  if (d.fokus){
    teile.push(el("p","hint kon-hint","Während einer Fokus-Session kannst du hier nichts ändern. Deine Regeln siehst du trotzdem."));
    if (d.regeln && typeof lkOffen === "function") lkOffen(d).forEach(e => { e.inert = true; e.classList?.add("lk-nurlesen"); teile.push(e); });   // gleiche Struktur wie sonst, nur nicht bedienbar
  } else if (d.offen){   // john 05.11.: ohne PIN, Server liefert den Locker gleich offen
    teile.push(...lkOffen(d));
  } else if (!d.pinGesetzt){
    teile.push(el("p","hint kon-hint","Lege eine PIN fest (4–24 Ziffern). Nur damit kommst du in die Einstellungen des App Lockers. In einer gesperrten App lässt sich nichts freischalten."),
      lkPinForm("Neue PIN", "Festlegen", "pinNeu", true));
  } else if (!d.offen){
    teile.push(lkPinForm("PIN", "Öffnen", "pin"));
  } else {
    teile.push(...lkOffen(d));
  }
  teile.push(lkImmer());
  box.replaceChildren(...teile);
}
// Immer gesperrt, unabhängig von PIN und Regeln
function lkImmer(){
  const z = el("div","lk-immer");
  z.append(el("span","lk-schloss","🔒"), el("div", null));
  z.lastChild.append(el("b", null, "Immer gesperrt: Erwachsenen-Inhalte"), el("span","k-s","Rund 973.000 Seiten" + (typeof beNurHandy === "function" && beNurHandy() ? "" : " auf allen deinen Geräten") + ", auch im Inkognito-Tab. Lässt sich nicht ausschalten."));
  return z;
}
// Neue Zufalls-PIN einmal zeigen
function lkNeuePin(){
  const w = el("div","lk-pinneu"), p = el("div","lk-pinzahl", lkPinGruppen(LK.neuePin));
  const kopie = el("button","ghost small","Kopieren"); kopie.type = "button";
  kopie.addEventListener("click", async () => { try { await navigator.clipboard.writeText(LK.neuePin); kopie.textContent = "Kopiert"; } catch { kopie.textContent = "Bitte abschreiben"; } });
  const ok = el("button","ask small","Notiert, weiter"); ok.type = "button";
  lkZweimal(ok, "Aufgeschrieben? Dann tippen", () => { LK.neuePin = ""; renderLocker(true); });
  const z = el("div","lk-unten"); z.append(kopie, ok);
  w.append(el("h3", null, "Deine neue PIN"), p,
    el("p","k-s","Nur mit dieser PIN kommst du ab jetzt in den App Locker. Sie wird nur dieses eine Mal angezeigt. Gib sie jemandem, dem du vertraust, oder bewahre sie weit weg vom Handy auf."), z);
  return w;
}
// Sicherheitsabfrage ohne confirm(): erst tippen, dann „Wirklich …?“ innerhalb von 5 s
function lkZweimal(b, frage, tun){
  const text = b.deText; let scharf = false, t;
  b.addEventListener("click", () => { if (scharf){ clearTimeout(t); tun(); return; }
    scharf = true; b.textContent = frage; t = setTimeout(() => { scharf = false; b.textContent = text; }, 5000); });
}
// Timer vor dem Lockern: Impulskontrolle, strenger machen geht sofort
function lkUhr(sek){ sek = Math.max(0, Math.round(sek)); if (sek >= 3600) return Math.floor(sek / 3600) + ":" + String(Math.floor(sek / 60) % 60).padStart(2, "0") + " Std.";   // 19.11.: 12 Std. nicht als „720:00“
  return Math.floor(sek / 60) + ":" + String(sek % 60).padStart(2, "0"); }
function lkTimerKarte(d){
  const k = el("div","lk-timer"), m = d.warteJetzt ?? d.warteMin;
  clearInterval(LK.tick);
  if (d.immerFrei){
    k.append(el("b", null, "Kein Timer vor dem Lockern"), el("span","k-s","Du kannst alles sofort ändern. Unten lässt sich eine Wartezeit einstellen."));
  } else if (d.wartet > 0){   // 19.11.: 12 Std. statt 5 Min: konkrete Uhrzeit statt Countdown
    const ab = el("button","ghost small","Abbrechen"); ab.type = "button"; ab.addEventListener("click", () => lkAktion({abbrechen:true}));
    k.classList.add("laeuft");
    k.append(el("b", null, "Lockern beantragt"), el("div","lk-uhr", "ab " + bdUhr(d.freiAbText)),
      el("span","k-s", `${bdLockernSatz(d)} Bis dahin gilt alles wie bisher, strenger geht weiter sofort.`), ab);
    LK.tick = setTimeout(lkLaden, Math.min(d.wartet * 1000 + 500, 2 ** 31 - 1));
  } else if (d.frei > 0){
    k.classList.add("frei");
    k.append(el("b", null, "🔓 Lockern ist frei"), el("span","k-s", `Bis ${bdUhr(d.freiBisText)}. Danach braucht es wieder einen Antrag.`));
  } else {
    const los = el("button","ask small", `Lockern beantragen (${bdWarte(m)})`); los.type = "button";
    los.addEventListener("click", () => lkAktion({warten:true}));
    k.append(el("b", null, "Strenger machen geht sofort"),
      el("span","k-s", `Neue Regeln und Einschalten gehen gleich. Löschen, Ausschalten${d.ohnePin ? "" : ", PIN ändern"} und Bindungen früher beenden erst ${bdWarte(m)} nach dem Antrag.`), los);
  }
  return k;
}
function lkWarteForm(d){
  if (!d.sofort) return el("span");   // 19.11.: Wartezeit fest 12 Std., nur die Entwicklerversion kann sie ändern
  const f = el("form","lk-zeit lk-warte"), inp = el("input"), b = el("button","ghost small","Speichern");
  inp.type = "number"; inp.min = "0"; inp.max = "720"; inp.value = d.warteMin; inp.setAttribute("aria-label","Wartezeit in Minuten"); b.type = "submit";
  f.append(el("span","k-s","Timer vor dem Lockern:"), inp, el("span","k-s","Min"), b);
  f.addEventListener("submit", ev => { ev.preventDefault(); lkAktion({warteMin:Number(inp.value)}); });
  if (d.warteMin > 0){
    // john 05.11.: „Lockern wird teurer“ ist immer an, kein Schalter mehr
    const t = el("p","k-s lk-teurer-fest","Lockern wird teurer: Jedes Lockern in derselben Woche verdoppelt die Wartezeit (höchstens 12 Std.). Immer an.");
    const w = el("div"); w.append(f, t); return w;
  }
  return f;
}
function lkIstRauschen(n){
  const k = n.toLowerCase();
  return LK_SYSTEM.includes(k) || /[,|·]/.test(n) || /\d{4}/.test(n) || n.split(/\s+/).length > 2 || n.length > 26;
}
function lkSchritt(nr, titel, ...inhalt){
  const s = el("div","lk-schritt"), kopf = el("div","lk-kopf");
  kopf.append(el("span","lk-nr", String(nr)), el("b", null, titel));
  s.append(kopf, ...inhalt); return s;
}
// Regel bearbeiten: Werte der Regel ins Formular laden (gleiches Formular wie „Neue Regel“)
const LK_NEU = () => ({art:"zeit", tage:new Set([0,1,2,3,4]), geraete:new Set(), apps:new Set(), extra:[], von:"09:00", bis:"17:00", min:"30", pause:"30", bearbeiten:null});
function lkBearbeiten(r){
  Object.assign(LK, {art:r.art, tage:new Set(r.tage), geraete:new Set(r.geraete || []), apps:new Set(r.apps), extra:[...r.apps],
    von:r.von || "09:00", bis:r.bis || "17:00", min:String(r.art === "oeffnen" ? (r.anzahl || 5) : (r.minuten || 30)), pause:String(r.pause || 30), bearbeiten:r.id});
  renderLocker(true);
  setTimeout(() => document.querySelector(".lk-neu")?.scrollIntoView({behavior:"smooth", block:"start"}), 50);
}
function lkAbbrechen(){ Object.assign(LK, LK_NEU()); renderLocker(true); }
// Gleich streng oder strenger? Dann geht die Änderung sofort, sonst braucht sie den Timer (wie locker_strenger im Server)
function lkFenster(von, bis){ const m = t => +t.slice(0, 2) * 60 + +t.slice(3, 5), v = m(von), b = m(bis), s = new Set();
  if (v < b) for (let i = v; i < b; i++) s.add(i); else { for (let i = v; i < 1440; i++) s.add(i); for (let i = 0; i < b; i++) s.add(i); } return s; }
function lkStrenger(alt){
  const klein = l => new Set([...(l || [])].map(x => String(x).toLowerCase())), drin = (a, b) => [...a].every(x => b.has(x));
  if (LK.art !== alt.art || !drin(klein(alt.apps), klein(LK.apps)) || !drin(new Set(alt.tage), LK.tage)) return false;
  if (LK.geraete.size && (!alt.geraete?.length || !drin(klein(alt.geraete), klein(LK.geraete)))) return false;
  if (LK.art === "zeit") return /^\d\d:\d\d$/.test(LK.von) && /^\d\d:\d\d$/.test(LK.bis) && drin(lkFenster(alt.von, alt.bis), lkFenster(LK.von, LK.bis));
  if (LK.art === "sitzung") return Number(LK.min) <= Number(alt.minuten) && Number(LK.pause) >= Number(alt.pause || 0);
  if (LK.art === "oeffnen") return Number(LK.min) <= Number(alt.anzahl);
  return Number(LK.min) <= Number(alt.minuten);
}
function lkOffen(d){
  const out = [lkTimerKarte(d)], darf = d.immerFrei || d.frei > 0;
  // bestehende Regeln als Karten
  const liste = el("div","lk-regeln");
  (d.regeln || []).forEach(r => {
    const k = el("div","lk-regel" + (r.gesperrt ? " zu" : "") + (LK.bearbeiten === r.id ? " bearbeitet" : "")), x = el("button","ghost small","Löschen"); x.type = "button";
    const bea = el("button","ghost small", LK.bearbeiten === r.id ? "Wird bearbeitet" : "Bearbeiten"); bea.type = "button"; bea.disabled = LK.bearbeiten === r.id;
    bea.addEventListener("click", () => lkBearbeiten(r));
    if (darf) lkZweimal(x, "Wirklich löschen?", () => lkAktion({loeschen:r.id}));
    else { x.disabled = true; x.title = "Erst den Timer zum Lockern abwarten"; }
    const kopf = el("div","lk-kopf"), apps = el("div","lk-pills");
    kopf.append(el("span","lk-icon", r.art === "zeit" ? "⏰" : r.art === "sitzung" ? "⏸" : r.art === "oeffnen" ? "🔢" : "⏳"), el("b", null, r.art === "zeit" ? "Sperrzeit" : r.art === "sitzung" ? "Am Stück" : r.art === "oeffnen" ? "Öffnungs-Limit" : "Tageslimit"),
      el("span","lk-status " + (r.gesperrt ? "bad" : "ok"), r.gesperrt ? (r.pauseBis ? `Pause bis ${r.pauseBis}` : "gerade gesperrt") : r.art === "limit" ? `heute ${r.verbraucht || 0} von ${r.minuten} Min` : r.art === "oeffnen" ? `${VB.modus === "handy" ? "" : "am Mac "}heute ${r.geoeffnet || 0}× von ${r.anzahl}` : "gerade frei"), bea, x);
    r.apps.forEach(a => apps.append(el("span","lk-pill", a)));
    k.append(kopf, apps, el("span","k-s", lkRegelText(r)));
    liste.append(k);
  });
  if (!(d.regeln || []).length) liste.append(el("p","k-s","Noch keine Regeln. Leg unten deine erste an."));
  out.push(liste);

  // ---- neue Regel in drei Schritten ----
  const f = el("form","lk-neu");
  const alleNamen = [], gesehen = new Set();
  const dazuName = n => { const k = n.toLowerCase().replace(/[^\p{L}\p{N}]/gu, ""); if (!k || gesehen.has(k)) return; gesehen.add(k); alleNamen.push(n); };
  (d.apps || []).forEach(a => dazuName(a.name)); LK.extra.forEach(dazuName);
  const info = n => (d.apps || []).find(a => a.name === n);
  const ablenkend = alleNamen.filter(n => !lkIstRauschen(n) && (info(n)?.kat === "prokrastination" || LK.extra.includes(n)));
  const weitere = alleNamen.filter(n => !lkIstRauschen(n) && !ablenkend.includes(n));
  const rauschen = alleNamen.filter(n => lkIstRauschen(n));

  // Ausgewählt + Zusammenfassung, ohne alles neu zu zeichnen
  const gewaehlt = el("div","lk-pills lk-gewaehlt"), satz = el("p","lk-satz"), ok = el("button","ask lk-ok","Regel hinzufügen"), bHinweis = el("p","k-s"); ok.type = "submit";
  const chipsAlle = [];
  function aktualisieren(){
    gewaehlt.replaceChildren();
    if (!LK.apps.size) gewaehlt.append(el("span","k-s","Noch nichts ausgewählt. Tippe unten auf Apps oder gib eine Seite ein."));
    [...LK.apps].forEach(n => { const p = el("button","lk-pill an", n + "  ×"); p.type = "button"; p.setAttribute("aria-label", n + " entfernen");
      p.addEventListener("click", () => { LK.apps.delete(n); aktualisieren(); }); gewaehlt.append(p); });
    chipsAlle.forEach(([b, n]) => b.setAttribute("aria-pressed", String(LK.apps.has(n))));
    const was = LK.apps.size ? [...LK.apps].join(", ") : "…";
    const wo = LK.geraete.size ? "auf " + [...LK.geraete].join(", ") : "auf allen Geräten";
    satz.textContent = LK.art === "zeit" ? `${was} ist ${lkTageText(LK.tage)} von ${LK.von} bis ${LK.bis} ${wo} gesperrt.`
                     : LK.art === "sitzung" ? `${was} geht ${lkTageText(LK.tage)} höchstens ${LK.min} Min am Stück ${wo}, danach ${LK.pause} Min Pause. Gegen endloses Scrollen.`
                     : LK.art === "oeffnen" ? `${was} lässt sich ${lkTageText(LK.tage)} höchstens ${LK.min}-mal öffnen ${wo} (jedes Gerät zählt selbst). Gegen das ständige Reinschauen.`
                                         : `${was} geht ${lkTageText(LK.tage)} höchstens ${LK.min} Min am Tag ${wo}, danach ist es gesperrt.`;
    ok.disabled = !LK.apps.size || !LK.tage.size;
    const alt = LK.bearbeiten && (d.regeln || []).find(r => r.id === LK.bearbeiten);
    if (alt){
      const lockert = !lkStrenger(alt);
      ok.textContent = lockert && !darf ? "Lockert die Regel: erst Timer abwarten" : "Änderung speichern";
      if (lockert && !darf) ok.disabled = true;
      bHinweis.textContent = lockert ? "Diese Änderung lockert die Regel (weniger Apps, Tage oder Geräte, kürzere Sperrzeit oder größeres Limit). Dafür braucht es den Timer oben."
                                     : "Diese Änderung macht die Regel strenger und gilt sofort.";
      bHinweis.className = "k-s " + (lockert ? "c-bad" : "c-good");
    }
  }
  const chipGruppe = namen => { const c = el("div","chips sp-chips");
    namen.forEach(n => { const b = el("button","chip small", n); b.type = "button"; b.dataset.n = n.toLowerCase();
      const i = info(n); if (i?.min) b.title = `${minText(i.min * 60)} in den letzten 7 Tagen`;
      b.addEventListener("click", () => { LK.apps.has(n) ? LK.apps.delete(n) : LK.apps.add(n); aktualisieren(); });
      chipsAlle.push([b, n]); c.append(b); });
    return c; };
  // Suchen oder eigene App/Seite eingeben
  const such = el("div","add lk-such"), sInp = el("input"), sPlus = el("button", null, "Hinzufügen");
  sInp.placeholder = "App oder Seite suchen oder eingeben, z. B. reddit.com"; sInp.setAttribute("aria-label","App oder Seite suchen oder hinzufügen"); sPlus.type = "button";
  const filtern = () => { const q = sInp.value.trim().toLowerCase(); chipsAlle.forEach(([b]) => b.hidden = !!q && !b.dataset.n.includes(q)); };
  const dazu = () => { let n = sInp.value.trim().replace(/^https?:\/\//i, "").replace(/^www\./i, "").replace(/\/.*$/, ""); if (!n) return;
    n = alleNamen.find(x => x.toLowerCase() === n.toLowerCase()) || n;
    if (!LK.extra.includes(n) && !alleNamen.includes(n)) LK.extra.push(n);
    LK.apps.add(n); sInp.value = "";
    if (!chipsAlle.some(([, x]) => x === n)) eigene.append(...chipGruppe([n]).childNodes);
    filtern(); aktualisieren(); };
  sInp.addEventListener("input", filtern);
  sInp.addEventListener("keydown", ev => { if (ev.key === "Enter"){ ev.preventDefault(); dazu(); } });
  sPlus.addEventListener("click", dazu); such.append(sInp, sPlus);
  const eigene = chipGruppe(LK.extra.filter(n => !ablenkend.includes(n)));
  const gruppen = el("div","lk-gruppen");
  if (ablenkend.length) gruppen.append(el("span","lk-gtitel","Ablenkend"), chipGruppe(ablenkend));
  if (weitere.length) gruppen.append(el("span","lk-gtitel","Weitere Apps und Seiten"), chipGruppe(weitere));
  gruppen.append(eigene);
  if (rauschen.length){ const det = el("details","lk-mehr"); det.append(el("summary", null, `Fenster und System (${rauschen.length})`), chipGruppe(rauschen)); gruppen.append(det); }

  // Schritt 2: wann
  const art = el("div","lk-arten");
  [["zeit","⏰","Sperrzeit","Zu festen Zeiten ganz gesperrt"],["limit","⏳","Tageslimit","Erlaubt bis zu einer Zeit pro Tag"],["sitzung","⏸","Am Stück","Nur ein paar Minuten am Stück, dann Pause"],["oeffnen","🔢","Öffnungs-Limit","Nur ein paar Mal am Tag öffnen"]].forEach(([k, ic, t, u]) => {
    const b = el("button","lk-art"); b.type = "button"; b.setAttribute("aria-pressed", String(LK.art === k));
    b.append(el("span","lk-icon", ic), el("b", null, t), el("span","k-s", u));
    b.addEventListener("click", () => { LK.art = k; renderLocker(true); }); art.append(b); });
  const tage = el("div","chips");
  LK_TAGE.forEach((t, i) => { const b = el("button","chip small", t); b.type = "button"; b.setAttribute("aria-pressed", String(LK.tage.has(i)));
    b.addEventListener("click", () => { LK.tage.has(i) ? LK.tage.delete(i) : LK.tage.add(i); b.setAttribute("aria-pressed", String(LK.tage.has(i))); aktualisieren(); }); tage.append(b); });
  const schnell = el("div","chips lk-schnell");
  [["Mo–Fr",[0,1,2,3,4]],["Wochenende",[5,6]],["Täglich",[0,1,2,3,4,5,6]]].forEach(([t, w]) => { const b = el("button","ghost small", t); b.type = "button";
    b.addEventListener("click", () => { LK.tage = new Set(w); renderLocker(true); }); schnell.append(b); });
  const zeit = el("div","lk-zeit");
  const von = el("input"), bis = el("input"), min = el("input");
  von.type = bis.type = "time"; von.value = LK.von; bis.value = LK.bis; von.setAttribute("aria-label","von"); bis.setAttribute("aria-label","bis");
  von.addEventListener("input", () => { LK.von = von.value; aktualisieren(); }); bis.addEventListener("input", () => { LK.bis = bis.value; aktualisieren(); });
  min.type = "number"; min.min = "1"; min.max = "1440"; min.value = LK.min; min.setAttribute("aria-label","Minuten pro Tag");
  min.addEventListener("input", () => { LK.min = min.value; aktualisieren(); });
  const pause = el("input"); pause.type = "number"; pause.min = "1"; pause.max = "1440"; pause.value = LK.pause; pause.setAttribute("aria-label","Minuten Pause");
  pause.addEventListener("input", () => { LK.pause = pause.value; aktualisieren(); });
  if (LK.art === "zeit") zeit.append(el("span","k-s","von"), von, el("span","k-s","bis"), bis);
  else if (LK.art === "sitzung"){ min.max = "240"; zeit.append(min, el("span","k-s","Min am Stück, dann"), pause, el("span","k-s","Min Pause")); }
  else if (LK.art === "oeffnen"){ min.max = "100"; min.setAttribute("aria-label","Mal pro Tag"); zeit.append(min, el("span","k-s","Mal pro Tag öffnen, danach gesperrt bis morgen")); }
  else zeit.append(min, el("span","k-s","Min pro Tag, auf allen gewählten Geräten zusammen"));

  // Schritt 3: wo
  const ger = el("div","chips");
  const alle = el("button","chip small","Alle Geräte"); alle.type = "button"; alle.setAttribute("aria-pressed", String(!LK.geraete.size));
  alle.addEventListener("click", () => { LK.geraete.clear(); renderLocker(true); }); ger.append(alle);
  (d.geraete || []).forEach(n => { const b = el("button","chip small", (n === "Mac" ? "💻 " : "📱 ") + n); b.type = "button"; b.setAttribute("aria-pressed", String(LK.geraete.has(n)));
    b.addEventListener("click", () => { LK.geraete.has(n) ? LK.geraete.delete(n) : LK.geraete.add(n); renderLocker(true); }); ger.append(b); });

  const abbr = el("button","ghost lk-abbr","Abbrechen"); abbr.type = "button"; abbr.addEventListener("click", lkAbbrechen);
  const knoepfe = el("div","lk-knoepfe"); knoepfe.append(ok); if (LK.bearbeiten) knoepfe.append(abbr);
  if (LK.bearbeiten) f.classList.add("lk-bearbeiten");
  f.append(el("h3", null, LK.bearbeiten ? "Regel bearbeiten" : "Neue Regel"),
    lkSchritt(1, "Was sperren?", such, gewaehlt, gruppen),
    lkSchritt(2, "Wann?", art, schnell, tage, zeit),
    ...((d.geraete || []).length <= 1 && typeof beNurHandy === "function" && beNurHandy() ? [] : [lkSchritt(3, "Auf welchen Geräten?", ger)]),   // 1.0.14: nur ein Handy

    satz, ...(LK.bearbeiten ? [bHinweis] : []), knoepfe);
  f.addEventListener("submit", async ev => { ev.preventDefault(); if (!LK.apps.size) return;
    const regel = {art:LK.art, apps:[...LK.apps], tage:[...LK.tage].sort(), geraete:[...LK.geraete]};
    if (LK.bearbeiten) regel.id = LK.bearbeiten;
    if (LK.art === "zeit"){ regel.von = von.value; regel.bis = bis.value; } else if (LK.art === "oeffnen") regel.anzahl = Number(min.value); else regel.minuten = Number(min.value);
    if (LK.art === "sitzung") regel.pause = Number(pause.value);
    ok.disabled = true; if (await lkAktion({regel})){ if (LK.bearbeiten){ Object.assign(LK, LK_NEU()); toast("Regel gespeichert."); } else { LK.apps.clear(); LK.extra = []; } } renderLocker(true); });
  aktualisieren();
  out.push(f);
  // Handys, die den Locker noch nicht kennen
  Object.entries(d.versionen || {}).forEach(([n, v]) => { if (!v || (v.split(".").length < 3 && parseFloat(v) < 1.7)) out.push(el("p","k-s c-bad", `${n}: Handy-App ${v || "alt"} sperrt noch nicht nach Regeln, bitte aktualisieren (Knopf „Update installieren“ in der Handy-App).`)); });
  // An/aus, PIN, schließen
  const unten = el("div","lk-unten");
  const an = el("button","ghost small", d.an ? "App Locker ausschalten" : "App Locker einschalten"); an.type = "button";
  an.addEventListener("click", () => lkAktion({an:!d.an}));
  if (d.an && !darf){ an.disabled = true; an.title = "Erst den Timer zum Lockern abwarten"; }
  const pin = el("button","ghost small","Neue lange PIN erzeugen"); pin.type = "button";
  if (darf) lkZweimal(pin, "Alte PIN ungültig machen?", () => lkAktion({pinZufall:true}));
  else { pin.disabled = true; pin.title = "Erst den Timer zum Lockern abwarten"; }
  const zu = el("button","ask small","Schließen"); zu.type = "button"; zu.addEventListener("click", () => { clearInterval(LK.tick); lkAktion({schliessen:true}); });
  unten.append(an, ...(d.ohnePin ? [] : [pin, zu]));
  out.push(lkWarteForm(d));
  // Eigene PIN ändern (gilt wie Lockern: nur nach dem Timer)
  if (darf && !d.ohnePin){ out.push(el("p","k-s","PIN ändern")); out.push(lkPinForm("Neue PIN", "Ändern", "pinNeu", true)); }
  out.push(el("p","hint kon-hint","Öffnest du eine gesperrte App, schickt dich das Handy zum Startbildschirm" + (typeof beNurHandy === "function" && beNurHandy() ? "" : " und der Computer blendet sie aus") + (d.ohnePin ? "." : ". Nach 10 Minuten schließt sich dieser Bereich von selbst.")), unten);
  return out;
}

/* ---------- Einstellungen (eigener Reiter): Deine KI, Kalender, Über dich, Mein Tag, Aussehen, Deine Daten ---------- */
// KI-Schlüssel bleiben auf dem Mac (ki-schluessel.json); die Oberfläche sieht nur eine Maske wie „sk-…abcd“.
const EI = {offen:null, modelle:{}, laedt:"", antwort:"", fehler:"", kalFehler:"", kalNeu:false};
function eiKnopf(text, cls, fn){ const b = el("button", cls || "ghost small", text); b.type = "button"; if (fn) b.addEventListener("click", fn); return b; }
function eiZeile(titel, ...kinder){ const r = el("div","ei-row"); r.append(el("span","ei-l", titel)); const w = el("div","ei-w"); w.append(...kinder); r.append(w); return r; }
function eiSchalter(an, fn, label){
  const cb = document.createElement("input"); cb.type = "checkbox"; cb.className = "auto-sw"; cb.setAttribute("role","switch"); cb.checked = !!an;
  if (label) cb.setAttribute("aria-label", label); cb.addEventListener("change", () => fn(cb.checked)); return cb;
}
async function eiApi(pfad, body, ok){
  try { const r = await api(pfad, body); if (r && r.heute) S.plan = r; if (ok) toast(ok); renderPlan(); return r; }
  catch (e){ toast(e.message || String(e)); throw e; }
}

function renderEinstellungen(){
  if (!$("eiKi")) return;
  const lokal = S.mode === "lokal" && S.plan;
  if (!lokal){ ["eiKi","eiKal","eiDu","eiTag","eiDaten"].forEach(id => $(id).replaceChildren(el("p","empty","Nur in BlockEm auf deinem Mac (oder in der Handy-App im WLAN).")));
    renderThema(); return; }
  // Beim Tippen nicht neu zeichnen (das Cockpit lädt jede Minute neu), sonst wäre ein halb eingefügter Schlüssel weg
  const tippt = id => { const a = document.activeElement; return a && $(id).contains(a) && /^(INPUT|SELECT|TEXTAREA)$/.test(a.tagName); };
  if (!tippt("eiKi")) renderEiKi();
  if (!tippt("eiKal")) renderEiKal();
  renderEiDu(); if (!tippt("eiTag")) renderEiTag(); renderThema(); renderEiDaten();
}

/* Deine KI: jeder verbindet die KI, die er schon hat */
function renderEiKi(){
  const ki = S.plan.ki || {}, liste = ki.anbieterListe || [], box = $("eiKi");
  $("eiKiSub").textContent = ki.anbieter ? `aktiv: ${ki.name}${ki.lokal ? " (lokal)" : ""}` : "noch keine verbunden";
  const status = el("div","ei-status " + (ki.anbieter ? "ok" : "aus"));
  status.append(el("span","ki-punkt " + (ki.anbieter ? "ok" : "aus"), ki.anbieter ? "●" : "○"),
    el("span", null, ki.anbieter ? `BlockEm nutzt ${ki.modell}.` : "Wähle eine KI. Dann kannst du sie in BlockEm fragen, und sie plant mit dir."));
  const wahl = el("div","chips ei-wahl");
  const auto = eiKnopf("Automatisch", "chip small", () => eiApi("api/ki", {anbieter:"auto"}, "Automatisch: Claude, sonst Ollama, sonst ein gespeicherter Schlüssel."));
  auto.setAttribute("aria-pressed", String(ki.wahl === "auto")); auto.title = "Nimmt Claude Code, wenn da, sonst Ollama, sonst den ersten gespeicherten Schlüssel";
  wahl.append(auto);
  const karten = el("div","ei-karten");
  liste.forEach(a => {
    const k = el("button","ei-karte" + (ki.anbieter === a.id ? " aktiv" : "") + (EI.offen === a.id ? " offen" : "")); k.type = "button";
    k.setAttribute("aria-expanded", String(EI.offen === a.id));
    const kopf = el("span","ei-k-kopf"); kopf.append(el("b", null, a.name));
    kopf.append(el("span","ei-badge " + (ki.anbieter === a.id ? "an" : a.bereit ? "bereit" : ""), ki.anbieter === a.id ? "aktiv" : a.bereit ? "bereit" : a.art === "programm" ? "nicht gefunden" : a.art === "ollama" ? (a.laeuft ? "kein Modell" : "aus") : "kein Schlüssel"));
    k.append(kopf, el("span","k-s", a.text));
    k.addEventListener("click", () => { EI.offen = EI.offen === a.id ? null : a.id; EI.fehler = EI.antwort = ""; renderEiKi();
      if (EI.offen && a.bereit && (a.art === "anthropic" || a.art === "openai") && !EI.modelle[a.id]) eiModelle(a.id); });
    karten.append(k);
    if (EI.offen === a.id) karten.append(eiKiForm(a, ki));
  });
  const test = eiKnopf(EI.laedt === "test" ? "Fragt …" : "KI testen", "ask small", async () => {
    EI.laedt = "test"; EI.antwort = EI.fehler = ""; renderEiKi();
    try { const r = await api("api/ki", {test:true}); EI.antwort = `${r.antwort} (${r.sekunden} s)`; delete r.antwort; delete r.sekunden; S.plan = r; }
    catch (e){ EI.fehler = e.message || String(e); }
    EI.laedt = ""; renderPlan(); });
  test.disabled = !ki.anbieter || EI.laedt === "test";
  const unten = el("div","ei-unten"); unten.append(test);
  const teile = [status, el("p","k-s ei-frage","Welche KI möchtest du nutzen?"), wahl, karten, unten];
  if (EI.antwort) teile.push(el("p","ki-antwort", EI.antwort));
  if (EI.fehler) teile.push(el("p","k-s c-bad", EI.fehler));
  teile.push(el("p","hint kon-hint", "Was die KI sieht: deinen Plan, deine Projekte, Termine und die Bildschirmzeit von heute, nur wenn du sie fragst. "
    + "Bei Cloud-Anbietern geht das an diesen Anbieter, bei Ollama bleibt alles auf deinem Mac. Schlüssel liegen nur auf deinem Mac und stehen in keiner Sicherung."));
  box.replaceChildren(...teile);
}
function eiKiForm(a, ki){
  const f = el("form","ei-form"); f.addEventListener("submit", e => e.preventDefault());
  const benutzen = eiKnopf(ki.anbieter === a.id ? "Wird benutzt" : "Diese KI benutzen", "ask small", () => eiApi("api/ki", {anbieter:a.id}, `${a.name} ist jetzt aktiv.`));
  benutzen.disabled = ki.anbieter === a.id || !a.bereit;
  if (a.art === "programm"){
    f.append(el("p","k-s", a.bereit ? `Gefunden: ${a.pfad}` : "Claude Code ist auf diesem Mac nicht installiert. Die Claude-App allein reicht nicht."));
    if (!a.bereit){ const l = el("a","zt-link","Claude Code installieren ↗"); l.href = "https://docs.claude.com/en/docs/claude-code/setup"; l.target = "_blank"; l.rel = "noopener"; f.append(l); }
    else f.append(el("p","k-s","Einmal anmelden: Claude Code hat eine eigene Anmeldung, getrennt von der Claude-App."),
      eiKnopf("Bei Claude anmelden", "ghost small", async () => { try { await api("api/ki", {login:true}); toast("Im Terminal anmelden, dann /exit und hier „KI testen“."); } catch (e){ toast(e.message); } }));
    f.append(el("div","ei-knoepfe")); f.lastChild.append(benutzen); return f;
  }
  if (a.art === "ollama"){
    f.append(el("p","k-s", a.laeuft ? (a.modelle?.length ? "Ollama läuft." : "Ollama läuft, aber es ist noch kein Modell geladen.") : "Ollama ist nicht gestartet. Installieren und einmal öffnen, dann hier neu laden."));
    if (a.modelle?.length){ const sel = document.createElement("select"); sel.setAttribute("aria-label","Modell");
      a.modelle.forEach(m => sel.append(new Option(m, m, false, m === a.modell)));
      sel.addEventListener("change", () => eiApi("api/ki", {speichern:{id:"ollama", modell:sel.value}, anbieter:"ollama"}, "Modell gespeichert."));
      f.append(eiZeile("Modell", sel)); }
    else if (a.laeuft) f.append(eiKnopf(ki.laedt ? "Lädt (ca. 3 GB) …" : "Empfohlenes Modell laden (ca. 3 GB)", "ghost small", () => eiApi("api/ki-laden", {}, "Download läuft im Hintergrund.")));
    if (!a.laeuft){ const l = el("a","zt-link","Ollama herunterladen ↗"); l.href = a.link; l.target = "_blank"; l.rel = "noopener"; f.append(l); }
    f.append(el("div","ei-knoepfe")); f.lastChild.append(benutzen); return f;
  }
  // Schlüssel-Anbieter (Claude-API, ChatGPT, Gemini, OpenRouter, Mistral) und eigener Server
  const sch = el("input"); sch.type = "password"; sch.autocomplete = "off"; sch.spellcheck = false;
  sch.placeholder = a.maske ? `gespeichert: ${a.maske} (neu einfügen zum Ersetzen)` : (a.id === "eigene" ? "Schlüssel, falls nötig" : "API-Schlüssel einfügen");
  sch.setAttribute("aria-label", "API-Schlüssel");
  let url = null;
  if (a.id === "eigene"){ url = el("input"); url.type = "url"; url.value = a.url || ""; url.placeholder = "http://localhost:1234/v1"; url.setAttribute("aria-label","Adresse des Servers"); f.append(eiZeile("Adresse", url)); }
  f.append(eiZeile("Schlüssel", sch));
  const modelle = EI.modelle[a.id];
  let mod;
  if (modelle?.length){ mod = document.createElement("select"); [...new Set([a.modell, ...modelle].filter(Boolean))].forEach(m => mod.append(new Option(m, m, false, m === a.modell))); }
  else { mod = el("input"); mod.value = a.modell || ""; mod.placeholder = "Modellname"; mod.spellcheck = false; }
  mod.setAttribute("aria-label","Modell");
  const liste = eiKnopf(EI.laedt === a.id ? "Lädt …" : "Modelle laden", "ghost small", () => eiModelle(a.id)); liste.disabled = !a.bereit || EI.laedt === a.id;
  liste.title = a.bereit ? "Fragt beim Anbieter, welche Modelle dein Schlüssel nutzen darf" : "Erst Schlüssel speichern";
  f.append(eiZeile("Modell", mod, liste));
  if (a.link) f.append(eiSchluesselHilfe(a));
  const speichern = eiKnopf("Speichern und benutzen", "ask small", async () => {
    const body = {speichern:{id:a.id, schluessel:sch.value, modell:mod.value}};
    if (url) body.speichern.url = url.value;
    if (!sch.value && !a.maske && a.id !== "eigene"){ sch.focus(); toast("Bitte zuerst den Schlüssel einfügen."); return; }
    speichern.disabled = true;
    try { await eiApi("api/ki", body, `${a.name} verbunden.`); EI.modelle[a.id] = null; if (sch.value) eiModelle(a.id); } catch {}
    speichern.disabled = false; });
  const knoepfe = el("div","ei-knoepfe"); knoepfe.append(speichern);
  if (a.bereit && ki.anbieter !== a.id) knoepfe.append(benutzen);
  if (a.maske || a.url){ const weg = eiKnopf("Entfernen", "ghost small", () => {
      if (weg.dataset.sicher){ eiApi("api/ki", {entfernen:a.id}, "Zugang entfernt."); return; }
      weg.dataset.sicher = "1"; weg.textContent = "Wirklich entfernen?"; setTimeout(() => { delete weg.dataset.sicher; weg.textContent = "Entfernen"; }, 4000); });
    knoepfe.append(weg); }
  f.append(knoepfe);
  return f;
}
async function eiModelle(id){
  EI.laedt = id; renderEiKi();
  try { const r = await api("api/ki", {modelle:id}); EI.modelle[id] = r.modelle || []; if (!EI.modelle[id].length) toast("Der Anbieter hat keine Modelle gemeldet."); }
  catch (e){ EI.fehler = e.message || String(e); }
  EI.laedt = ""; renderEiKi();
}

/* Kalender: mehrere Kalender (iCal-Adresse), Termine erscheinen auf Heute und in der Zeitleiste */
function renderEiKal(){
  const a = S.plan.automatik || {}, liste = a.kalenderListe || [], k = S.plan.kalender, box = $("eiKal");
  if (box.contains(document.activeElement) && document.activeElement.tagName === "INPUT") return;   // nicht beim Tippen neu zeichnen
  $("eiKalSub").textContent = liste.length ? `${liste.filter(x => x.an !== false).length} verbunden` : "Termine sehen und mitplanen";
  const teile = [];
  if (!autoAn("kalender")) teile.push(el("p","k-s c-warn","Der Kalender ist im Reiter Automatik ausgeschaltet."));
  liste.forEach(x => {
    const r = el("div","ei-kal"), dot = el("i","ei-dot"); dot.style.background = x.farbe;
    const weg = eiKnopf("Entfernen", "ghost small", () => {
      if (weg.dataset.sicher){ eiApi("api/kalender", {weg:x.id}, "Kalender entfernt."); return; }
      weg.dataset.sicher = "1"; weg.textContent = "Wirklich?"; setTimeout(() => { delete weg.dataset.sicher; weg.textContent = "Entfernen"; }, 4000); });
    r.append(dot, el("b", null, x.name), eiSchalter(x.an !== false, an => eiApi("api/kalender", {id:x.id, an}), `${x.name} anzeigen`), weg);
    teile.push(r);
  });
  if (k?.fehler) teile.push(el("p","k-s c-bad", k.fehler));
  if (k && liste.length && !k.fehler) teile.push(el("p","k-s", `Heute: ${k.anzahl || 0} ${k.anzahl === 1 ? "Termin" : "Termine"}${k.belegtMin ? `, ${stdText(k.belegtMin / 60)} belegt` : ""}.`));
  const f = el("form","ei-form ei-kal-neu"), name = el("input"), url = el("input"), los = el("button","ask small","Verbinden");
  name.placeholder = "Name, z. B. Privat"; name.setAttribute("aria-label","Name des Kalenders"); name.maxLength = 40;
  url.type = "url"; url.placeholder = "iCal-Adresse (https://… oder webcal://…)"; url.setAttribute("aria-label","iCal-Adresse"); url.required = true;
  los.type = "submit"; f.append(name, url, los);
  f.addEventListener("submit", async e => { e.preventDefault(); los.disabled = true;
    try { await eiApi("api/kalender", {neu:{name:name.value, url:url.value}}, "Kalender verbunden. Termine erscheinen gleich."); name.value = url.value = ""; } catch {}
    los.disabled = false; });
  teile.push(f);
  // Platzhalter: Einträge wie „X“ halten Zeit nur frei und blocken nichts
  const pf = el("form","ei-form ei-platz"), pin = el("input"), pok = el("button","ghost small","Speichern");
  pin.value = (a.kalPlatzhalter || ["X"]).join(", "); pin.placeholder = "z. B. X, Block, frei halten"; pin.setAttribute("aria-label","Platzhalter-Titel");
  pok.type = "submit";
  pf.append(eiZeile("Zählt als frei", pin, pok),
    el("p","k-s","Einträge, die genau so heißen, sind nur Platzhalter: Die Zeit gilt als frei und BlockEm plant dort Aufgaben ein. Mehrere mit Komma trennen. Termine, die du im Kalender auf „Verfügbar“ (bzw. „Frei“) stellst, zählen schon von selbst als frei."));
  pf.addEventListener("submit", async e => { e.preventDefault(); pok.disabled = true;
    try { await eiApi("api/kalender", {platzhalter:pin.value}, pin.value.trim() ? `Zählt als frei: ${pin.value}` : "Keine Platzhalter mehr."); } catch {}
    pok.disabled = false; });
  if (liste.length) teile.push(pf);
  teile.push(eiGoogle(a.google || {}));
  const hilfe = el("details","more ei-hilfe"); hilfe.append(el("summary", null, "Wo finde ich die iCal-Adresse?"));
  [["Google Kalender", "Am Computer: Einstellungen › links deinen Kalender wählen › „Kalender integrieren“ › „Privatadresse im iCal-Format“ kopieren."],
   ["Apple / iCloud", "Kalender-App: Rechtsklick auf den Kalender › „Kalender freigeben“ › „Öffentlicher Kalender“ an › Adresse kopieren (beginnt mit webcal://)."],
   ["Outlook / Microsoft 365", "outlook.com › Einstellungen › Kalender › Freigegebene Kalender › „Kalender veröffentlichen“ › ICS-Link kopieren."]]
    .forEach(([t, x]) => { const p = el("p","k-s"); p.append(el("b", null, t + ": "), x); hilfe.append(p); });
  hilfe.append(el("p","k-s","Die Adresse bleibt nur auf deinem Mac. BlockEm liest die Termine nur, es ändert nichts in deinem Kalender."));
  teile.push(hilfe);
  box.replaceChildren(...teile);
}

/* Google: bestätigte Blöcke („Passt so“) als Termine eintragen; in Google verschobene Termine ändern die Zeit im Cockpit */
const EI_GOOGLE_SCHRITTE = [
  ["Projekt anlegen", "console.cloud.google.com öffnen (mit deinem Google-Konto) › oben „Projekt auswählen“ › „Neues Projekt“ › Name „BlockEm“ › Erstellen.", "https://console.cloud.google.com/projectcreate"],
  ["Kalender-Zugang einschalten", "Im neuen Projekt nach „Google Calendar API“ suchen › „Aktivieren“.", "https://console.cloud.google.com/apis/library/calendar-json.googleapis.com"],
  ["App beschreiben", "„Google Auth Platform“ › „Jetzt starten“: App-Name „BlockEm“, deine E-Mail, Zielgruppe „Extern“, Kontakt-E-Mail › Fertigstellen. Danach unter „Zielgruppe“ auf „App veröffentlichen“ tippen. Sonst musst du dich alle 7 Tage neu anmelden.", "https://console.cloud.google.com/auth/overview"],
  ["Zugangsdaten holen", "„Clients“ › „Client erstellen“ › Anwendungstyp „Desktop-App“ › Name egal › Erstellen. Client-ID und Clientschlüssel kopieren.", "https://console.cloud.google.com/auth/clients"],
  ["Hier einfügen und anmelden", "Beides unten einfügen, „Speichern“, dann „Mit Google anmelden“. Bei „Google hat diese App nicht überprüft“: „Erweitert“ › „Weiter zu BlockEm“. Das ist deine eigene App, nur du nutzt sie."]];
function eiGoogle(g){
  const box = el("div","ei-google"), lokal = ["localhost","127.0.0.1"].includes(location.hostname);
  box.append(el("h4", null, "Blöcke in Google eintragen"));
  if (g.verbunden){
    const z = el("div","ei-kal"); z.append(el("i","ei-dot ok"), el("b", null, "Verbunden" + (g.email ? ` mit ${g.email}` : "")),
      eiSchalter(autoAn("googleBloecke"), async an => { try { S.plan = await api("api/automatik", {schalter:{googleBloecke:an}}); renderPlan(); toast(an ? "Blöcke kommen in deinen Google-Kalender." : "Keine Blöcke mehr in Google."); } catch (e){ toast(e.message || String(e)); } }, "Blöcke in Google eintragen"),
      eiKnopf("Trennen", "ghost small", () => eiApi("api/google", {trennen:true}, "Google getrennt.")));
    box.append(z, el("p","k-s", "Sobald du „Mein Tag“ mit „Passt so“ bestätigst, stehen die Blöcke als Termine in deinem Google-Kalender. Verschiebst oder kürzt du dort einen, übernimmt BlockEm die neue Zeit. Löschst du ihn dort, bleibt die Aufgabe heute ohne feste Zeit." + (g.zuletzt ? ` Zuletzt abgeglichen: ${g.zuletzt} Uhr.` : "")));
    if (g.fehler) box.append(el("p","k-s c-bad", g.fehler));
    return box;
  }
  box.append(el("p","k-s","Bestätigst du deinen Tag, landen die Blöcke von selbst als Termine in deinem Google-Kalender. Dafür legst du einmal einen eigenen, kostenlosen Zugang bei Google an (etwa 10 Minuten). Deine Daten gehen nur zwischen deinem Mac und Google hin und her."));
  const anl = el("details","more ei-hilfe ei-schritte"); anl.open = !g.clientDa;
  anl.append(el("summary", null, "So richtest du den Zugang ein"));
  const ol = el("ol");
  EI_GOOGLE_SCHRITTE.forEach(([t, x, link]) => { const li = el("li"); li.append(el("b", null, t + ": "), x);
    if (link){ const l = el("a", null, " Öffnen ↗"); l.href = link; l.target = "_blank"; l.rel = "noopener"; li.append(l); } ol.append(li); });
  anl.append(ol);
  if (g.redirect) anl.append(el("p","k-s", `Fragt Google nach einer Weiterleitungs-Adresse, trage ${g.redirect} ein.`));
  box.append(anl);
  const f = el("form","ei-form"), id = el("input"), sec = el("input"), ok = el("button","ghost small","Speichern");
  id.placeholder = g.clientDa ? `Gespeichert: ${g.clientMaske}` : "Client-ID (…apps.googleusercontent.com)"; id.setAttribute("aria-label","Client-ID"); id.autocomplete = "off";
  sec.type = "password"; sec.placeholder = "Clientschlüssel"; sec.setAttribute("aria-label","Clientschlüssel"); sec.autocomplete = "off";
  ok.type = "submit"; f.append(id, sec, ok);
  f.addEventListener("submit", async e => { e.preventDefault(); if (!id.value.trim()){ id.focus(); return; } ok.disabled = true;
    try { await eiApi("api/google", {client:{id:id.value, secret:sec.value}}, "Gespeichert. Jetzt mit Google anmelden."); } catch {}
    ok.disabled = false; });
  box.append(f);
  if (g.clientDa){
    if (lokal){
      const an = eiKnopf("Mit Google anmelden", "ask small", async () => {
        an.disabled = true;
        try { const r = await api("api/google", {anmelden:true}); location.href = r.url; } catch (e){ toast(e.message || String(e)); an.disabled = false; } });
      box.append(an);
    } else box.append(el("p","k-s","Die Anmeldung bei Google geht nur am Mac (dort in BlockEm)."));
  }
  if (g.fehler) box.append(el("p","k-s c-bad", g.fehler));
  return box;
}

/* Über dich: Name, großes Ziel mit Datum (Kopfzeile „Tage bis …“), Tagesziele */
function renderEiDu(){
  const pr = S.plan.profil || {}, box = $("eiDu");
  if (box.contains(document.activeElement)) return;   // nicht beim Tippen neu zeichnen
  const f = el("form","ei-form"), name = el("input"), datum = el("input"), ziel = el("input"), prod = el("input"), budget = el("input");
  name.value = pr.name || ""; name.maxLength = 40; name.setAttribute("aria-label","Dein Name");
  ziel.value = pr.zielText || ""; ziel.placeholder = "z. B. eigenes Business"; ziel.maxLength = 60; ziel.setAttribute("aria-label","Großes Ziel");
  datum.type = "date"; datum.value = pr.zielDatum || ""; datum.setAttribute("aria-label","Ziel-Datum");
  prod.type = budget.type = "number"; prod.min = budget.min = "5"; prod.step = "15"; budget.step = "5";
  prod.value = S.goalMin; budget.value = S.limitMin; prod.setAttribute("aria-label","Produktiv-Ziel in Minuten"); budget.setAttribute("aria-label","Ablenkungs-Budget in Minuten");
  const ok = el("button","ask small","Speichern"); ok.type = "submit";
  f.append(eiZeile("Name", name), eiZeile("Großes Ziel", ziel), eiZeile("bis", datum),
    eiZeile("Produktiv pro Tag", prod, el("span","k-s","Min")), eiZeile("Ablenkung höchstens", budget, el("span","k-s","Min")), ok);
  f.addEventListener("submit", async e => { e.preventDefault(); ok.disabled = true;
    S.goalMin = Math.max(5, +prod.value || 180); S.limitMin = Math.max(5, +budget.value || 60);
    store("cockpit.ziele", {goalMin:S.goalMin, limitMin:S.limitMin});
    try { await eiApi("api/einstellungen", {name:name.value, zielText:ziel.value, zielDatum:datum.value, produktivZielMin:S.goalMin, prokrastinationLimitMin:S.limitMin}, "Gespeichert.");
      limitAbgleich(); renderHeader(); renderDay(); renderWeek(); } catch {}
    ok.disabled = false; document.activeElement?.blur(); renderEiDu(); });
  box.replaceChildren(f, el("p","hint kon-hint","Das große Ziel steht oben als „Tage bis …“. Produktiv-Ziel und Budget gelten für Heute, Werte und die Hinweise."));
}

/* Mein Tag: Tagesrahmen für Zeitleiste und freie Zeiten, Termine von den Stunden abziehen */
function renderEiTag(){
  const r = S.plan.automatik?.tagRahmen || {von:8, bis:20, abziehen:true}, box = $("eiTag");
  const sel = (wert, werte, fn, label) => { const s = document.createElement("select"); s.setAttribute("aria-label", label);
    werte.forEach(h => s.append(new Option(`${pad(h)}:00`, h, false, h === wert))); s.addEventListener("change", () => fn(+s.value)); return s; };
  const h = [...Array(25).keys()];
  const von = sel(r.von, h.slice(0, 24), v => eiApi("api/kalender", {von:v}, "Tagesrahmen gespeichert."), "Tag beginnt"),
        bis = sel(r.bis, h.slice(1), v => eiApi("api/kalender", {bis:v}, "Tagesrahmen gespeichert."), "Tag endet");
  const z = zeitDaten();
  box.replaceChildren(
    eiZeile("Mein Tag", von, el("span","k-s","bis"), bis),
    eiZeile("Termine abziehen", eiSchalter(r.abziehen !== false, an => eiApi("api/kalender", {abziehen:an}), "Termine von den Stunden abziehen"),
      el("span","k-s","Ein voller Kalendertag bekommt weniger Stunden für Projekte.")),
    eiZeile("Für Projekte", el("span", null, `${stdKurz(z.std)} und ${z.aufgaben} Aufgaben pro Tag`), (() => { const b = eiKnopf("Ändern", "zt-link", () => { showTab("ziele"); ztOeffnen("standard", "woche"); window.scrollTo(0, 0); }); return b; })()),
    el("p","hint kon-hint","In diesem Rahmen verteilt die Zeitleiste auf Heute deine Aufgaben zwischen die Termine."));
}

/* Aussehen: Automatisch / Hell / Dunkel (pro Gerät) */
function themaSetzen(t){
  const echt = t === "auto" ? (matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark") : t;
  document.documentElement.dataset.theme = echt;
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", echt === "light" ? "#f4f6f8" : "#071017");
}
function renderThema(){
  const box = $("eiThema"); if (!box) return;
  const w = store("cockpit.thema") || "auto", c = el("div","chips");
  [["auto","Wie das System"],["light","Hell"],["dark","Dunkel"]].forEach(([k, n]) => {
    const b = eiKnopf(n, "chip small", () => { store("cockpit.thema", k); themaSetzen(k); renderThema(); }); b.setAttribute("aria-pressed", String(w === k)); c.append(b); });
  box.replaceChildren(c, el("p","hint kon-hint","Gilt für dieses Gerät."));
}
themaSetzen(store("cockpit.thema") || "auto");
try { matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => { if ((store("cockpit.thema") || "auto") === "auto") themaSetzen("auto"); }); } catch {}

/* Deine Daten: wo sie liegen, Export, Datenschutz */
function renderEiDaten(){
  const pr = S.plan.profil || {}, box = $("eiDaten");
  const liste = el("ul","ei-liste");
  (VB.modus === "handy" ? [["Aufgaben, Ziele, Projekte, Habits", "als Notizen nur auf diesem Handy (im Speicher der App)"],
   ["Bildschirmzeit", "aus der Android-Nutzungsstatistik, ausgewertet nur auf diesem Handy"],
   ["KI-Schlüssel", "nur auf diesem Handy, nicht im Export"],
   ["Wichtig", "Deinstallierst du die App, sind die Daten weg. Exportiere sie vorher."]]
  : S.serverModus === "server" ? [["Aufgaben, Ziele, Projekte, Habits", "auf deinem BlockEm-Server"],
   ["Bildschirmzeit", "von den Handys mit der BlockEm-App, gespeichert auf deinem Server"],
   ["KI-Schlüssel", "nur auf dem Server, nicht in Sicherungen und Exporten"]]
  : [["Aufgaben, Ziele, Projekte, Habits", pr.vault ? `als Markdown in ${pr.vault}${pr.obsidian ? " (dein Obsidian-Vault)" : ""}` : "noch kein Ordner"],
   ["Bildschirmzeit", "vom Computer über den eigenen Zähler von BlockEm, von Handys über die BlockEm-App im WLAN; gespeichert nur auf deinem Mac"],
   ["Einstellungen und Fokus-Verlauf", "im App-Ordner auf deinem Mac"],
   ["KI-Schlüssel", "nur auf deinem Mac, nicht in Sicherungen und Exporten"]]).forEach(([t, x]) => { const li = el("li"); li.append(el("b", null, t + ": "), x); liste.append(li); });
  const ex = VB.inApp ? eiKnopf("Alle Daten exportieren (ZIP)", "ask small ei-export", handyExport) : el("a","ask small ei-export","Alle Daten exportieren (ZIP)");
  if (!VB.inApp){ ex.href = "api/export" + (CODE ? `?code=${encodeURIComponent(CODE)}` : ""); ex.setAttribute("download", ""); }
  const imp = eiKnopf("Daten importieren", "ghost small", importOeffnen); imp.title = "Projekte, Aufgaben, Habits und Ziele aus ChatGPT, Claude, Notion, Todoist …";
  if (!pr.vault) imp.disabled = true;
  const knoepfe = el("div","ei-knoepfe"); knoepfe.append(ex, imp);
  box.replaceChildren(el("p","ei-claim","Deine Bildschirmzeit verlässt nie dein Gerät."), liste, knoepfe,
    el("p","hint kon-hint", `BlockEm ${pr.version || ""}. Kein Konto, keine Cloud, keine Werbung. Daten gehen nur nach draußen, wenn du selbst eine Cloud-KI fragst oder einen Kalender verbindest.`));
}

// Schritt-für-Schritt: so bekommt man den API-Schlüssel beim jeweiligen Anbieter
const EI_HILFE = {
  anthropic:{wo:"console.anthropic.com", konto:"Mit E-Mail oder Google anmelden.", zahlen:"Unter Billing eine Karte hinterlegen und Guthaben aufladen (5 $ reichen lange).", knopf:"„Create Key“"},
  openai:{wo:"platform.openai.com", konto:"Mit deinem ChatGPT-Konto anmelden (das ChatGPT-Abo zählt hier nicht).", zahlen:"Unter Billing eine Karte hinterlegen und Guthaben aufladen.", knopf:"„Create new secret key“"},
  gemini:{wo:"aistudio.google.com", konto:"Mit deinem Google-Konto anmelden.", zahlen:"Für den Anfang kostenlos, mit Tageslimit.", knopf:"„Create API key“"},
  openrouter:{wo:"openrouter.ai", konto:"Konto anlegen (E-Mail oder Google).", zahlen:"Unter Credits Guthaben aufladen. Manche Modelle sind kostenlos.", knopf:"„Create Key“"},
  mistral:{wo:"console.mistral.ai", konto:"Konto anlegen und Workspace erstellen.", zahlen:"Einen Plan wählen (es gibt einen kostenlosen zum Ausprobieren).", knopf:"„Create new key“"}
};
function eiSchluesselHilfe(a){
  const h = EI_HILFE[a.id], d = el("details","more ei-hilfe ei-schritte");
  d.append(el("summary", null, "So bekommst du den Schlüssel"));
  if (!h){ const l = el("a","zt-link","Schlüssel holen ↗"); l.href = a.link; l.target = "_blank"; l.rel = "noopener"; d.append(l); return d; }
  const ol = el("ol"), li1 = el("li"), l = el("a","zt-link", h.wo + " ↗"); l.href = a.link; l.target = "_blank"; l.rel = "noopener";
  li1.append("Öffne ", l, ". ", h.konto);
  ol.append(li1, el("li", null, h.zahlen), el("li", null, `Auf ${h.knopf} tippen, einen Namen wie „BlockEm“ geben und den Schlüssel kopieren. Er wird nur einmal angezeigt.`),
    el("li", null, "Hier oben einfügen und „Speichern und benutzen“ tippen. Mit „KI testen“ siehst du, ob alles klappt."));
  d.append(ol, el("p","k-s","Der Schlüssel ist wie ein Passwort: nicht weitergeben. Er bleibt nur auf deinem Mac. Bezahlt wird beim Anbieter nach Nutzung, meist ein paar Cent pro Frage."));
  if (!a.maske) d.open = true;
  return d;
}

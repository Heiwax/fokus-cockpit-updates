/* ---------- BlockEm 1.0.14 (04.11.2026, john: „alle Ungereimtheiten raus“) ----------
   1. Nur ein Handy: keine Mac-Schalter, keine Computer-Texte (welche Geräte, merkt sich die Einrichtung in cockpit.geraete)
   2. Locker: Schutz, Nachfrage, „regelt mit“ und Orts-Sperre unter dem App Locker, ändern erst nach der PIN
   3. Einstellungen ohne Planungs- und Entwickler-Reste
   4. Test-Kanal (versteckt, 7× auf die Versionszeile im Systemcheck): Updates aus dem Beta-Zweig, Sync-Dienst-Adresse von Hand */
const BE_BETA = "https://raw.githubusercontent.com/Heiwax/fokus-cockpit-updates/beta/version.json";
const beNurTr = () => document.documentElement.classList.contains("nur-tracking");
function beGeraete(){
  const g = store("cockpit.geraete"); if (g && typeof g === "object") return g;
  // Vor 1.0.14 eingerichtet: aus den Geräten raten, die schon Daten geschickt haben
  const namen = (TR.daten?.geraete || []).join(" ");   // nicht S.day: dort stehen vor dem Nutzungszugriff Beispielgeräte
  return /windows|\bpc\b/i.test(namen) ? {windows:1} : /mac|computer|laptop/i.test(namen) ? {mac:1} : null;
}
// Nur dieses Handy, kein Computer dabei
function beNurHandy(){ if (VB.modus !== "handy") return false; const g = beGeraete(); return !(g && (g.mac || g.windows)); }
// Wie der Computer heißt: am Handy aus der Einrichtung, sonst vom Server
function bePc(){
  if (VB.modus !== "handy") return TR.daten?.pc === "Windows-PC" ? "PC" : TR.daten?.pc || "Mac";
  const g = beGeraete() || {}; return g.mac && g.windows ? "Computer" : g.windows ? "PC" : "Mac";
}
const BE = {};
// Zeit ohne Bildschirm: am Mac „Nicht am PC“, am Handy „Nicht am Handy“ bzw. „Offline“ (mehrere Geräte)
function beAway(){ return VB.modus !== "handy" ? "Nicht am PC" : beNurHandy() ? "Nicht am Handy" : "Offline"; }
if (VB.modus === "handy") document.querySelectorAll('.tab[data-r="werte"] .lbl, .tab[data-r="werte"] span').forEach(e => { if (e.childElementCount <= 1 && /^\s*Nicht am PC\s*$/.test(e.textContent)) e.lastChild.textContent = beAway(); });
const beTestKanal = () => store("cockpit.updateQuelle") === BE_BETA;

/* ----- 1. Einstellungen › Automatik: Texte ohne Mac, Vault und „Kommt noch“ ----- */
if (beNurTr() && typeof AUTOMATIKEN !== "undefined"){
  const neu = {
    hinweise: () => "Mitteilung" + (beNurHandy() ? "" : " auf Handy und " + bePc()) + ", sobald dein Ablenkungs-Budget voll ist, danach alle 30 Min.",
    rueckblick: () => "Kachel auf Heute am Sonntag/Montag und am Monatsende. Im Werte-Reiter kannst du ihn immer ansehen.",
    sicherung: () => "Jede Nacht eine Sicherung deiner Daten, 14 Tage lang.",
  };
  AUTOMATIKEN.forEach(x => { if (neu[x.k]) Object.defineProperty(x, "t", {get: neu[x.k], configurable:true}); });
  ["fokusAuto", "hinweise"].forEach(k => { const i = AUTOMATIKEN.findIndex(x => x.k === k); if (i >= 0) AUTOMATIKEN.splice(i, 1); });   // 1.0.48: Ablenkungs-Hinweis ruht (server waechter)
}

/* ----- 2. Locker: Reihenfolge, Symbole, ändern nur nach PIN ----- */
const BE_KARTEN = [["Inhaltsschutz"], ["Orts-Sperre"], ["Nachfrage"], ["BlockEm regelt mit"]];   // 1.0.48: wichtigstes zuerst
function beKartenOrdnen(){
  const box = $("trLockerKarten"); if (!box || box.hidden) return;
  const karten = [...box.children].filter(k => k.classList.contains("tr-karte"));
  const rang = k => { const t = k.querySelector(".tr-karte-kopf b")?.textContent || ""; const i = BE_KARTEN.findIndex(([n]) => t.startsWith(n)); return i < 0 ? 99 : i; };
  karten.sort((a, b) => rang(a) - rang(b)).forEach(k => {
    box.append(k);
  });
  beSperrHinweis();
}
// Ist eine PIN gesetzt und der Locker zu, lassen sich die Karten nur ansehen. Ändern: oben PIN eingeben.
function beZu(){ const d = LK.daten; return !!(d && d.pinGesetzt && !d.offen && !TR.daten?.entwickler); }
function beSperrHinweis(){
  const box = $("trLockerKarten"); if (!box) return;
  const zu = beZu(); box.classList.toggle("be-zu", zu);
  let h = $("beZuHinweis");
  if (!zu){ h?.remove(); return; }
  if (!h){
    h = el("div","be-zuhinweis"); h.id = "beZuHinweis";
    const b = el("button","ghost small be-pin","PIN eingeben"); b.type = "button";
    b.addEventListener("click", () => { $("lockerBox")?.scrollIntoView({behavior:"smooth", block:"start"}); setTimeout(() => $("locker")?.querySelector("input[type=password]")?.focus(), 350); });
    h.append(el("span", null, "Ansehen geht immer. Ändern erst, wenn du oben im App Locker deine PIN eingibst."), b);
  }
  box.prepend(h);
}
if (typeof trLockerKarten === "function"){
  const _beTlk = trLockerKarten;
  trLockerKarten = async function(...a){ const r = await _beTlk.apply(this, a); beKartenOrdnen(); return r; };
}
if (typeof renderLocker === "function"){
  const _beRl = renderLocker;
  renderLocker = function(...a){ const r = _beRl.apply(this, a); beSperrHinweis(); return r; };
}

/* ----- 3. Einstellungen: Planungs-Reste raus (BlockEm plant keine Projekte) ----- */
if (beNurTr() && typeof renderEiDu === "function"){
  const _beDu = renderEiDu;
  renderEiDu = function(...a){
    const r = _beDu.apply(this, a), box = $("eiDu"); if (!box) return r;
    // 1.0.48 (john 08.11.): Produktiv-Ziel und Ablenkungs-Limit raus, Limits gibt es nur noch im Locker
    box.querySelectorAll("input[aria-label='Großes Ziel'], input[aria-label='Ziel-Datum'], input[aria-label='Produktiv-Ziel in Minuten'], input[aria-label='Ablenkungs-Budget in Minuten']").forEach(i => i.closest(".ei-row")?.remove());
    box.querySelector(".hint")?.remove();
    return r;
  };
}
if (beNurTr()){ const t = document.querySelector('.es-page[data-s="profil"] section[aria-labelledby="hEiTag"]'); if (t) t.hidden = true; }

/* ----- 4. Systemcheck: Mac-Reste raus, Test-Kanal und Sync-Adresse ----- */
function beSystemcheck(){
  if (VB.modus !== "handy") return;
  const box = $("laeuftListe");
  if (box){
    // Neustart gehört zum Mac (start-cockpit.command), am Handy gibt es ihn nicht
    box.querySelectorAll("button").forEach(b => { if (/BlockEm neu starten/.test(b.textContent)) b.remove(); });
    box.querySelectorAll("p").forEach(p => { if (/Hilft, wenn etwas hängt/.test(p.textContent)) p.remove(); });
  }
  const upd = $("updSuche"); if (!upd) return;
  $("beTest")?.remove();
  if (!beTestKanal()) return;
  const k = el("div","be-test"); k.id = "beTest";
  const ad = el("input"); ad.type = "url"; ad.placeholder = "https://… (Adresse des Sync-Dienstes)"; ad.setAttribute("aria-label","Adresse des Sync-Dienstes");
  ad.value = SYNC.st?.adresse && SYNC.st.adresse !== SYNC.st.standard ? SYNC.st.adresse : "";
  const ok = el("button","ghost small","Adresse speichern"); ok.type = "button";
  ok.addEventListener("click", async () => {
    const v = ad.value.trim(); if (v && !/^https?:\/\//.test(v)) return toast("Bitte mit https:// anfangen.");
    try { SYNC.st = await api("api/sync", {aktion:"testAdresse", adresse:v}); toast(v ? "Gespeichert. BlockEm Sync steht jetzt unter Geräte & Konto." : "Sync-Adresse entfernt."); if (typeof renderSpeicherort === "function") renderSpeicherort(); }
    catch (e){ toast(e.message || String(e)); }
  });
  const aus = el("button","ghost small","Test-Kanal aus"); aus.type = "button";
  aus.addEventListener("click", () => { store("cockpit.updateQuelle", null); store("cockpit.updateCheck", null); toast("Test-Kanal aus. Updates wieder wie bei allen."); k.remove(); });
  const kn = el("div","be-knoepfe"); kn.append(ok, aus);
  k.append(el("b", null, "Test-Kanal an"), el("span","k-s","Dieses Handy bekommt Testversionen. „Nach Updates suchen“ schaut im Test-Zweig. BlockEm Sync zum Testen (leer = keiner):"), ad, kn);
  upd.after(k);
}
// 7× schnell auf „Handy-App 1.0.x“ tippen: Test-Kanal an
document.addEventListener("click", e => {
  const z = e.target.closest("#updSuche > span"); if (!z) return;
  const t = Date.now(); BE.tips = (BE.tips || []).filter(x => t - x < 4000).concat(t);
  if (BE.tips.length < 7) return; BE.tips = [];
  if (beTestKanal()) return toast("Test-Kanal ist schon an.");
  store("cockpit.updateQuelle", BE_BETA); store("cockpit.updateCheck", null);
  toast("Test-Kanal an: dieses Handy bekommt Testversionen."); beSystemcheck();
});
if (typeof renderLaeuft === "function"){
  const _beLf = renderLaeuft;
  renderLaeuft = function(...a){ const r = _beLf.apply(this, a); if (r && typeof r.then === "function") r.then(beSystemcheck); else beSystemcheck(); return r; };
}

/* ----- 5. Nachfrage: Apps als Symbole antippen, keine Wörterlisten, kein Pausen-Satz ----- */
const BE_STD = {
  social: ["Instagram", "TikTok", "Snapchat", "Facebook", "X", "Reddit", "Threads", "Pinterest", "Tumblr", "BeReal", "9gag", "Jodel", "Lemon8", "Likee", "Imgur"],
  streaming: ["YouTube", "Netflix", "Prime Video", "Disney+", "Paramount+", "Twitch", "Joyn", "Kick.com", "RTL+", "WOW", "Crunchyroll", "Apple TV", "MagentaTV", "DAZN", "Sky Go", "ARD Mediathek", "ZDFmediathek", "Pluto TV", "Dailymotion", "Vimeo"],
};
if (typeof CM_SVG !== "undefined" && !CM_SVG.pin) CM_SVG.pin = '<svg viewBox="0 0 24 24"><path d="M12 21s-6.5-6.2-6.5-11a6.5 6.5 0 0 1 13 0c0 4.8-6.5 11-6.5 11z" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="10" r="2.4" fill="currentColor"/></svg>';
function beAppChip(name, an, klick, weg){
  const b = el("button","chip be-appchip"); b.type = "button"; b.setAttribute("aria-pressed", String(!!an));
  if (typeof cmKachel === "function") b.append(cmKachel(name));
  b.append(el("span", null, name));
  if (weg){ const x = el("span","be-weg","×"); x.setAttribute("aria-hidden","true"); b.append(x); b.setAttribute("aria-label", name + " entfernen"); }
  b.addEventListener("click", klick); return b;
}
if (typeof trInnehaltenKarte === "function"){
  trInnehaltenKarte = function(x){
    const k = el("section","hud tr-karte"), kopf = el("div","tr-karte-kopf"), kat = TR.daten?.kategorien || {social:[], streaming:[]};
    const speichern = async body => { try { const r = await api("api/innehalten", body); TR.daten.innehalten = r.innehalten; setTimeout(() => trLockerKarten(true), 250); toast("Gespeichert."); } catch (e){ toast(e.message || String(e)); return false; } };
    kopf.append(el("span","tr-ico","✋"), el("div", null), trSchalter(x.an, v => speichern({an:v}), "Nachfrage an oder aus"));
    kopf.children[1].append(el("b", null, "Nachfrage"), el("span","k-s","„Brauchst du das gerade wirklich?“ Kurze Pause vor den Apps unten, auch in erlaubten Zeiten. Bei „Lieber nicht“ fragt BlockEm, warum."));
    k.append(kopf);
    if (!x.an){ k.append(el("p","k-s","Aus. Schalte es ein, dann kommt vor Instagram, TikTok, YouTube und Co. eine kurze Pause.")); return k; }
    // Auswahl: was in der Liste steht, ist an. Listen aus (alte Einstellung) = nichts aus den Listen an
    const listenAn = x.kategorien !== false, low = s => s.toLowerCase();
    const wahl = {social:new Set(listenAn ? (kat.social || []).map(low) : []), streaming:new Set(listenAn ? (kat.streaming || []).map(low) : [])};
    const extra = [...(x.apps || [])];
    let sek = x.sekunden || 10, geaendert = false;
    const ok = el("button","ask small","Speichern"); ok.type = "button"; ok.disabled = true;
    const merk = () => { geaendert = true; ok.disabled = false; };
    const gruppe = (titel, art) => {
      const namen = [...BE_STD[art]];
      (kat[art] || []).forEach(n => { if (low(n) !== "twitter" && !namen.some(m => low(m) === low(n))) namen.push(n); });
      const c = el("div","chips be-apps");
      namen.forEach(n => { const b = beAppChip(n, wahl[art].has(low(n)), () => {
        const an = !wahl[art].has(low(n)); an ? wahl[art].add(low(n)) : wahl[art].delete(low(n)); b.setAttribute("aria-pressed", String(an)); merk(); }); c.append(b); });
      return [el("b","be-st", titel), c];
    };
    const weitere = el("div","chips be-apps");
    const weitereZeichnen = () => weitere.replaceChildren(...extra.map((n, i) => beAppChip(n, true, () => { extra.splice(i, 1); weitereZeichnen(); merk(); }, true)));
    weitereZeichnen();
    const neu = el("input"); neu.placeholder = "App oder Seite, z. B. Telegram"; neu.setAttribute("aria-label","Weitere App oder Seite");
    const dazu = el("button","ghost small","Dazu"); dazu.type = "button";
    const hinzu = () => { const v = neu.value.trim(); if (v.replace(/[^\w]/g, "").length < 3) return toast("Mindestens 3 Buchstaben.");
      if (!extra.some(m => low(m) === low(v))) extra.push(v); neu.value = ""; weitereZeichnen(); merk(); };
    dazu.addEventListener("click", hinzu); neu.addEventListener("keydown", e => { if (e.key === "Enter"){ e.preventDefault(); hinzu(); } });
    const neuZ = el("div","be-neu"); neuZ.append(neu, dazu);
    const dur = el("div","r10-dur be-dur");
    [5, 10, 20, 30].forEach(v => { const b = el("button", v === sek ? "an" : "", v + " Sek."); b.type = "button";
      b.addEventListener("click", () => { sek = v; dur.querySelectorAll("button").forEach(x => x.classList.toggle("an", x === b)); merk(); }); dur.append(b); });
    if (![5, 10, 20, 30].includes(sek)){ const b = el("button","an", sek + " Sek."); b.type = "button"; dur.append(b); }
    ok.addEventListener("click", async () => {
      const liste = art => BE_STD[art].concat((kat[art] || []).filter(n => !BE_STD[art].some(m => low(m) === low(n)))).filter(n => wahl[art].has(low(n)));
      const social = liste("social").filter(n => low(n) !== "twitter"); if (social.includes("X")) social.push("twitter");
      try { const r = await api("api/kategorien", {social, streaming:liste("streaming")}); TR.daten.kategorien = r.kategorien; } catch (e){ toast(e.message || String(e)); return; }
      await speichern({apps:extra, sekunden:sek, kategorien:true, text:""});   // Satz-Vorlagen sind raus: leer = Standardfrage
      if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {});
    });
    const test = el("button","ghost small","Ausprobieren"); test.type = "button";
    test.addEventListener("click", () => trInnehalten("Instagram", "", {...x, sekunden:sek}));
    const kn = el("div","lk-knoepfe"); kn.append(ok, test);
    k.append(...gruppe("Social Media", "social"), ...gruppe("Streaming", "streaming"),
      el("b","be-st","Weitere Apps und Seiten"), weitere, neuZ, el("b","be-st","Pause"), dur, kn);
    return k;
  };
}

/* ----- 6. Einstellungen aufgeräumt (1.0.17, john: „räume das ganze Menü auf“) ----- */
if (typeof CM_SVG !== "undefined"){
  const s = (d, extra = "") => `<svg viewBox="0 0 24 24"><path d="${d}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>${extra}</svg>`;
  CM_SVG.person = CM_SVG.person || s("M4.5 20c.8-3.6 3.9-5.5 7.5-5.5s6.7 1.9 7.5 5.5", '<circle cx="12" cy="8" r="3.8" fill="none" stroke="currentColor" stroke-width="2"/>');
  CM_SVG.lock = CM_SVG.lock || s("M7.5 10.5V8a4.5 4.5 0 0 1 9 0v2.5", '<rect x="5" y="10.5" width="14" height="10" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/>');
  CM_SVG.bolt = CM_SVG.bolt || s("M13 2.5L5 13.5h6l-1 8 8-11h-6z");
  CM_SVG.cloud = CM_SVG.cloud || s("M7 18.5h10a4 4 0 0 0 .6-8 5.5 5.5 0 0 0-10.6 1.2A3.4 3.4 0 0 0 7 18.5z");
  CM_SVG.pulse = CM_SVG.pulse || s("M3 12h4l2.5-6 4 12 2.5-6H21");
  CM_SVG.palette = CM_SVG.palette || s("M12 3a9 9 0 0 0 0 18c1.2 0 1.8-.8 1.8-1.7 0-1.3-1-1.6-1-2.6 0-.9.7-1.6 1.7-1.6H17a4 4 0 0 0 4-4C21 6.6 17 3 12 3z", '<circle cx="7.8" cy="11" r="1.3" fill="currentColor"/><circle cx="11" cy="7.3" r="1.3" fill="currentColor"/><circle cx="15.5" cy="8.2" r="1.3" fill="currentColor"/>');
}
const BE_ES_ICO = {profil:"person", aussehen:"palette", locker:"lock", fokus:"hourglass", automatik:"bolt", geraete:"phone", speicherort:"cloud", status:"pulse", datenweg:"lock"};
if (beNurTr() && typeof ES_GRUPPEN !== "undefined"){
  const alle = Object.fromEntries(ES_GRUPPEN.flatMap(([, l]) => l.map(x => [x.k, x])));
  const setz = (k, t, s, such) => { const x = alle[k]; if (!x) return null; Object.assign(x, {t, s}); if (such) x.such += " " + such; return x; };
  setz("profil", "Über dich", "Dein Name");
  setz("aussehen", "Aussehen", "Hell, dunkel oder wie das System");
  setz("locker", "Locker", "Sperrzeiten, Limits, Schutz", "schutz nachfrage orte");
  setz("fokus", "Fokus-Sperre", "Was während einer Fokus-Session zu ist");
  setz("automatik", "Automatik", "Hinweise, Rückblick, Nacht-Sicherung");
  setz("geraete", "Handy-App", "Rechte, Schutz, Deinstallier-Sperre", "rechte bedienungshilfe");
  setz("speicherort", "Geräte & Konto", "Dein Konto, deine Geräte, anmelden", "sync blockem konto code qr koppeln weiteres gerät anmelden passwort speicherort");
  setz("status", "Systemcheck", "Sicherung, Updates, ob alles läuft", "update version");
  const neu = [["Du", ["profil", "aussehen"]], ["Sperren", ["locker", "fokus", "automatik"]], ["Geräte & Daten", ["geraete", "speicherort", "datenweg", "status"]]]
    .map(([n, ks]) => [n, ks.map(k => alle[k]).filter(Boolean)]);
  const rest = Object.values(alle).filter(x => !neu.some(([, l]) => l.includes(x)));   // Entwickler-Seiten bleiben, ganz unten
  if (rest.length) neu.push(["Weitere", rest]);
  ES_GRUPPEN.splice(0, ES_GRUPPEN.length, ...neu);
  if (typeof MEHR_REITER !== "undefined") MEHR_REITER.forEach(m => { if (m[0] === "einstellungen") m[2] = "Sperren, Geräte, Sync"; });
}
if (beNurTr() && typeof esListe === "function"){
  const _beEs = esListe;
  esListe = function(...a){
    const r = _beEs.apply(this, a);
    $("esListe")?.querySelectorAll(".es-zeile").forEach(z => { const ico = z.querySelector(".es-ico"), g = BE_ES_ICO[z.dataset.k];
      if (ico && g && typeof CM_SVG !== "undefined" && CM_SVG[g]){ ico.innerHTML = CM_SVG[g]; ico.style.background = ""; } });
    return r;
  };
}
// Fokus-Sperre: App-Symbole wie bei der Nachfrage
if (beNurTr() && typeof renderSperre === "function"){
  const _beSp = renderSperre;
  renderSperre = function(...a){
    const r = _beSp.apply(this, a);
    $("fkSperre")?.querySelectorAll(".sp-chips .chip").forEach(b => { if (b.querySelector(".cm-kachel") || typeof cmKachel !== "function") return;
      const n = b.textContent; b.classList.add("be-appchip"); b.classList.remove("small"); b.replaceChildren(cmKachel(n), el("span", null, n)); });
    return r;
  };
}
if (beNurTr()){ const h = $("hOrt"); if (h) h.textContent = "Geräte & Konto"; }

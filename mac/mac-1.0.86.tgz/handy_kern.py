"""BlockEm in der Handy-App ohne Server (ab 3.0).

Die App lädt Python (Pyodide) und führt dieselbe Logik aus wie der Server auf dem Mac (server.py),
nur ohne HTTP-Server: die Oberfläche ruft anfrage() direkt auf. Daten liegen im Handy unter /daten
(IndexedDB der App): /daten/app = BlockEm-Dateien, /daten/vault = Notizen (gleiches Format wie im Obsidian-Vault).
Internet (KI, Kalender) geht über die App-Brücke CockpitApp.http, weil Python im Handy keine eigenen Verbindungen öffnen kann.
"""
import io
import json
import os
import sys
from pathlib import Path

# Mit Mac/Server (3.14): Python läuft nur für den Locker ohne Verbindung, in einem eigenen Ordner (COCKPIT_DATEN_HANDY)
_DATEN = os.environ.get("COCKPIT_DATEN_HANDY") or "/daten/app"
os.environ["COCKPIT_DATEN"] = _DATEN
os.environ["COCKPIT_MODUS"] = "handy"
Path(_DATEN).mkdir(parents=True, exist_ok=True)
Path("/daten/vault").mkdir(parents=True, exist_ok=True)
_cfg = Path(_DATEN) / "config.json"
if not _cfg.exists():
    _cfg.write_text(json.dumps({"port": 0, "lan": False, "vault": "/daten/vault", "cockpitNotiz": "Cockpit/Cockpit.md",
                                "datenOrdner": "Cockpit", "projekteOrdner": "Projekte", "tagesberichtOrdner": "Cockpit/Bildschirmzeit",
                                "produktivZielMin": 180, "prokrastinationLimitMin": 60, "handyCode": "HANDY", "modus": "handy"},
                               ensure_ascii=False, indent=2), "utf-8")

# john 17.11.2026: Entwickler-Handy (nur mit Entwickler-Code in der App freigeschaltet) darf wie der Mac alles umschalten
try:
    from js import CockpitApp as _App
    if _App.entwickler():
        os.environ["COCKPIT_ENTWICKLER"] = "1"
except Exception:
    pass

import server  # noqa: E402
from urllib.error import HTTPError, URLError  # noqa: E402
from urllib.parse import parse_qs  # noqa: E402


class _Antwort(io.BytesIO):
    def __init__(self, status, daten, kopf):
        super().__init__(daten)
        self.status, self.headers = status, kopf

    def getcode(self):
        return self.status

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


def _urlopen(req, data=None, timeout=None, **_):
    """Ersatz für urllib.request.urlopen: geht über die Brücke der App (Java macht die Verbindung)."""
    import base64
    url = getattr(req, "full_url", req)
    methode = req.get_method() if hasattr(req, "get_method") else ("POST" if data else "GET")
    kopf = dict(req.header_items()) if hasattr(req, "header_items") else {}
    body = getattr(req, "data", None) or data or b""
    if isinstance(body, str):
        body = body.encode("utf-8")
    try:
        from js import CockpitApp
        http = CockpitApp.http
    except (ImportError, AttributeError):
        http = None
    if http:   # Android: Java macht die Verbindung (kein CORS)
        r = json.loads(http(methode, url, json.dumps(kopf), base64.b64encode(body).decode()))
    else:      # iPhone/Browser: synchrones XMLHttpRequest (der Anbieter muss Anfragen aus dem Browser erlauben)
        r = _xhr(methode, url, kopf, body)
    roh = base64.b64decode(r.get("daten") or "")
    if not r.get("status"):
        raise URLError(r.get("fehler") or "nicht erreichbar")
    if r["status"] >= 400:
        raise HTTPError(url, r["status"], r.get("fehler") or "", r.get("kopf") or {}, io.BytesIO(roh))
    return _Antwort(r["status"], roh, r.get("kopf") or {})


def _xhr(methode, url, kopf, body):
    import base64
    from js import XMLHttpRequest
    x = XMLHttpRequest.new()
    x.open(methode, url, False)
    x.overrideMimeType("text/plain; charset=x-user-defined")
    for k, v in kopf.items():
        if k.lower() not in ("user-agent", "content-length", "host"):
            x.setRequestHeader(k, v)
    if "api.anthropic.com" in url:
        x.setRequestHeader("anthropic-dangerous-direct-browser-access", "true")
    try:
        x.send(body.decode("utf-8") if body else None)
    except Exception as e:
        return {"status": 0, "fehler": f"nicht erreichbar ({e})"}
    roh = bytes(ord(c) & 0xFF for c in x.responseText)
    return {"status": x.status, "daten": base64.b64encode(roh).decode()}


server.urlopen = _urlopen


def anfrage(methode, pfad, query, body):
    """Eine Anfrage der Oberfläche wie beim Server: Antwort als JSON-Text, Fehler als {"__fehler": …}."""
    try:
        if methode == "GET":
            if pfad == "/api/export":
                import base64
                return json.dumps({"zip": base64.b64encode(server.export_zip()).decode()})
            r = server.api_get(pfad, parse_qs(query), True)
        else:
            r = server.api_post(pfad, json.loads(body or "{}"))
        return json.dumps(r, ensure_ascii=False)
    except server.ApiFehler as e:
        return json.dumps({"__fehler": str(e), "__code": e.code}, ensure_ascii=False)
    except Exception as e:
        print("Fehler", pfad, repr(e), file=sys.stderr)
        return json.dumps({"__fehler": str(e) or e.__class__.__name__, "__code": 500}, ensure_ascii=False)


def locker_setzen(stand, fokus_bis_ms=0):
    """Locker ohne Verbindung (3.14): Kopie vom Mac/letzten Stand übernehmen, letzter bekannter Fokus sperrt den Locker."""
    server.FOKUS_EXTERN["bis"] = float(fokus_bis_ms or 0) / 1000
    with server.AUTOMATIK_LOCK:
        a = server.automatik_load()
        a["locker"] = json.loads(stand or "{}")
        server.automatik_save(a)


def locker_fuer(geraet):
    return json.dumps(server.locker_fuer_handy(geraet), ensure_ascii=False)


def locker_lesen():
    return json.dumps(server.automatik_load().get("locker") or {}, ensure_ascii=False)


def taeglich():
    """Was auf dem Mac der Hintergrund-Wächter macht (Tageswechsel, Habits automatisch, Sicherung)."""
    for f in ("rollover", "nacht_sicherung"):
        try:
            getattr(server, f)()
        except Exception as e:
            print(f, e, file=sys.stderr)

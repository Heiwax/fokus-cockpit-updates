/* Schutz vor Deinstallieren am Mac und Windows-PC (09.11.2026). Nur am Computer (nicht in der Handy-App).
   Server: schutz_pc.py über GET/POST api/schutz-pc. Wirkt voll ohne Vertrauensperson (48 Std Ausstieg),
   die PIN einer Vertrauensperson ist nur eine Abkürzung (1 Std). Blatt im Design S (.ka-blatt, .vp-* aus vertrauen.css). */
const SP = {s: null, schritt: "", fehler: "", laedt: false};

function spAktiv(){ return !window.CockpitApp && VB.modus !== "handy"; }

async function spLaden(){
  if (!spAktiv()) return;
  try { SP.s = await api("api/schutz-pc"); } catch (e) { return; }
  spLeiste();
  if ($("spDialog")?.open) spZeichnen();
  // Neue Konto-Sperre: das Blatt einmal von selbst öffnen, damit niemand ratlos vor zugesperrten Apps sitzt
  const k = SP.s.kontoSperre;
  if (k && !$("spDialog")?.open){
    let neu = true;
    try { neu = localStorage.getItem("spSperreGesehen") !== String(k.seit || ""); localStorage.setItem("spSperreGesehen", String(k.seit || "")); } catch (e) {}
    if (neu) spOeffnen();
  }
}

async function spTun(body){
  if (SP.laedt) return;
  SP.laedt = true; SP.fehler = ""; spZeichnen();
  try {
    // länger warten als die üblichen 20 s: beim Einrichten tippt man das Passwort, der Wächter antwortet in Sekunden
    const s = await vbServer("api/schutz-pc", body, body.aktion === "einrichten" ? 330000 : 90000);
    SP.s = s;
    SP.schritt = "";
  } catch (e) { SP.fehler = e.message || String(e); }
  SP.laedt = false; spZeichnen(); spLeiste();
}

// Feste Leiste, solange der Schutz nicht eingerichtet ist (wie fsSchutzPflicht am Handy)
function spLeiste(){
  const s = SP.s; let b = $("spPflicht");
  if (!s || s.eingerichtet || s.entwickler || s.plattform === "andere"){ b?.remove(); return; }
  if (!b){
    b = el("button","fs-pflicht sp-pflicht"); b.id = "spPflicht"; b.type = "button";
    b.append(el("b", null, "🔒 Schutz vor Deinstallieren einschalten"), el("span", null, "Ein Klick, damit BlockEm in schwachen Momenten bleibt."));
    b.addEventListener("click", spOeffnen);
    document.body.append(b);
  }
}

function spOeffnen(){
  if (!spAktiv()) return;
  let d = $("spDialog");
  if (!d){
    d = el("dialog", "mehr-blatt modern ka-blatt vp-blatt"); d.id = "spDialog"; d.setAttribute("aria-label", "Schutz vor Deinstallieren");
    d.addEventListener("click", e => { if (e.target === d) d.close(); });
    d.addEventListener("close", () => { SP.schritt = ""; SP.fehler = ""; if (location.hash === "#schutz-pc") history.replaceState(null, "", location.pathname); });
    document.body.append(d);
  }
  spZeichnen();
  if (!d.open) d.showModal();
  spLaden();
}

function spKnopf(text, cls, fn){ const b = el("button", cls || "primary vp-breit", text); b.type = "button"; b.disabled = SP.laedt; b.addEventListener("click", fn); return b; }
function spLink(text, fn){ const b = el("button","vp-link", text); b.type = "button"; b.disabled = SP.laedt; b.addEventListener("click", fn); return b; }

function spZeichnen(){
  const d = $("spDialog"); if (!d) return;
  const s = SP.s, pc = s?.plattform === "windows" ? "Windows" : "dein Mac";
  d.replaceChildren();
  const zu = el("button","ka-zu","×"); zu.type = "button"; zu.setAttribute("aria-label","Schließen"); zu.addEventListener("click", () => d.close());
  d.append(zu, el("h2", null, "Schutz vor Deinstallieren"));
  if (!s){ d.append(el("p","vp-klein","Lädt …")); return; }

  const k = s.kontoSperre;
  if (k){
    // john 09.11.: Wer hier landet, ist oft aufgewühlt („Ich hab meinen PC kaputt gemacht“). Erst beruhigen, dann ruhig den Weg zeigen.
    const c = el("div","vp-karte vp-neu sp-ruhe");
    const bis = k.bis ? new Date(k.bis).toLocaleString("de-DE", {weekday:"long", hour:"2-digit", minute:"2-digit"}) : "";
    const wo = /handy|android|pixel|phone/i.test(k.geraet || "") ? "deinem Handy" : "einem deiner Geräte";
    const weg = el("ol","sp-schritte");
    if (k.wartetAufGeraet){
      weg.append(el("li", null, `Schalte BlockEm auf ${wo} wieder ein.`),
        el("li", null, "Dann laufen 48 Std. Nimm dir die Zeit und schau ehrlich hin: Willst du das wirklich?"),
        el("li", null, "Danach ist diese Sperre von selbst weg."));
    } else {
      weg.append(el("li", null, `Die Sperre endet ${bis ? "am " + bis : "bald"} von selbst.`),
        el("li", null, "Nimm dir die Zeit und schau ehrlich hin: Willst du das wirklich?"));
    }
    c.append(el("b", null, "Alles okay. Dein Computer ist heil."),
      el("p","vp-text", `Auf ${wo} wurde BlockEm abgeschaltet. Darum schützt dich dieser Computer jetzt strenger: Ablenker sind zu, deine Arbeit geht ganz normal weiter. Das ist kein Fehler. Das ist der Schutz, den du selbst für dich eingerichtet hast.`),
      el("p","vp-klein","So geht es weiter, ganz in Ruhe:"), weg,
      el("p","vp-klein","Hast du eine Vertrauensperson? Ruf sie an und erzähl ehrlich, was los war. Danach kann sie „Geklärt“ tippen, dann ist die Sperre sofort vorbei."));
    if (k.wartetAufGeraet){
      const b = spLink("Gerät kaputt oder verloren?", () => {});
      lkZweimal(b, "Dann endet die Sperre in 48 Std. Nochmal tippen", () => spTun({aktion:"geraetKaputt"}));
      c.append(b);
    }
    d.append(c);
  }

  if (!s.eingerichtet){
    d.append(el("p","vp-text","BlockEm bleibt, auch in einem schwachen Moment. Entfernen geht dann nur nach 48 Std Wartezeit."),
      spKnopf(SP.laedt ? "Einen Moment …" : "Schutz einschalten", null, () => spTun({aktion:"einrichten"})),
      el("p","vp-klein", s.plattform === "windows" ? "Windows fragt einmal, ob du es erlaubst." : "Dein Mac fragt einmal nach deinem Passwort."));
    if (s.entwickler) d.append(el("p","vp-klein","Entwicklerversion: Terminal und Aktivitätsanzeige bleiben offen."));
  } else {
    const c = el("div","vp-karte"), kopf = el("div","vp-kopf");
    kopf.append(el("b", null, s.frei ? "Frei" : s.timer ? "Ausstieg läuft" : s.pinWartet ? "PIN richtig" : "An"),
      el("span", s.laeuft ? "vp-ok" : "vp-wartet", s.laeuft ? "läuft" : "antwortet nicht"));
    c.append(kopf);
    if (s.frei){
      c.append(el("p","vp-klein", `Noch ${s.freiNoch} frei. Jetzt kannst du den Schutz entfernen. Danach kannst du den BlockEm-Ordner löschen.`));
      const b = spKnopf("Schutz entfernen", "ghost vp-breit"); lkZweimal(b, "Wirklich entfernen? Nochmal tippen", () => spTun({aktion:"entfernen"}));
      c.append(b, spLink("Doch bleiben", () => spTun({aktion:"abbrechen"})));
    } else if (s.timer){
      c.append(el("p","vp-klein", `Frei in ${s.timerFreiIn}. Bestätige spätestens in ${s.bestaetigenIn}, sonst beginnt es von vorn. Nachts zählt nicht.`),
        spKnopf("Ich will immer noch", s.bestaetigenBald ? "primary vp-breit" : "ghost vp-breit", () => spTun({aktion:"bestaetigen"})),
        spLink("Doch bleiben", () => spTun({aktion:"abbrechen"})));
    } else if (s.pinWartet){
      c.append(el("p","vp-klein", `Frei in ${s.pinFreiIn}.`), spLink("Doch bleiben", () => spTun({aktion:"abbrechen"})));
    } else if (SP.schritt === "gehen"){
      c.append(el("p","vp-text","Bevor du gehst: Soll jemand davon wissen?"),
        el("p","vp-klein","Sag es deiner Vertrauensperson, oder lade eine ein: am Handy unter Mehr › Vertrauensperson. Der Ausstieg dauert 48 Std (beim zweiten Mal in 30 Tagen 72 Std), alle 6 Std bestätigen."),
        spKnopf("Wartezeit starten", "ghost vp-breit", () => spTun({aktion:"timer"})),
        spLink("Doch bleiben", () => { SP.schritt = ""; spZeichnen(); }));
    } else {
      c.append(el("p","vp-klein", `BlockEm lässt sich an ${pc === "Windows" ? "diesem PC" : "diesem Mac"} gerade nicht entfernen.` + (s.zugriff ? "" : " Hinweis: Der BlockEm-Ordner liegt in Dokumente, dort kann der Schutz ihn nicht sichern. Besser in den Programme-Ordner legen.")),
        spLink("Schutz beenden …", () => { SP.schritt = "gehen"; spZeichnen(); }));
    }
    d.append(c);

    // PIN der Vertrauensperson (john 09.11.): nur sie hat sie (in ihrer BlockEm-App), der Server prüft sie, Ausstieg nach 1 Std
    const p = el("div","vp-karte");
    if (s.pinDa && !s.frei && !s.pinWartet){
      const f = el("input","vp-feld"); f.inputMode = "numeric"; f.autocomplete = "off"; f.placeholder = "10 Ziffern";
      p.append(el("b", null, "PIN deiner Vertrauensperson"), el("p","vp-klein","Sie steht in ihrer BlockEm-App. Mit ihr ist der Ausstieg nach 1 Std frei statt nach 48 Std. Jede PIN gilt nur einmal."),
        f, spKnopf("PIN prüfen", "ghost vp-breit", () => spTun({aktion:"pin", pin:f.value})));
    } else if (!s.pinDa && !s.frei){
      p.append(el("b", null, "Vertrauensperson (freiwillig)"), el("p","vp-klein","Mit einer Vertrauensperson geht der Ausstieg nach 1 Std statt nach 48 Std: Sie bekommt in ihrer App eine PIN, die nur sie kennt. Einrichten am Handy unter Mehr › Vertrauensperson."));
    }
    if (p.childElementCount) d.append(p);
  }

  // Plan B: nur mit Konto (ein zweites Gerät kann melden)
  if (s.kontoDa){
    const r = el("div","vp-karte sp-zeile"), t = el("div");
    t.append(el("b", null, "Geräte schützen sich gegenseitig"), el("p","vp-klein","Wird BlockEm auf einem deiner Geräte abgeschaltet, sperrt dieser Computer Ablenker, bis es geklärt ist."));
    r.append(t, eiSchalter(s.planB, an => spTun({aktion:"planB", an}), "Geräte schützen sich gegenseitig"));
    d.append(r);
  }
  if (SP.fehler) d.append(el("p","vp-klein sp-fehler", SP.fehler));
}

if (spAktiv()){
  setTimeout(spLaden, 3000); setInterval(spLaden, 60000);
  window.addEventListener("hashchange", () => { if (location.hash === "#schutz-pc") spOeffnen(); });
  if (location.hash === "#schutz-pc") setTimeout(spOeffnen, 1500);
}

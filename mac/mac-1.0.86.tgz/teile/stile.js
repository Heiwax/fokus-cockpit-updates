/* ---------- Stile (11.11.2026, ganz hinten, nach schutz-pc.js): Belohnung fürs Durchhalten ----------
   Unter den Abzeichen auf Heute steht eine Reihe Farb-Stile. Jeder Stil wird ab einer Zahl sauberer Tage frei und bleibt es
   (stil.max = höchster je gesehener Stand, auch nach einem Neuanfang). Technik wie frau.css: Farbdrehung per CSS-Filter, dazu je Stil
   eine andere Kachel-Form. Nur Aussehen, keine Sperrlogik. CSS in stile.css.
   shortcut: stil.max liegt nur auf diesem Gerät (localStorage) und ist nicht fälschungssicher; sobald Stile Geldwert bekommen, über den Server zählen.
   shortcut: im Frauen-Profil gibt es die Reihe nicht (dort läuft schon ein Filter); eigene Farbwerte nötig, wenn Frauen Stile bekommen sollen. */
const STILE = [
  {k:"orange", t:"Orange", ab:0, farbe:"#F4471C"},
  {k:"ozean", t:"Eisblau", ab:7, farbe:"#3D7DF2"},     // 19.11. (john): Eisblau, Smaragd, Bernstein; Violett raus. Schlüssel bleiben, damit gewählte Stile erhalten bleiben
  {k:"smaragd", t:"Smaragd", ab:30, farbe:"#0F8A6B"},
  {k:"gold", t:"Bernstein", ab:180, farbe:"#B66000"},   // shortcut: per Farbdrehung erreichbar ist nur dunkler Bernstein; heller (#E9A23B) braucht Akzent als Variable statt Filter
  {k:"rose", t:"Rosé", ab:365, farbe:"#ff6fb5"},
];
function stilFrei(s){ return s.ab <= (store("stil.max") || 0); }
function stilSetzen(k){
  const s = STILE.find(x => x.k === k && stilFrei(x)) || STILE[0];
  STILE.forEach(x => document.documentElement.classList.toggle("stil-" + x.k, x === s && x.ab > 0));
  return s.k;
}
function stilReihe(tage){
  if (tage > (store("stil.max") || 0)) store("stil.max", tage);
  const aktiv = stilSetzen(store("stil.wahl")), reihe = el("div","st-reihe");
  reihe.setAttribute("role","group"); reihe.setAttribute("aria-label","Stil der App");
  STILE.forEach(s => {
    const frei = stilFrei(s), b = el("button", frei ? "" : "zu", frei ? "" : String(s.ab)); b.type = "button";
    b.style.setProperty("--st-farbe", s.farbe); b.setAttribute("aria-pressed", String(s.k === aktiv));
    b.title = frei ? `Stil ${s.t}` : `Stil ${s.t}: frei ab ${s.ab} Tagen`; b.setAttribute("aria-label", b.title);
    b.addEventListener("click", () => {
      if (!frei){ toast(`Stil ${s.t} schaltest du mit ${s.ab} Tagen sauber frei.`); return; }
      store("stil.wahl", s.k); stilSetzen(s.k);
      reihe.querySelectorAll("button").forEach(x => x.setAttribute("aria-pressed", String(x === b)));
    });
    reihe.append(b);
  });
  return reihe;
}
if (NUR_TRACKING){
  stilSetzen(store("stil.wahl"));   // gleich beim Start, damit die Seite nicht erst violett aufblitzt
  const stilHeroAlt = trHeroZeichnen;
  trHeroZeichnen = function(h, d){
    stilHeroAlt(h, d);
    if (document.documentElement.classList.contains("r2-frau")) return;
    h.querySelector(".cm-abzeichen")?.after(stilReihe(d.sauber?.tage ?? 0));
  };
}

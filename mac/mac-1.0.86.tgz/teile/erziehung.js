/* ---------- Erziehungs-System (02.11.2026, john): Karte „Dein Weg“ auf Heute (nach clearmind.js) ----------
   Je Kategorie (Social Media, Videos, weitere Apps) Stufe Hart → Nachfrage → Frei. Lockern nur als Angebot nach 14 bzw. 30 sauberen Tagen.
   Rückfall: Hinweis mit Zahlen + „Ja, wieder voll sperren“ / „Ich krieg das hin“; geht es 24 Std. weiter, sperrt der Server wieder hart.
   Pornografie bleibt immer gesperrt. Daten: GET /api/erziehung (auch in /api/tracking „erziehung“), POST /api/erziehung {kat, aktion}. */
const ERZ = {daten:null, zweimal:""};

async function erzAktion(kat, aktion, extra){
  try {
    ERZ.daten = await api("api/erziehung", {kat, aktion, ...(extra || {})});
    if (TR.daten) TR.daten.erziehung = ERZ.daten;
    erzZeichnen();
    const k = (ERZ.daten.kategorien || []).find(x => x.k === kat);
    if (aktion === "sperren") toast(`${k?.name || "Kategorie"} ist wieder hart gesperrt. Gute Entscheidung.`);
    if (aktion === "lockern") toast(`Stufe ${k?.stufeName}. Du schaffst das.`);
    if (aktion === "schaffeDas") toast("Okay. Ich schau in 24 Std. nochmal drauf.");
  } catch (e){ toast(e.message || String(e)); }
}
function erzKnopf(text, klasse, fn){ const b = el("button", klasse, text); b.type = "button"; b.addEventListener("click", fn); return b; }
function erzStunden(bis){ const h = Math.max(0, Math.round((bis - Date.now()) / 3600000)); return h <= 1 ? "der nächsten Stunde" : `den nächsten ${h} Std.`; }

function erzZeichnen(){
  const heute = document.querySelector('.tab[data-r="heute"]'); if (!heute) return;
  let box = $("erzBox");
  if (!box){ box = el("section","erz"); box.id = "erzBox"; }
  const hero = $("trHero");
  if (hero && hero.parentNode){ if (hero.nextElementSibling !== box) hero.after(box); }
  else if (!box.parentNode) heute.prepend(box);
  const d = ERZ.daten || TR.daten?.erziehung;
  if (!d || !(d.kategorien || []).length){ box.hidden = true; return; }
  const teile = [];
  d.kategorien.forEach(k => {
    if (k.hinweis){
      const c = el("div","erz-karte erz-alarm");
      c.append(el("span","erz-klein", `Rückfall · ${k.name}`), el("h3", null, "Ich sehe, du bist wieder rückfällig geworden."), el("p", null, k.hinweis.text));
      c.append(el("p","erz-leise", k.hinweis.abgelehnt
        ? `Okay, du willst es selbst schaffen. Geht es in ${erzStunden(k.hinweis.bis)} so weiter, sperre ich ${k.name} automatisch wieder hart.`
        : `Ich glaube, wir sollten wieder voll sperren. Machst du in ${erzStunden(k.hinweis.bis)} so weiter, mache ich das automatisch.`));
      const kn = el("div","erz-knoepfe");
      kn.append(erzKnopf("Ja, wieder voll sperren", "erz-ja", () => erzAktion(k.k, "sperren")));
      if (!k.hinweis.abgelehnt) kn.append(erzKnopf("Ich krieg das hin", "erz-nein", () => erzAktion(k.k, "schaffeDas")));
      c.append(kn); teile.push(c);
    } else if (k.angebot){
      const c = el("div","erz-karte erz-angebot");
      const satz = k.naechste === "Frei"
        ? "Lass uns probieren, ob du es ganz ohne Sperre schaffst. Ich beobachte nur noch und melde mich, wenn du in alte Muster fällst."
        : "Lass uns probieren, ob du es auch ohne harte Sperre schaffst. Statt zu sperren frage ich dann kurz: Brauchst du das gerade wirklich?";
      c.append(el("span","erz-klein", `Geschafft · ${k.name}`), el("h3", null, `${k.angebot.tage} Tage durchgehalten. Stark.`), el("p", null, satz));
      const kn = el("div","erz-knoepfe");
      kn.append(erzKnopf("Ja, probieren", "erz-ja", () => erzAktion(k.k, "lockern")), erzKnopf("Noch nicht", "erz-nein", () => erzAktion(k.k, "spaeter")));
      c.append(kn); teile.push(c);
    } else if (k.autoHart){
      const c = el("div","erz-karte erz-info");
      c.append(el("p", null, `${k.name} ist wieder hart gesperrt, weil es nach dem Hinweis weiterging. Das ist kein Scheitern: Ab heute zählen die Tage neu.`)); teile.push(c);
    } else if (k.gutGemacht){
      const c = el("div","erz-karte erz-info");
      c.append(el("p", null, `Stark: Nach dem Hinweis hast du bei ${k.name} die Kurve gekriegt.`)); teile.push(c);
    }
  });
  const weg = el("div","erz-karte erz-weg");
  weg.append(el("h3", null, "Dein Weg"), el("p","erz-leise", "Hart sperren, durchhalten, lockern. Fällst du zurück, wird es wieder hart."));
  d.kategorien.forEach(k => {
    const z = el("div","erz-zeile"), kopf = el("div","erz-kopf");
    kopf.append(el("b", null, k.name));
    const stufen = el("div","erz-stufen");
    ["Hart","Nachfrage","Frei"].forEach(s => stufen.append(el("span", s === k.stufeName ? "an" : "", s)));
    kopf.append(stufen); z.append(kopf);
    if (k.ziel){
      const t = Math.min(k.tage, k.ziel), bar = el("div","erz-balken"), fuell = el("i");
      fuell.style.width = Math.round(t / k.ziel * 100) + "%"; bar.append(fuell); z.append(bar);
    }
    let unten = k.stufe === "hart" ? `Tag ${Math.min(k.tage, k.ziel)} von ${k.ziel} bis ${k.naechste}` + (k.regeln ? "" : " · noch keine Sperr-Regel dafür")
      : k.stufe === "nachfrage" ? `Heute ${k.heute?.min ?? 0} Min, ${k.heute?.oeffnen ?? 0}× geöffnet · Tag ${Math.min(k.tage, k.ziel)} von ${k.ziel} bis ${k.naechste}`
      : `Ich beobachte nur noch. Heute ${k.heute?.min ?? 0} Min, ${k.heute?.oeffnen ?? 0}× geöffnet`;
    const fuss = el("div","erz-fuss"); fuss.append(el("small", null, unten));
    if (k.stufe !== "hart"){
      const sicher = ERZ.zweimal === k.k;
      fuss.append(erzKnopf(sicher ? "Wirklich? Tippen" : "Wieder hart", "erz-mini", () => {
        if (!sicher){ ERZ.zweimal = k.k; erzZeichnen(); setTimeout(() => { if (ERZ.zweimal === k.k){ ERZ.zweimal = ""; erzZeichnen(); } }, 4000); return; }
        ERZ.zweimal = ""; erzAktion(k.k, "sperren");
      }));
    }
    z.append(fuss);
    if (d.entwickler){
      const sel = el("select","erz-mini");
      ["hart","nachfrage","frei"].forEach(s => { const o = el("option", null, s); o.value = s; o.selected = s === k.stufe; sel.append(o); });
      sel.title = "Nur Entwicklerversion: Stufe zum Testen setzen";
      sel.addEventListener("change", () => erzAktion(k.k, "stufe", {stufe: sel.value}));
      z.append(sel);
    }
    weg.append(z);
  });
  const porno = el("div","erz-zeile erz-fest"); porno.append(el("b", null, "Pornografie"), el("span", null, "immer gesperrt"));
  weg.append(porno);
  box.replaceChildren(...teile, weg); box.hidden = false;
}

async function erzLaden(){ try { ERZ.daten = await api("api/erziehung"); erzZeichnen(); } catch {} }

if (typeof trHeroZeichnen === "function"){
  const _erzHero = trHeroZeichnen;
  trHeroZeichnen = function(h, d){ const r = _erzHero.apply(this, arguments); if (d?.erziehung) ERZ.daten = d.erziehung; erzZeichnen(); return r; };
}
// Innehalten: in der Stufe „Nachfrage“ mit der Erziehungs-Frage und eigenen Knöpfen
if (typeof trInnehalten === "function"){
  const _erzPause = trInnehalten;
  trInnehalten = function(w, u, x){
    const jetzt = TR.daten?.innehaltenJetzt;
    const r = _erzPause.call(this, w, u, jetzt && jetzt.erziehung ? jetzt : x);
    if (jetzt && jetzt.erziehung){
      const d = $("trPause"), b = d ? d.querySelectorAll(".tr-pause-knoepfe button") : [];
      if (b[0]) b[0].textContent = "War nur eine Attacke";
      if (b[1]){ const alt = b[1].disabled; b[1].textContent = `Bewusst: weiter zu ${w}`; b[1].disabled = alt; }
    }
    return r;
  };
}

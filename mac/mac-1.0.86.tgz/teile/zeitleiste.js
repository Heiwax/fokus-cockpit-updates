/* ---------- Mein Tag: Zeitleiste auf Heute (Termine aus dem Kalender + feste Zeiten für die Aufgaben + Fokus-Sessions) ---------- */
// Der Server verteilt die Aufgaben von heute in die Lücken zwischen den Terminen (zeitplan in automatik.json).
// Mit „Passt so“ ist der Tag bestätigt: zu Beginn jedes Blocks startet der Fokus von selbst (Schalter „planfokus“).
const ZL = {offen:null};
const zlMin = hhmm => { const [h, m] = hhmm.split(":").map(Number); return h * 60 + m; };
async function zlSetzen(body, ok){
  try { S.plan = await api("api/zeitplan", body); renderPlan(); if (ok) toast(ok); }
  catch (e){ toast(e.message || String(e)); }
}
function renderZeitleiste(){
  const box = $("tagBox"); if (!box) return;
  const z = S.plan?.zeitplan;
  box.hidden = S.mode !== "lokal" || !z; if (box.hidden) return;
  // nicht neu zeichnen, während eine Uhrzeit getippt wird
  if (box.contains(document.activeElement) && document.activeElement.tagName === "INPUT") return;
  const k = S.plan.kalender, termine = z.termine.filter(t => !t.ganz), ganz = z.termine.filter(t => t.ganz);
  const h = el("h2"); h.id = "hTag"; h.append("Mein Tag ");
  h.append(el("span", null, `${pad(z.von)}–${pad(z.bis)} Uhr · ${termine.length} ${termine.length === 1 ? "Termin" : "Termine"} · ${z.bloecke.length} ${z.bloecke.length === 1 ? "Block" : "Blöcke"}`));
  if (z.bloecke.some(b => b.status !== "fertig")){
    const neu = eiKnopf("Neu einteilen", "act-btn", () => zlSetzen({neu:true}, "Neu verteilt."));
    neu.title = "Alles, was noch nicht begonnen hat, neu in die freien Lücken legen (feste Zeiten bleiben)"; h.append(neu);
  }
  const teile = [h];
  if (ganz.length){ const c = el("div","zl-ganz"); ganz.forEach(t => { const x = el("span","zl-chip"); x.style.setProperty("--f", t.farbe); x.append(el("i"), t.titel); c.append(x); }); teile.push(c); }
  teile.push(zlBalken(z));
  // Bestätigen: dann startet der Fokus zu den Zeiten von selbst
  const offen = z.bloecke.filter(b => b.status === "kommt" || b.status === "jetzt");
  if (offen.length){
    const bar = el("div","zl-ok" + (z.bestaetigt ? " an" : ""));
    if (!z.bestaetigt){
      bar.append(el("span", null, z.planfokus ? "Vorschlag: Passt der Tag so? Dann startet der Fokus zu jeder Zeit von selbst, mit Sperre." : "Vorschlag für deinen Tag. Passt er so?"),
        eiKnopf("Passt so", "ask small", () => zlSetzen({bestaetigen:true}, (z.planfokus ? "Abgemacht. Der Fokus startet zu den Zeiten von selbst." : "Tag geplant.") + (z.google ? " Die Blöcke kommen in deinen Google-Kalender." : ""))));
    } else {
      bar.append(el("span", null, (z.planfokus ? "✓ Tag steht. Der Fokus startet zu Beginn jedes Blocks von selbst (3 Min vorher kommt eine Mitteilung)." : "✓ Tag steht.") + (z.google ? " Die Blöcke stehen in deinem Google-Kalender." : "")),
        eiKnopf("Zurücknehmen", "ghost small", () => zlSetzen({bestaetigen:false})));
    }
    teile.push(bar);
  }
  // Agenda: Termine, Blöcke und Fokus-Sessions in zeitlicher Reihenfolge, dazu eine „Jetzt“-Linie
  const eintraege = [
    ...termine.map(t => ({art:"termin", s:t.von, e:t.bis, t})),
    ...z.bloecke.map(b => ({art:"block", s:b.start, e:b.ende, b})),
    ...z.fokus.filter(f => !z.bloecke.some(b => b.text === f.aufgabe && zlMin(f.start) >= zlMin(b.start) - 10 && zlMin(f.start) < zlMin(b.ende))).map(f => ({art:"fokus", s:f.start, e:f.ende, f}))
  ].sort((a, b) => zlMin(a.s) - zlMin(b.s) || (a.art === "termin" ? -1 : 1));
  const liste = el("ol","zl-liste"), jetzt = zlMin(z.jetzt);
  let jetztGesetzt = false;
  const jetztLinie = () => { const li = el("li","zl-jetzt"); li.append(el("span","zl-zeit", z.jetzt), el("span","zl-linie")); return li; };
  eintraege.forEach(x => {
    if (!jetztGesetzt && zlMin(x.s) > jetzt && jetzt >= z.von * 60 && jetzt <= z.bis * 60){ liste.append(jetztLinie()); jetztGesetzt = true; }
    liste.append(x.art === "termin" ? zlTermin(x.t) : x.art === "block" ? zlBlock(x.b, z) : zlFokus(x.f));
  });
  if (!jetztGesetzt && jetzt >= z.von * 60 && jetzt <= z.bis * 60 && eintraege.length) liste.append(jetztLinie());
  if (!eintraege.length) liste.append(el("li","empty", S.plan.heute.length ? "Alles für heute ist erledigt." : "Noch nichts für heute geplant. Tipp unten auf „Heute planen“."));
  teile.push(liste);
  if (z.passtNicht.length){ const p = el("p","k-s c-warn zl-passt");
    p.append(`Passt heute nicht mehr in den Tag: ${z.passtNicht.map(x => `${x.text} (${stdText(x.min / 60)})`).join(", ")}. `,
      eiKnopf("Tagesrahmen ändern", "zt-link", () => esOeffnen("profil")));
    teile.push(p); }
  if (z.uebersprungen.length){ const p = el("div","zl-ohne"); p.append(el("span","k-s","Ohne feste Zeit:"));
    z.uebersprungen.forEach(t => p.append(eiKnopf(`${t} · einplanen`, "chip small", () => zlSetzen({text:t, rein:true}))));
    teile.push(p); }
  if (!k && !(S.plan.automatik?.kalenderListe || []).length){
    const p = el("p","hint zl-hint"); p.append("Tipp: Verbinde deinen Kalender, dann plant der Tag um deine Termine herum. ",
      eiKnopf("Kalender verbinden", "zt-link", () => esOeffnen("kalender"))); teile.push(p); }
  box.replaceChildren(...teile);
}
// Tagesbalken: von–bis, Termine, Blöcke (in Projektfarbe), Fokus (grün), Jetzt-Strich
function zlBalken(z){
  const von = z.von * 60, bis = z.bis * 60, span = Math.max(60, bis - von), pos = m => Math.max(0, Math.min(100, (m - von) / span * 100));
  const bar = el("div","zl-balken"); bar.setAttribute("role","img");
  bar.setAttribute("aria-label", `Tagesübersicht ${pad(z.von)} bis ${pad(z.bis)} Uhr`);
  const seg = (s, e, cls, farbe, titel) => { const i = el("i", cls); i.style.left = pos(zlMin(s)) + "%"; i.style.width = Math.max(.6, pos(zlMin(e)) - pos(zlMin(s))) + "%";
    if (farbe) i.style.setProperty("--f", farbe); i.title = titel; bar.append(i); };
  z.termine.filter(t => !t.ganz).forEach(t => seg(t.von, t.bis, "t", t.farbe, `${t.von}–${t.bis} ${t.titel}`));
  z.bloecke.forEach(b => seg(b.start, b.ende, "b " + b.status, b.projekt ? projFarbe(b.projekt) : "var(--cyan)", `${b.start}–${b.ende} ${b.text}`));
  z.fokus.forEach(f => seg(f.start, f.ende, "f", null, `Fokus ${f.start}–${f.ende}`));
  const j = zlMin(z.jetzt); if (j >= von && j <= bis){ const n = el("b","n"); n.style.left = pos(j) + "%"; bar.append(n); }
  const skala = el("div","zl-skala");
  for (let h = z.von; h <= z.bis; h += (z.bis - z.von > 12 ? 3 : 2)) { const s = el("span", null, pad(h)); s.style.left = pos(h * 60) + "%"; skala.append(s); }
  const w = el("div","zl-uebersicht"); w.append(bar, skala); return w;
}
function zlTermin(t){
  const li = el("li","zl-e termin"); li.style.setProperty("--f", t.farbe);
  const info = el("div","zl-info"); info.append(el("b", null, t.titel), el("span","k-s", [t.kalender, t.ort].filter(Boolean).join(" · ")));
  li.append(el("span","zl-zeit", `${t.von}\n${t.bis}`), el("i","zl-strich"), info); return li;
}
function zlFokus(f){
  const li = el("li","zl-e fokus"); const info = el("div","zl-info");
  info.append(el("b", null, f.laeuft ? "Fokus läuft" : "Fokus"), el("span","k-s", [f.aufgabe || f.projekt, f.produktivMin ? `${f.produktivMin} Min produktiv` : ""].filter(Boolean).join(" · ")));
  li.append(el("span","zl-zeit", `${f.start}\n${f.ende}`), el("i","zl-strich"), info); return li;
}
function zlBlock(b, z){
  const li = el("li","zl-e block " + b.status); li.style.setProperty("--f", b.projekt ? projFarbe(b.projekt) : "var(--cyan)");
  const info = el("div","zl-info"), sub = [];
  if (b.projekt) sub.push(b.projekt);
  sub.push(stdText(b.min / 60));
  if (b.status === "fertig") sub.push("erledigt ✓");
  else if (b.status === "verpasst") sub.push(b.gestartet ? "Zeit ist um" : "verpasst");
  else if (b.status === "jetzt") sub.push(b.gestartet ? "läuft" : "jetzt dran");
  else if (z.bestaetigt && z.planfokus) sub.push("Fokus startet von selbst");
  if (b.fest) sub.push("feste Zeit");
  info.append(el("b", null, b.text), el("span","k-s", sub.join(" · ")));
  const akt = el("div","zl-akt");
  if (b.status !== "fertig"){
    const fokusLaeuft = !!FK.data?.aktiv;
    if ((b.status === "jetzt" || b.status === "kommt" || b.status === "verpasst") && !fokusLaeuft){
      akt.append(eiKnopf("▶ Jetzt", "focus-btn", () => fkAction({aktion:"start", projekt:b.projekt || null, aufgabe:b.text,
        minuten:Math.max(5, Math.min(240, b.status === "jetzt" ? zlMin(b.ende) - zlMin(z.jetzt) : b.min)), vonPlan:true})));
    }
    const zeit = eiKnopf("Uhrzeit", "ghost small", () => { ZL.offen = ZL.offen === b.text ? null : b.text; renderZeitleiste(); });
    zeit.setAttribute("aria-expanded", String(ZL.offen === b.text));
    akt.append(zeit);
  }
  li.append(el("span","zl-zeit", `${b.start}\n${b.ende}`), el("i","zl-strich"), info, akt);
  if (ZL.offen === b.text){
    const f = el("form","zl-form"), inp = el("input"), dur = document.createElement("select"), ok = el("button","ask small","Speichern");
    inp.type = "time"; inp.value = b.start; inp.step = 300; inp.setAttribute("aria-label","Beginn");
    [15, 30, 45, 60, 90, 120, 150, 180, 240].forEach(m => dur.append(new Option(stdText(m / 60), m, false, m === b.min)));
    if (![15, 30, 45, 60, 90, 120, 150, 180, 240].includes(b.min)) dur.append(new Option(stdText(b.min / 60), b.min, true, true));
    dur.setAttribute("aria-label","Dauer"); ok.type = "submit";
    const raus = eiKnopf("Heute ohne feste Zeit", "ghost small", () => { ZL.offen = null; zlSetzen({text:b.text, raus:true}, "Bleibt auf der Liste, ohne feste Zeit."); });
    f.append(el("span","k-s","Beginn"), inp, el("span","k-s","Dauer"), dur, ok, raus);
    f.addEventListener("submit", e => { e.preventDefault(); ZL.offen = null; zlSetzen({text:b.text, projekt:b.projekt, start:inp.value, min:+dur.value}, `${b.text} um ${inp.value}.`); });
    li.append(f);
  }
  return li;
}

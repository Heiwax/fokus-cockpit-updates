// Jede App einzeln einordnen: antippen, dann Produktiv / Neutral / Prokrastination (gilt auf allen Geräten für denselben Namen)
const KAT_OFFEN = {k:null};
function appRow(g, a){
  const k = `${g.name}|${a.name}`, offen = KAT_OFFEN.k === k, wrap = el("div","app-w" + (offen ? " offen" : ""));
  const row = el("button","app"), sw = el("i","sw"), n = el("span","n", a.name);
  row.type = "button"; row.setAttribute("aria-expanded", offen); row.title = "Antippen, um einzuordnen";
  sw.style.background = KAT.find(x => x[0] === a.kat)?.[1] || "var(--neutral)";
  if (a.eigen) n.append(el("small","app-eigen","selbst eingeordnet"));
  row.append(sw, n, el("span","v", minText(a.sek)));
  row.addEventListener("click", () => { KAT_OFFEN.k = offen ? null : k; renderDevices(S.day); });
  wrap.append(row);
  if (offen){
    const pick = el("div","kat-pick");
    KAT.forEach(([kk, c, nm]) => { const b = el("button","chip small"); b.type = "button"; b.setAttribute("aria-pressed", a.kat === kk); b.style.setProperty("--kc", c);
      b.append(el("i"), nm); b.addEventListener("click", () => katSetzen(a.name, kk, nm)); pick.append(b); });
    if (a.eigen){ const b = el("button","chip small","Automatisch"); b.type = "button"; b.title = "Wieder nach den Stichwörtern in kategorien.json";
      b.addEventListener("click", () => katSetzen(a.name, null)); pick.append(b); }
    wrap.append(pick);
  }
  return wrap;
}
async function katSetzen(name, kat, nm){
  KAT_OFFEN.k = null;
  const msg = kat ? `„${name}“ zählt jetzt als ${nm}.` : `„${name}“ wird wieder automatisch eingeordnet.`;
  if (S.mode !== "lokal" || S.demoActivity){
    // Beispielwerte: nur hier im Browser umfärben
    [...(S.day.apps || []), ...(S.day.geraete || []).flatMap(g => g.apps)].filter(a => key(a.name.replace(/ \(Handy\)$/, "")) === key(name))
      .forEach(a => { if (kat) a.kat = kat; a.eigen = !!kat; });
    renderDay(); toast(msg); return;
  }
  try {
    S.day = await api("api/kategorie", {name, kat}); renderDay(); toast(msg);
    S.week = await api("api/week"); S.apiFresh = Date.now(); renderWeek();
  } catch (e) { S.fehler = [`Einordnen hat nicht geklappt: ${e.message || e}`]; renderHeader(); }
}

function renderWeek(){
  const w = S.week; if (!w) return;
  const max = Math.max(3600, ...w.tage.map(t => t.produktiv + t.neutral + t.prokrastination));
  const box = $("week"); box.replaceChildren();
  w.tage.forEach(t => {
    const col = el("div", "col" + (t.date === TODAY ? " today" : "")); const st = el("div","stack");
    st.title = `${t.date}: Produktiv ${minText(t.produktiv)}, Neutral ${minText(t.neutral)}, Ablenkung ${minText(t.prokrastination)}`;
    [["produktiv","var(--good)"],["neutral","var(--neutral)"],["prokrastination","var(--bad)"]].forEach(([k,c]) => {
      if (t[k] > 0){ const seg = el("i"); seg.style.height = (t[k]/max*100) + "%"; seg.style.background = c; st.append(seg); }
    });
    col.append(st, el("small", null, WD[new Date(t.date + "T12:00").getDay()])); box.append(col);
  });
  const sum = k => w.tage.reduce((a,t) => a + t[k], 0);
  const ws = $("weekSum"); ws.replaceChildren();
  [["Produktiv", sum("produktiv")],["Ablenkung", sum("prokrastination")]].forEach(([l,v]) => { const s = el("span", null, l + " "); s.append(el("b", null, minText(v))); ws.append(s); });

  $("mStreak").textContent = `${w.serie} ${w.serie === 1 ? "Tag" : "Tage"}`;
  $("streakHint").textContent = w.serie ? `Serie: ${w.serie} ${w.serie === 1 ? "Tag" : "Tage"} in Folge mit erreichtem Produktiv-Ziel.` : "Erreiche das Produktiv-Ziel, um eine Serie zu starten.";

  const days = w.tage.filter(t => t.produktiv + t.neutral + t.prokrastination > 0);
  const avg = days.length ? days.reduce((a,t) => a + t.prokrastination, 0) / days.length / 60 : 0;
  $("fDay").textContent = bigText(avg); $("fWeek").textContent = bigText(avg*7); $("fMonth").textContent = bigText(avg*30.4);
  $("fYear").textContent = bigText(avg*365); $("fDecade").textContent = bigText(avg*3652);
  const fy = (avg*365/1440).toLocaleString("de-DE",{maximumFractionDigits:1, minimumFractionDigits:1});
  const fd = (avg*3652/1440).toLocaleString("de-DE",{maximumFractionDigits:1, minimumFractionDigits:1});
  const lim = (S.limitMin*365/1440).toLocaleString("de-DE",{maximumFractionDigits:1, minimumFractionDigits:1});
  const p = $("fcText"); p.replaceChildren("Bei diesem Tempo verlierst du ", el("em", null, `${fy} volle Tage pro Jahr`), " und ", el("em", null, `${fd} Tage pro Jahrzehnt`), `. Dein Limit (${S.limitMin} Min/Tag) wären ${lim} Tage pro Jahr.`);
}

function nextStep(){
  const p = S.plan; if (!p) return null;
  const t = p.heute.find(x => !x.done); if (t) return t.text;
  const pr = p.projekte.find(x => x.aktiv && x.next); return pr ? `${pr.name}: ${pr.next}` : null;
}
function renderCopilot(){
  const d = S.day; if (!d) return;
  const s = d.summe, act = s.produktiv + s.prokrastination, score = act ? s.produktiv/act*100 : 0;
  const worst = d.apps?.find(a => a.kat === "prokrastination");
  const hr = d.stunden[NOW.getHours()] || [0,0,0,0];
  const step = nextStep(), stepTxt = step ? ` Nächster Schritt: ${step}.` : "";
  let mood = "NEUTRAL", cls = "", text;
  if (!act) text = `Heute ist noch nichts erfasst.${step ? " Fang an mit: " + step + "." : ""}`;
  else if (s.prokrastination/60 > S.limitMin){ mood = "ABGELENKT"; cls = "bad"; text = `Budget gerissen: ${minText(s.prokrastination)} Prokrastination${worst ? `, am meisten ${worst.name} (${minText(worst.sek)})` : ""}. Mach ${worst ? worst.name : "die Ablenkung"} zu.${stepTxt}`; }
  else if (hr[2] > hr[0] && hr[2] > 600){ mood = "ABGELENKT"; cls = "bad"; text = `Die laufende Stunde geht gerade mehr an Ablenkung als an Arbeit (${minText(hr[2])}).${stepTxt}`; }
  else if (s.produktiv/60 >= S.goalMin){ mood = "ZIEL ERREICHT"; cls = "good"; text = `Produktiv-Ziel geschafft: ${minText(s.produktiv)}. Alles ab jetzt ist Bonus.${stepTxt}`; }
  else if (score >= 70){ mood = "FOKUSSIERT"; cls = "good"; text = `Starker Fokus (${Math.round(score)} %). Noch ${minText(S.goalMin*60 - s.produktiv)} bis zum Produktiv-Ziel.${stepTxt}`; }
  else text = `Noch ${minText(S.goalMin*60 - s.produktiv)} bis zum Produktiv-Ziel, ${minText(Math.max(0, S.limitMin*60 - s.prokrastination))} Budget übrig.${stepTxt}`;
  if (!S.coBusy) $("coText").textContent = text;
  $("mood").textContent = mood; $("mood").className = "badge " + cls;
}

async function askClaude(){
  if (!S.sample || S.coBusy) return;
  S.coBusy = true; $("askBtn").disabled = true; $("coText").textContent = "Claude schaut sich deinen Tag an …";
  const d = S.day, p = S.plan;
  const data = {uhrzeit:NOW.toTimeString().slice(0,5), produktivMin:Math.round(d.summe.produktiv/60), prokrastinationMin:Math.round(d.summe.prokrastination/60),
    nichtAmPcMin:Math.round(d.summe.afk/60), produktivZielMin:S.goalMin, budgetMin:S.limitMin, apps:d.apps?.slice(0,6).map(a => `${a.name} (${a.kat}, ${Math.round(a.sek/60)} Min)`),
    beispieldaten:S.demoActivity, aufgabenHeute:p?.heute.map(t => (t.done ? "[x] " : "[ ] ") + t.text), wochenziele:p?.woche.map(t => t.text),
    projekte:p?.projekte.filter(x => x.aktiv).map(x => `${x.name}: nächster Schritt ${x.next}`)};
  try {
    await S.sample(`Du bist Johns Fokus-Co-Pilot. John (24, selbstständiger Closer) baut nebenbei eigene Projekte auf und will weniger prokrastinieren. Hier sind seine heutigen Daten:\n${JSON.stringify(data)}\nAntworte auf Deutsch in höchstens 3 kurzen Sätzen, direkt und ehrlich, ohne Markdown: eine Einschätzung seines Tages und genau ein konkreter nächster Schritt für die nächsten 30 Minuten.`,
      {modelTier:"quick", cache:false, onText:({text}) => { if (text) $("coText").textContent = text; }});
  } catch (e) {
    $("coText").textContent = e?.code === "not_granted" ? "Claude darf hier nicht gefragt werden. Du kannst es in den Berechtigungen der Seite erlauben." : "Claude hat gerade nicht geantwortet. Versuch es gleich noch einmal.";
    if (e?.code === "not_granted") $("askBtn").hidden = true;
  } finally { S.coBusy = false; $("askBtn").disabled = false; }
}


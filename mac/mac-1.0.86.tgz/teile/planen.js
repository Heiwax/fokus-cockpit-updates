/* ---------- Planen: Monat = Meilensteine der Projekte, an denen du diesen Monat arbeitest; Woche = bis zu 3 Wochenziele;
   Heute = welche Wochenziele heute dran sind ---------- */
const PL = {mode:"woche", projs:new Set(), items:[], hProj:null, hPhase:null};
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
function planDays(){
  // heute bis Sonntag; am Sonntag die kommende Woche
  const out = [];
  for (let d = NOW.getDay() === 0 ? addDays(NOW, 1) : new Date(NOW); ; d = addDays(d, 1)){
    out.push({iso:iso(d), wd:d.getDay(), label:iso(d) === TODAY ? "Heute" : `${WD[d.getDay()]} ${d.getDate()}.${d.getMonth()+1}.`});
    if (d.getDay() === 0) break;
  }
  return out;
}
const planKw = () => isoWeek(new Date(planDays()[0].iso + "T12:00"));
const plVisible = i => PL.mode === "heute" || !i.projekt || PL.projs.has(i.projekt);
// Heute planen: Aufgaben aus jeder Phase jedes Projekts (Projekt antippen, dann Phase)
const plOffenePhasen = x => (x.phasen || []).filter(f => !f.fertig && f.ziele.some(g => !g.fertig));
const plHz = g => { const st = g.aufwand || 2; return {std:st, rest:Math.round(st * (100 - (g.prozent || 0))) / 100}; };
function plPhaseLaden(){
  const p = S.plan, x = p.projekte.find(y => y.name === PL.hProj), f = x && (x.phasen || []).find(y => y.name === PL.hPhase);
  if (!f) return;
  const inHeute = new Set(p.heute.filter(t => !t.done).map(t => key(t.text)));
  f.ziele.filter(g => !g.fertig).forEach(g => {
    const k = key(g.name); if (PL.items.some(i => i.k === k && i.projekt === x.name)) return;
    PL.items.push({k, text:g.name, projekt:x.name, src:"phase", phase:f.name, abschnitt:g.abschnitt || "", z:g.einzel ? null : g, on:false, inHeute:inHeute.has(k), ...plHz(g)});
  });
}
// offene Ziele eines Projekts, die des aktuellen Meilensteins zuerst (oder nur die)
function openGoals(x, nurAktiv){
  const ph = x.phasen || [];
  return [...ph.filter(f => f.aktiv), ...(nurAktiv ? [] : ph.filter(f => !f.aktiv))].flatMap(f => f.ziele).filter(g => !g.fertig);
}
// Vorschläge für die Woche: Ziele der Meilensteine, die fürs Monat geplant sind, sonst des aktuellen
function weekGoals(x, p){
  const mo = new Set(p.monat.filter(i => !i.done && i.projekt === x.name).map(i => key(i.text)));
  const ph = (x.phasen || []).filter(f => mo.has(key(f.name)));
  return ph.length ? ph.flatMap(f => f.ziele).filter(g => !g.fertig) : openGoals(x, true);
}
const stoneInfo = f => ({done:f.ziele.filter(z => z.fertig).length, total:f.ziele.length});
function openPlaner(mode){
  const p = S.plan; if (!p) return;
  PL.mode = mode; PL.items = []; PL.hProj = PL.hPhase = null;
  const inHeute = new Set(p.heute.filter(t => !t.done).map(t => key(t.text)));
  const push = (text, projekt, src, z, ms, h = {}) => {
    const k = key(text); if (PL.items.some(i => i.k === k && i.projekt === (projekt || null))) return;
    PL.items.push({k, text, projekt:projekt || null, src, z, ms, on:false, inHeute:inHeute.has(k), std:h.std ?? null, rest:h.rest ?? h.std ?? null});
  };
  // Stunden: Einträge aus der Cockpit-Notiz bringen sie mit, Projektziele haben Aufwand und Fortschritt (ohne Angabe 2 Std)
  const hz = plHz;
  const act = p.projekte.filter(x => x.aktiv);
  if (mode === "monat"){
    const mo = p.monat.filter(g => !g.done);
    mo.forEach(g => push(g.text, g.projekt, "ziel", null, g.meilenstein));
    act.forEach(x => { const ph = (x.phasen || []).filter(f => !f.fertig && f.name !== "Aufgaben");
      [...ph.filter(f => f.aktiv), ...ph.filter(f => !f.aktiv)].forEach(f => push(f.name, x.name, "projziel", null, stoneInfo(f))); });
    PL.items.forEach(i => i.on = i.src === "ziel");
    PL.projs = new Set(mo.map(g => g.projekt).filter(Boolean));
  } else if (mode === "woche"){
    const wk = p.woche.filter(g => !g.done);
    wk.forEach(g => push(g.text, g.projekt, "ziel", g.ziel, null, g));
    act.forEach(x => x.phasen ? weekGoals(x, p).forEach(g => push(g.name, x.name, "projziel", g.einzel ? null : g, null, hz(g)))
      : (x.aufgaben || []).filter(t => !t.done).forEach(t => push(t.text, x.name, "aufgabe", null, null, {std:t.aufwand})));
    PL.items.forEach(i => i.on = i.src === "ziel");
    PL.projs = new Set([...wk.map(g => g.projekt), ...p.monat.filter(g => !g.done).map(g => g.projekt)].filter(Boolean));
    if (!PL.projs.size) act.slice(0, 3).forEach(x => PL.projs.add(x.name));
  } else {
    // Heute: die Wochenziele, dazu was schon bei Heute steht
    p.woche.filter(g => !g.done).forEach(g => push(g.text, g.projekt, "ziel", g.ziel, null, g));
    p.heute.filter(t => !t.done).forEach(t => push(t.text, t.projekt, "heute", t.ziel, null, t));
    PL.items.forEach(i => i.on = i.inHeute);
  }
  renderPlaner(); $("planer").showModal();
}
const PL_TEXT = {
  monat:{title:"Monat planen", s1:"1. Woran willst du diesen Monat arbeiten?", s1b:" Nur die Projekte antippen, die diesen Monat dran sind.",
    s2:"2. Was willst du bis Monatsende geschafft haben?", s2b:" Pro Projekt reicht meist eine Phase. „Eigenes“ legt eine neue Phase an.",
    ok:"Monat übernehmen", schon:"schon Monatsziel", eins:"Monatsziel", viele:"Monatsziele"},
  woche:{title:"Woche planen", s1:"1. Woran willst du diese Woche arbeiten?", s1b:" Deine Monatsprojekte sind schon ausgewählt.",
    s2:"2. Was willst du bis Sonntag geschafft haben?", s2b:" Ein Wochenziel ist ein Ergebnis, das du am Sonntag abhakst. Unten siehst du, ob es in deine Stunden bis Sonntag passt. Vorschläge kommen aus deinen Phasen für diesen Monat.",
    ok:"Woche übernehmen", schon:"schon Wochenziel", eins:"Wochenziel", viele:"Wochenziele"},
  heute:{title:"Heute planen", s1:"1. Aus welchem Projekt und welcher Phase?", s1b:" Tipp ein Projekt an, dann die Phase. Jede Phase geht, nicht nur die aktive.",
    s2:"2. Woran arbeitest du heute?", s2b:" Deine Wochenziele stehen schon da, dazu die Aufgaben der gewählten Phase. Nimm so viel, wie in deine Stunden für heute passt.", ok:"Für heute übernehmen"}
};
function renderPlaner(){
  const m = PL.mode, T = PL_TEXT[m], heute = m === "heute", p = S.plan, act = p.projekte.filter(x => x.aktiv);
  $("plTitle").textContent = T.title;
  $("plStep1").hidden = $("plChips").hidden = false;
  $("plStep1").replaceChildren(el("b", null, T.s1), T.s1b);
  $("plStep2").replaceChildren(el("b", null, T.s2), T.s2b);
  // Stundenkonto: was schon gewählt ist (Heute: plus heute Erledigtes) gegen die Zeit von heute bzw. bis Sonntag
  const th = zeitTag(TODAY), erledigt = heute ? p.heute.filter(t => t.done) : [];
  const zeit = heute ? th.std : m === "woche" ? kontoWoche(p).rest : null;
  const gewaehlt = PL.items.filter(i => i.on && plVisible(i)).reduce((a, i) => a + (i.rest ?? 0), 0) + erledigt.reduce((a, t) => a + (t.std || 0), 0);
  if (heute && !th.std) $("plStep2").append(el("span","c-warn"," Heute ist als frei eingetragen."));
  const chip = (label, pressed, onClick) => { const b = el("button", "chip", label); b.type = "button"; b.setAttribute("aria-pressed", pressed); b.addEventListener("click", onClick); return b; };
  if (heute){
    // Projekte mit offenen Aufgaben (aktive zuerst), darunter die Phasen des gewählten Projekts
    const projs = [...act, ...p.projekte.filter(x => !x.aktiv)].filter(x => plOffenePhasen(x).length);
    const reihe = el("div","chips pl-projekte");
    projs.forEach(x => reihe.append(chip((x.icon ? x.icon + " " : "") + x.name, String(PL.hProj === x.name), () => {
      if (PL.hProj === x.name){ PL.hProj = PL.hPhase = null; renderPlaner(); return; }
      const ph = plOffenePhasen(x); PL.hProj = x.name; PL.hPhase = (ph.find(f => f.aktiv) || ph[0]).name; plPhaseLaden(); renderPlaner(); })));
    const teile = [reihe];
    const x = projs.find(y => y.name === PL.hProj);
    if (x){
      const phasen = el("div","chips pl-phasen");
      plOffenePhasen(x).forEach(f => { const offen = f.ziele.filter(g => !g.fertig).length;
        phasen.append(chip(`${f.name}${f.aktiv ? " · aktiv" : ""} (${offen})`, String(PL.hPhase === f.name), () => { PL.hPhase = f.name; plPhaseLaden(); renderPlaner(); })); });
      teile.push(phasen);
    }
    if (!projs.length) teile.push(el("p","empty","Keine offenen Aufgaben in deinen Projekten."));
    $("plChips").replaceChildren(...teile);
  } else $("plChips").replaceChildren(...act.map(x => chip(x.name, PL.projs.has(x.name), () => {
    PL.projs.has(x.name) ? PL.projs.delete(x.name) : PL.projs.add(x.name); renderPlaner(); })));
  // Aufgaben aus Phasen, die gerade nicht gewählt sind, nur zeigen, wenn sie angehakt sind
  const plZeigen = i => i.src !== "phase" || i.on || (i.projekt === PL.hProj && i.phase === PL.hPhase);
  const names = !heute ? act.filter(x => PL.projs.has(x.name)).map(x => x.name)
    : [PL.hProj, ...act.map(x => x.name), ...PL.items.map(i => i.projekt)].filter(n => n && PL.items.some(i => i.projekt === n && plZeigen(i)));
  const boxes = [...new Set(names), null].map(g => {
    const items = PL.items.filter(i => i.projekt === g && plZeigen(i));
    if (g === null && !items.length) return "";
    const box = el("div","plgrp"); box.append(el("h3", null, g || "Ohne Projekt"));
    items.forEach(i => {
      const row = el("div", "plrow" + (i.on ? "" : " off")), cb = document.createElement("input"), t = el("div","t", i.text);
      cb.type = "checkbox"; cb.checked = i.on; cb.setAttribute("aria-label", i.text);
      if (heute && i.inHeute){ cb.disabled = true; t.append(el("span","tag","schon bei Heute")); }
      cb.addEventListener("change", () => { i.on = cb.checked; renderPlaner(); });
      if (i.src === "phase") t.append(el("span","tag", i.phase + (i.abschnitt ? " · " + i.abschnitt : "")));
      if (i.z?.total) t.append(el("span","tag prog", `${i.z.done}/${i.z.total}`));
      if (m !== "monat" && i.rest) t.append(el("span","tag", stdText(i.rest)));
      if (zeit != null && !i.on && i.rest && gewaehlt + i.rest > zeit + 1e-9) t.append(el("span","tag warn", heute ? "passt heute nicht mehr" : "passt nicht mehr in die Woche"));
      if (i.ms) t.append(el("span","tag prog", `${i.ms.done}/${i.ms.total} Ziele`));
      if (!heute && i.src === "ziel") t.append(el("span","tag", T.schon));
      if (i.src === "neu") t.append(el("span","tag on","neu"));
      row.append(cb, t); box.append(row);
    });
    if (!items.length) box.append(el("p","empty", m === "monat" ? "Noch keine Phasen. Leg unten eine an." : "Keine offenen Ziele. Leg unten eins an."));
    const f = el("form","add"), inp = el("input"), b = el("button", null, "+"), lbl = `Eigenes für ${g || "ohne Projekt"}`;
    inp.placeholder = m === "monat" ? "Eigene Phase" : "Eigener Meilenstein"; inp.autocomplete = "off"; inp.setAttribute("aria-label", lbl);
    b.type = "submit"; b.setAttribute("aria-label", "Hinzufügen");
    f.addEventListener("submit", e => { e.preventDefault(); const t = inp.value.trim(); if (!t) return;
      if (!PL.items.some(i => i.k === key(t) && i.projekt === g)) PL.items.push({k:key(t), text:t, projekt:g, src:"neu", on:true});
      renderPlaner(); $("plList").querySelector(`input[aria-label="${CSS.escape(lbl)}"]`)?.focus(); });
    f.append(inp, b); box.append(f);
    return box;
  });
  if (heute && !PL.items.length && !PL.hProj){
    const e = el("div","plgrp"), b = el("button","act-btn","Woche planen"); b.type = "button";
    b.addEventListener("click", () => openPlaner("woche"));
    e.append(el("p","empty","Noch keine Wochenziele. Tipp oben ein Projekt an oder plane zuerst deine Woche."), b);
    boxes.unshift(e);
  }
  if (!heute && !PL.projs.size) boxes.unshift(el("p","empty","Tipp oben die Projekte an, an denen du arbeiten willst."));
  $("plList").replaceChildren(...boxes);
  const sel = PL.items.filter(i => i.on && plVisible(i)), sum = $("plSum"); sum.replaceChildren();
  if (!heute){
    const s = el("span"); s.append(el("b", null, String(sel.length)), " " + (sel.length === 1 ? T.eins : T.viele)); sum.append(s);
    if (m === "woche") sum.append(el("span", gewaehlt > zeit + 1e-9 ? "c-warn" : null, `${stdKurz(gewaehlt)} Arbeit · ${stdKurz(zeit)} Zeit bis So`));
    else sum.append(el("span", null, `bis Monatsende, ${leftText(monthEnd())}`));
  } else {
    const neu = sel.filter(i => !i.inHeute).length, n = sel.length + erledigt.length;
    sum.append(el("span", null, neu ? `${neu} ${neu === 1 ? "Ziel kommt" : "Ziele kommen"} dazu` : "Nichts Neues ausgewählt."),
      el("span", gewaehlt > zeit + 1e-9 ? "c-warn" : null, `${stdKurz(gewaehlt)} von ${stdKurz(zeit)}`),
      el("span", n > th.aufgaben ? "c-warn" : null, `${n} von ${th.aufgaben} Aufgaben`));
  }
  $("plOk").textContent = T.ok;
}
async function savePlaner(){
  const m = PL.mode, sel = PL.items.filter(i => i.on && plVisible(i)), it = i => ({text:i.text, projekt:i.projekt, neu:i.src === "neu"});
  const body = m === "woche" ? {kw:planKw(), woche:sel.map(it)} : m === "monat" ? {monat:sel.map(it)} : {heute:sel.filter(i => !i.inHeute).map(it)};
  $("plOk").disabled = true;
  try {
    if (S.mode === "lokal") S.plan = await api("api/plan-setzen", body);
    else {
      // Beispielansicht: nur im Browser übernehmen, so wie der Server es tut
      const P = S.plan, mk = x => { const pi = PL.items.find(i => key(i.text) === key(x.text) && i.projekt === (x.projekt || null));
        return {id:"n" + Date.now() + Math.random(), done:false, own:false, ...x, ...(pi?.std != null ? {std:pi.std, rest:pi.rest} : {})}; };
      const has = (list, x) => list.some(t => key(t.text) === key(x.text));
      const replace = (liste, items) => { const neu = new Set(items.map(x => key(x.text)));
        const weg = new Set(P[liste].filter(g => !g.done && !neu.has(key(g.text))).map(g => key(g.text)));
        P[liste] = [...P[liste].filter(g => g.done || neu.has(key(g.text))), ...items.filter(x => !has(P[liste], x)).map(mk)]; return weg; };
      if (body.woche){ const weg = replace("woche", body.woche); P.heute = P.heute.filter(t => t.done || !weg.has(key(t.text))); }
      if (body.monat) replace("monat", body.monat);
      (body.heute || []).forEach(x => { if (!has(P.heute, x)) P.heute.push(mk(x)); if (x.projekt && !has(P.woche, x)) P.woche.push(mk(x)); });
      [...(body.woche || []), ...(body.heute || [])].filter(x => x.neu && x.projekt).forEach(x => {
        const pr = P.projekte.find(y => y.name === x.projekt), ph = pr?.phasen?.find(f => f.aktiv);
        if (ph && !pr.phasen.some(f => f.ziele.some(g => key(g.name) === key(x.text)))) ph.ziele.push({name:x.text, einzel:false, schritte:[]});
      });
      (body.monat || []).filter(x => x.neu && x.projekt).forEach(x => {
        const pr = P.projekte.find(y => y.name === x.projekt);
        if (pr?.phasen && !pr.phasen.some(f => key(f.name) === key(x.text))) pr.phasen.push({name:x.text, marke:false, ziele:[]});
      });
      recalc(P);
    }
    $("planer").close(); renderPlan();
  } catch (e) { S.fehler = [`Planen hat nicht geklappt: ${e.message || e}`]; renderHeader(); }
  finally { $("plOk").disabled = false; }
}


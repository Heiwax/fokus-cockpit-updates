/* ---------- Weniger auf einmal (3.1): Ziele in Heute/Woche/Monat/Jahr, Hinweise auf Heute, Habits ruhiger ---------- */
// Ziele: oben eine Leiste, darunter nur der gewählte Zeitraum (Standard Woche, weil Heute schon auf dem Heute-Reiter steht).
const ZG_TEILE = [["heute", "Heute"], ["woche", "Woche"], ["monat", "Monat"], ["jahr", "Jahr"]];
function zgZeigen(k){
  if (k) store("cockpit.zieleTeil", k);
  k = store("cockpit.zieleTeil") || "woche";
  const karten = [...($("zieleCols")?.children || [])];
  karten.forEach((c, i) => c.classList.toggle("wt-aus", ZG_TEILE[i]?.[0] !== k));
  $("zieleCols")?.classList.add("zg-eins");
  const wp = $("wpBox"); if (wp) wp.classList.toggle("wt-aus", k !== "woche");
  const p = S.plan || {}, offen = l => (l || []).filter(x => !x.done).length;
  document.querySelectorAll("#zgLeiste button").forEach(b => {
    b.setAttribute("aria-pressed", String(b.dataset.k === k));
    const n = offen(p[b.dataset.k]); b.querySelector("small").textContent = n ? String(n) : "";
  });
}
(function(){
  const tab = document.querySelector('.tab[data-r="ziele"]'); if (!tab || $("zgLeiste")) return;
  const leiste = el("div","chips wt-leiste"); leiste.id = "zgLeiste"; leiste.setAttribute("role", "group"); leiste.setAttribute("aria-label", "Zeitraum");
  ZG_TEILE.forEach(([k, n]) => { const b = el("button","chip", n); b.type = "button"; b.dataset.k = k; b.append(el("small","wt-n")); b.addEventListener("click", () => zgZeigen(k)); leiste.append(b); });
  tab.prepend(leiste);
})();
const _renderZieleOrd = renderZiele;
renderZiele = function(p){ _renderZieleOrd(p); zgZeigen(); };
// „Heute planen“ / „Woche planen“ aus anderen Reitern: den passenden Zeitraum zeigen
document.addEventListener("click", e => { const b = e.target.closest("[data-zg]"); if (b){ showTab("ziele"); zgZeigen(b.dataset.zg); window.scrollTo(0, 0); } });

// Heute: kurze Hinweise statt ganzer Karten (Wochenplan-Vorschlag liegt unter Ziele › Woche)
function heuteHinweise(){
  const box = $("heuteHinweise"); if (!box) return;
  const teile = [];
  if ($("wpBox") && !$("wpBox").hidden){
    const h = el("div","hud hh-karte"), t = el("div");
    t.append(el("b", null, "Dein Wochenplan-Vorschlag ist fertig"), el("span","k-s", "Ziele für diese Woche aus deinen aktiven Phasen"));
    h.append(t, eiKnopf("Ansehen", "ask small", () => { showTab("ziele"); zgZeigen("woche"); window.scrollTo(0, 0); }));
    teile.push(h);
  }
  box.replaceChildren(...teile);
}
const _renderAutomatikOrd = renderAutomatik;
renderAutomatik = function(){ _renderAutomatikOrd(); heuteHinweise(); };

// Habits: Tage-Auswahl und Erklärung erst zeigen, wenn man einen neuen Habit tippt
(function(){
  const inp = $("habText"), box = $("habBox"); if (!inp || !box) return;
  const tipp = box.querySelector(".kon-hint");
  if (tipp && !tipp.closest("details")){ const d = el("details","more hab-wie"); d.append(el("summary", null, "Tipps: Tage und Habits, die sich selbst abhaken")); tipp.replaceWith(d); d.append(tipp); }
  const zeig = () => box.classList.toggle("hab-tippt", !!inp.value.trim());
  inp.addEventListener("input", zeig); $("habForm")?.addEventListener("submit", () => setTimeout(zeig, 0));
})();

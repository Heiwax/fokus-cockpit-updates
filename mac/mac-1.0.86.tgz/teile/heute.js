/* ---------- Anzeige ---------- */
function renderHeader(){
  $("today").textContent = NOW.toLocaleDateString("de-DE",{weekday:"long", day:"numeric", month: matchMedia("(max-width:760px)").matches ? "short" : "long"});
  const pr = S.plan?.profil || {}, name = pr.name || "";
  $("kw").textContent = `BlockEm · KW ${isoWeek(NOW)}`;
  document.title = "BlockEm";
  const ziel = pr.zielDatum ? new Date(pr.zielDatum + "T12:00") : new Date(NOW.getFullYear(), 11, 31);
  $("mDays").textContent = Math.max(0, Math.ceil((ziel - new Date(NOW.getFullYear(),NOW.getMonth(),NOW.getDate()))/864e5));
  $("mDaysLbl").textContent = pr.zielDatum ? `Tage bis ${pr.zielText || ziel.toLocaleDateString("de-DE")}` : "Tage bis Jahresende";
  $("mDaysLbl").title = pr.zielDatum ? `${pr.zielText ? pr.zielText + ", " : ""}${ziel.toLocaleDateString("de-DE")} (Einstellungen › Über dich)` : "Eigenes Ziel-Datum: Einstellungen › Über dich";
  const src = $("src");
  const live = S.mode === "lokal" && !S.demoActivity;
  src.className = "pill " + (S.demoActivity ? "demo" : "live");
  src.textContent = S.demoActivity ? "Beispieldaten" : live ? "Live" : "Sync";
  src.title = S.demoActivity ? "Die Bildschirmzeit-Werte sind Beispiele. Echte Werte kommen, sobald der BlockEm-Server auf deinem Mac läuft." : "";
  const n = $("notice"); n.replaceChildren();
  const msgs = [...S.fehler];
  if (S.demoActivity) msgs.unshift(S.mode === "lokal"
    ? (VB.modus === "handy" ? "Die Bildschirmzeit unten sind Beispielwerte, bis du der App den Nutzungszugriff erlaubst (Einstellungen › Handy-App)."
      : S.serverModus === "server" ? "Die Bildschirmzeit unten sind Beispielwerte, bis ein Handy mit der BlockEm-App Daten schickt."
      : "Die Bildschirmzeit unten sind Beispielwerte, bis der Zähler am Computer die ersten Minuten hat.")
    : "Die Bildschirmzeit unten sind Beispielwerte. Live-Werte zeigt BlockEm, wenn du es über den BlockEm-Server auf deinem Mac öffnest.");
  if (msgs.length){ const ul = el("ul"); msgs.forEach(m => ul.append(el("li", null, m))); n.append(ul); }
  n.hidden = !msgs.length;
}

function renderDay(){
  const d = S.day; if (!d) return;
  const s = d.summe, act = s.produktiv + s.prokrastination;
  const score = act ? Math.round(s.produktiv / act * 100) : null;
  $("scoreVal").textContent = score == null ? "–" : `${score} %`;
  $("ringBox").setAttribute("aria-label", `Fokus-Score ${score ?? "noch offen"}`);
  const C = 2*Math.PI*74; $("ringArc").style.strokeDashoffset = C * (1 - (score ?? 0)/100);
  $("ringArc").style.stroke = score == null ? "var(--line-hi)" : score >= 50 ? "var(--cyan)" : "var(--bad)";
  $("lProd").textContent = $("tProd").textContent = minText(s.produktiv);
  $("lProk").textContent = $("tProk").textContent = minText(s.prokrastination);
  $("tAway").textContent = minText(s.afk);
  const g = Math.min(100, Math.round(s.produktiv/60 / S.goalMin * 100) || 0), l = Math.round(s.prokrastination/60 / S.limitMin * 100) || 0;
  $("goalLbl").parentElement.style.display = "none";   // 1.0.47: BlockEm zeigt kein Produktiv-Ziel mehr (Cockpit-Rest)
  $("limitLbl").textContent = `Ablenkungs-Limit ${minText(S.limitMin*60)}`; $("limitBar").style.width = Math.min(100,l) + "%"; $("limitPc").textContent = l + " %";
  $("limitPc").style.color = l > 100 ? "var(--bad)" : "";
  $("stand").textContent = d.stand ? `Stand ${new Date(d.stand).toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"})}` : "";

  const box = $("hours"); box.replaceChildren(); const axis = $("axis"); axis.replaceChildren();
  const colors = ["var(--good)","var(--neutral)","var(--bad)","var(--away)"], names = ["Produktiv","Neutral","Ablenkung", typeof beAway === "function" ? beAway() : "Nicht am PC"];
  d.stunden.forEach((h, i) => {
    const st = el("div", "stack" + (d.date === TODAY && i === NOW.getHours() ? " now" : ""));
    st.title = `${pad(i)}:00 – ` + (h.map((v,k) => v ? `${names[k]} ${minText(v)}` : "").filter(Boolean).join(", ") || "keine Daten");
    h.forEach((v, k) => { if (v > 0){ const seg = el("i"); seg.style.height = Math.min(100, v/36) + "%"; seg.style.background = colors[k]; st.append(seg); } });
    box.append(st); axis.append(el("span", null, [0,6,12,18,23].includes(i) ? String(i) : ""));
  });

  renderDevices(d);
  renderCopilot();
  renderDash();
}

// Heute-Dashboard: Fokus-Score, Produktiv, Ablenkung, Ziele; Ablenkungs-Apps von heute über alle Geräte; Bildschirmzeit nach Gerät
function kpi(label, wert, farbe, cls = ""){ const k = el("div","kpi" + (cls ? " " + cls : "")), v = el("b","k-v", wert); if (farbe) v.style.color = farbe; k.append(el("span","k-l", label), v); return k; }
function kpiBar(p, farbe){ const b = barEl(p, false); b.querySelector("i").style.background = farbe; return b; }
function renderDash(){
  const box = $("dashKpis"); if (!box) return;
  const d = S.day, s = d?.summe, act = s ? s.produktiv + s.prokrastination : 0, score = act ? Math.round(s.produktiv / act * 100) : null;
  const p = S.plan, zd = p ? p.heute.filter(t => t.done).length : 0, zn = p ? p.heute.length : 0;
  const sc = el("div","kpi kscore"), ring = el("span","mini-ring"), txt = el("div");
  ring.innerHTML = ringSvg(score ?? 0, 22); ring.style.color = score == null ? "var(--line-hi)" : score >= 50 ? "var(--cyan)" : "var(--bad)";
  txt.append(el("span","k-l","Fokus-Score"), el("b","k-v", score == null ? "–" : score + " %"), el("span","k-s", score == null ? "Noch keine Daten" : score >= 50 ? "Mehr Fokus als Ablenkung" : "Mehr Ablenkung als Fokus"));
  sc.append(ring, txt);
  const gp = s ? Math.round(s.produktiv / 60 / S.goalMin * 100) || 0 : 0, lp = s ? Math.round(s.prokrastination / Math.max(1, s.produktiv + s.neutral + s.prokrastination) * 100) : 0;   // 1.0.48: Anteil an der Bildschirmzeit statt Limit
  const prod = kpi("Bildschirmzeit", s ? minText(s.produktiv + s.neutral + s.prokrastination) : "–");   // 1.0.47: statt Produktiv-Ziel
  prod.append(el("span","k-s", s ? `davon ${minText(s.produktiv)} sinnvoll genutzt` : "Noch keine Daten"));
  const prok = kpi("Ablenkung", s ? minText(s.prokrastination) : "–", "var(--bad)");
  prok.append(kpiBar(Math.min(100, lp), "var(--bad)"), el("span", "k-s", `${lp} % deiner Bildschirmzeit`));
  const zi = kpi("Ziele heute", `${zd}/${zn}`);
  zi.append(kpiBar(zn ? zd / zn * 100 : 0, "var(--cyan)"), el("span","k-s", zn ? (zd === zn ? "Alles geschafft" : `noch ${zn - zd} offen`) : "Noch nichts geplant"));
  const kons = el("button","kpi kbtn"), kv = p?.konsistenz?.[TODAY], ks = p?.habits ? konScore(kv) : null, gut = p?.habits?.schwelle || 80;
  kons.type = "button"; kons.addEventListener("click", () => { showTab("habits"); window.scrollTo(0, 0); });
  const dran = p?.habits ? (p.habits.dran || p.habits.liste) : [], hd = p?.habits ? dran.filter(n => (p.habits.log[TODAY] || []).some(x => key(x) === key(n))).length : 0, serie = p?.habits ? konSerie(p.konsistenz || {}, gut) : 0;
  kons.append(el("span","k-l","Consistency"), el("b","k-v", kv?.frei ? "frei" : ks == null ? "–" : ks + " %"));
  kons.querySelector(".k-v").style.color = ks == null ? "" : ks >= gut ? "var(--good)" : ks >= 50 ? "var(--cyan)" : "var(--bad)";
  kons.append(kpiBar(ks ?? 0, ks != null && ks >= gut ? "var(--good)" : "var(--cyan)"),
    el("span","k-s", p?.habits ? `Habits ${hd}/${dran.length} · Serie ${serie} ${serie === 1 ? "Tag" : "Tage"}` : "Habits anlegen"));
  kons.hidden = !p?.habits;
  // Ab 3.1 nur drei Kacheln (Ziele stehen in der Liste darunter, Consistency unter Habits); antippen öffnet Werte › Heute
  const zuWerte = () => { showTab("werte"); wtZeigen("heute"); window.scrollTo(0, 0); };
  [sc, prod, prok].forEach(k => { k.classList.add("kklick"); k.tabIndex = 0; k.setAttribute("role", "button");
    k.addEventListener("click", zuWerte); k.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " "){ e.preventDefault(); zuWerte(); } }); });
  box.replaceChildren(sc, prod, prok);
  // Ablenkungs-Apps (Kategorie Prokrastination) von heute, gleiche App auf mehreren Geräten zusammengezählt
  const al = $("ablList"), gl = $("gerList"); al.replaceChildren(); gl.replaceChildren();
  const devs = d?.geraete?.length ? d.geraete : d?.apps?.length ? [{name:"", apps:d.apps}] : [], m = new Map();
  devs.forEach(g => (g.apps || []).filter(a => a.kat === "prokrastination").forEach(a => {
    const k = a.name.toLowerCase(), e = m.get(k) || {name:a.name, sek:0, wo:[]};
    e.sek += a.sek; if (g.name && !e.wo.includes(g.name)) e.wo.push(g.name); m.set(k, e);
  }));
  const top = [...m.values()].sort((a, b) => b.sek - a.sek).slice(0, 6), max = top[0]?.sek || 1;
  const zeilen = top.map(a => { const r = el("div","abl"), n = el("div","n"); n.append(el("span", null, a.name)); if (a.wo.length) n.append(el("small", null, a.wo.join(", ")));
    r.append(n, el("span","v", minText(a.sek)), kpiBar(a.sek / max * 100, "var(--bad)")); return r; });
  if (!s) al.append(el("p","empty", "Wird geladen …"));
  else al.append(klapp("abl", [gesamt(minText(s.prokrastination), `${lp} % deiner Bildschirmzeit`,
      false, top.length ? `${top.length} ${top.length === 1 ? "App" : "Apps"}` : "keine Apps"), kpiBar(Math.min(100, lp), "var(--bad)")],
    zeilen.length ? zeilen : [el("p","empty","Heute noch keine Ablenkungs-Apps. Stark.")]));
  $("ablSub").textContent = ""; $("ablSub").className = "";
  const mixBar = g => { const mix = el("div","mix"), tot = g.sek || 1;
    KAT.forEach(([k, c, nm]) => { if (!g[k]) return; const i = el("i"); i.style.width = g[k] / tot * 100 + "%"; i.style.background = c; i.title = `${nm} ${minText(g[k])}`; mix.append(i); }); return mix; };
  const gers = (d?.geraete || []).map(g => { const r = el("div","ger"); r.append(el("span","n", g.name), el("span","v", minText(g.sek)), mixBar(g)); return r; });
  if (!s) gl.append(el("p","empty", "Wird geladen …"));
  else {
    const ges = {sek: s.produktiv + s.prokrastination + (s.neutral || 0), produktiv: s.produktiv, neutral: s.neutral || 0, prokrastination: s.prokrastination};
    const leg = el("div","kl-leg"); KAT.forEach(([k, c, nm]) => { if (!ges[k]) return; const x = el("span"), i = el("i"); i.style.background = c; x.append(i, `${nm} ${minText(ges[k])}`); leg.append(x); });
    gl.append(klapp("ger", [gesamt(minText(ges.sek), "am Bildschirm, alle Geräte", false, `${gers.length} ${gers.length === 1 ? "Gerät" : "Geräte"}`), mixBar(ges), leg],
      gers.length ? gers : [el("p","empty","Noch keine Zeit erfasst.")]));
  }
  $("gerSub").textContent = "";
  renderAutomatik();
}
// Aufklappbarer Block (merkt sich, ob er offen ist) und die große Gesamtzahl oben drin
function klapp(id, kopf, inhalt, cls = ""){
  const d = el("details","klapp" + (cls ? " " + cls : "")), s = el("summary"), body = el("div","kl-body");
  d.open = !!store("cockpit.auf." + id); d.addEventListener("toggle", () => store("cockpit.auf." + id, d.open));
  s.append(...kopf); body.append(...inhalt); d.append(s, body); return d;
}
function gesamt(wert, sub, schlecht, rechts){
  const g = el("div","kl-ges"), l = el("div"); l.append(el("b","k-v" + (schlecht ? " c-bad" : ""), wert), el("span","k-s" + (schlecht ? " c-bad" : ""), sub));
  g.append(l, el("span","kl-mehr", rechts)); return g;
}
const KAT = [["produktiv","var(--good)","Produktiv"],["neutral","var(--neutral)","Neutral"],["prokrastination","var(--bad)","Ablenkung"]];
function renderDevices(d){
  const box = $("apps"); box.replaceChildren();
  let devs = d.geraete;
  if (!devs?.length && d.apps?.length){
    const g = {name:"Alle Geräte", apps:d.apps, produktiv:0, neutral:0, prokrastination:0};
    d.apps.forEach(a => g[a.kat] += a.sek); g.sek = g.produktiv + g.neutral + g.prokrastination; devs = [g];
  }
  if (!devs?.length){ box.append(el("p","empty","Noch keine Zeit erfasst.")); return; }
  devs.forEach(g => {
    const det = el("details","dev"); det.open = S.openDevs.has(g.name);
    det.addEventListener("toggle", () => { det.open ? S.openDevs.add(g.name) : S.openDevs.delete(g.name); store("cockpit.geraeteOffen", [...S.openDevs]); });
    const sum = el("summary"), mix = el("div","mix"), sub = el("div","sub"), tot = g.sek || 1;
    KAT.forEach(([k, c, n]) => {
      if (!g[k]) return;
      const i = el("i"); i.style.width = (g[k]/tot*100) + "%"; i.style.background = c; i.title = `${n} ${minText(g[k])}`; mix.append(i);
      const s = el("span"); const sw = el("i","sw"); sw.style.background = c; sw.style.marginRight = "6px"; s.append(sw, `${n} ${minText(g[k])}`); sub.append(s);
    });
    const sync = S.phoneInfo?.geraete.find(x => x.name === g.name)?.letzterSync;
    if (sync) sub.append(el("span", null, "gesendet " + new Date(sync).toLocaleString("de-DE", {weekday:"short", hour:"2-digit", minute:"2-digit"})));
    sum.append(el("b", null, g.name), mix, el("span","v", minText(g.sek)), sub);
    const list = el("div","apps");
    g.apps.forEach(a => list.append(appRow(g, a)));
    if (!g.apps.length) list.append(el("p","empty","Keine Apps erfasst."));
    det.append(sum, list); box.append(det);
  });
}


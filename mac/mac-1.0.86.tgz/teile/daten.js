/* ---------- Datenquellen ---------- */
const CODE = (() => { const c = new URLSearchParams(location.search).get("code"); if (c) store("cockpit.code", c); return c || store("cockpit.code") || ""; })();
// Alle Anfragen laufen hier durch (Server, offline oder Python im Handy: siehe verbindung.js)
function api(path, body){ return VB.modus === "handy" ? vbHandy(path, body) : vbServer(path, body); }
async function toggle(it, done){
  try {
    if (S.mode === "lokal"){
      const warHeute = S.plan.heute.some(x => x.id === it.id);
      S.plan = await api("api/toggle", {id:it.id, done, text:it.text}); renderPlan();
      if (done && warHeute) nachAbhaken(it);
    }
    else if (S.mode === "claude") await S.db.doc(`${it.kind}/${it.id}`).update({done});
    else {
      // Beispielansicht: wie der Server (Ziel abgehakt -> alle Schritte; wieder offen -> letzter Schritt offen)
      it.done = done; it.own = done;
      const all = [...S.plan.heute, ...S.plan.woche, ...S.plan.monat, ...S.plan.jahr, ...(S.plan.tage || []).flatMap(d => d.items)];
      if (it.ziel){ const ss = it.ziel.schritte; if (done) ss.forEach(s => s.done = true); else if (ss.length && ss.every(s => s.done)) ss[ss.length - 1].done = false; }
      else if (!done) all.forEach(i => { if (i.ziel?.schritte.includes(it)) i.own = false; });
      recalc(S.plan); renderPlan();
    }
  } catch (e) { S.fehler = [`Speichern hat nicht geklappt: ${e.message || e}`]; renderHeader(); }
}
async function addItem(liste, text, projekt = null, extra = {}){
  projekt = projekt || null;
  try {
    if (S.mode === "lokal"){ S.plan = await api("api/add", {liste, text, projekt, ...extra}); renderPlan(); }
    else if (S.mode === "claude"){
      const project = projekt ? S.projIds?.[projekt] ?? null : null;
      if (liste === "heute") await S.db.collection("tasks").add({text, date:TODAY, done:false, project, created:new Date().toISOString()});
      else if (PERIOD_DB[liste]) await S.db.collection("goals").add({text, period:PERIOD_DB[liste], done:false, project, created:new Date().toISOString()});
    } else {
      const x = S.plan.projekte.find(x => x.name === projekt), id = "n" + Date.now();
      if (liste === "schritt") x.phasen.flatMap(f => f.ziele).find(g => key(g.name) === key(extra.ziel))?.schritte.push({id, text, done:false});
      else if (liste === "meilenstein"){ if (!x.phasen.some(f => key(f.name) === key(text))) x.phasen.push({name:text, marke:false, ziele:[]}); }
      else if (liste === "endziel"){ const m = text.match(/\s*\(bis ([^)]+)\)/); x.endziel = {text:text.replace(/\s*\(bis [^)]+\)/, ""), frist:null}; }
      else if (liste === "ziel" || liste === "projekt"){
        const ph = x.phasen.find(f => f.name === extra.phase) || x.phasen.find(f => f.aktiv) || x.phasen[0];
        if (!x.phasen.some(f => f.ziele.some(g => key(g.name) === key(text))))
          ph.ziele.push(ph.ziele.every(g => g.einzel) && ph.name === "Aufgaben" ? {name:text, einzel:true, schritte:[{id, text, done:false}]} : {name:text, einzel:false, schritte:[]});
      }
      else S.plan[liste].push({id, text, done:false, own:false, projekt});
      recalc(S.plan); renderPlan();
    }
  } catch (e) { S.fehler = [`Speichern hat nicht geklappt: ${e.message || e}`]; renderHeader(); }
}

async function loadLocal(){
  const st = await api("api/status");
  S.fehler = st.fehler || [];
  const saved = store("cockpit.ziele");
  S.goalMin = saved?.goalMin ?? st.produktivZielMin; S.limitMin = saved?.limitMin ?? st.prokrastinationLimitMin;
  const plan = await api("api/plan");
  if (JSON.stringify(plan) !== JSON.stringify(S.plan)){ S.plan = plan; renderPlan(); }
  renderPhones().catch(() => {});
  fkLoad();
  if (st.aw || st.handy){
    S.demoActivity = false;
    S.day = await api("api/today"); renderDay();
    if (Date.now() - S.apiFresh > 600000){ S.week = await api("api/week"); S.apiFresh = Date.now(); renderWeek(); }
  } else if (!S.day){ S.day = demoDay(TODAY, NOW.getHours()); S.week = demoWeek(); renderDay(); renderWeek(); }
  renderHeader();
}

function startClaude(db){
  S.db = db;
  const map = s => s.docs.map(d => ({id:d.id, ...d.data()}));
  let tasks = [], goals = [], projects = [];
  const build = () => {
    const open = tasks.filter(t => t.date === TODAY || (t.date < TODAY && !t.done));
    const pn = id => projects.find(p => p.id === id)?.name;
    S.projIds = Object.fromEntries(projects.map(p => [p.name, p.id]));
    const conv = (x, kind) => ({id:x.id, kind, text:x.text, done:!!x.done, projekt:pn(x.project) || null, tag:x.label || null,
      from: kind === "tasks" && x.date < TODAY ? new Date(x.date + "T12:00").toLocaleDateString("de-DE",{day:"numeric", month:"short"}) : null});
    S.plan = {heute:open.map(t => conv(t,"tasks")), woche:[], monat:[], jahr:[],
      projekte:[...projects].sort((a,b) => (a.order ?? 99) - (b.order ?? 99)).map(p => { const ms = p.milestones || []; return {name:p.name, status:p.status || "aktiv", aktiv:p.status !== "pausiert", done:ms.filter(m => m.done).length, total:ms.length, next:p.next}; })};
    goals.forEach(g => { const k = Object.keys(PERIOD_DB).find(k => PERIOD_DB[k] === g.period); if (k) S.plan[k].push(conv(g,"goals")); });
    renderPlan();
  };
  const err = () => { S.fehler = ["Die Verbindung ist abgebrochen. Lade die Seite neu."]; renderHeader(); };
  db.collection("projects").onSnapshot(s => { projects = map(s); build(); }, err);
  db.collection("tasks").onSnapshot(s => { tasks = map(s); build(); }, err);
  db.collection("goals").onSnapshot(s => { goals = map(s); build(); }, err);
  db.collection("days").onSnapshot(s => {
    const days = Object.fromEntries(map(s).map(d => [d.id, d]));
    if (!days[TODAY]) return;
    S.demoActivity = false; S.day = days[TODAY];
    const tage = []; for (let n = 6; n >= 0; n--){ const d = new Date(NOW); d.setDate(d.getDate()-n); const k = iso(d); tage.push({date:k, ...(days[k]?.summe || {produktiv:0,neutral:0,prokrastination:0,afk:0})}); }
    S.week = {tage, serie:days[TODAY].serie ?? 0}; renderHeader(); renderDay(); renderWeek();
  }, () => {});
}

async function renderPhones(){
  const info = await api("api/handy-info");
  S.phoneInfo = info; if (S.day) renderDevices(S.day);
  $("phoneBox").hidden = VB.modus === "handy";   // im Modus „Nur dieses Handy“ gibt es keinen Mac zum Verbinden
  $("phoneSum").textContent = info.geraete.length ? `${info.geraete.length} verbunden, Zeiten stehen oben bei „Wofür die Zeit heute ging“` : "Noch kein Handy verbunden";
  if (!info.geraete.length) $("phoneDet").open = true;
  const box = $("phones"); box.replaceChildren();
  info.geraete.forEach(g => {
    const c = el("div","phone"); c.append(el("b", null, g.name), el("span","v", minText(g.heuteSek)), el("span", null, "heute am Handy"),
      el("span", null, g.letzterSync ? "zuletzt gesendet " + new Date(g.letzterSync).toLocaleString("de-DE",{weekday:"short", hour:"2-digit", minute:"2-digit"}) : ""));
    box.append(c);
  });
  if (!info.geraete.length) box.append(el("p","empty","Noch kein Handy verbunden."));
  const st = $("phoneSteps"); st.replaceChildren();
  if (!info.code){ st.hidden = true; return; }
  const li = (...parts) => { const l = el("li"); parts.forEach(p => l.append(typeof p === "string" ? p : p)); st.append(l); };
  if (!info.lan) li("Im WLAN ist BlockEm noch aus. Setz in config.json \"lan\": true und starte BlockEm neu.");
  li("Installieren oder auf die neueste Version aktualisieren: Handy ins selbe WLAN wie den Mac, im Handy-Browser ", el("code", null, info.adresse + "/handy.apk"), " öffnen und installieren (Installation aus dieser Quelle erlauben).");
  li("In der App „BlockEm“: Nutzungszugriff erlauben, dann Adresse ", el("code", null, info.adresse), " und Code ", el("code", null, info.code), " eintragen und senden.");
  li("BlockEm am Handy ansehen: ", el("code", null, `${info.adresse}/?code=${info.code}`));
}


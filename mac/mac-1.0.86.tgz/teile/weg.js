/* ---------- Reiter „Weg“ (john 11.11.2026 12:59): alles zum Durchhalten an einem Ort ----------
   Unten fünf Reiter: Heute · Fokus · Locker · Werte · Weg. „Mehr“ gibt es in der Tracking-App nicht mehr als Reiter:
   Das Zahnrad oben rechts öffnet dieselbe Liste, geordnet in Schutz / Konto / App. Habits liegt als Knopf in „Werte“.
   Weg zeigt: wann es Geschenke gibt (nur wann, nicht was), Spenden-Tage, „Gemeinsam“, Sammlung/Farbe/Abzeichen/Warum.
   Baut auf tuerchen.js (tueGeschenke, tueStand, tueBlatt, gmKarte) und handy.js (mehrOeffnen). CSS in weg.css. */
const WEG = {alle:false};
const WEG_SPENDE = [90, 180, 270, 365];   // Tage am Stück, an denen BlockEm spendet (Vault „Belohnungssystem“); startet mit der Veröffentlichung
function wegPunkte(d){   // [{noch, spende, geschenk}] aufsteigend, höchstens ein Jahr voraus
  const tage = d.sauber?.tage ?? 0, m = new Map();
  const dazu = (noch, k) => { if (noch > 0 && noch <= 365){ const p = m.get(noch) || {noch}; p[k] = true; m.set(noch, p); } };
  tueGeschenke(d).filter(g => !g.da).forEach(g => dazu(g.noch, "geschenk"));
  WEG_SPENDE.forEach(t => dazu(t - tage, "spende"));
  return [...m.values()].sort((a, b) => a.noch - b.noch);
}
function wegZeichnen(){
  const tab = document.querySelector('.tab[data-r="weg"]'), d = TR.daten; if (!tab) return;
  if (!d){ tab.replaceChildren(el("p","k-s","Lädt …")); trLaden().then(x => { if (x) wegZeichnen(); }); return; }
  if (!GM.stand && !GM.fehler) gmHolen();
  const tage = d.sauber?.tage ?? 0, st = tueStand(d), seite = el("div","w-seite");
  const kopf = el("div"); kopf.append(el("h1", null, "Dein Weg"), el("p","w-sub", `${tage} ${tage === 1 ? "Tag" : "Tage"} am Stück`));
  // 1. Wann es Geschenke gibt
  const k1 = el("section","w-karte"), pfad = el("div","w-pfad"), alle = wegPunkte(d), zeigen = WEG.alle ? alle : alle.slice(0, 3);
  const punkt = (cls, ico, titel, sub, rechts) => { const p = el("div","w-p " + cls), t = el("span"); t.append(el("b", null, titel)); if (sub) t.append(el("small", null, sub)); p.append(el("i", null, ico), t, el("em", null, rechts)); return p; };
  pfad.append(punkt("hier", "", "Heute", "", `Tag ${tage}`));
  zeigen.forEach((p, i) => pfad.append(punkt(i === 0 ? "next" : "", p.spende ? "❤️" : "🎁", p.spende && p.geschenk ? "Geschenk und Spende" : p.spende ? "Spende" : "Geschenk",
    new Date(Date.now() + p.noch * 864e5).toLocaleDateString("de-DE", {day:"numeric", month:"long"}), p.noch === 1 ? "morgen" : `in ${p.noch} Tagen`)));
  k1.append(el("b", null, "Wann es Geschenke gibt"), pfad);
  if (alle.length > 3){ const mehr = el("button","w-mehr", WEG.alle ? "Weniger zeigen" : `Alle ${alle.length} anzeigen`); mehr.type = "button"; mehr.addEventListener("click", () => { WEG.alle = !WEG.alle; wegZeichnen(); }); k1.append(mehr); }
  if (zeigen.some(p => p.spende)) k1.append(el("p","k-s","Spenden starten mit der Veröffentlichung."));   // john 17.11.: weniger Text; der Hinweis bleibt, solange noch nicht gespendet wird
  // 2. Gemeinsam
  const k2 = el("section","w-karte w-gm"); k2.append(gmKarte());
  // 3. Was du schon hast
  const liste = el("div","w-liste");
  const zeile = (ico, titel, wert, zu) => { const z = el("button","w-z"); z.type = "button"; z.append(el("i", null, ico), el("b", null, titel), el("small", null, wert), el("em", null, "›")); z.addEventListener("click", () => tueBlatt(d, zu)); liste.append(z); };
  zeile("🖼", "Sammlung", `${st.fertig} ${st.fertig === 1 ? "Bild" : "Bilder"}`, "sammlung");
  if (d.profil?.geschlecht !== "w" && typeof STILE !== "undefined"){ const max = Math.max(+(store("stil.max") || 0), tage); zeile("🎨", "Farbe der App", `${STILE.filter(x => max >= x.ab).length} frei`, "farbe"); }
  if (typeof TR_MEILENSTEINE !== "undefined") zeile("🏅", "Abzeichen", `${TR_MEILENSTEINE.filter(m => tage >= m).length} von ${TR_MEILENSTEINE.length}`, "abzeichen");
  zeile("💬", "Dein Warum", store("tue.warum") ? "gesetzt" : "noch leer", "warum");
  seite.append(kopf, k1, k2, liste); tab.replaceChildren(seite);
}
function wegOeffnen(){ showTab("weg"); window.scrollTo(0, 0); }

/* Zahnrad-Liste ordnen: Schutz (Vertrauensperson) / Konto (BlockEm Pro) / App (Rest). Die Zeilen kommen teils erst per Beobachter dazu, daher mehrfach und ohne Nebenwirkung. */
function wegMenueOrdnen(){
  const d = $("mehrDialog"), l = d?.querySelector(".mb-liste"); if (!l) return;
  const h2 = d.querySelector("h2"); if (h2) h2.textContent = "Konto und Einstellungen";
  const z = [...l.children].filter(x => !x.classList.contains("mb-gr")), vp = z.filter(x => x.classList.contains("vp-zeile-mehr")), ka = z.filter(x => x.classList.contains("ka-zeile")), rest = z.filter(x => !vp.includes(x) && !ka.includes(x));
  const gr = (t, zeilen) => zeilen.length ? [el("div","mb-gr", t), ...zeilen] : [];
  const neu = [...gr("Schutz", vp), ...gr("Konto", ka), ...gr("App", rest)];
  if (neu.length === l.children.length && neu.every((x, i) => x === l.children[i])) return;   // stimmt schon: nichts verschieben (Fokus bleibt)
  l.replaceChildren(...neu);
}

if (NUR_TRACKING && typeof tueGeschenke === "function" && $("reiter")){
  // Reiter und Fläche anlegen
  REITER.push("weg"); HAUPT_REITER.push("weg");
  const knopf = el("button"); knopf.type = "button"; knopf.setAttribute("role", "tab"); knopf.dataset.r = "weg"; knopf.setAttribute("aria-selected", "false");
  knopf.innerHTML = '<svg class="ri" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 21V4"/><path d="M5 4h11l-2 4 2 4H5"/></svg><span>Weg</span>';
  ($("reiter").querySelector('[data-r="einstellungen"]') || $("mehrBtn") || $("reiter").lastElementChild).before(knopf);   // Mac-Seitenleiste: vor Einstellungen
  const flaeche = el("div","tab"); flaeche.dataset.r = "weg"; flaeche.setAttribute("role", "tabpanel"); flaeche.hidden = true;
  [...document.querySelectorAll(".tab")].pop().after(flaeche);
  // Habits: aus der Liste hinter dem Zahnrad raus, als Knopf in „Werte“
  for (let i = MEHR_REITER.length - 1; i >= 0; i--) if (MEHR_REITER[i][0] === "habits") MEHR_REITER.splice(i, 1);
  // john 17.11.2026: Habits braucht die Tracking-App nicht, kein Knopf mehr in „Werte“
  const wegHeroAlt = trHeroZeichnen;   // „Weg“ mit neuen Daten auffrischen (auch wenn es beim Öffnen noch lud)
  trHeroZeichnen = function(h, d){ wegHeroAlt(h, d); if (store("cockpit.reiter") === "weg") wegZeichnen(); };
  const wegTabAlt = showTab;
  showTab = function(r){
    wegTabAlt(r);
    const jetzt = store("cockpit.reiter");
    if (jetzt === "weg") wegZeichnen();
    if (jetzt === "habits") document.querySelector('#reiter button[data-r="werte"]')?.setAttribute("aria-selected", "true");   // Habits gehört zu Werte
  };
  // Zahnrad öffnet die Liste (vorher: sprang direkt in die Einstellungen)
  window.addEventListener("click", e => { if (!e.target.closest?.("#setBtn")) return; e.stopImmediatePropagation(); e.stopPropagation(); mehrOeffnen(); }, true);   // vor dem alten Listener (bedienung.js), auch in alten WebViews
  const wegMehrAlt = mehrOeffnen;
  mehrOeffnen = function(){ wegMehrAlt(); queueMicrotask(wegMenueOrdnen); setTimeout(wegMenueOrdnen, 400); };   // nach den Beobachtern aus kasse.js/vertrauen.js
  if (TR.startHash === "#weg") showTab("weg");   // Link #weg: das erste showTab lief vor dieser Datei
}

// 1.0.4: Bild-KI-Modell (CLIP, 89 MB) am Handy von Hand laden, mit Fortschritt (Schutz-Karte im Locker)
if (typeof trSchutzKarte === "function"){
  const _trSchutzClip = trSchutzKarte;
  trSchutzKarte = function(x){
    const k = _trSchutzClip.call(this, x), box = bkBox();
    if (!box) return k;
    const nach = [...k.querySelectorAll(".tr-schutz-zeile")].find(z => /^(Nackte Haut|Bild-KI in Social)/.test(z.querySelector("b")?.textContent || ""));
    if (nach) nach.after(box); else k.append(box);
    return k;
  };
}
// 19.11.: als eigene Funktion, damit bindung.js die Box unter „Bild-KI“ setzen kann (spätere Schichten hatten sie verworfen)
function bkBox(){
    const A = window.CockpitApp;
    if (!A?.clipStand) return null;
    const box = el("div","bk-clip"), txt = el("div", null), kn = eiKnopf("Jetzt laden","small", () => { A.clipLaden(); kn.disabled = true; setTimeout(zeigen, 400); });
    const titel = el("b", null, "Bild-KI-Modell"), stand = el("span","k-s", "");
    txt.append(titel, el("br"), stand);
    if (A.akkuAnsicht){   // 19.11.: kein geschätzter Prozentwert, nur der Weg zur Akku-Ansicht von Android
      const ak = el("button","bk-akku","Akkuverbrauch ansehen ›"); ak.type = "button"; ak.addEventListener("click", () => A.akkuAnsicht());
      txt.append(el("br"), ak);
    }
    box.append(txt, kn);
    // 1.0.14: Aussehen in blockem.css (inline display:flex hat die Box auch bei zugeklappter Karte gezeigt)
    let uhr = 0;
    function zeigen(){
      if (!box.isConnected && uhr){ clearInterval(uhr); uhr = 0; return; }
      let s = {}; try { s = JSON.parse(A.clipStand() || "{}"); } catch {}
      if (s.laedt){ stand.textContent = "Lädt … " + (s.prozent || 0) + " % (" + (s.mb || 0) + " von 89 MB)"; kn.disabled = true; kn.textContent = "Lädt …"; if (!uhr) uhr = setInterval(zeigen, 1000); return; }
      if (uhr){ clearInterval(uhr); uhr = 0; }
      kn.disabled = false;
      // 19.11.: Social-Apps sind nur offen, wenn die Prüfung bereit ist; das steht hier in einem Satz
      const zu = " Bis dahin bleiben Instagram, TikTok und Co. zu.";
      titel.textContent = s.bereit === false && s.da ? "Bild-KI wird vorbereitet" : s.da ? "Bild-KI ist bereit" : "Bild-KI-Modell fehlt";
      box.classList.toggle("bk-wartet", !s.da || s.bereit === false);
      if (s.da && s.ausfall){ stand.textContent = "Die Prüfung ist kurz ausgefallen und startet neu." + zu; kn.style.setProperty("display", "none", "important"); if (!uhr) uhr = setInterval(zeigen, 3000); }
      else if (s.da && s.bereit === false){ stand.textContent = "Das Modell wird gestartet." + zu; kn.style.setProperty("display", "none", "important"); if (!uhr) uhr = setInterval(zeigen, 1500); }
      else if (s.da){ stand.textContent = "✓ Sie prüft Bilder in Social-Apps, alle 1,2 Sekunden." + (s.weg ? " Rechnet mit: " + s.weg : ""); kn.style.setProperty("display", "none", "important"); if (s.weg === "Wird gemessen …" && !uhr) uhr = setInterval(zeigen, 1500); }
      else { stand.textContent = (s.meldung ? s.meldung + ". " : "") + "Ohne das Modell (89 MB) erkennt die Bild-KI nichts." + zu + " Am besten im WLAN laden."; kn.textContent = "Jetzt laden"; kn.style.removeProperty("display"); }
    }
    zeigen();
    return box;
}

/* ---------- Automatik: Tagesplan kommt fertig, „Mehr machen?“, Zeit pro Projekt, Hinweis bei Ablenkung, Rückblick ---------- */
// Was wie automatisch läuft, steht im Vault in „Browser-App Cockpit – Automatisierung“.
function renderAutomatik(){
  renderSchalter(); renderKi(); fcKnopf(); renderEinstellungen(); renderZeitleiste(); renderEinWeiter(); einrichtungPruefen(); renderTagesplan(S.plan); renderV12(); renderHinweis();   /* „Zeit pro Projekt“ entfernt (john, 15.10.2026) */ rbKachel(); limitAbgleich();
  if (S.mode === "lokal" && !RB.daten && !RB.laedt && $("rbBox") && !$("rbBox").closest(".tab").hidden) rbLaden();
}
/* Reiter „Automatik“: jede Automatik einzeln an/aus (gespeichert in automatik.json, Standard an) */
const AUTOMATIKEN = [
  {k:"tagesplan", n:"Tagesplan kommt fertig", t:"Morgens steht auf Heute ein Vorschlag aus Wochenzielen und aktiven Phasen, du bestätigst nur."},
  {k:"mehr", n:"„Mehr machen?“", t:"Ist alles für heute abgehakt, schlägt BlockEm vor, was noch in deine Stunden passt."},
  {k:"habits", n:"Habits haken sich selbst ab", t:"Messbare Habits wie „1 Std Fokus“ oder „kein Instagram vor 12“ hakt BlockEm selbst ab."},
  {k:"hinweise", n:"Hinweis bei Ablenkung", t:"Mitteilung auf Mac und Handy, sobald das Ablenkungs-Budget voll ist, danach alle 30 Min."},
  {k:"rueckblick", n:"Rückblick", t:"Kachel auf Heute am Sonntag/Montag und Monatsende, Notiz in „Claude Memory/Rückblicke“. Im Werte-Reiter kannst du ihn immer ansehen."},
  {k:"jetzt", n:"„Jetzt dran“", t:"Oben auf Heute steht die eine nächste Aufgabe mit „Fokus starten“."},
  {k:"abend", n:"Abendabschluss", t:"Ab 19 Uhr: was geschafft ist, Offenes bleibt für morgen oder kommt raus. Vergessen ist kein Problem."},
  {k:"sperre", n:"Sperre im Fokus", t:"Während einer Fokus-Session sind die angehakten Seiten und Apps gesperrt (auswählen unter Einstellungen › Fokus-Sperre)."},
  {k:"wochenplan", n:"Wochenplan kommt fertig", t:"Sonntag und Montag liegt ein Vorschlag für die Wochenziele aus den aktiven Phasen bereit."},
  {k:"kalender", n:"Termine aus deinem Kalender", t:"Zeigt deine Termine auf Heute und in „Mein Tag“ und zieht sie von deinen Stunden ab (Kalender verbinden: Einstellungen › Kalender)."},
  {k:"zeitleiste", n:"„Mein Tag“: feste Zeiten für deine Aufgaben", t:"Die Aufgaben für heute bekommen Zeitblöcke in den Lücken zwischen deinen Terminen. Neue Aufgaben kommen in die nächste Lücke."},
  {k:"planfokus", n:"Fokus startet zum geplanten Block", t:"Hast du deinen Tag mit „Passt so“ bestätigt, startet der Fokus zu Beginn jedes Blocks von selbst, mit Sperre. 3 Minuten vorher kommt eine Mitteilung."},
  {k:"googleBloecke", n:"Blöcke stehen in deinem Google-Kalender", t:"Sobald du deinen Tag mit „Passt so“ bestätigst, trägt BlockEm die Blöcke als Termine ein. Verschiebst du einen Termin in Google, übernimmt BlockEm die neue Zeit (Google verbinden: Einstellungen › Kalender)."},
  {k:"sicherung", n:"Nacht-Sicherung", t:"Jede Nacht eine Sicherung der BlockEm-Daten und Notizen, 14 Tage lang."},
  {k:"fokusAuto", n:"Fokus startet von selbst", t:"Längeres Arbeiten in produktiven Apps zählt als Fokuszeit.", geplant:true},
];
function autoAn(k){ const a = S.plan?.automatik; if (!a) return true; return k === "hinweise" ? a.hinweise !== false : a.schalter?.[k] !== false; }
function renderSchalter(){
  const box = $("autoListe"); if (!box) return;
  if (S.mode !== "lokal" || !S.plan?.automatik){ box.replaceChildren(el("p","empty", S.mode === "lokal" ? "Wird geladen …" : "Die Schalter gibt es nur in BlockEm auf dem Mac (oder in der Handy-App im WLAN).")); return; }
  const an = AUTOMATIKEN.filter(x => !x.geplant && autoAn(x.k)).length, alle = AUTOMATIKEN.filter(x => !x.geplant).length;
  $("autoSub").textContent = `${an} von ${alle} an`;
  box.replaceChildren(...AUTOMATIKEN.map(x => {
    const r = el("label","auto-row" + (x.geplant ? " geplant" : "")), cb = document.createElement("input"), t = el("div","auto-t");
    cb.type = "checkbox"; cb.className = "auto-sw"; cb.setAttribute("role","switch");
    cb.checked = !x.geplant && autoAn(x.k); cb.disabled = !!x.geplant;
    t.append(el("b", null, x.n), el("span","k-s", x.geplant ? x.t + " Kommt noch." : x.t));
    cb.addEventListener("change", async () => {
      cb.disabled = true;
      try { S.plan = await api("api/automatik", {schalter:{[x.k]:cb.checked}}); renderPlan(); toast(`${x.n}: ${cb.checked ? "an" : "aus"}`); }
      catch (e){ cb.checked = !cb.checked; cb.disabled = false; alert(e.message || e); }
    });
    r.append(t, cb); return r;
  }));
}

// Server bekommt das Ablenkungs-Budget aus den Einstellungen (für die Mitteilungen)
function limitAbgleich(){
  const a = S.plan?.automatik; if (S.mode !== "lokal" || !a || a.limitMin === S.limitMin) return;
  a.limitMin = S.limitMin; api("api/automatik", {limitMin:S.limitMin}).catch(() => {});
}

/* Tagesplan: morgens steht ein Vorschlag aus Wochenzielen und aktiven Phasen da, du bestätigst nur */
function renderTagesplan(p){
  const box = $("tpBox"); if (!box) return;
  const tp = p?.tagesplan; box.hidden = !tp || S.mode !== "lokal"; if (box.hidden) return;
  const wahl = new Set(tp.liste.map((_, i) => i)), ul = el("ul","list");
  const summe = () => tp.liste.filter((_, i) => wahl.has(i)).reduce((a, x) => a + x.std, 0);
  const sub = el("span","k-s");
  const zeigeSumme = () => { sub.textContent = `${wahl.size} ${wahl.size === 1 ? "Aufgabe" : "Aufgaben"} · ${stdText(summe())} von ${stdKurz(tp.std)} · aus Wochenzielen und aktiven Phasen`; };
  tp.liste.forEach((x, i) => {
    const li = el("li","item"), cb = document.createElement("input"), t = el("div","t", x.text);
    cb.type = "checkbox"; cb.checked = true; cb.setAttribute("aria-label", x.text);
    cb.addEventListener("change", () => { cb.checked ? wahl.add(i) : wahl.delete(i); ok.disabled = !wahl.size; zeigeSumme(); });
    if (x.projekt) t.append(el("span","tag", x.projekt)); t.append(el("span","tag", stdText(x.std)));
    li.append(cb, t); ul.append(li);
  });
  const ok = el("button","ask","Übernehmen"), selbst = el("button","ghost small","Selbst planen"), weg = el("button","ghost small","Heute nicht");
  [ok, selbst, weg].forEach(b => b.type = "button");
  const senden = async (status, danach) => {
    ok.disabled = selbst.disabled = weg.disabled = true;
    try {
      S.plan = await api("api/tagesplan", {status, heute: status === "uebernommen" ? tp.liste.filter((_, i) => wahl.has(i)).map(x => ({text:x.text, projekt:x.projekt})) : []});
      renderPlan(); if (status === "uebernommen") toast("Dein Tag steht. Viel Erfolg!"); danach?.();
    } catch (e){ S.fehler = [`Tagesplan: ${e.message || e}`]; renderHeader(); ok.disabled = selbst.disabled = weg.disabled = false; }
  };
  ok.addEventListener("click", () => senden("uebernommen"));
  selbst.addEventListener("click", () => senden("weg", () => openPlaner("heute")));
  weg.addEventListener("click", () => senden("weg"));
  const btns = el("div","tp-btns"); btns.append(ok, selbst, weg);
  zeigeSumme();
  box.replaceChildren(el("b","tp-h","Dein Tag ist vorbereitet"), sub, ul, btns);
}

/* „Mehr machen?“: wenn alles für heute erledigt ist, Vorschläge, die noch in die Stunden passen */
function nachAbhaken(it){
  const p = S.plan; if (!p) return;
  const offen = p.heute.filter(t => !t.done).length;
  if (offen){ toast(`Geschafft! Noch ${offen} für heute offen.`); return; }
  if (!autoAn("mehr")){ toast("Alles für heute geschafft. Stark!"); return; }
  const v = p.vorschlag; if (!v?.liste?.length){ toast("Alles für heute geschafft. Stark!"); return; }
  const passt = v.liste.filter(x => x.std <= v.frei + 1e-9), liste = (passt.length ? passt : [...v.liste].sort((a, b) => a.std - b.std)).slice(0, 3);
  let d = $("mehrDlg");
  if (!d){ d = el("dialog","planer mehr"); d.id = "mehrDlg"; d.setAttribute("aria-labelledby","mehrTitel"); $("planer").parentNode.append(d); }
  const zu = el("button","ghost","Für heute reicht's"); zu.type = "button"; zu.addEventListener("click", () => d.close());
  const kopf = el("div","ph"); kopf.append(el("h2", null, "Alles geschafft. Mehr machen?"), zu); kopf.firstChild.id = "mehrTitel";
  const body = el("div","pb");
  body.append(el("p","step", v.frei >= 0.25 ? `Heute sind noch ${stdText(v.frei)} von ${stdKurz(v.std)} frei.` : `Deine ${stdKurz(v.std)} für heute sind voll. Wenn du noch Lust hast, passt das hier gut:`));
  liste.forEach(x => {
    const r = el("div","plrow mehr-row"), t = el("div","t", x.text), b = el("button","ask small","Dazu");
    t.append(el("span","tag", x.projekt || x.woher), el("span","tag", stdText(x.std)));
    b.type = "button";
    b.addEventListener("click", async () => {
      b.disabled = true;
      try { S.plan = await api("api/plan-setzen", {heute:[{text:x.text, projekt:x.projekt}]}); renderPlan(); d.close(); toast(`„${x.text}“ ist jetzt für heute geplant.`); }
      catch (e){ b.disabled = false; alert(e.message || e); }
    });
    r.append(t, b); body.append(r);
  });
  if (!passt.length) body.append(el("p","hint","Keiner der Vorschläge passt ganz in die freie Zeit, das sind die kleinsten."));
  const wrap = el("div","plwrap"); wrap.append(kopf, body); d.replaceChildren(wrap);
  if (!d.open) d.showModal();
}

/* Zeit pro Projekt (automatisch erkannt) und „Wozu gehörte das?“ */
function renderProjektZeit(){
  const box = $("pzList"); if (!box) return;
  const d = S.day, p = S.plan;
  $("pzBox").hidden = S.mode !== "lokal" || !d || !("projekte" in d) || !autoAn("erkennung");
  if ($("pzBox").hidden) return;
  const pr = d.projekte || [], max = pr[0]?.sek || 1, ges = pr.reduce((a, x) => a + x.sek, 0), zeilen = [];
  pr.forEach(x => {
    const r = el("div","abl"), farbe = p?.projekte?.find(y => y.name === x.name)?.farbe || "var(--cyan)";
    // Plan gegen Wirklichkeit: heute für das Projekt geplante Stunden daneben
    const gepl = (p?.heute || []).filter(t => t.projekt === x.name).reduce((a, t) => a + (t.std || 0), 0);
    r.append(el("div","n", x.name), el("span","v", minText(x.sek) + (gepl ? ` / ${stdText(gepl)} geplant` : "")), kpiBar(x.sek / max * 100, farbe)); zeilen.push(r);
  });
  const kids = [klapp("pz", [gesamt(minText(ges), pr.length ? "automatisch Projekten zugeordnet" : "noch keinem Projekt zugeordnet", false, `${pr.length} ${pr.length === 1 ? "Projekt" : "Projekte"}`)],
    zeilen.length ? zeilen : [el("p","empty","Noch nichts erkannt. Ordne unten zu, dann lernt BlockEm.")])];
  const offen = d.offen || [];
  if (offen.length){
    const f = el("div","pz-frage"); f.append(el("b", null, "Wozu gehörte das?"), el("span","k-s","Produktive Zeit ohne Projekt. Einmal zuordnen, dann erkennt BlockEm es selbst."));
    offen.slice(0, 5).forEach(x => {
      const r = el("div","pz-row"), sel = el("select");
      sel.setAttribute("aria-label", `„${x.name}“ zuordnen`);
      sel.append(new Option("Zuordnen …", ""), ...(p?.projekte || []).filter(y => y.aktiv).map(y => new Option(y.name, y.name)), new Option("Werkzeug für alles (zählt zum Projekt drumherum)", "*"), new Option("Kein Projekt (nicht mehr fragen)", "-"));
      sel.addEventListener("change", async () => {
        if (!sel.value) return; sel.disabled = true;
        try { const r2 = await api("api/erkennung", {stichwort:x.name, projekt:sel.value === "-" ? "" : sel.value}); S.day = r2.tag; delete r2.tag; S.plan = r2; renderPlan(); renderDay();
          toast(sel.value === "-" ? `„${x.name}“: BlockEm fragt nicht mehr.` : sel.value === "*" ? `„${x.name}“ ist jetzt ein Werkzeug und zählt zum Projekt, an dem du gerade arbeitest.` : `„${x.name}“ zählt ab jetzt für ${sel.value}.`); }
        catch (e){ sel.disabled = false; alert(e.message || e); }
      });
      r.append(el("span","n", x.name), el("span","v", minText(x.sek)), sel); f.append(r);
    });
    kids.push(f);
  }
  const wz = p?.automatik?.werkzeuge || [];
  if (wz.length || d.werkzeugOhne){
    const w = el("p","hint kon-hint", `Werkzeuge wie ${wz.slice(0, 4).join(", ")} zählen zum Projekt, an dem du 10 Min davor oder danach gearbeitet hast.` +
      (d.werkzeugOhne >= 60 ? ` Ohne Projekt drumherum: ${minText(d.werkzeugOhne)} (zählt nirgends).` : ""));
    kids.push(w);
  }
  if (p?.automatik?.erkennungNotiz){ const l = obsidianLink(p.automatik.erkennungNotiz); l.textContent = "Stichwörter in Obsidian ansehen"; kids.push(l); }
  box.replaceChildren(...kids);
}

/* Hinweis bei Ablenkung: Mitteilung auf dem Mac und in der Handy-App, sobald das Budget voll ist */
function renderHinweis(){
  const box = $("ablHinweis"); if (!box) return;
  const a = S.plan?.automatik; box.hidden = S.mode !== "lokal" || !a; if (box.hidden) return;
  const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = a.hinweise !== false;
  cb.addEventListener("change", async () => { a.hinweise = cb.checked; try { await api("api/automatik", {hinweise:cb.checked}); } catch {} renderHinweis(); renderSchalter(); });
  const l = el("label","ah-set"); l.append(cb, " Mitteilung, wenn das Budget voll ist (dann alle 30 Min wieder)");
  box.replaceChildren(l);
  if (a.hinweis && a.hinweise !== false) box.append(el("span","k-s", `Zuletzt um ${a.hinweis.zeit}: ${a.hinweis.text}`));
}

/* Rückblick: Woche (Sonntag) und Monat (Monatsende), im Werte-Reiter; am Sonntag/Montag bzw. Monatsende/-anfang als Kachel auf Heute */
const RB = {art:"woche", bezug:TODAY, daten:null, laedt:false};
function rbVerschieben(n){
  const d = new Date(RB.bezug + "T12:00");
  if (RB.art === "monat"){ d.setDate(1); d.setMonth(d.getMonth() + n); } else d.setDate(d.getDate() + 7 * n);
  if (iso(d) > TODAY) return; RB.bezug = iso(d); rbLaden();
}
async function rbLaden(){
  if (S.mode !== "lokal" || RB.laedt) return;
  RB.laedt = true; $("rbInhalt").replaceChildren(el("p","empty","Wird geladen …"));
  try { RB.daten = await api(`api/rueckblick?art=${RB.art}&datum=${RB.bezug}`); }
  catch (e){ RB.daten = null; $("rbInhalt").replaceChildren(el("p","empty", "Rückblick ging nicht: " + (e.message || e))); }
  RB.laedt = false; if (RB.daten) renderRueckblick();
}
function renderRueckblick(){
  const r = RB.daten, box = $("rbInhalt"); if (!r || !box) return;
  document.querySelectorAll("#rbArt button").forEach(b => b.setAttribute("aria-pressed", b.dataset.art === RB.art));
  $("rbTitel").textContent = r.titel + (r.fertig ? "" : " (läuft noch)");
  $("rbVor").disabled = r.bis >= TODAY;
  const s = r.summe, f = r.fokus, k = r.konsistenz;
  const kz = (lbl, wert, sub, farbe) => { const x = kpi(lbl, wert, farbe); x.append(el("span","k-s", sub)); return x; };
  const top = el("div","kon-top rb-top");
  top.append(kz("Produktiv", minText(s.produktiv), `Ablenkung ${minText(s.prokrastination)}`, "var(--good)"),
    kz("Fokuszeit", minText(f.produktiv), f.sessions ? `${f.sessions} Sessions · ${f.prozent} % Fokus · ${f.anzahl}× abgelenkt` : "keine Fokus-Sessions"),
    kz("Consistency", k.schnitt == null ? "–" : k.schnitt + " %", `${k.durchgezogen} von ${k.tage} Tagen durchgezogen${k.frei ? ` · ${k.frei} frei` : ""}`,
      k.schnitt == null ? "" : k.schnitt >= k.schwelle ? "var(--good)" : "var(--cyan)"));
  // Tage: produktiv (grün) und Ablenkung (rot) nebeneinander
  const bar = el("div","rb-tage"), mx = Math.max(1, ...r.tage.map(t => Math.max(t.produktiv, t.prokrastination)));
  // alle Tage des Zeitraums zeigen, auch die noch kommenden (leer)
  const alle = [], da = Object.fromEntries(r.tage.map(t => [t.date, t]));
  for (const d = new Date(r.von + "T12:00"); iso(d) <= r.bis; d.setDate(d.getDate() + 1)) alle.push(da[iso(d)] || {date:iso(d), produktiv:0, prokrastination:0, leer:true});
  alle.forEach(t => {
    const d = new Date(t.date + "T12:00"), c = el("div","rb-tag"), sp = el("div","rb-s"), a = el("i"), b = el("i");
    a.style.height = (t.leer ? 0 : Math.max(2, t.produktiv / mx * 100)) + "%"; a.style.background = "var(--good)";
    b.style.height = (t.leer ? 0 : Math.max(2, t.prokrastination / mx * 100)) + "%"; b.style.background = "var(--bad)";
    c.title = `${d.toLocaleDateString("de-DE",{weekday:"short", day:"numeric", month:"numeric"})}: produktiv ${minText(t.produktiv)}, Ablenkung ${minText(t.prokrastination)}`;
    sp.append(a, b); c.append(sp, el("span", null, r.art === "woche" ? ["So","Mo","Di","Mi","Do","Fr","Sa"][d.getDay()] : String(d.getDate()))); bar.append(c);
  });
  const liste = (titel, xs, leer) => { const w = el("div","rb-l"); w.append(el("h3", null, titel)); xs.length ? xs.forEach(x => w.append(x)) : w.append(el("p","empty", leer)); return w; };
  const zeile = (n, v) => { const z = el("div","rb-z"); z.append(el("span", null, n), el("b", null, v)); return z; };
  const spalten = el("div","rb-grid");
  spalten.append(
    liste("Zeit pro Projekt", r.projekte.map(x => zeile(x.name, minText(x.sek))), "Noch nichts erkannt."),
    liste("Habits", r.habits.filter(x => x.faellig).map(x => zeile(x.name, `${x.erledigt}/${x.faellig}`)), "Keine Habits."),
    liste("Größte Ablenkungen", r.ablenkung.map(x => zeile(x.name, minText(x.sek))), "Keine Ablenkung. Stark."),
    liste(`Erledigt (${r.erledigt.length})`, r.erledigt.slice(0, 12).map(t => el("div","rb-z rb-done", "✓ " + t)), "Noch nichts abgehakt."));
  box.replaceChildren(top, bar, spalten, rbKi(r), el("p","hint kon-hint", r.fertig || new Date().getDay() === 0 ? "Steht auch im Vault unter „Claude Memory/Rückblicke“." : "Am Sonntag bzw. Monatsende landet der Rückblick auch im Vault unter „Claude Memory/Rückblicke“."));
}
function rbKachel(){
  const box = $("dashKpis"); if (!box || S.mode !== "lokal" || !autoAn("rueckblick")) return;
  const t = new Date(NOW), morgen = new Date(NOW); morgen.setDate(t.getDate() + 1);
  const wd = t.getDay(), art = (morgen.getDate() === 1 || t.getDate() === 1) ? "monat" : (wd === 0 || wd === 1) ? "woche" : null;
  if (!art) return;
  const zurueck = art === "woche" ? wd === 1 : t.getDate() === 1, b = el("button","kpi kbtn");
  b.type = "button";
  b.append(el("span","k-l", art === "woche" ? "Wochenrückblick" : "Monatsrückblick"), el("b","k-v", "Ansehen"),
    el("span","k-s", zurueck ? (art === "woche" ? "Wie lief letzte Woche?" : "Wie lief der letzte Monat?") : (art === "woche" ? "Wie lief diese Woche?" : "Wie lief dieser Monat?")));
  b.addEventListener("click", () => {
    const d = new Date(NOW); if (zurueck) art === "woche" ? d.setDate(d.getDate() - 7) : d.setDate(0);
    RB.art = art; RB.bezug = iso(d); showTab("werte"); if (typeof wtZeigen === "function") wtZeigen("rueckblick"); rbLaden(); $("rbBox").scrollIntoView({behavior:"smooth"});
  });
  box.append(b);
}
$("rbZur")?.addEventListener("click", () => rbVerschieben(-1));
$("rbVor")?.addEventListener("click", () => rbVerschieben(1));
document.querySelectorAll("#rbArt button").forEach(b => b.addEventListener("click", () => { RB.art = b.dataset.art; RB.bezug = TODAY; rbLaden(); }));
document.querySelector('#reiter button[data-r="werte"]')?.addEventListener("click", () => { if (!RB.daten) rbLaden(); });

/* KI im Cockpit: Claude Code mit deinem eigenen Claude-Abo (keine API-Kosten) oder lokal Ollama */
const KIW = {antwort:"", fehler:"", laeuft:false};
function renderKi(){
  const box = $("kiSet"); if (!box) return;
  if (S.mode !== "lokal" || !S.plan?.ki){ box.replaceChildren(el("p","empty","Nur in BlockEm auf dem Mac.")); return; }
  const ki = S.plan.ki;
  $("kiSub").textContent = ki.anbieter === "claude" ? "Claude (dein Abo)" : ki.ollamaModell ? "Ollama lokal" : "keine KI gefunden";
  const zeile = (ok, titel, text) => { const r = el("div","ki-zeile"); r.append(el("span","ki-punkt " + (ok ? "ok" : "aus"), ok ? "●" : "○"), el("div", null)); r.lastChild.append(el("b", null, titel), el("span","k-s", text)); return r; };
  const teile = [
    zeile(ki.claude, "Claude (dein Abo)", ki.claude ? `Gefunden (${ki.claudePfad}). Läuft über dein Claude-Abo, keine Extra-Kosten.` : "Nicht gefunden. Die Claude-App allein reicht nicht, BlockEm braucht Claude Code (die Terminal-Version). Einrichten: siehe Chat."),
    zeile(!!ki.ollamaModell, "Ollama (lokal, kostenlos)", ki.ollamaModell ? `Läuft mit ${ki.ollamaModell}.` : ki.laeuft ? "Läuft, aber noch kein Modell geladen." : "Nicht gestartet (optional).")];
  const wahl = el("div","chips");
  [["auto","Automatisch"],["claude","Claude"],["ollama","Ollama"]].forEach(([k, n]) => { const b = el("button","chip small", n); b.type = "button";
    b.setAttribute("aria-pressed", String((ki.wahl || "auto") === k));
    b.addEventListener("click", async () => { try { S.plan = await api("api/ki", {anbieter:k}); renderPlan(); } catch (e){ KIW.fehler = e.message || String(e); renderKi(); } });
    wahl.append(b); });
  const test = el("button","ask small", KIW.laeuft ? "Fragt …" : "Testen"); test.type = "button"; test.disabled = KIW.laeuft;
  test.addEventListener("click", async () => { KIW.laeuft = true; KIW.antwort = KIW.fehler = ""; renderKi();
    try { const r = await api("api/ki", {test:true}); KIW.antwort = `${r.antwort} (${r.sekunden} s)`; delete r.antwort; delete r.sekunden; S.plan = r; }
    catch (e){ KIW.fehler = e.message || String(e); }
    KIW.laeuft = false; renderPlan(); renderKi(); });
  const unten = el("div","lk-unten"); unten.append(el("span","k-s","Welche KI nutzen?"), wahl, test);
  teile.push(unten);
  if (ki.claude && /log ?in/i.test(KIW.fehler)){
    const an = el("button","ask small","Bei Claude anmelden"); an.type = "button";
    an.addEventListener("click", async () => { try { await api("api/ki", {login:true}); KIW.fehler = ""; KIW.antwort = "Im Terminal hat sich Claude geöffnet: dort mit deinem Claude-Konto anmelden (Browser geht auf), danach /exit eingeben und hier auf „Testen“ tippen."; } catch (e){ KIW.fehler = e.message || String(e); } renderKi(); });
    teile.push(el("p","k-s","Claude Code hat eine eigene Anmeldung, getrennt von der Claude-App. Einmal anmelden reicht:"), an);
  }
  if (KIW.antwort) teile.push(el("p","ki-antwort", KIW.antwort));
  if (KIW.fehler) teile.push(el("p","k-s c-bad", KIW.fehler));
  teile.push(el("p","hint kon-hint","„Automatisch“ nimmt Claude, wenn es da ist, sonst Ollama. Die KI fasst schon jetzt Ideen in Stichpunkte zusammen (Häkchen „KI-Stichpunkte“ bei Ideen); weitere Aufgaben kommen Schritt für Schritt."));
  box.replaceChildren(...teile);
}

// Ehrliche Auswertung durch die gewählte KI, mit Vorschlägen zum Übernehmen
function rbKi(r){
  const w = el("div","rb-ki");
  if (S.mode !== "lokal" || !S.plan?.ki?.anbieter){
    const p = el("p","hint kon-hint"); p.append("Mit einer verbundenen KI bekommst du hier eine ehrliche Auswertung mit drei Regeln für nächste Woche. ",
      eiKnopf("KI verbinden", "zt-link", () => esOeffnen("ki"))); w.append(p); return w;
  }
  const kopf = el("div","rb-ki-kopf"); kopf.append(el("h3", null, `✦ Auswertung von ${fcName()}`));
  const los = eiKnopf(RB.kiLaeuft ? "Denkt nach …" : r.ki ? "Neu auswerten" : (r.art === "woche" ? "Woche auswerten" : "Monat auswerten"), r.ki ? "ghost small" : "ask small", async () => {
    RB.kiLaeuft = true; renderRueckblick();
    try { const x = await api("api/ki-rueckblick", {art:r.art, datum:r.von}); r.ki = {...x, zeit:"gerade eben"}; }
    catch (e){ toast(e.message || String(e)); }
    RB.kiLaeuft = false; renderRueckblick();
  });
  los.disabled = !!RB.kiLaeuft; kopf.append(los); w.append(kopf);
  if (r.ki){
    const t = fcAntwort(r.ki.antwort); t.classList.add("rb-ki-text"); w.append(t);
    if (r.ki.aktionen?.length) w.append(fcAktionen(r.ki));
    w.append(el("p","k-s", `Stand ${r.ki.zeit}. Steht auch im Cockpit-Chat.`));
  } else if (!RB.kiLaeuft) w.append(el("p","k-s", "Die KI liest die Zahlen oben und sagt dir, was gut lief, wo Zeit verloren ging und was du nächste Woche anders machen kannst."));
  return w;
}

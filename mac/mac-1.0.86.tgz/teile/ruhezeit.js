/* ---------- Ruhezeit „Konsum-Apps begrenzen“ (john 19.11.2026) ----------
   Eine Sperrzeit kann alle Konsum-Apps sperren (Social Media, Video, Streaming, Spiele aus den Listen von BlockEm und eigene
   Einordnungen). Alltags-Apps (Banking, Bahn, Karten …) und unbekannte neue Apps bleiben offen, WhatsApp auch. „Bleiben erlaubt“
   gilt nur für diese Regel. Welche Apps wirklich zu sind, rechnet der Server (locker_wirksame_apps); Lockern prüft er auch.
   Gespeichert: apps = selbst dazugenommen (z. B. WhatsApp), konsum = true, erlaubt = Konsum-Apps, die offen bleiben. */

// Konsum-Regeln nie mit alten App-Listen-Regeln zu einer Karte zusammenlegen
szSchluessel = (orig => function(r){ return orig(r) + (r.konsum ? "/konsum/" + [...(r.erlaubt || [])].map(x => x.toLowerCase()).sort().join("|") + "/" + [...(r.extra || [])].map(x => x.toLowerCase()).sort().join("|") : ""); })(szSchluessel);
szGruppen = (orig => function(regeln){
  return orig(regeln).map(g => { const r = g.regeln[0]; return r?.konsum ? {...g, konsum:true, erlaubt:r.erlaubt || [], extra:r.extra || []} : g; });
})(szGruppen);
szKarte = (orig => function(g){
  const k = orig(g); if (!g.konsum) return k;
  const n = (g.erlaubt || []).length, f = k.querySelector(".lm-fuss");
  if (f) f.textContent = `Konsum-Apps${n ? ` · ${n} erlaubt` : ""} · ${lmTage(g.tage)} · ${g.geraete.length ? g.geraete.join(" + ") : "alle Geräte"}`;
  return k;
})(szKarte);
szAuf = (orig => function(g){
  orig(g); const e = SZ.e; if (!e) return;
  e.konsum = g ? !!g.konsum : true;   // neue Ruhezeit: Konsum-Apps begrenzen ist die Vorgabe
  e.erlaubt = new Set(g?.erlaubt || []); e.alleKonsum = false;
  if (g?.konsum) e.apps = new Set(g.extra || []);
  e.appsZeigen = !g || !g.konsum ? e.appsZeigen : false;
  szZeichnen();
})(szAuf);

const rzHat = (set, n) => [...set].some(x => x.toLowerCase() === n.toLowerCase());
function rzSchalter(){
  const e = SZ.e, s = el("section","lm-abschnitt rz-schalter"), z = el("label","rz-zeile"), tx = el("div"), cb = el("input");
  cb.type = "checkbox"; cb.checked = e.konsum; cb.className = "rz-toggle"; cb.setAttribute("role","switch");
  cb.addEventListener("change", () => { e.konsum = cb.checked; szZeichnen(); });
  tx.append(el("b", null, "Konsum-Apps begrenzen"), el("small", null, "Social Media, Videos, Streaming und Spiele sind zu. Banking, Bahn, Karten, Wecker und andere Alltags-Apps bleiben offen, auch neue."));
  z.append(tx, cb); s.append(z);
  return s;
}
function rzErlaubt(){
  const e = SZ.e, d = LK.daten || {}, s = el("section","lm-abschnitt lm-apps rz-erlaubt");
  const kopf = el("div","lm-akopf"); kopf.append(cmKachel("", "sun"), el("b", null, `Diese Apps bleiben erlaubt (${e.erlaubt.size})`)); s.append(kopf);
  const alle = d.konsumApps || [], gesehen = new Set((d.apps || []).map(a => a.name.toLowerCase()));
  // zuerst, was auf den Geräten wirklich läuft; der Rest auf Wunsch
  const hier = alle.filter(n => gesehen.has(n.toLowerCase()) || rzHat(e.erlaubt, n)), liste = e.alleKonsum || hier.length < 4 ? alle : hier;
  const gitter = el("div","lm-appgitter");
  liste.forEach(n => { const an = rzHat(e.erlaubt, n), b = el("button", an ? "an" : "", null); b.type = "button"; b.dataset.n = n.toLowerCase();
    b.setAttribute("aria-pressed", String(an)); b.append(cmKachel(n), el("span", null, n));
    b.addEventListener("click", () => { if (an) [...e.erlaubt].forEach(x => { if (x.toLowerCase() === n.toLowerCase()) e.erlaubt.delete(x); }); else e.erlaubt.add(n); szZeichnen(); });
    gitter.append(b); });
  s.append(el("span","lm-klein","Tippe an, was du in dieser Zeit trotzdem nutzen willst. Gilt nur für diese Ruhezeit, Bindungen und der Porno-Schutz bleiben."), gitter);
  if (liste.length < alle.length){ const m = el("button","lm-link", `Alle ${alle.length} Konsum-Apps zeigen`); m.type = "button";
    m.addEventListener("click", () => { e.alleKonsum = true; szZeichnen(); }); s.append(m); }
  s.append(el("span","lm-klein rz-falsch","Steht eine App falsch unter Konsum? Unter Werte bei der App die Kategorie ändern. Lockern braucht dort dieselbe Wartezeit."));
  return s;
}
szApps = (orig => function(){
  const e = SZ.e, w = el("div","rz-apps"); w.append(rzSchalter());
  if (!e.konsum){ w.append(orig()); return w; }
  w.append(rzErlaubt());
  const zus = orig(); zus.classList.add("rz-zusatz");
  const b = zus.querySelector(".lm-akopf b"); if (b) b.textContent = `Zusätzlich sperren (${e.apps.size})`;
  zus.querySelector(".lm-schnell")?.remove();   // „Alle Social Media“ ist mit dem Schalter schon drin
  const hint = el("span","lm-klein","Zum Beispiel WhatsApp, das sonst offen bleibt."); zus.querySelector(".lm-akopf")?.after(hint);
  w.append(zus); return w;
})(szApps);

// Gespeichert wird wie bisher; bei Konsum dazu konsum/erlaubt, apps sind nur die dazugenommenen
szPlan = function(){
  const e = SZ.e, apps = [...e.apps], k = !!e.konsum, erl = k ? [...e.erlaubt].sort((a, b) => a.localeCompare(b)) : undefined;
  const basis = {art:"zeit", apps, von:e.von, bis:e.bis, tage:[...e.tage].sort(), geraete:[...e.geraete], gruppe:e.name || "", konsum:k, erlaubt:erl || []};
  if (e.neu) return [{regel:basis}];
  const sig = (apps, konsum, erlaubt, von, bis, tage, ger, gr) => JSON.stringify([lmSchluessel(apps), !!konsum, lmSchluessel(erlaubt || []), von, bis, [...tage].sort(), ger || [], gr || ""]);
  const ziel = sig(apps, k, erl, e.von, e.bis, basis.tage, basis.geraete, basis.gruppe);
  return e.alt.filter(a => sig(a.konsum ? a.extra || [] : a.apps, a.konsum, a.erlaubt, a.von, a.bis, a.tage, a.geraete, a.gruppe) !== ziel)
    .map(a => { const {gesperrt, pauseBis, verbraucht, geoeffnet, extra, ...rein} = a; return {regel:{...rein, ...basis, id:a.id}, alt:a}; });
};
// Hinweis „lockert“ im Dialog: wirksame Apps vergleichen (der Server prüft dasselbe noch einmal)
lmLockert = (orig => function(p){
  if (p.loeschen || !p.alt || !(p.regel?.konsum || p.alt.konsum)) return orig(p);
  const kl = LK.daten?.konsumApps || [];
  const eff = (r, neu) => !r.konsum ? r.apps : [...kl.filter(n => !(r.erlaubt || []).some(x => x.toLowerCase() === n.toLowerCase())), ...(neu ? r.apps : r.extra || [])];
  return orig({...p, regel:{...p.regel, apps:eff(p.regel, true)}, alt:{...p.alt, apps:eff(p.alt, false)}});
})(lmLockert);
// Ohne Konsum-Schalter braucht es mindestens eine App, mit Schalter nicht
szHinweis = (orig => function(){
  const e = SZ.e; if (!e?.konsum || e.apps.size) return orig();
  const echt = e.apps, schein = new Set(echt); Object.defineProperty(schein, "size", {get: () => 1});   // nur die Leer-Prüfung, Plan bleibt echt
  e.apps = schein; try { orig(); } finally { e.apps = echt; }
})(szHinweis);

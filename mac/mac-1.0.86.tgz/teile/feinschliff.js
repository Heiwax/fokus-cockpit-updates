/* ---------- Feinschliff Release 1.0 (05.11.2026, john: „das muss in die 1.0 richtig rein“) ----------
   1. Locker: eigener Bereich „Sperrzeiten“. Eine Sperrzeit = ein Zeitfenster, in das man Apps legt. Gruppen und einzelne Apps
      haben nur noch Limits (Pro Tag, Öffnen, Am Stück + Pause). Gespeichert wird weiter als Regel art "zeit" (Server unverändert).
   2. Schutz-Seite: Kopf mit Profil und Zahl, Reiter als Segment, Zeilen als Kacheln (CSS in feinschliff.css).
   Steht nach runde2.js, überschreibt lmGruppen/lmSperrzeit/lmKarte und trSchutzKarte. */

/* ===== 1. Sperrzeiten ===== */
const SZ = {e:null, fehler:"", speichert:false};
const SZ_VORLAGEN = [["Nachts","23:00","07:00"],["Abends","21:00","07:00"],["Morgens","06:00","09:00"],["Arbeitszeit","09:00","17:00"]];

// Gruppen und einzelne Apps ohne Sperrzeiten (die stehen jetzt im eigenen Bereich)
if (typeof lmGruppen === "function"){
  const _lmGruppenFs = lmGruppen;
  lmGruppen = function(regeln){ return _lmGruppenFs.call(this, (regeln || []).filter(r => r.art !== "zeit")); };
}
// Im Limit-Fenster keine Sperrzeit mehr, nur ein Hinweis
if (typeof lmSperrzeit === "function"){
  lmSperrzeit = function(){
    const s = el("section","lm-abschnitt fs-hinweis"), b = el("button","lm-link","Zu den Sperrzeiten"); b.type = "button";
    b.addEventListener("click", () => { lmZu(); CM.tab = "apps"; store("cm.lmTeil", "zeiten"); renderLocker(true); });
    s.append(el("span","lm-klein","Feste Uhrzeiten, in denen Apps ganz zu sind, stellst du im Locker unter „Sperrzeiten“ ein."), b);
    return s;
  };
}
if (typeof lmKarte === "function"){
  const _lmKarteFs = lmKarte;
  lmKarte = function(g){ const k = _lmKarteFs.call(this, g); [...k.querySelectorAll(".lm-wert")].find(f => f.firstChild?.textContent === "Sperrzeit")?.remove(); return k; };
}

function szSchluessel(r){ return [r.von, r.bis, [...(r.tage || [])].sort().join(""), [...(r.geraete || [])].sort().join("|")].join("/"); }
function szGruppen(regeln){
  const g = new Map();
  (regeln || []).filter(r => r.art === "zeit").forEach(r => { const k = szSchluessel(r);
    if (!g.has(k)) g.set(k, {von:r.von, bis:r.bis, tage:r.tage, geraete:r.geraete || [], apps:[], regeln:[], name:r.gruppe || ""});
    const e = g.get(k); r.apps.forEach(a => { if (!e.apps.some(x => x.toLowerCase() === a.toLowerCase())) e.apps.push(a); }); e.regeln.push(r); });
  return [...g.values()].sort((a, b) => a.von.localeCompare(b.von));
}
// 1.0.48 (john 08.11.): Sperrzeiten haben einen Namen (Regel-Feld „gruppe“), sonst nach der Uhrzeit
function szName(g){ if (g.name) return g.name; const v = SZ_VORLAGEN.find(([, a, b]) => a === g.von && b === g.bis); return v ? v[0] : "Sperrzeit"; }
function szKarte(g){
  const k = el("button","lm-karte fs-sz"), zu = g.regeln.some(r => r.gesperrt); k.type = "button";
  const kopf = el("div","lm-kopf"), text = el("div","lm-titel");
  text.append(el("b", null, szName(g)), el("small", zu ? "zu" : "", `${g.von} – ${g.bis} · ` + (zu ? "jetzt gesperrt" : "gerade frei")));
  kopf.append(cmKachel("", "clock"), text, el("span","lm-pfeil","›"));
  const reihe = el("div","fs-sz-apps");
  g.apps.slice(0, 7).forEach(a => reihe.append(cmKachel(a)));
  if (g.apps.length > 7) reihe.append(el("span","fs-sz-mehr", `+${g.apps.length - 7}`));
  const ger = g.geraete.length ? g.geraete.join(" + ") : "alle Geräte";
  k.append(kopf, reihe, el("span","lm-fuss", `${g.apps.length} ${g.apps.length === 1 ? "App" : "Apps"} · ${lmTage(g.tage)} · ${ger}`));
  k.addEventListener("click", () => szAuf(g));
  return k;
}
function szListe(d){
  const gr = szGruppen(d.regeln), ent = d.entfernen || {}, out = [];
  gr.forEach(g => { out.push(szKarte(g)); const weg = g.regeln.filter(r => ent[r.id]);
    if (weg.length) out.push(el("div","r10-weg", "Wird bald entfernt, gilt bis dahin weiter.")); });
  if (!gr.length) out.push(el("p","cm-leer","Noch keine Sperrzeit. Leg fest, wann Apps ganz zu sind, z. B. nachts von 23 bis 7 Uhr, und wähle die Apps dafür."));
  return out;
}

function szAuf(g){
  SZ.fehler = "";
  SZ.e = {neu:!g, alt:g ? g.regeln : [], von:g?.von || "23:00", bis:g?.bis || "07:00", apps:new Set(g ? g.apps : []), name:g ? g.name : "Nachts",
    tage:new Set(g ? g.tage : [0,1,2,3,4,5,6]), geraete:new Set(g?.geraete || []), appsZeigen:!g};
  szZeichnen();
}
function szDialog(){
  let d = $("szDialog"); if (!d){ d = el("dialog","cm-regel lm-dialog fs-szd"); d.id = "szDialog"; document.body.append(d);
    d.addEventListener("cancel", ev => { ev.preventDefault(); szZu(); }); }
  return d;
}
function szZu(){ SZ.e = null; const d = $("szDialog"); if (d?.open) d.close(); }
function szZeit(){
  const e = SZ.e, s = el("section","lm-abschnitt");
  const kopf = el("div","lm-akopf"); kopf.append(cmKachel("", "clock"), el("b", null, "Wann ist alles zu?")); s.append(kopf);
  const name = el("input","r4-name"); name.value = e.name; name.maxLength = 40; name.placeholder = szName({von:e.von, bis:e.bis}); name.setAttribute("aria-label","Name der Sperrzeit");
  name.addEventListener("input", () => { e.name = name.value.trim(); szHinweis(); });
  s.append(el("span","lm-klein","Name"), name);
  const z = el("div","fs-zeit"), von = el("input"), bis = el("input");
  von.type = bis.type = "time"; von.value = e.von; bis.value = e.bis; von.setAttribute("aria-label","gesperrt von"); bis.setAttribute("aria-label","gesperrt bis");
  // 1.0.48: Vorlagen-Name passt nach Hand-Änderung der Zeit nicht mehr → passende Vorlage oder leer (Platzhalter zeigt „Sperrzeit“)
  const zeitNeu = () => { if (SZ_VORLAGEN.some(([n]) => n === e.name)) e.name = SZ_VORLAGEN.find(([, v, b]) => v === e.von && b === e.bis)?.[0] || ""; szZeichnen(); };
  von.addEventListener("change", () => { e.von = von.value; zeitNeu(); }); bis.addEventListener("change", () => { e.bis = bis.value; zeitNeu(); });
  const f = (t, i) => { const b = el("label","fs-zeit-feld"); b.append(el("span", null, t), i); return b; };
  z.append(f("Von", von), el("span","fs-zeit-pfeil","→"), f("Bis", bis)); s.append(z);
  const schnell = el("div","lm-schnell");
  SZ_VORLAGEN.forEach(([t, v, b]) => { const k = el("button", e.von === v && e.bis === b ? "an" : "", t); k.type = "button"; k.title = `${v}–${b}`;
    k.addEventListener("click", () => { if (!e.name || SZ_VORLAGEN.some(([n]) => n === e.name)) e.name = t; e.von = v; e.bis = b; szZeichnen(); }); schnell.append(k); });
  s.append(schnell);
  const tage = el("div","lm-tage");
  LK_TAGE.forEach((t, i) => { const b = el("button", e.tage.has(i) ? "an" : "", t); b.type = "button";
    b.addEventListener("click", () => { e.tage.has(i) ? e.tage.delete(i) : e.tage.add(i); szZeichnen(); }); tage.append(b); });
  s.append(el("span","lm-klein","An diesen Tagen"), tage);
  return s;
}
function szApps(){
  const e = SZ.e, d = LK.daten || {}, s = el("section","lm-abschnitt lm-apps");
  const kopf = el("div","lm-akopf"); kopf.append(cmKachel("", "phone"), el("b", null, `Welche Apps? (${e.apps.size})`));
  const w = el("button","lm-link", e.appsZeigen ? "Fertig" : "Ändern"); w.type = "button"; w.addEventListener("click", () => { e.appsZeigen = !e.appsZeigen; szZeichnen(); });
  kopf.append(w); s.append(kopf);
  if (!e.appsZeigen){
    const reihe = el("div","fs-sz-apps"); [...e.apps].slice(0, 12).forEach(a => reihe.append(cmKachel(a)));
    if (e.apps.size > 12) reihe.append(el("span","fs-sz-mehr", `+${e.apps.size - 12}`));
    if (!e.apps.size) reihe.append(el("span","lm-klein","Noch keine App gewählt."));
    s.append(reihe); return s;
  }
  // Schnell: ganze Listen
  const kat = TR.daten?.kategorien || {}, schnell = el("div","lm-schnell");
  [["Alle Social Media","social"],["Alle Streaming","streaming"]].forEach(([t, k]) => { const l = kat[k] || []; if (!l.length) return;
    const alle = l.every(a => [...e.apps].some(x => x.toLowerCase() === a.toLowerCase()));
    const b = el("button", alle ? "an" : "", (alle ? "✓ " : "＋ ") + t); b.type = "button";
    b.addEventListener("click", () => { if (alle) l.forEach(a => [...e.apps].forEach(x => { if (x.toLowerCase() === a.toLowerCase()) e.apps.delete(x); })); else l.forEach(a => e.apps.add(a)); szZeichnen(); });
    schnell.append(b); });
  s.append(schnell);
  const namen = [], gesehen = new Set();
  const dazuName = n => { const k = n.toLowerCase().replace(/[^\p{L}\p{N}]/gu, ""); if (!k || gesehen.has(k)) return; gesehen.add(k); namen.push(n); };
  [...e.apps].forEach(dazuName); (d.apps || []).forEach(a => dazuName(a.name));
  const info = n => (d.apps || []).find(a => a.name === n);
  const sicht = namen.filter(n => e.apps.has(n) || !lkIstRauschen(n)).sort((a, b) => (e.apps.has(b) - e.apps.has(a)) || ((info(b)?.kat === "prokrastination") - (info(a)?.kat === "prokrastination")));
  const such = el("div","lm-such"), inp = el("input"), plus = el("button", null, "＋"); plus.type = "button"; plus.setAttribute("aria-label","Hinzufügen");
  inp.placeholder = "App oder Seite, z. B. reddit.com"; inp.setAttribute("aria-label","App oder Seite suchen oder eingeben");
  const gitter = el("div","lm-appgitter");
  sicht.forEach(n => { const b = el("button", e.apps.has(n) ? "an" : "", null); b.type = "button"; b.dataset.n = n.toLowerCase();
    b.append(cmKachel(n), el("span", null, n));
    b.addEventListener("click", () => { e.apps.has(n) ? e.apps.delete(n) : e.apps.add(n); szZeichnen(); }); gitter.append(b); });
  const dazu = () => { const n = inp.value.trim().replace(/^https?:\/\//i, "").replace(/^www\./i, "").replace(/\/.*$/, ""); if (!n) return;
    e.apps.add(namen.find(x => x.toLowerCase() === n.toLowerCase()) || n); szZeichnen(); };
  inp.addEventListener("input", () => { const q = inp.value.trim().toLowerCase(); gitter.querySelectorAll("button").forEach(b => b.hidden = !!q && !b.dataset.n.includes(q)); });
  inp.addEventListener("keydown", ev => { if (ev.key === "Enter"){ ev.preventDefault(); dazu(); } });
  plus.addEventListener("click", dazu); such.append(inp, plus);
  s.append(such, gitter);
  return s;
}
// Was wird gespeichert? Neue Sperrzeit = eine Regel; bestehende: jede Regel des Fensters bekommt die neuen Werte
function szPlan(){
  const e = SZ.e, apps = [...e.apps], basis = {art:"zeit", apps, von:e.von, bis:e.bis, tage:[...e.tage].sort(), geraete:[...e.geraete], gruppe:e.name || ""};
  if (e.neu) return [{regel:basis}];
  const gleich = a => JSON.stringify([lmSchluessel(a.apps), a.von, a.bis, [...a.tage].sort(), a.geraete || [], a.gruppe || ""]) === JSON.stringify([lmSchluessel(apps), e.von, e.bis, basis.tage, basis.geraete, basis.gruppe]);
  return e.alt.filter(a => !gleich(a)).map(a => { const {gesperrt, pauseBis, verbraucht, geoeffnet, ...rein} = a; return {regel:{...rein, ...basis, id:a.id}, alt:a}; });
}
function szHinweis(){
  const e = SZ.e, d = LK.daten || {}, darf = d.immerFrei || d.frei > 0, box = $("szHinweis"), ok = $("szOk"); if (!e || !box || !ok) return;
  const plan = szPlan(), lockert = plan.some(lmLockert), leer = !e.apps.size || !e.tage.size || !e.von || !e.bis || e.von === e.bis;
  box.replaceChildren();
  ok.disabled = SZ.speichert || leer || !plan.length || (lockert && !darf);
  ok.textContent = e.neu ? "Sperrzeit speichern" : plan.length ? "Änderungen speichern" : "Nichts geändert";
  if (leer) box.append(el("span","lm-klein", !e.apps.size ? "Wähle mindestens eine App." : !e.tage.size ? "Wähle mindestens einen Tag." : "Von und Bis brauchen zwei verschiedene Uhrzeiten."));
  else if (lockert && !darf){
    const t = el("button","ghost small", d.wartet > 0 ? "Beantragt" : `Lockern beantragen (${bdWarte(d.warteJetzt ?? d.warteMin)})`); t.type = "button"; t.disabled = d.wartet > 0;
    t.addEventListener("click", async () => { await lkAktion({warten:true}); szHinweis(); });
    box.append(el("span","lm-klein c-bad", bdLockernSatz(d, "die Sperrzeit")), t);
  } else if (plan.length) box.append(el("span","lm-klein " + (lockert ? "" : "c-good"), lockert ? "Lockern ist gerade frei." : "Wird strenger und gilt sofort."));
  if (SZ.fehler) box.append(el("span","lm-klein c-bad", SZ.fehler));
}
async function szSchicken(liste){
  SZ.speichert = true; SZ.fehler = ""; szHinweis();
  try {
    for (const body of liste){ const r = await api("api/locker", {...body, token:LK.token}); LK.token = r.token || ""; LK.daten = r; }
    SZ.speichert = false; szZu(); toast("Gespeichert."); renderLocker(true);
  } catch (err){ SZ.speichert = false; SZ.fehler = err.message || String(err); renderLocker(true); szZeichnen(); }
}
function szSpeichern(){ szSchicken(szPlan().sort((a, b) => lmLockert(a) - lmLockert(b)).map(p => ({regel:p.regel}))); }
function szZeichnen(){
  const e = SZ.e; if (!e) return;
  const d = szDialog(), y = d.querySelector(".lm-body")?.scrollTop || 0, darf = LK.daten?.immerFrei || LK.daten?.frei > 0;
  const kopf = el("div","lm-dkopf"), x = el("button","ghost small","✕"); x.type = "button"; x.setAttribute("aria-label","Schließen"); x.addEventListener("click", szZu);
  const titel = el("div","lm-titel"); titel.append(el("b", null, e.neu ? "Neue Sperrzeit" : `${e.name || szName(e)} · ${e.von} – ${e.bis}`), el("small", null, "In dieser Zeit sind die Apps ganz zu."));
  kopf.append(cmKachel("", "clock"), titel, x);
  const body = el("div","lm-body");
  body.append(szZeit(), szApps());
  if (!e.neu){ const del = el("button","lm-loeschen","Sperrzeit löschen"); del.type = "button";
    if (darf) lkZweimal(del, "Wirklich löschen?", () => szSchicken(e.alt.map(r => ({loeschen:r.id}))));
    else { del.disabled = true; del.title = "Erst den Timer zum Lockern abwarten"; }
    body.append(del); }
  const fuss = el("div","lm-dfuss"), hinweis = el("div","lm-hinweis"), ok = el("button","ask cm-violett lm-ok","Speichern");
  hinweis.id = "szHinweis"; ok.id = "szOk"; ok.type = "button"; ok.addEventListener("click", szSpeichern);
  fuss.append(hinweis, ok);
  d.replaceChildren(kopf, body, fuss);
  if (!d.open) d.showModal();
  body.scrollTop = y;
  szHinweis();
}
if (typeof renderLocker === "function"){
  const _rlSz = renderLocker;
  renderLocker = function(...a){ const r = _rlSz.apply(this, a); if (SZ.e && !LK.daten?.offen) szZu(); else if (SZ.e) szHinweis(); return r; };
}

/* ===== 2. Schutz-Seite modern: Kopf mit Profil + Zahl, Segment-Reiter, Kacheln ===== */
if (typeof trSchutzKarte === "function"){
  const _trSchutzFs = trSchutzKarte;
  trSchutzKarte = function(x){
    const k = _trSchutzFs.call(this, x); k.classList.add("fs-schutz");
    const leiste = k.querySelector(".r2-sch-tabs"), aktiv = k.querySelector(".r2-sch-aktiv"), einst = k.querySelector(".r2-sch-einst");
    if (!leiste || !aktiv) return k;
    const pr = TR.daten?.profil || {}, n = aktiv.querySelectorAll(".r2-sch-zeile").length;
    const hero = el("div","fs-hero"), schild = el("div","fs-schild");
    schild.innerHTML = '<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l7 3v5c0 4.5-3 8.3-7 10-4-1.7-7-5.5-7-10V6l7-3z"/><path d="M9 12l2 2 4-4"/></svg>';
    const tx = el("div"), wer = pr.geschlecht === "w" ? "Frau · " : pr.geschlecht === "m" ? "Mann · " : "";
    tx.append(el("b", null, `${n} Schutz-Ebenen aktiv`), el("span", null, wer + (pr.pornoSchutz === false ? "Profil Fokus" : "Porno-Schutz")));
    hero.append(schild, tx);
    leiste.classList.add("fs-segment");
    leiste.before(hero);
    // Profil-Zeile steht jetzt im Kopf; Knopf „Porno-Schutz einschalten“ / „Zu Fokus wechseln“ bleibt als Kachel
    const prof = einst?.querySelector(".r2-profil"); if (prof && !prof.querySelector("button")) prof.remove();
    // „Was blockiert wird“: Hinweis als kleine Zeile, Einträge als Kacheln
    aktiv.querySelector("p.k-s")?.classList.add("fs-leise");
    fsBildModus(k);
    return k;
  };
}

/* ===== 3. Laufendes Lockern oben überall sichtbar (john 05.11. 18:51) =====
   Wartet der Timer oder ist Lockern frei, zeigt eine kleine Leiste oben die Restzeit, egal auf welchem Reiter. */
const LB = {wartetBis:0, freiBis:0, uhr:0, abruf:0};
function lbUebernehmen(d){
  if (!d) return; const j = Date.now();
  LB.wartetBis = d.wartet > 0 ? j + d.wartet * 1000 : 0;
  LB.freiBis = d.frei > 0 ? j + d.frei * 1000 : 0;
  lbZeichnen();
}
function lbZeichnen(){
  let b = $("lbLeiste"); const j = Date.now(), w = 0, f = LB.freiBis - j;   // 19.11.: ein 12-Std.-Antrag steht auf der Sperren-Seite, die Leiste nur, solange Lockern frei ist
  if (LB.wartetBis && LB.wartetBis <= j && j - LB.wartetBis < 2000) lbAbruf();   // Antrag gerade abgelaufen: Stand holen
  if (f <= 0){ if (b) b.hidden = true; if (LB.uhr && !(LB.wartetBis > j)){ clearInterval(LB.uhr); LB.uhr = 0; } else if (!LB.uhr && LB.wartetBis > j) LB.uhr = setInterval(lbZeichnen, 1000); return; }
  if (!b){
    b = el("button","lb-leiste"); b.id = "lbLeiste"; b.type = "button";
    b.addEventListener("click", () => document.querySelector('.reiter button[data-r="locker"]')?.click());
    document.body.append(b);
  }
  b.hidden = false;
  const nav = document.querySelector(".reiter"), nr = nav?.getBoundingClientRect(), nt = nr && nr.height > 0 ? nr.top : innerHeight;
  b.style.bottom = Math.max(12, innerHeight - nt + 10) + "px";
  b.classList.toggle("lb-frei", w <= 0);
  b.textContent = `🔓 Lockern frei · noch ${lkUhr(f / 1000)}`;
  if (!LB.uhr) LB.uhr = setInterval(lbZeichnen, 1000);
}
async function lbAbruf(){
  if (Date.now() - LB.abruf < 5000) return; LB.abruf = Date.now();
  try { lbUebernehmen(await api("api/locker" + (LK.token ? "?token=" + LK.token : ""))); } catch {}
}
if (typeof renderLocker === "function"){
  const _rlLb = renderLocker;
  renderLocker = function(...a){ const r = _rlLb.apply(this, a); lbUebernehmen(LK.daten); return r; };
}
setTimeout(lbAbruf, 3000);
setInterval(lbAbruf, 60000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) lbAbruf(); });

/* ===== 4. Karte beim Ort hinzufügen groß, mit Vollbild (john 05.11. 18:51) =====
   Knopf ⤢ oben rechts in jeder geladenen Karte; Leaflet passt sich beim resize-Ereignis selbst an. */
function fsKarteKnoepfe(){
  document.querySelectorAll(".r10-karte.leaflet-container").forEach(box => {
    if (box.querySelector(":scope > .fs-karte-voll")) return;
    const voll = el("button","fs-karte-voll","⤢"); voll.type = "button"; voll.setAttribute("aria-label","Karte im Vollbild");
    voll.addEventListener("click", e => {
      e.stopPropagation(); e.preventDefault();
      const an = !box.classList.contains("fs-voll"); box.classList.toggle("fs-voll", an);
      voll.textContent = an ? "✕" : "⤢"; document.documentElement.classList.toggle("fs-karte-offen", an);
      setTimeout(() => { box._karte?.invalidateSize(); window.dispatchEvent(new Event("resize")); }, 60);
    });
    ["mousedown","touchstart","dblclick","pointerdown"].forEach(t => voll.addEventListener(t, e => e.stopPropagation()));
    box.append(voll);
  });
}
setInterval(fsKarteKnoepfe, 800);

/* ===== 5. Bild-KI: Modus wählen statt Schalter (john 05.11. 19:30: „zu viel Schrift“, „auswählen statt an/aus“) ===== */
function fsBildModus(k){
  const z = [...k.querySelectorAll(".tr-schutz-zeile")].find(r => /^Bild-KI: Sicher-Modus/.test(r.querySelector("b")?.textContent || ""));
  if (!z) return;
  const sicher = TR.daten?.schutz?.bildSicher !== false;
  const box = el("div","tr-schutz-zeile fs-modus"), kopf = el("div");
  kopf.append(el("b", null, "Bild-KI"), el("span","k-s","Wie genau soll sie schauen?"));
  const wahl = el("div","fs-modus-wahl");
  const kachel = (wert, titel, text, akku) => {
    const b = el("button","fs-modus-k" + (sicher === wert ? " an" : "")); b.type = "button";
    b.append(el("b", null, titel), el("span", null, text), el("small", null, akku));
    b.addEventListener("click", async () => {
      if (sicher === wert) return;
      wahl.querySelectorAll("button").forEach(x => x.disabled = true);
      try { const r = await api("api/schutz", {bildSicher: wert}); TR.daten.schutz = r.schutz; toast(wert ? "Sicher-Modus an." : "Sparsam an."); }
      catch (e){ toast(e.message || String(e)); }
      setTimeout(() => trLockerKarten(true), 250);
    });
    return b;
  };
  wahl.append(kachel(true, "Sicher", "Prüft schon beim Scrollen.", "ca. 6–10 % Akku"), kachel(false, "Sparsam", "Prüft, wenn du anhältst.", "ca. 3–5 % Akku"));
  box.append(kopf, wahl);
  z.replaceWith(box);
}

/* ===== 6. Schutz vor Deinstallieren ist Pflicht (john 05.11. 19:28): wer ihn noch nicht an hat, sieht oben eine feste Leiste ===== */
function fsSchutzPflicht(){
  const A = window.CockpitApp; if (!A?.rechte || typeof handyRechte !== "function") return;
  if (TR.daten?.entwickler) return;
  const r = handyRechte(); let b = $("fsPflicht");
  if (r.schutz){ b?.remove(); return; }
  if (!b){
    b = el("button","fs-pflicht"); b.id = "fsPflicht"; b.type = "button";
    b.append(el("b", null, "🔒 Schutz vor Deinstallieren einschalten"), el("span", null, "Pflicht, damit BlockEm in schwachen Momenten bleibt. Tippen."));
    b.addEventListener("click", () => A.einstellungen?.());
    document.body.append(b);
  }
}
setTimeout(fsSchutzPflicht, 2500); setInterval(fsSchutzPflicht, 15000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) setTimeout(fsSchutzPflicht, 800); });

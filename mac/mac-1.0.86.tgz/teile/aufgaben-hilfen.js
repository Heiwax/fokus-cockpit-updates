/* ---------- Fristen: „noch X Tage“ ---------- */
const MONATE = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"];
const dayDiff = d => Math.round((new Date(d + "T12:00") - new Date(TODAY + "T12:00")) / 864e5);
const leftText = d => { const n = dayDiff(d); return n < 0 ? `${-n} ${n === -1 ? "Tag" : "Tage"} drüber` : n === 0 ? "heute fällig" : `noch ${n} ${n === 1 ? "Tag" : "Tage"}`; };
// Aufwand kommt in Stunden; TAG_STD = Projektstunden pro Tag (fürs Tempo)
const TAG_STD = 3;
const stdText = h => h < 1 ? Math.round(h * 60) + " Min" : String(Math.round(h * 10) / 10).replace(".", ",") + " Std";
function fertigWenn(list, titel = "Fertig, wenn"){
  const box = el("div","fw"), ul = el("ul"); box.append(el("span","lbl", titel));
  list.forEach(t => ul.append(el("li", null, t))); box.append(ul); return box;
}
function fristTag(d){
  const n = dayDiff(d), t = el("span", "tag frist" + (n < 0 ? " warn" : n <= 2 ? " on" : ""), leftText(d));
  t.title = "bis " + new Date(d + "T12:00").toLocaleDateString("de-DE", {weekday:"short", day:"numeric", month:"long", year:"numeric"}); return t;
}
const weekEnd = () => { const d = new Date(NOW); d.setDate(d.getDate() + (7 - d.getDay()) % 7); return iso(d); };
const monthEnd = () => iso(new Date(NOW.getFullYear(), NOW.getMonth() + 1, 0));
const yearEnd = () => `${NOW.getFullYear()}-12-31`;
const fmtFrist = d => { const x = new Date(d + "T12:00"); return `${x.getDate()}.${x.getMonth() + 1}.${x.getFullYear()}`; };

const byDone = list => [...list].sort((a,b) => a.done - b.done);
function itemRow(it, o = {}){
  const li = el("li", "item" + (it.done ? " done" : ""));
  const cb = document.createElement("input"); cb.type = "checkbox"; cb.checked = !!it.done; cb.setAttribute("aria-label", it.text);
  cb.addEventListener("change", () => toggle(it, cb.checked));
  const tag = o.noTag ? null : it.projekt || it.tag;
  const tags = [tag && el("span","tag", tag), it.from && el("span","tag warn", "von " + it.from), it.aufwand && el("span","tag", stdText(it.aufwand)), echtTag(it),
    it.prio && !it.done && el("span", it.prio === "muss" ? "tag on" : "tag", it.prio[0].toUpperCase() + it.prio.slice(1)), it.frist && !it.done && fristTag(it.frist)].filter(Boolean);
  // Ziel mit Schritten bzw. Meilenstein mit Zielen: aufklappbar, Fortschritt am Text
  const t = it.ziel ? goalDetails(it.text, it.ziel, it.projekt, o.ctx || "i", tags)
    : it.meilenstein ? stoneDetails(it, tags, o.ctx || "i") : el("div","t", it.text);
  if (!it.ziel && !it.meilenstein) t.append(...tags);
  li.append(cb, t);
  if (S.mode === "lokal" && it.id && !o.noDel){
    if (o.ctx === "h" && it.projekt && !it.done){
      const x = el("button","x-del","×"); x.type = "button"; x.title = "Aus Heute nehmen (bleibt im Projekt)"; x.setAttribute("aria-label", `„${it.text}“ aus Heute nehmen`);
      x.addEventListener("click", ev => { ev.stopPropagation(); x.disabled = true; ausHeute(it); }); li.append(x);
    } else li.append(delBtn("×", {art:"zeile", id:it.id, text:it.text}, `„${it.text}“ löschen?`, "x-del"));
  }
  if (o.fokus && !it.done && S.mode === "lokal"){
    const b = el("button","focus-btn","Fokus"); b.type = "button"; b.title = "Fokus-Timer für dieses Ziel";
    b.addEventListener("click", () => fkPrefill(it));
    const im = it.projekt ? ` im Projekt ${it.projekt}` : "", btns = el("span","item-btns");
    btns.append(b, claudeLos("Claude", `Lass uns die Aufgabe „${it.text}“${im} jetzt zusammen machen.`, "focus-btn"));
    li.classList.add("act"); li.append(btns);
  }
  else if (o.plan){ li.classList.add("act"); li.append(planTag(it.text, o.plan)); }
  else if (o.project && !it.done && S.mode !== "claude"){
    li.classList.add("act"); li.append(todayBtn(it.text, o.project));
  }
  return li;
}
// Eingeplant für heute: Knopf zum Wieder-Rausnehmen (die Aufgabe bleibt im Projekt)
function planTag(text, pl){
  const h = pl === "heute" && S.mode === "lokal" && S.plan.heute.find(t => key(t.text) === key(text) && t.id && !t.done);
  if (!h) return el("span","tag on", pl);
  const b = el("button","today-btn on","Heute ×"); b.type = "button"; b.title = "Aus Heute nehmen (bleibt im Projekt)";
  b.addEventListener("click", () => { b.disabled = true; ausHeute(h); });
  return b;
}
async function ausHeute(it){
  try { S.plan = await api("api/loeschen", {art:"zeile", id:it.id, text:it.text}); renderPlan(); toast(`„${it.text}“ ist nicht mehr für heute geplant.`); }
  catch (e){ alert(e.message); }
}
function todayBtn(text, projekt){
  const b = el("button","today-btn","+ Heute"); b.type = "button"; b.title = "Für heute einplanen";
  b.addEventListener("click", () => { b.disabled = true; addItem("heute", text, projekt); });
  return b;
}
function projOptions(sel, projekte){
  const cur = sel.value;
  sel.replaceChildren(new Option("Ohne Projekt", ""), ...projekte.filter(x => x.aktiv).map(x => new Option(x.name, x.name)));
  sel.value = projekte.some(x => x.aktiv && x.name === cur) ? cur : "";
}


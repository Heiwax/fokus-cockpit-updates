/* ---------- Werte › Woche: „Wiederkehrende Zeiten“ (john 19.11.2026) ----------
   Erst die Beobachtung in Alltagssprache, dann ein freiwilliger Vorschlag. Eine Regel entsteht nur, wenn man selbst auf
   „Ruhezeit einrichten“ tippt und im Dialog speichert. Gerechnet wird lokal (api/muster), nichts wird gespeichert oder geteilt. */
const MU = {daten:null, laedt:false, zu:false};
function muSektion(){
  let s = $("muSek"); if (s) return s;
  const nach = document.querySelector('.tab[data-r="werte"] section[aria-labelledby="hWeek"]'); if (!nach) return null;
  s = el("section","hud mu-sek"); s.id = "muSek"; s.setAttribute("aria-labelledby","hMuster"); nach.after(s);
  const wt = WT_TEILE.find(t => t[0] === "woche"); if (wt && !wt[2].includes("hMuster")) wt[2].push("hMuster");
  s.classList.toggle("wt-aus", (store("cockpit.werteTeil") || "heute") !== "woche");   // sonst leere Karte auf „Heute“ bis zum ersten Wechsel
  return s;
}
function muZeichnen(){
  const s = muSektion(); if (!s) return;
  const h = el("h2", null, "Wiederkehrende Zeiten "); h.id = "hMuster"; h.append(el("span", null, "letzte 4 Wochen"));
  const d = MU.daten, inhalt = [];
  if (!d) inhalt.push(el("p","k-s", MU.laedt ? "Wird ausgewertet …" : "Noch nicht ausgewertet."));
  else if (d.status === "zuwenig") inhalt.push(el("p","k-s", `Noch zu wenig Tage für ein Muster (${d.tage} von ${d.brauche}). BlockEm schaut einfach weiter mit.`));
  else if (d.status === "keins") inhalt.push(el("p","k-s", "Kein festes Muster zu sehen. Gut so. Wenn sich eine Zeit wiederholt, steht sie hier."));
  else {
    const k = el("div","mu-karte"), kopf = el("div","mu-kopf");
    kopf.append(cmKachel("", "clock"), el("b","mu-zeit", `${d.art === "wochentag" ? WT_MEHRZAHL_JS[d.wochentag] + ", " : ""}${d.von} – ${d.bis}`));
    k.append(kopf, el("p","mu-satz", d.satz));
    if (d.zusatz) k.append(el("p","mu-zusatz", d.zusatz));
    if (d.schonAbgedeckt) k.append(el("p","k-s mu-schon", "Deine Ruhezeit deckt diese Zeit schon ab."));
    else if (!MU.zu){
      const b = el("button","mu-knopf", "Für diesen Zeitraum eine Ruhezeit einrichten"); b.type = "button";
      b.addEventListener("click", muRuhezeit);
      const nein = el("button","lm-link", "Nicht jetzt"); nein.type = "button";
      nein.addEventListener("click", () => { MU.zu = true; muZeichnen(); });
      k.append(b, nein, el("span","lm-klein mu-privat", "Nur ein Vorschlag: Es passiert nichts, bis du die Ruhezeit selbst speicherst. Die Auswertung bleibt auf diesem Gerät."));
    }
    inhalt.push(k);
  }
  s.replaceChildren(h, ...inhalt);
}
const WT_MEHRZAHL_JS = ["Montags","Dienstags","Mittwochs","Donnerstags","Freitags","Samstags","Sonntags"];
async function muRuhezeit(){
  const d = MU.daten; if (!d) return;
  if (!LK.daten && typeof lkLaden === "function") await lkLaden();
  szAuf(null);
  Object.assign(SZ.e, {von:d.von, bis:d.bis, tage:new Set(d.regelTage), name:""});
  szZeichnen();
}
async function muLaden(){
  if (MU.laedt) return; MU.laedt = true; muZeichnen();
  try { MU.daten = await api("api/muster"); } catch { MU.daten = null; }
  MU.laedt = false; muZeichnen();
}
wtZeigen = (orig => function(k){ muSektion(); orig(k); if (k === "woche" && !MU.daten) muLaden(); })(wtZeigen);
muSektion(); if (store("cockpit.werteTeil") === "woche") wtZeigen("woche");

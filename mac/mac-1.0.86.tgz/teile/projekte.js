// Projekte-Navigation: Liste → Projektseite → Phasenseite. Jede Ebene ist ein Eintrag im Browser-Verlauf,
// so geht auch die Zurück-Taste am Handy eine Ebene zurück.
const PV = {p:null, ph:null}, ZIEL_OFFEN = new Set();
const pvHash = () => "#projekte" + (PV.p ? "/" + encodeURIComponent(PV.p) + (PV.ph ? "/" + encodeURIComponent(PV.ph) : "") : "");
function pvFromHash(){
  const [r, p, ph] = location.hash.slice(1).split("/").map(s => { try { return decodeURIComponent(s); } catch { return s; } });
  PV.p = r === "projekte" && p || null; PV.ph = PV.p && ph || null;
}
function einblenden(e){ if (!e) return; e.classList.remove("enter"); void e.offsetWidth; e.classList.add("enter"); }
function pvGo(p, ph){
  PV.anim = true; PV.p = p || null; PV.ph = PV.p && ph || null;
  try { history.pushState({pv:1}, "", pvHash()); } catch {}
  renderPlan(); window.scrollTo(0, 0);
}
function pvBack(p){
  // kam man per Tippen hierher, ist die vorige Seite im Verlauf die übergeordnete Ebene
  if (history.state?.pv) { history.back(); return; }
  PV.anim = true; PV.p = p || null; PV.ph = null;
  try { history.replaceState(null, "", pvHash()); } catch {}
  renderPlan(); window.scrollTo(0, 0);
}
function backBtn(label, onClick){ const b = el("button","pv-back", "‹ " + label); b.type = "button"; b.addEventListener("click", onClick); return b; }
function barEl(p, full){ const b = el("div","pv-bar" + (full ? " full" : "")), i = el("i"); i.style.width = Math.max(0, Math.min(100, +p || 0)) + "%"; b.append(i); return b; }
function metaEl(parts, cls = "pv-meta"){ const m = el("p", cls); parts.filter(Boolean).forEach((t, i) => m.append(i ? " · " : "", t)); return m; }
function fristText(d){ const n = dayDiff(d), s = el("span", n <= 2 ? "c-warn" : null, leftText(d)); s.title = "bis " + fmtFrist(d); return s; }
const projPct = x => x.prozent ?? (x.total ? Math.round(x.done / x.total * 100) : 0);
const projCounts = (x, p) => ({heute:p.heute.filter(t => t.projekt === x.name && !t.done).length, woche:p.woche.filter(g => g.projekt === x.name && !g.done).length});
const nurListe = ph => ph.length === 1 && ph[0].name === "Aufgaben" && ph[0].ziele.every(g => g.einzel);
const phAufwand = f => f.aufwand && f.ziele.length ? (f.fertig || f.rest === f.aufwand ? stdText(f.aufwand) : `noch ${stdText(f.rest)} von ${stdText(f.aufwand)}`) : "";
const phMonat = (f, x) => S.plan.monat.some(i => i.projekt === x.name && key(i.text) === key(f.name) && !i.done) ? "diesen Monat" : "";
// Neues Projekt / Durchplanen: immer die 5 Ebenen der Vorlage, gemeinsam mit Claude, eine Ebene nach der anderen
const planSatz = name => `Lass uns das Projekt „${name}“ nach der Vorlage Projektplan durchplanen. Geh es gemeinsam mit mir durch, Schritt für Schritt: 1. Projektziel, 2. Phasen (Ziel der Phase, Fertig-Kriterium), 3. Umsetzung pro Phase (Aufgaben mit Aufwand, Priorität, Termin), 4. Woche und Heute. Stell mir zu jeder Ebene Fragen und trag sie erst ein, wenn ich Okay sage. Eintragen heißt: in meinen Obsidian-Vault (Dokumente/Obsidian Vault) in die Notiz „${name} – Aufgaben“ unter Projekte/ im Format der Vorlage Projektplan (Claude Memory/Vorlage Projektplan), dann zeigt mein BlockEm den Plan von selbst.`;
// Jedes Projekt hat eine feste Farbe (nach Namen; ist sie schon vergeben, die nächste freie) und ein Icon mit seinen Anfangsbuchstaben
const PFARBEN = ["#5ad1ec","#a78bfa","#fb923c","#f472b6","#60a5fa","#2dd4bf","#a3e635","#fcd34d"];
function projFarbe(name){
  const eigen = S.plan?.projekte?.find(y => y.name === name)?.farbe;
  if (eigen) return eigen;
  const alle = [...new Set((S.plan?.projekte || []).map(x => x.name).concat(name))].sort((a, b) => a.localeCompare(b, "de")), belegt = new Map();
  for (const n of alle){
    let h = 0; for (const c of n) h = (h * 31 + c.codePointAt(0)) >>> 0;
    let i = h % PFARBEN.length;
    for (let k = 0; k < PFARBEN.length && [...belegt.values()].includes(i); k++) i = (i + 1) % PFARBEN.length;
    belegt.set(n, i); if (n === name) break;
  }
  return PFARBEN[belegt.get(name)];
}
function projIcon(name, big, tag = "span"){
  const icon = S.plan?.projekte?.find(y => y.name === name)?.icon, w = name.split(/[\s\-–]+/).filter(Boolean);
  const i = el(tag, "picon" + (big ? " big" : "") + (icon ? " emoji" : ""), icon || ((w[0]?.[0] || "?") + (w[1]?.[0] || "")).toUpperCase());
  if (tag === "span") i.setAttribute("aria-hidden", "true"); return i;
}
// Aussehen ändern (Icon-Knopf auf der Projektseite): Emoji antippen oder eintippen, Farbe wählen, wird sofort gespeichert
const EMOJIS = ["🚀","💡","📱","💻","🧠","🤖","📈","💰","🎯","🎨","✍️","🎮","🙏","⭐","🔥","🏆","📚","🛠️","🌱","❤️","🎵","📊","🧩","⚡","🏋️","🌍"];
const FARBEN = ["#5ad1ec","#60a5fa","#818cf8","#a78bfa","#f472b6","#fb7185","#fb923c","#fcd34d","#a3e635","#4ade80","#2dd4bf","#94a3b8"];
const LOOK_OFFEN = new Set();
async function setLook(ziel, cur, aend){
  try { S.plan = await api("api/look", {...ziel, farbe:cur.farbe || "", icon:cur.icon || "", ...aend}); renderPlan(); }
  catch (e){ alert("Speichern hat nicht geklappt: " + e.message); }
}
// k: Schlüssel fürs Offen-Halten, ziel: {art, projekt, phase, name}, cur: {icon, farbe}, standard: Farbe ohne eigene Wahl
function lookPanel(k, ziel, cur, standard, ohneIcon = "Kein Icon"){
  const box = el("div","pv-look"), emo = el("div","row"), farb = el("div","row"), set = aend => setLook(ziel, cur, aend);
  const auto = (label, onClick, on) => { const b = el("button","ghost small", label); b.type = "button"; b.setAttribute("aria-pressed", on); b.addEventListener("click", onClick); return b; };
  EMOJIS.forEach(e => { const b = el("button","emo", e); b.type = "button"; b.setAttribute("aria-label", "Icon " + e); b.setAttribute("aria-pressed", cur.icon === e); b.addEventListener("click", () => set({icon:e})); emo.append(b); });
  emo.append(auto(ohneIcon, () => set({icon:""}), !cur.icon));
  const eig = addForm(`icon|${k}`, "Eigenes Emoji eintippen", t => set({icon:t}));
  FARBEN.forEach(c => { const b = el("button","sw-btn"); b.type = "button"; b.style.setProperty("--sw", c); b.setAttribute("aria-label", "Farbe " + c); b.setAttribute("aria-pressed", (cur.farbe || "").toLowerCase() === c); b.addEventListener("click", () => set({farbe:c})); farb.append(b); });
  const pick = el("input","farbwahl"); pick.type = "color"; pick.value = cur.farbe || standard; pick.title = "Eigene Farbe"; pick.setAttribute("aria-label", "Eigene Farbe");
  pick.addEventListener("change", () => set({farbe:pick.value}));
  farb.append(pick, auto("Automatisch", () => set({farbe:""}), !cur.farbe));
  const fertig = el("button","claude-btn", "Fertig"); fertig.type = "button"; fertig.style.alignSelf = "flex-start";
  fertig.addEventListener("click", () => { LOOK_OFFEN.delete(k); renderPlan(); });
  box.append(el("span","pv-sl","Icon"), emo, eig, el("span","pv-sl","Farbe"), farb, fertig);
  return box;
}
function lookBtn(k){
  const b = el("button","ghost small", "Icon & Farbe"); b.type = "button"; b.setAttribute("aria-expanded", LOOK_OFFEN.has(k));
  b.addEventListener("click", () => { LOOK_OFFEN.has(k) ? LOOK_OFFEN.delete(k) : LOOK_OFFEN.add(k); renderPlan(); });
  return b;
}
// Liste: eine ruhige Karte pro Projekt
function projCard(x, p){
  const {heute, woche} = projCounts(x, p), pc = projPct(x), fz = FK.data?.wocheProjekt?.[x.name];
  const b = el("button","pcard" + (heute || woche ? " focus" : "")); b.type = "button"; b.style.setProperty("--cyan", projFarbe(x.name));
  const top = el("div","pc-top"); top.append(projIcon(x.name), el("b", null, x.name), el("span","pc-pct", pc + "%"));
  const next = x.next || (x.total ? "Alles erledigt" : "Noch nicht geplant");
  b.append(top, barEl(pc, pc >= 100), el("p","pc-next", next),
    metaEl([x.phase && !(x.phasen?.length === 1 && x.phase === "Aufgaben") ? x.phase : "", heute ? `Heute ${heute}` : "", woche ? `Woche ${woche}` : "",
      fz >= 60 ? `Fokus ${minText(fz)}` : "", !x.aktiv ? x.status : "", x.endziel?.frist ? fristText(x.endziel.frist) : ""]));
  b.addEventListener("click", () => pvGo(x.name));
  return b;
}
// Projektseite: Kopf, eingeklapptes Projektziel, Phasen als Zeilen zum Antippen, Aktionen unten
// Ideen und Notizen: eigene Notiz „<Projekt> – Ideen und Notizen“ im Projektordner (Obsidian). Allgemein = ohne Phase.
const IDEE_SATZ = {
  sortieren: x => `Sortier die Ideen im Projekt ${x} (Notiz „${x} – Ideen und Notizen“, Bereich Allgemein) in die passenden Phasen und fass sie als kurze Stichpunkte zusammen.`,
  angehen: (x, t, ph) => `Lass uns die Idee „${t}“ im Projekt ${x}${ph ? `, Phase ${ph}` : ""} angehen.`
};
async function ideeApi(body){
  try {
    const r = await api("api/idee", body); S.plan = r; renderPlan();
    if (typeof r.ki === "string") toast(r.ki);
    else if (body.aktion === "add" && (body.sortieren || r.ki)) toast((r.ki ? "In Stichpunkte zusammengefasst. " : "") + (r.einsortiert ? `In die Phase „${r.einsortiert}“ einsortiert.` : body.sortieren ? "Unter Allgemein gespeichert." : ""));
    if (body.aktion === "aufgabe") toast("Ist jetzt eine Aufgabe in der Phase.");
  } catch (e){ alert(e.message || e); }
}
function obsidianLink(pfad){
  const a = el("a","pv-link","In Obsidian öffnen");
  a.href = `obsidian://open?vault=${encodeURIComponent(S.plan?.vaultName || "Obsidian Vault")}&file=${encodeURIComponent(pfad.replace(/\.md$/, ""))}`;
  return a;
}
function ideenBox(x, f){
  const ideen = x.ideen; if (!ideen) return null;
  const ph = f ? f.name : "", liste = f ? (ideen.phasen[f.name.toLowerCase()] || []) : ideen.allgemein, lokal = S.mode === "lokal";
  const box = el("aside","pv-card pv-ideen"), kopf = el("div","pc-top");
  kopf.append(el("b", null, f ? "Ideen für diese Phase" : "Ideen & Notizen"), el("span","pv-meta", liste.length ? String(liste.length) : ""));
  box.append(kopf);
  const ul = el("ul","ideen");
  liste.forEach(i => {
    const li = el("li","idee"), t = el("div","idee-t", i.text);
    if (i.unter.length){ const u = el("ul"); i.unter.forEach(s => u.append(el("li", null, s))); t.append(u); }
    li.append(t);
    if (lokal){
      const a = el("div","idee-acts");
      const auf = el("button","ghost small","Zu Aufgabe"); auf.type = "button"; auf.title = f ? "Als Aufgabe in diese Phase übernehmen" : "Als Aufgabe in die aktive Phase übernehmen";
      auf.addEventListener("click", () => { auf.disabled = true; ideeApi({projekt:x.name, phase:ph, aktion:"aufgabe", raw:i.raw}); });
      const weg = el("button","x-del","×"); weg.type = "button"; weg.title = "Idee löschen (landet in Gelöscht)"; weg.setAttribute("aria-label", `Idee „${i.text}“ löschen`);
      weg.addEventListener("click", () => { if (confirm(`Idee „${i.text}“ löschen?`)){ weg.disabled = true; ideeApi({projekt:x.name, phase:ph, aktion:"weg", raw:i.raw}); } });
      a.append(auf, claudeLos("Mit Claude", IDEE_SATZ.angehen(x.name, i.text, ph), "ghost small"), weg);
      li.append(a);
    }
    ul.append(li);
  });
  if (!liste.length) ul.append(el("li","empty", f ? "Noch keine Ideen für diese Phase." : "Noch keine Ideen. Schreib einfach drauflos, ohne Plan."));
  box.append(ul);
  if (!f){
    // Ideen, die schon in Phasen stecken: kurz zeigen, mit Sprung in die Phase
    const inPh = (x.phasen || []).map(p => [p, (ideen.phasen[p.name.toLowerCase()] || []).length]).filter(([, n]) => n);
    if (inPh.length){
      const r = el("div","idee-ph"); r.append(el("span","pv-sl","In Phasen"));
      inPh.forEach(([p, n]) => { const b = el("button","tag", `${p.name} · ${n}`); b.type = "button"; b.addEventListener("click", () => pvGo(x.name, p.name)); r.append(b); });
      box.append(r);
    }
  }
  if (lokal){
    const k = `idee|${x.name}|${ph}`, fm = el("form","idee-add"), ta = el("textarea"), ok = el("button","ask", "Speichern");
    ta.placeholder = f ? "Neue Idee für diese Phase" : "Neue Idee, einfach drauflos";
    ta.rows = 2; ta.dataset.k = k; ta.value = S.drafts[k] || ""; ta.setAttribute("aria-label", ta.placeholder);
    ta.addEventListener("input", () => S.drafts[k] = ta.value);
    ta.addEventListener("keydown", e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) fm.requestSubmit(); });
    ok.type = "submit";
    const ki = S.plan?.ki || {}, kiAn = () => !!ki.modell && store("cockpit.kiIdeen") !== "aus";
    fm.addEventListener("submit", e => { e.preventDefault(); if (DIKTAT?.k === k) DIKTAT.r.stop(); const t = ta.value.trim(); if (!t) return;
      const z = kiAn(); if (z){ ok.disabled = true; ok.textContent = "Fasse zusammen …"; }
      S.drafts[k] = ""; S.refocus = k;
      ideeApi({projekt:x.name, phase:ph, aktion:"add", text:t, sortieren:!f, zusammenfassen:z}); });
    const row = el("div","pv-btns"), mic = diktatBtn(ta, k); row.append(ok); if (mic) row.append(mic);
    if (ki.modell){
      const l = el("label","ki-schalter"), cb = el("input"); cb.type = "checkbox"; cb.checked = kiAn();
      cb.addEventListener("change", () => store("cockpit.kiIdeen", cb.checked ? "an" : "aus"));
      l.title = "Beim Speichern fasst die KI auf deinem Mac die Idee in Stichpunkte zusammen (kostenlos, nichts verlässt den Rechner)";
      l.append(cb, " KI-Stichpunkte"); row.append(l);
    }
    if (!f && liste.length) row.append(claudeLos("Mit Claude sortieren", IDEE_SATZ.sortieren(x.name)));
    fm.append(ta, row); box.append(fm);
    if (!f) box.append(el("p","pv-meta", ki.modell ? "Die KI fasst zusammen und sucht die passende Phase aus." : "Nennst du eine Phase (z. B. „Marketing“), landet die Idee direkt dort."));
    if (!f && !ki.modell) box.append(kiHinweis(ki));
  }
  if (x.ideenNotiz && S.mode === "lokal") box.append(obsidianLink(x.ideenNotiz));
  return box;
}
// Diktieren ins Ideen-Feld (Chrome auf dem Mac; Spracherkennung des Browsers, Deutsch). Läuft weiter, auch wenn die Seite neu zeichnet.
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let DIKTAT = null;   // {r, k, start, fest}
function diktatFeld(d){ return document.querySelector(`textarea[data-k="${CSS.escape(d.k)}"]`); }
function diktatKnopf(b, an){ b.textContent = an ? "■ Stopp" : "🎤 Diktieren"; b.classList.toggle("on", an); b.title = an ? "Diktieren beenden" : "Idee per Sprache eingeben"; }
function diktatBtn(ta, k){
  if (!SR || !window.isSecureContext) return null;
  const b = el("button","claude-btn mic"); b.type = "button"; diktatKnopf(b, DIKTAT?.k === k);
  b.addEventListener("click", () => {
    if (DIKTAT){ const war = DIKTAT.k; DIKTAT.r.stop(); if (war === k) return; }
    const feld = diktatFeld({k}) || ta, r = new SR();
    r.lang = "de-DE"; r.continuous = true; r.interimResults = true;
    const d = DIKTAT = {r, k, start: feld.value.trim() ? feld.value.replace(/\s*$/, " ") : "", fest: ""};
    r.onresult = e => {
      let zw = "";
      for (let i = e.resultIndex; i < e.results.length; i++){ const t = e.results[i][0].transcript; if (e.results[i].isFinal) d.fest += t; else zw += t; }
      const f = diktatFeld(d); if (!f) return;
      f.value = d.start + d.fest + zw; S.drafts[k] = f.value; f.scrollTop = f.scrollHeight;
    };
    r.onerror = e => toast(e.error === "not-allowed" || e.error === "service-not-allowed" ? "Chrome darf das Mikrofon nicht benutzen. Erlaub es oben links in der Adresszeile." : e.error === "no-speech" ? "Nichts gehört. Tipp nochmal auf Diktieren." : "Diktieren ging nicht: " + e.error);
    r.onend = () => { if (DIKTAT !== d) return; DIKTAT = null; document.querySelectorAll(".mic.on").forEach(x => diktatKnopf(x, false)); };
    try { r.start(); diktatKnopf(b, true); } catch (e){ DIKTAT = null; toast("Diktieren ging nicht: " + e.message); }
  });
  return b;
}
// Lokale KI (Ollama) noch nicht bereit: kurzer Hinweis bzw. Knopf zum Laden des Modells
function kiHinweis(ki){
  const p = el("p","pv-meta ki-hinweis");
  if (ki.laedt) p.append("KI-Modell wird geladen (ca. 3 GB). Das dauert ein paar Minuten, du kannst normal weitermachen.");
  else if (ki.laeuft){
    const b = el("button","ghost small","KI-Modell laden (ca. 3 GB)"); b.type = "button";
    b.addEventListener("click", async () => { b.disabled = true; try { S.plan = await api("api/ki-laden", {}); renderPlan(); } catch (e){ alert(e.message || e); } });
    p.append("Ollama läuft. Für KI-Stichpunkte noch einmal das Modell laden: ", b);
    if (ki.fehler) p.append(el("span","c-warn", " " + ki.fehler));
  } else p.append("KI-Stichpunkte: Claude Code (dein Abo) oder Ollama auf dem Mac installieren, siehe Einstellungen › Deine KI.");
  return p;
}
function mitIdeen(page, box){
  if (!box) return page;
  const w = el("div","pv-split"); w.style.cssText = page.style.cssText; w.append(page, box); return w;
}
function projPage(x, p, planned){
  const {heute, woche} = projCounts(x, p), pc = projPct(x), ph = x.phasen || [], akt = ph.find(f => f.aktiv);
  const page = el("div","pv"), head = el("div","pv-head"), t = el("div","pv-title");
  page.style.setProperty("--cyan", projFarbe(x.name));
  const ic = projIcon(x.name, true, S.mode === "lokal" ? "button" : "span");
  if (S.mode === "lokal"){ ic.type = "button"; ic.title = "Icon und Farbe ändern"; ic.setAttribute("aria-label", "Icon und Farbe ändern"); ic.setAttribute("aria-expanded", LOOK_OFFEN.has("p|" + x.name));
    ic.addEventListener("click", () => { const k = "p|" + x.name; LOOK_OFFEN.has(k) ? LOOK_OFFEN.delete(k) : LOOK_OFFEN.add(k); renderPlan(); }); }
  t.append(ic, el("h3", null, x.name), el("span","pc-pct", pc + "%"));
  head.append(backBtn("Projekte", () => pvBack(null)), t, barEl(pc, pc >= 100),
    metaEl([akt ? "Jetzt: " + akt.name : "", heute ? `Heute ${heute}` : "", woche ? `Woche ${woche}` : "", !x.aktiv ? x.status : "", x.endziel?.frist ? fristText(x.endziel.frist) : ""]));
  page.append(head);
  if (S.mode === "lokal" && LOOK_OFFEN.has("p|" + x.name)) page.append(lookPanel("p|" + x.name, {art:"projekt", projekt:x.name}, x, projFarbe(x.name), "Buchstaben"));
  if (nurListe(ph)){
    // Notiz noch ohne Phasen: einfache Liste
    const card = el("div","pv-card"), ul = el("ul","list");
    byDone(ph[0].ziele.map(g => ({...g, done:g.fertig}))).forEach(g => ul.append(goalRow(g, x, planned)));
    if (!ph[0].ziele.length) ul.append(el("li","empty","Noch keine Ziele."));
    card.append(ul);
    if (S.mode !== "claude") card.append(addForm(`z|${x.name}|`, "Neues Ziel", t => addItem("ziel", t, x.name), satzNeu(x.name)));
    page.append(el("h4","pv-sec","Aufgaben"), card);
  } else if (ph.length){
    const z = el("details","pv-ziel"); z.open = ZIEL_OFFEN.has(x.name);
    z.addEventListener("toggle", () => z.open ? ZIEL_OFFEN.add(x.name) : ZIEL_OFFEN.delete(x.name));
    const sm = el("summary"); sm.append(el("span","pv-sl","Projektziel"), el("span","pv-sv", x.endziel?.text || "Noch kein Endziel"));
    z.append(sm, endzielBox(x)); page.append(z);
    const list = el("div","pv-list"); ph.forEach(f => list.append(phaseRow(f, x)));
    page.append(el("h4","pv-sec","Phasen"), list);
  } else page.append(el("p","empty", S.mode === "lokal" ? "Noch nicht geplant. Geh mit Claude die Ebenen durch: Ziel, Phasen, Aufgaben." : x.next ? "Als Nächstes: " + x.next : "Phasen und Aufgaben siehst du in BlockEm auf dem Mac."));
  if (S.mode !== "claude"){
    const acts = el("div","pv-acts"), btns = el("div","pv-btns");
    if (ph.length && !nurListe(ph)) acts.append(addForm(`m|${x.name}`, "Neue Phase", t => addItem("meilenstein", t, x.name)));
    if (S.mode === "lokal"){ const w = el("button","claude-btn", "Durchplanen (Assistent)"); w.type = "button"; w.addEventListener("click", () => wizOpen(x.name)); btns.append(w); }
    btns.append(copyBtn(ph.length ? "Mit Claude weiterplanen" : "Mit Claude durchplanen", planSatz(x.name)));
    acts.append(btns); page.append(acts);
  }
  return page;
}
function phaseRow(f, x){
  const b = el("button","phrow" + (f.aktiv ? " cur" : "") + (f.fertig ? " fin" : "") + (f.farbe ? " farbig" : "")); b.type = "button";
  if (f.farbe) b.style.setProperty("--cyan", f.farbe);
  const mid = el("div","ph-mid"), fertig = f.ziele.filter(g => g.fertig).length, nm = el("b");
  if (f.icon) nm.append(el("span","ph-emo", f.icon)); nm.append(f.name);
  mid.append(nm,
    metaEl([f.aktiv ? el("span","c-cyan","Jetzt") : "", f.frist && !f.fertig ? fristText(f.frist) : "", phAufwand(f), phMonat(f, x),
      f.ziele.length ? `${fertig} von ${f.ziele.length} Aufgaben` : "Noch keine Aufgaben"], "ph-meta"),
    barEl(f.prozent, f.fertig));
  b.append(el("span","ph-ico", f.fertig ? "✓" : ""), mid, el("span","ph-pct", f.prozent + "%"), el("span","chev"));
  b.addEventListener("click", () => pvGo(x.name, f.name));
  return b;
}
// Abschnitt einer Phase: aufklappbar mit eigenem Fortschritt, der aktuelle (erste offene) ist offen
const ABS_OFFEN = new Map();
function abschnittBox(a, f, x, planned, cur){
  const zs = f.ziele.filter(g => g.abschnitt === a.name), k = `${x.name}|${f.name}|${a.name}`, det = el("details","pv-abs" + (a.fertig ? " fin" : cur ? " cur" : "") + (a.farbe ? " farbig" : ""));
  if (a.farbe) det.style.setProperty("--cyan", a.farbe);
  det.open = ABS_OFFEN.has(k) ? ABS_OFFEN.get(k) : cur || !zs.length;
  det.addEventListener("toggle", () => ABS_OFFEN.set(k, det.open));
  const fertig = zs.filter(g => g.fertig).length;
  const sm = el("summary"), top = el("div","pc-top"); const an = el("b"); if (a.icon) an.append(el("span","ph-emo", a.icon)); an.append(a.name);
  top.append(an, el("span","pc-pct", a.prozent + "%"));
  sm.append(top, barEl(a.prozent, a.fertig), metaEl([zs.length ? `${fertig} von ${zs.length} Aufgaben` : "Noch keine Aufgaben",
    zs.length && a.aufwand ? (a.fertig || a.rest === a.aufwand ? stdText(a.aufwand) : `noch ${stdText(a.rest)} von ${stdText(a.aufwand)}`) : "",
    a.frist && !a.fertig ? fristText(a.frist) : ""]));
  const body = el("div","pv-abs-b"), ul = el("ul","list"), ak = `a|${x.name}|${f.name}|${a.name}`;
  if (S.mode === "lokal" && LOOK_OFFEN.has(ak)){ det.open = true; body.append(lookPanel(ak, {art:"abschnitt", projekt:x.name, phase:f.name, name:a.name}, a, f.farbe || projFarbe(x.name))); }
  zs.forEach(g => ul.append(goalRow(g, x, planned)));
  if (!zs.length) ul.append(el("li","empty","Noch keine Aufgaben in diesem Abschnitt."));
  body.append(ul);
  if (S.mode !== "claude") body.append(addForm(`z|${x.name}|${f.name}|${a.name}`, "Neue Aufgabe", t => addItem("ziel", t, x.name, {phase:f.name, abschnitt:a.name}), satzNeu(x.name, f.name)));
  if (S.mode === "lokal"){
    const acts = el("div","gacts pv-btns");
    acts.append(renameBtn(a.name, x.name, acts, "abschnitt", f.name), lookBtn(ak),
      delBtn("Abschnitt löschen", {art:"abschnitt", projekt:x.name, phase:f.name, name:a.name}, `Abschnitt „${a.name}“ mit allen Aufgaben löschen?`));
    body.append(acts);
  }
  det.append(sm, body); return det;
}
// Phasenseite: Ziel der Phase, Aufgabenliste, Aufgabe hinzufügen, Umbenennen/Löschen
function phasePage(f, x, planned){
  const page = el("div","pv"), head = el("div","pv-head"), t = el("div","pv-title");
  page.style.setProperty("--cyan", f.farbe || projFarbe(x.name));
  const pk = `ph|${x.name}|${f.name}`, h3 = el("h3"); if (f.icon) h3.append(el("span","ph-emo", f.icon)); h3.append(f.name);
  t.append(h3, el("span","pc-pct", f.prozent + "%"));
  head.append(backBtn(x.name, () => pvBack(x.name)), t, barEl(f.prozent, f.fertig),
    metaEl([f.fertig ? "Abgeschlossen" : f.aktiv ? el("span","c-cyan","Aktive Phase") : "", f.frist && !f.fertig ? fristText(f.frist) : "", phAufwand(f), phMonat(f, x)]));
  page.append(head);
  if (S.mode === "lokal" && LOOK_OFFEN.has(pk)) page.append(lookPanel(pk, {art:"phase", projekt:x.name, phase:f.name}, f, projFarbe(x.name)));
  if (f.ergebnis || f.fertigWenn?.length){
    const info = el("div","pv-card pv-info");
    if (f.ergebnis){ const r = el("div","pv-kv"); r.append(el("span","pv-sl","Ziel der Phase"), el("p", null, f.ergebnis)); info.append(r); }
    if (f.fertigWenn?.length) info.append(fertigWenn(f.fertigWenn));
    page.append(info);
  }
  const abs = f.abschnitte || [], ohne = abs.length ? f.ziele.filter(g => !g.abschnitt) : f.ziele;
  if (!abs.length || ohne.length){
    const card = el("div","pv-card"), ul = el("ul","list");
    ohne.forEach(g => ul.append(goalRow(g, x, planned)));
    if (!f.ziele.length) ul.append(el("li","empty","Noch keine Aufgaben in dieser Phase."));
    card.append(ul);
    if (S.mode !== "claude" && !abs.length) card.append(addForm(`z|${x.name}|${f.name}`, "Neue Aufgabe", t => addItem("ziel", t, x.name, {phase:f.name}), satzNeu(x.name, f.name)));
    page.append(el("h4","pv-sec", abs.length ? "Ohne Abschnitt" : "Aufgaben"), card);
  }
  if (abs.length){
    const cur = abs.find(a => !a.fertig) || abs[abs.length - 1];
    page.append(el("h4","pv-sec","Abschnitte"), ...abs.map(a => abschnittBox(a, f, x, planned, a === cur)));
  }
  if (S.mode === "lokal"){
    const box = el("div","pv-acts");
    box.append(addForm(`a|${x.name}|${f.name}`, "Neuer Abschnitt", t => addItem("abschnitt", t, x.name, {phase:f.name})));
    if (!abs.length && f.ziele.length) box.append(el("p","pv-meta","Unterteil die Phase in Abschnitte. Der erste Abschnitt nimmt alle bisherigen Aufgaben auf."));
    page.append(box);
  }
  if (S.mode !== "claude"){
    const acts = el("div","gacts pv-btns");
    if (!f.ziele.length) acts.append(stoneBtn(f.name, x.name, true));
    acts.append(renameBtn(f.name, x.name, acts, "meilenstein"));
    if (S.mode === "lokal") acts.append(lookBtn(pk));
    if (S.mode === "lokal") acts.append(delBtn("Phase löschen", {art:"meilenstein", projekt:x.name, name:f.name}, `Phase „${f.name}“ mit allen Aufgaben löschen?`));
    page.append(acts);
  }
  return page;
}
function renderPlan(){
  const p = S.plan; if (!p) return;
  const focused = document.activeElement?.dataset?.k || S.refocus; S.refocus = null;
  // Heute-Reiter: Heute + diese Woche
  const tl = $("tasks"); tl.replaceChildren();
  byDone(p.heute).forEach(t => tl.append(itemRow(t, {fokus:true, ctx:"h"})));
  if (!p.heute.length) tl.append(el("li","empty","Für heute ist noch kein Ziel geplant. Tipp auf „Heute planen“."));
  const done = p.heute.filter(t => t.done).length;
  $("mTasks").textContent = `${done}/${p.heute.length}`; renderDash(); renderHabits(p); $("taskCount").textContent = p.heute.length ? `${done} von ${p.heute.length} erreicht · ${stdKurz(kontoHeute(p).std)} von ${stdKurz(zeitTag(TODAY).std)}` : zeitTag(TODAY).std ? "" : "heute frei";
  // Wochenziele nach Projekt gruppiert, jede Gruppe aufklappbar
  const wl = $("weekGoals"), grp = new Map(); wl.replaceChildren();
  p.woche.forEach(g => { const k = g.projekt || ""; if (!grp.has(k)) grp.set(k, []); grp.get(k).push(g); });
  [...grp.entries()].sort((a, b) => (a[1].every(g => g.done) - b[1].every(g => g.done)) || (!a[0]) - (!b[0]) || a[0].localeCompare(b[0], "de")).forEach(([pr, gs]) => {
    const fertig = gs.filter(g => g.done).length, name = pr || "Ohne Projekt", kopf = el("div","wg-kopf"), t = el("div","wg-t");
    t.append(el("b", null, name), barEl(fertig / gs.length * 100));
    kopf.append(pr ? projIcon(pr) : el("span","picon", "–"), t, el("span","wg-n", `${fertig}/${gs.length}`));
    const k = klapp("w." + name, [kopf], [el("ul","list", null)], "wg");
    k.querySelector("ul").append(...byDone(gs).map(g => itemRow(g, {ctx:"w2", noTag:!!pr})));
    if (pr) k.style.setProperty("--cyan", projFarbe(pr));
    if (fertig === gs.length) k.classList.add("fertig");
    wl.append(el("li","wg-li")); wl.lastChild.append(k);
  });
  if (!p.woche.length) wl.append(el("li","empty","Noch keine Wochenziele. Tipp auf „Woche planen“."));
  $("wkLeft").textContent = `KW ${p.wocheKw || p.kw || isoWeek(NOW)} · ${leftText(weekEnd())}`;
  projOptions($("taskProj"), p.projekte);
  renderZiele(p);
  // wo ist welches Ziel eingeplant? heute oder ein Tag im alten Wochenplan
  const planned = new Map();
  (p.tage || []).forEach(d => d.items.forEach(t => planned.set(key(t.text), d.label.split(" ")[0])));
  p.heute.forEach(t => planned.set(key(t.text), "heute"));
  renderWeekPlan(p); fkFill();
  document.querySelectorAll(".plan-btn").forEach(b => b.hidden = S.mode === "claude");
  // Projekte: die mit Plan für heute, diese Woche oder diesen Monat zuerst
  const weight = x => p.heute.filter(t => t.projekt === x.name && !t.done).length * 9 + p.woche.filter(g => g.projekt === x.name && !g.done).length * 3
    + p.monat.filter(g => g.projekt === x.name && !g.done).length;
  const act = p.projekte.filter(x => x.aktiv).sort((a,b) => weight(b) - weight(a)), rest = p.projekte.filter(x => !x.aktiv);
  const pb = $("projects"), cur = PV.p && p.projekte.find(x => x.name === PV.p), curPh = cur && PV.ph && (cur.phasen || []).find(f => f.name === PV.ph);
  $("hProj").hidden = !!cur;
  if (cur){
    pb.replaceChildren(mitIdeen(curPh ? phasePage(curPh, cur, planned) : projPage(cur, p, planned), ideenBox(cur, curPh)));
    $("projOthers").hidden = true;
  } else {
    pb.replaceChildren(...act.map(x => projCard(x, p)));
    if (S.mode === "lokal") pb.append(addForm("np", "Neues Projekt (Name)", t => addItem("neuesprojekt", t), t => planSatz(t)));
    if (!p.projekte.length) pb.append(el("p","empty", S.mode === "lokal" ? "Keine Projekte gefunden. BlockEm liest Notizen namens „<Projekt> – Aufgaben“ im Projekte-Ordner deines Vaults." : "Noch keine Projekte."));
    $("projOthers").hidden = !rest.length; $("projOthersLbl").textContent = `Ideen und pausierte Projekte (${rest.length})`;
    $("projects2").replaceChildren(...rest.map(x => projCard(x, p)));
  }
  $("projCount").textContent = act.length ? `${act.length} aktiv` : "";
  pb.classList.toggle("grid", !cur); $("projects2").classList.add("grid");
  if (PV.anim){ PV.anim = false; einblenden(pb); }
  if (focused) document.querySelector(`[data-k="${CSS.escape(focused)}"]`)?.focus();
  renderCopilot();
}

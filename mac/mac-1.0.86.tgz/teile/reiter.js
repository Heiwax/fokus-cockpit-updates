/* ---------- Reiter ---------- */
const REITER = ["heute", "ziele", "habits", "projekte", "fokus", "locker", "werte", "automatik", "einstellungen"];   // „automatik“ nur noch für alte Links: führt zu Einstellungen › Automatik
function showTab(r){
  if (!REITER.includes(r)) r = "heute";
  document.querySelectorAll(".tab").forEach(t => { const neu = t.hidden && t.dataset.r === r; t.hidden = t.dataset.r !== r; if (neu) einblenden(t); });
  document.querySelectorAll("#reiter button").forEach(b => b.setAttribute("aria-selected", b.dataset.r === r));
  store("cockpit.reiter", r);
  const hash = r === "projekte" ? pvHash() : "#" + r;
  try { if (location.hash !== hash) history.replaceState(history.state, "", hash); } catch {}
}

function renderWeekPlan(p){
  const tage = (p.tage || []).filter(d => d.items.length), box = $("weekDays");
  $("weekPlan").hidden = !tage.length;
  const n = tage.reduce((a, d) => a + d.items.filter(t => !t.done).length, 0);
  $("weekPlanLbl").textContent = `Rest der Woche (${n} geplant)`;
  box.replaceChildren(...tage.map(d => {
    const w = el("div","day"), ul = el("ul","list");
    d.items.forEach(t => ul.append(itemRow(t, {ctx:"w"})));
    w.append(el("span","lbl", d.label), ul); return w;
  }));
}


/* ---------- Planungs-Assistent: Projektziel → Phasen → Umsetzung pro Phase (Woche und Heute plant John übergeordnet).
   Speichern schreibt die ganze Aufgaben-Notiz neu (alte Fassung geht in „Gelöscht.md“). ---------- */
const W = {};
const WIZ_SCHRITTE = [
  ["Projektziel", "Was willst du konkret erschaffen? Woran erkennst du, dass es erfolgreich ist? Was gehört dazu, was nicht? Welche Zeit und Grenzen hast du?"],
  ["Phasen", "Welche großen Abschnitte sind nötig, in welcher Reihenfolge? Welches Ergebnis liefert jede Phase, und woran erkennst du, dass sie abgeschlossen ist? Markiere die aktuelle Phase."],
  ["Umsetzung", "Welche Aufgaben braucht diese Phase, in welcher Reihenfolge? Wie viel Aufwand, welche Priorität, bis wann? Die Reihenfolge der Liste ist die Arbeitsreihenfolge."],
];
const wizTask = g => g.einzel
  ? {abschnitt:g.abschnitt || "", text:g.schritte[0].text, std:g.schritte[0].aufwand || "", prio:g.schritte[0].prio || "", frist:g.schritte[0].frist || "", done:!!g.schritte[0].done}
  : {abschnitt:g.abschnitt || "", text:g.name, std:g.aufwand || "", prio:g.prio || "", frist:g.frist || "", done:!!g.fertig,
     sub:g.schritte.map(t => ({text:t.text, min:t.aufwand ? Math.round(t.aufwand * 60) : "", done:!!t.done}))};
function wizOpen(name){
  const x = S.plan.projekte.find(y => y.name === name); if (!x) return;
  // „Durchplanen“ ist die Checkliste der Planungsschritte, die pflegt der Server selbst
  const phs = (x.phasen || []).filter(f => f.name !== "Durchplanen" && !(f.name === "Aufgaben" && !f.marke && (x.phasen || []).length === 1 && !f.ziele.length));
  const inf = x.endziel?.infos || {};
  Object.assign(W, {projekt:name, step:0, alt:null, sel:0, d:{
    endziel:x.endziel?.text || "", frist:x.endziel?.frist || "", fertigWenn:(x.endziel?.fertigWenn || []).join("\n"),
    drin:inf["Drin"] || "", nichtDrin:inf["Nicht drin"] || "", rahmen:inf["Rahmen"] || "",
    phasen:phs.map(f => ({name:f.name.replace(/^\d+[.)]\s*/, ""), ziel:f.ergebnis || "", fertigWenn:(f.fertigWenn || []).join(" "), frist:f.frist || "", abschnitte:(f.abschnitte || []).map(a => ({name:a.name, icon:a.icon || "", farbe:a.farbe || ""})), icon:f.icon || "", farbe:f.farbe || "", aufgaben:f.ziele.map(wizTask)})),
    aktiv:Math.max(0, phs.findIndex(f => f.aktiv)), monat:[], woche:[], heute:[]}});
  W.sel = W.d.aktiv;
  let dlg = $("wiz");
  if (!dlg){ dlg = el("dialog","planer wiz modern"); dlg.id = "wiz"; document.body.append(dlg); }
  wizRender(); dlg.showModal();
}
function wizField(label, val, onIn, type = "text", ph = ""){
  const l = el("label","wf"), i = el(type === "area" ? "textarea" : "input");
  if (type !== "area") i.type = type; i.value = val ?? ""; i.placeholder = ph; i.addEventListener("input", () => onIn(i.value));
  l.append(el("span", null, label), i); return l;
}
function wizRow(...kids){ const r = el("div","wrow"); r.append(...kids); return r; }
function wizInp(val, onIn, ph, cls = "", type = "text"){ const i = el("input", cls); i.type = type; i.value = val ?? ""; i.placeholder = ph; i.setAttribute("aria-label", ph); i.addEventListener("input", () => onIn(i.value)); return i; }
function wizBtn(label, title, onClick, cls = "x-del"){ const b = el("button", cls, label); b.type = "button"; b.title = title; b.addEventListener("click", () => { onClick(); wizRender(); }); return b; }
function wizAdd(label, onClick){ return wizBtn(label, label, onClick, "ghost small"); }
const wizSum = list => list.reduce((s, a) => s + (parseFloat(String(a.std).replace(",", ".")) || 0), 0);
function wizPhaseSel(){
  const sel = el("select"); sel.setAttribute("aria-label","Phase");
  W.d.phasen.forEach((f, i) => { const o = el("option", null, `${i + 1}. ${f.name || "(ohne Namen)"}${i === W.d.aktiv ? " (aktuell)" : ""}`); o.value = i; sel.append(o); });
  sel.value = W.sel; sel.addEventListener("change", () => { W.sel = +sel.value; wizRender(); });
  return wizRow(el("span","lbl","Phase"), sel);
}
function wizRender(){
  const dlg = $("wiz"), d = W.d, [titel, frage] = WIZ_SCHRITTE[W.step], last = WIZ_SCHRITTE.length - 1;
  const wrap = el("div","plwrap"), head = el("div","ph"), body = el("div","pb"), foot = el("div","pf");
  const close = el("button","ghost", "Schließen"); close.type = "button"; close.addEventListener("click", () => dlg.close());
  head.append(el("h2", null, `${W.projekt} · ${W.step + 1}/${last + 1} ${titel}`), close);
  const nav = el("div","wsteps"); WIZ_SCHRITTE.forEach(([t], i) => { const b = el("button", "chip", `${i + 1}. ${t}`); b.type = "button"; b.setAttribute("aria-pressed", i === W.step); b.addEventListener("click", () => { W.step = i; wizRender(); }); nav.append(b); });
  body.append(nav, el("p","step", frage));
  if (W.step === 0){
    body.append(wizField("Was willst du erschaffen?", d.endziel, v => d.endziel = v, "text", "z. B. Fertige App, die ich installieren kann"),
      wizField("Woran erkennst du den Erfolg? (ein Punkt pro Zeile)", d.fertigWenn, v => d.fertigWenn = v, "area", "z. B. Läuft auf Mac und beiden Handys"),
      wizField("Was gehört dazu?", d.drin, v => d.drin = v, "text", "z. B. Tracking, Projektplanung, Handy-App"),
      wizField("Was gehört nicht dazu?", d.nichtDrin, v => d.nichtDrin = v, "text", "z. B. Teamfunktionen, Bezahlsystem"),
      wizField("Zeit und Grenzen", d.rahmen, v => d.rahmen = v, "text", "z. B. 2 bis 5 Std pro Tag, kein Budget"),
      wizField("Bis wann?", d.frist, v => d.frist = v, "date"));
  } else if (W.step === 1){
    d.phasen.forEach((f, i) => {
      const r = el("input"); r.type = "radio"; r.name = "wizAktiv"; r.checked = d.aktiv === i; r.title = "Aktuelle Phase"; r.addEventListener("change", () => { d.aktiv = i; W.sel = i; });
      const box = el("div","wms");
      box.append(wizRow(r, el("b","wnum", `${i + 1}.`), wizInp(f.name, v => f.name = v, "Name der Phase", "wgrow"), wizInp(f.frist, v => f.frist = v, "Frist", "", "date"),
          i > 0 ? wizBtn("↑", "Nach oben", () => { d.phasen.splice(i - 1, 0, d.phasen.splice(i, 1)[0]); if (d.aktiv === i) d.aktiv--; else if (d.aktiv === i - 1) d.aktiv++; W.sel = d.aktiv; }) : el("span"),
          wizBtn("×", "Phase entfernen", () => { d.phasen.splice(i, 1); d.aktiv = Math.min(d.aktiv, Math.max(0, d.phasen.length - 1)); W.sel = d.aktiv; })),
        wizRow(wizInp(f.ziel, v => f.ziel = v, "Ziel der Phase: welches Ergebnis liefert sie?", "wgrow")),
        wizRow(wizInp(f.fertigWenn, v => f.fertigWenn = v, "Fertig, wenn …", "wgrow")));
      body.append(box);
    });
    if (!d.phasen.length) body.append(el("p","empty","Noch keine Phasen. Typisch für eine App: Konzept, Prototyp, Entwicklung, Test und Veröffentlichung."));
    body.append(wizAdd("+ Phase", () => d.phasen.push({name:"", ziel:"", fertigWenn:"", frist:"", aufgaben:[]})));
  } else if (!d.phasen.length){
    body.append(el("p","empty","Leg zuerst in Schritt 2 die Phasen an."));
  } else if (W.step === 2){
    W.sel = Math.min(W.sel, d.phasen.length - 1);
    const f = d.phasen[W.sel]; body.append(wizPhaseSel());
    if (f.ziel) body.append(el("small","vision", "Ziel der Phase: " + f.ziel));
    if (f.fertigWenn) body.append(el("small","vision", "Fertig, wenn: " + f.fertigWenn));
    f.aufgaben.forEach((a, i) => {
      if (f.abschnitte?.length && (i === 0 || a.abschnitt !== f.aufgaben[i - 1].abschnitt)) body.append(el("b","wabs", a.abschnitt || "Ohne Abschnitt"));
      const c = el("input"); c.type = "checkbox"; c.checked = a.done; c.title = "Erledigt"; c.addEventListener("change", () => a.done = c.checked);
      const pr = el("select"); pr.setAttribute("aria-label","Priorität"); [["","Priorität"],["muss","Muss"],["soll","Soll"],["kann","Kann"]].forEach(([v, t]) => { const o = el("option", null, t); o.value = v; pr.append(o); });
      pr.value = a.prio || ""; pr.addEventListener("change", () => a.prio = pr.value);
      body.append(wizRow(c, el("b","wnum", `${i + 1}.`), wizInp(a.text, v => a.text = v, "Aufgabe", "wgrow"), wizInp(a.std, v => { a.std = v; sum.textContent = wizSumText(f); }, "Std", "wnum-in", "number"), el("span","ts","Std"), pr,
        wizInp(a.frist, v => a.frist = v, "Termin", "", "date"),
        i > 0 ? wizBtn("↑", "Nach oben", () => f.aufgaben.splice(i - 1, 0, f.aufgaben.splice(i, 1)[0])) : el("span"),
        wizBtn("×", "Aufgabe entfernen", () => f.aufgaben.splice(i, 1))));
      if (a.sub?.length) body.append(el("small","ts", `  ${a.sub.length} Unterschritte bleiben erhalten`));
    });
    if (!f.aufgaben.length) body.append(el("p","empty","Noch keine Aufgaben in dieser Phase."));
    const sum = el("p","step", wizSumText(f));
    body.append(wizAdd("+ Aufgabe", () => f.aufgaben.push({abschnitt:f.aufgaben.at(-1)?.abschnitt || (f.abschnitte || []).at(-1)?.name || "", text:"", std:"", prio:"", frist:"", done:false})), sum);
  }
  const old = el("details","wold"); old.append(el("summary", null, "Ideen aus dem alten Plan"));
  const pre = el("pre", null, W.alt ?? "Wird geladen …"); old.append(pre);
  old.addEventListener("toggle", async () => { if (old.open && W.alt === null){ try { W.alt = (await api(`api/alterplan?projekt=${encodeURIComponent(W.projekt)}`)).text || "Kein alter Plan vorhanden."; } catch (e){ W.alt = "Konnte den alten Plan nicht laden."; } pre.textContent = W.alt; } });
  body.append(old);
  const back = el("button","ghost","Zurück"); back.type = "button"; back.disabled = W.step === 0; back.addEventListener("click", () => { W.step--; wizRender(); });
  const save = el("button", W.step === last ? "" : "ghost", "Speichern"); save.type = "button"; save.addEventListener("click", wizSave);
  foot.append(back, save);
  if (W.step < last){ const nx = el("button", null, "Weiter"); nx.type = "button"; nx.addEventListener("click", () => { W.step++; wizRender(); }); foot.append(nx); }
  wrap.append(head, body, foot); dlg.replaceChildren(wrap);
}
const wizSumText = f => { const h = wizSum(f.aufgaben); return h ? `Geschätzter Aufwand der Phase: ${String(Math.round(h * 10) / 10).replace(".", ",")} Std` : ""; };
async function wizSave(){
  const d = W.d;
  const payload = {projekt:W.projekt, endziel:d.endziel, frist:d.frist, fertigWenn:d.fertigWenn.split("\n").map(t => t.trim()).filter(Boolean),
    drin:d.drin, nichtDrin:d.nichtDrin, rahmen:d.rahmen, aktiv:d.aktiv, phasen:d.phasen, monat:d.monat, woche:d.woche, heute:d.heute};
  try { S.plan = await api("api/projektplan", payload); $("wiz").close(); S.openProj.add(W.projekt); renderPlan(); }
  catch (e){ alert("Speichern hat nicht geklappt: " + e.message); }
}

/* ---------- „Frag die KI“: die KI deiner Wahl (Einstellungen › Deine KI) direkt im Cockpit fragen; sieht Plan, Projekte, Phasen, Termine ---------- */
// Vorschläge kommen als Knöpfe („Für heute“, „Aufgabe anlegen“, „Habit“, „Fokus starten“) und werden erst mit einem Tipp übernommen.
const FC = {verlauf:[], laeuft:false};
const FC_SCHNELL = ["Was mache ich jetzt am besten?", "Optimier meine Ziele für diese Woche", "Was ist in diesem Projekt als Nächstes dran?", "Passt mein Plan für heute in meine Stunden?"];
function fcOrt(){
  const r = document.querySelector("#reiter [aria-selected=true]")?.dataset.r || "heute";
  return r === "projekte" ? decodeURIComponent(location.hash.replace(/^#/, "")) || "projekte" : r;
}
function fcKnopf(){
  // Knopf in der Kopfzeile, nur wenn eine KI eingerichtet ist
  let b = $("fcBtn");
  if (!b){ b = el("button","ask fc-btn","✦ Frag Claude"); b.id = "fcBtn"; b.type = "button"; b.addEventListener("click", fcOeffnen);
    document.querySelector("header.top .meta")?.prepend(b); }
  const ki = S.plan?.ki; b.hidden = S.mode !== "lokal" || !ki?.modell;
  if (ki) b.textContent = fcName() === "Claude" ? "✦ Frag Claude" : "✦ Frag die KI";
}
function fcName(){ const n = S.plan?.ki?.name || ""; return /^Claude/.test(n) ? "Claude" : n || "die KI"; }
function fcOeffnen(){
  let d = $("fcDialog");
  if (!d){
    d = el("dialog","planer fc-dialog modern"); d.id = "fcDialog"; d.setAttribute("aria-labelledby","fcTitel");
    const kopf = el("div","fc-kopf"), zu = el("button","ghost small","Schließen"); zu.type = "button"; zu.addEventListener("click", () => d.close());
    kopf.append(el("h2", null, "Frag Claude"), zu); kopf.firstChild.id = "fcTitel";
    const liste = el("div","fc-liste"); liste.id = "fcListe";
    const f = el("form","fc-form"), ta = el("textarea"), los = el("button","ask","Fragen");
    ta.id = "fcEingabe"; ta.rows = 2; ta.placeholder = "Frag zu deinen Zielen, Projekten oder was jetzt dran ist …"; ta.setAttribute("aria-label","Frage an Claude"); los.type = "submit"; los.id = "fcLos";
    ta.addEventListener("keydown", ev => { if (ev.key === "Enter" && !ev.shiftKey){ ev.preventDefault(); f.requestSubmit(); } });
    f.append(ta, los);
    f.addEventListener("submit", ev => { ev.preventDefault(); fcFragen(ta.value); });
    const schnell = el("div","chips fc-schnell"); schnell.id = "fcSchnell";
    FC_SCHNELL.forEach(q => { const c = el("button","chip small", q); c.type = "button"; c.addEventListener("click", () => fcFragen(q)); schnell.append(c); });
    const fuss = el("p","k-s fc-fuss"); fuss.id = "fcFuss";
    d.append(kopf, liste, schnell, f, fuss);
    document.body.append(d);
  }
  $("fcTitel").textContent = fcName() === "Claude" ? "Frag Claude" : `Frag ${fcName() === "die KI" ? "die KI" : fcName()}`;
  $("fcFuss").textContent = `${S.plan?.ki?.modell || "Die KI"} sieht deinen Plan, Projekte, Phasen und Termine. Vorschläge übernimmst du mit einem Tipp. Gespräche landen in deinen Notizen unter „${S.plan?.profil?.datenOrdner || "BlockEm"}/Cockpit-Chat“.`;
  fcZeichnen(); d.showModal(); $("fcEingabe").focus();
}
function fcZeichnen(){
  const l = $("fcListe"); if (!l) return;
  const teile = FC.verlauf.flatMap(x => [el("div","fc-msg ich", x.frage), x.antwort != null ? fcAntwort(x.antwort) : el("div","fc-msg ki laedt", `${fcName() === "die KI" ? "Die KI denkt" : fcName() + " denkt"} nach …`), ...(x.aktionen?.length ? [fcAktionen(x)] : []), ...(x.fehler ? [el("div","fc-msg fehler", x.fehler)] : [])]);
  if (!teile.length) teile.push(el("p","k-s","Frag einfach drauf los, z. B. was du jetzt machen kannst."));
  l.replaceChildren(...teile); l.scrollTop = l.scrollHeight;
  $("fcLos").disabled = FC.laeuft; $("fcSchnell").hidden = FC.verlauf.length > 0;
}
// einfache Formatierung: **fett**, Spiegelstriche, Absätze (sicher, ohne innerHTML)
function fcAntwort(text){
  const box = el("div","fc-msg ki");
  String(text).split(/\n{2,}/).forEach(abs => {
    const zeilen = abs.split("\n"), liste = zeilen.every(z => /^\s*([-*•]|\d+[.)])\s+/.test(z));
    if (liste){ const ul = el("ul"); zeilen.forEach(z => { const li = el("li"); fcFett(li, z.replace(/^\s*([-*•]|\d+[.)])\s+/, "")); ul.append(li); }); box.append(ul); }
    else { const p = el("p"); zeilen.forEach((z, i) => { if (i) p.append(el("br")); fcFett(p, z.replace(/^#+\s*/, "")); }); box.append(p); }
  });
  return box;
}
function fcFett(ziel, text){ text.split(/(\*\*[^*]+\*\*|\*[^*\s][^*]*\*)/).forEach(t => ziel.append(/^\*\*.+\*\*$/.test(t) ? el("b", null, t.slice(2, -2)) : /^\*[^*].*\*$/.test(t) ? el("em", null, t.slice(1, -1)) : document.createTextNode(t))); }
async function fcFragen(frage){
  frage = (frage || "").trim(); if (!frage || FC.laeuft) return;
  const vorher = FC.verlauf.filter(x => x.antwort).slice(-4).map(x => ({frage:x.frage, antwort:x.antwort}));
  const eintrag = {frage, antwort:null}; FC.verlauf.push(eintrag); FC.laeuft = true; $("fcEingabe").value = ""; fcZeichnen();
  try { const r = await api("api/frage", {frage, verlauf:vorher, ort:fcOrt()}); eintrag.antwort = r.antwort || "(keine Antwort)"; eintrag.aktionen = r.aktionen || []; }
  catch (e){ eintrag.antwort = ""; eintrag.fehler = e.message || String(e); }
  FC.laeuft = false; fcZeichnen(); $("fcEingabe")?.focus();
}
// Vorschläge der KI als Knöpfe: erst ein Tipp übernimmt sie
function fcAktionen(x){
  const box = el("div","fc-akt");
  x.aktionen.forEach(a => {
    const txt = {heute:`＋ Für heute: ${a.text}`, aufgabe:`＋ In ${a.projekt}${a.phase ? " › " + a.phase : ""}: ${a.text}${a.std ? ` (${stdText(a.std)})` : ""}`,
      habit:`＋ Habit: ${a.text}`, fokus:`▶ Fokus ${a.minuten} Min: ${a.text}`}[a.typ];
    const b = el("button","chip small fc-a" + (a.erledigt ? " ok" : ""), a.erledigt ? "✓ " + txt.slice(2) : txt); b.type = "button"; b.disabled = !!a.erledigt;
    b.addEventListener("click", async () => { b.disabled = true;
      try { S.plan = await api("api/ki-aktion", a); a.erledigt = true; b.classList.add("ok"); b.textContent = "✓ " + txt.slice(2); renderPlan(); if (a.typ === "fokus") fkLoad(); if ($("fcDialog")?.open) fcZeichnen(); }
      catch (e){ b.disabled = false; toast(e.message || String(e)); } });
    box.append(b);
  });
  return box;
}

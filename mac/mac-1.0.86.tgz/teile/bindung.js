/* ---------- 19.11.2026 (john): Bindungen „bis Freitag 18 Uhr kein Instagram“ + 12 Std. Wartezeit zum Lockern ----------
   Server: locker-Regel art "bis" mit ende (Sek.), Satz kommt fertig vom Server (bindung_satz), am Handy derselbe Satz beim Sperren.
   Früher beenden = Lockern: 12 Std. nach dem Antrag (endet sie vorher ohnehin, bleibt es beim gewählten Ende). */
const BD_TAGE = ["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"];
// gleiche Regel wie zeit_text (server.py) und SperrDienst.zeitText: heute / morgen / Wochentag (bis 6 Tage) / 28.11.
function bdZeit(ms){
  const d = new Date(ms), j = new Date(), tag0 = x => new Date(x.getFullYear(), x.getMonth(), x.getDate());
  const tage = Math.round((tag0(d) - tag0(j)) / 864e5), p = n => String(n).padStart(2, "0");
  const tag = tage === 0 ? "heute" : tage === 1 ? "morgen" : tage > 1 && tage <= 6 ? BD_TAGE[d.getDay()] : `${p(d.getDate())}.${p(d.getMonth() + 1)}.`;
  return `${tag}, ${p(d.getHours())}:${p(d.getMinutes())} Uhr`;
}
const bdUhr = t => String(t || "").replace(", ", " ");
const bdWarte = m => m >= 60 ? `${Math.round(m / 60)} Std.` : `${m} Min`;
function bdAppsText(a){ a = [...a]; return a.length <= 1 ? a.join("") : a.length <= 3 ? a.slice(0, -1).join(", ") + " und " + a.at(-1) : `${a[0]}, ${a[1]} und ${a.length - 2} weitere`; }
function bdLockernSatz(d, was){
  if (d?.wartet > 0 && d.freiAbText) return `Du kannst diese Regel ${String(d.freiAbText).replace(", ", " ab ")} lockern.`;
  return `Das lockert ${was || "eine Regel"}. Lockern geht ${bdWarte(d?.warteJetzt ?? d?.warteMin ?? 720)} nach dem Antrag, strenger sofort.`;
}

/* ----- Liste oben auf der Sperren-Seite ----- */
function bdListe(d){
  const box = el("section","bd-box"), kopf = el("div","bd-kopf");
  const neu = el("button","bd-neu","＋ Neu"); neu.type = "button"; neu.addEventListener("click", () => bdAuf());
  kopf.append(el("b","s17-st","Bindungen"), neu); box.append(kopf);
  const ent = d.entfernen || {}, liste = (d.regeln || []).filter(r => r.art === "bis" && r.gesperrt).sort((a, b) => a.ende - b.ende);
  if (!liste.length) box.append(el("p","bd-leer","Keine. Zum Beispiel: bis Freitag, 18:00 Uhr kein Instagram."));
  liste.forEach(r => {
    const z = el("div","bd-zeile"), tx = el("div","bd-text"), weg = ent[r.id];
    tx.append(el("b", null, r.satz), el("small", null, d.an === false ? "Gerade ohne Wirkung: Die Sperren sind ausgeschaltet." : weg ? `Endet vorzeitig ${bdUhr(bdZeit(weg * 1000))}.` : "Verbindlich. Früher beenden erst 12 Std. nach dem Antrag."));
    const k = el("button","bd-link", weg ? "Doch nicht" : "Früher beenden"); k.type = "button";
    if (weg) k.addEventListener("click", () => lkAktion({loeschenAbbrechen:r.id}));
    else lkZweimal(k, "Antrag stellen?", () => lkAktion({loeschen:r.id}));
    z.append(cmKachel(r.apps[0]), tx, k); box.append(z);
  });
  if (d.wartet > 0 || d.frei > 0){   // ausstehende Lockerung: dieselbe Zeile, egal ob sie für eine Bindung oder ein Limit ist
    const z = el("div","bd-zeile bd-antrag"), tx = el("div","bd-text");
    tx.append(el("b", null, d.wartet > 0 ? "Lockern beantragt" : "Lockern ist frei"),
      el("small", null, d.wartet > 0 ? bdLockernSatz(d) : `Bis ${bdUhr(d.freiBisText)} kannst du Regeln lockern.`));
    const ab = el("button","bd-link", d.wartet > 0 ? "Abbrechen" : "Fertig"); ab.type = "button";
    ab.addEventListener("click", () => lkAktion(d.wartet > 0 ? {abbrechen:true} : {schliessen:true}));
    z.append(el("span","bd-sym","⏳"), tx, ab); box.append(z);
  }
  return box;
}
if (typeof lkOffen === "function"){
  const _bdLkOffen = lkOffen;
  lkOffen = function(d){
    const out = _bdLkOffen.call(this, d);
    if (!d?.offen && !d?.fokus) return out;   // im Fokus nur lesen (locker.js setzt inert)
    const seg = out.findIndex(x => x.classList?.contains("s17-seg"));
    out.splice(seg < 0 ? 0 : seg, 0, bdListe(d));
    return out;
  };
}

/* ----- Neue Bindung: Apps, Ende, Satz zur Kontrolle ----- */
const BD = {e:null};
function bdDialog(){
  let d = $("bdDialog"); if (!d){ d = el("dialog","cm-regel lm-dialog bd-dialog"); d.id = "bdDialog"; document.body.append(d);
    d.addEventListener("cancel", ev => { ev.preventDefault(); bdZu(); }); }
  return d;
}
function bdZu(){ BD.e = null; const d = $("bdDialog"); if (d?.open) d.close(); }
function bdAuf(){
  const m = new Date(); m.setDate(m.getDate() + ((5 - m.getDay() + 7) % 7 || 7)); m.setHours(18, 0, 0, 0);   // Vorschlag: nächster Freitag 18 Uhr
  BD.e = {apps:new Set(), ende:+m, appsZeigen:true};
  bdZeichnen();
}
function bdSchnell(){
  const j = new Date(), at = (tage, h) => { const x = new Date(j); x.setDate(x.getDate() + tage); x.setHours(h, 0, 0, 0); return +x; };
  const fr = (5 - j.getDay() + 7) % 7 || 7, so = (7 - j.getDay()) % 7 || 7;
  return [["Heute 22 Uhr", at(0, 22)], ["Morgen 18 Uhr", at(1, 18)], ["Freitag 18 Uhr", at(fr, 18)], ["Sonntag 20 Uhr", at(so, 20)], ["1 Woche", +j + 7 * 864e5]]
    .filter(([, t], i, l) => t > Date.now() + 60e3 && l.findIndex(x => x[1] === t) === i);   // Donnerstag: „Freitag 18 Uhr“ = „Morgen 18 Uhr“, nur einmal
}
function bdZeichnen(){
  const e = BD.e; if (!e) return;
  const d = bdDialog(), y = d.querySelector(".lm-body")?.scrollTop || 0;
  const kopf = el("div","lm-dkopf"), x = el("button","ghost small","✕"); x.type = "button"; x.setAttribute("aria-label","Schließen"); x.addEventListener("click", bdZu);
  const titel = el("div","lm-titel"); titel.append(el("b", null, "Neue Bindung"), el("small", null, "Bis zu diesem Zeitpunkt bleibt die App zu."));
  kopf.append(cmKachel("", "lock"), titel, x);
  const body = el("div","lm-body");
  // Ende
  const s = el("section","lm-abschnitt"), sk = el("div","lm-akopf"); sk.append(cmKachel("", "clock"), el("b", null, "Bis wann?")); s.append(sk);
  const schnell = el("div","lm-schnell");
  bdSchnell().forEach(([t, ms]) => { const b = el("button", Math.abs(ms - e.ende) < 60e3 ? "an" : "", t); b.type = "button"; b.addEventListener("click", () => { e.ende = ms; bdZeichnen(); }); schnell.append(b); });
  const z = el("div","fs-zeit"), tag = el("input"), uhr = el("input"), p = n => String(n).padStart(2, "0"), de = new Date(e.ende);
  tag.type = "date"; uhr.type = "time"; tag.value = `${de.getFullYear()}-${p(de.getMonth() + 1)}-${p(de.getDate())}`; uhr.value = `${p(de.getHours())}:${p(de.getMinutes())}`;
  tag.setAttribute("aria-label","Datum"); uhr.setAttribute("aria-label","Uhrzeit");
  const neuZeit = () => { const [Y, M, D] = tag.value.split("-").map(Number), [h, mi] = uhr.value.split(":").map(Number); if (!Y || isNaN(h)) return; e.ende = +new Date(Y, M - 1, D, h, mi); bdZeichnen(); };
  tag.addEventListener("change", neuZeit); uhr.addEventListener("change", neuZeit);
  const f = (t, i) => { const b = el("label","fs-zeit-feld"); b.append(el("span", null, t), i); return b; };
  z.append(f("Tag", tag), el("span","fs-zeit-pfeil","·"), f("Uhrzeit", uhr));
  s.append(schnell, z);
  body.append(bdApps(e), s);
  const fuss = el("div","lm-dfuss"), hinweis = el("div","lm-hinweis"), ok = el("button","ask cm-violett lm-ok","Bindung starten"); ok.type = "button";
  const gueltig = e.apps.size && e.ende > Date.now() + 60e3;
  hinweis.append(el("span","lm-klein " + (gueltig ? "bd-satz" : ""), !e.apps.size ? "Wähle mindestens eine App." : !(e.ende > Date.now() + 60e3) ? "Das Ende muss in der Zukunft liegen."
    : `${bdAppsText(e.apps)} ${e.apps.size === 1 ? "bleibt" : "bleiben"} bis ${bdZeit(e.ende)} gesperrt.`));
  if (gueltig) hinweis.append(el("span","lm-klein","Früher beenden geht erst 12 Std. nach einem Antrag."));
  ok.disabled = !gueltig;
  ok.addEventListener("click", async () => { ok.disabled = true;
    if (await lkAktion({regel:{art:"bis", apps:[...e.apps], ende:Math.round(e.ende / 1000)}})){ bdZu(); toast(`${bdAppsText(e.apps)} ${e.apps.size === 1 ? "ist" : "sind"} bis ${bdZeit(e.ende)} gesperrt.`);
      if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {}); }
    else ok.disabled = false; });
  fuss.append(hinweis, ok);
  d.replaceChildren(kopf, body, fuss);
  if (!d.open) d.showModal();
  body.scrollTop = y;
}

// App-Auswahl wie bei Sperrzeiten (szApps), eigene Kopie, weil szApps fest auf SZ.e und szZeichnen arbeitet
function bdApps(e){
  const d = LK.daten || {}, s = el("section","lm-abschnitt lm-apps");
  const kopf = el("div","lm-akopf"); kopf.append(cmKachel("", "phone"), el("b", null, `Welche Apps? (${e.apps.size})`));
  const w = el("button","lm-link", e.appsZeigen ? "Fertig" : "Ändern"); w.type = "button"; w.addEventListener("click", () => { e.appsZeigen = !e.appsZeigen; bdZeichnen(); });
  kopf.append(w); s.append(kopf);
  if (!e.appsZeigen){
    const reihe = el("div","fs-sz-apps"); [...e.apps].slice(0, 12).forEach(a => reihe.append(cmKachel(a)));
    if (!e.apps.size) reihe.append(el("span","lm-klein","Noch keine App gewählt."));
    s.append(reihe); return s;
  }
  const namen = [], gesehen = new Set();
  const dazuName = n => { const k = n.toLowerCase().replace(/[^\p{L}\p{N}]/gu, ""); if (!k || gesehen.has(k)) return; gesehen.add(k); namen.push(n); };
  [...e.apps].forEach(dazuName); (d.apps || []).forEach(a => dazuName(a.name));
  const info = n => (d.apps || []).find(a => a.name === n);
  const sicht = namen.filter(n => e.apps.has(n) || !lkIstRauschen(n)).sort((a, b) => (e.apps.has(b) - e.apps.has(a)) || ((info(b)?.kat === "prokrastination") - (info(a)?.kat === "prokrastination")));
  const such = el("div","lm-such"), inp = el("input"), plus = el("button", null, "＋"); plus.type = "button"; plus.setAttribute("aria-label","Hinzufügen");
  inp.placeholder = "App oder Seite, z. B. reddit.com"; inp.setAttribute("aria-label","App oder Seite suchen oder eingeben");
  const gitter = el("div","lm-appgitter");
  sicht.forEach(n => { const b = el("button", e.apps.has(n) ? "an" : "", null); b.type = "button"; b.dataset.n = n.toLowerCase();
    b.append(cmKachel(n), el("span", null, n));
    b.addEventListener("click", () => { e.apps.has(n) ? e.apps.delete(n) : e.apps.add(n); bdZeichnen(); }); gitter.append(b); });
  const dazu = () => { const n = inp.value.trim().replace(/^https?:\/\//i, "").replace(/^www\./i, "").replace(/\/.*$/, ""); if (!n) return;
    e.apps.add(namen.find(x => x.toLowerCase() === n.toLowerCase()) || n); bdZeichnen(); };
  inp.addEventListener("input", () => { const q = inp.value.trim().toLowerCase(); gitter.querySelectorAll("button").forEach(b => b.hidden = !!q && !b.dataset.n.includes(q)); });
  inp.addEventListener("keydown", ev => { if (ev.key === "Enter"){ ev.preventDefault(); dazu(); } });
  plus.addEventListener("click", dazu); such.append(inp, plus);
  s.append(such, gitter);
  return s;
}
if (typeof renderLocker === "function"){   // Locker zu (Fokus läuft): Dialog schließen
  const _rlBd = renderLocker;
  renderLocker = function(...a){ const r = _rlBd.apply(this, a); if (BD.e && !LK.daten?.offen) bdZu(); return r; };
}

// Bild-KI-Hinweis (bereit / wird vorbereitet / Akku) direkt unter dem Titel „Bild-KI“ im Inhaltsschutz
if (typeof trSchutzKarte === "function"){
  const _trBd = trSchutzKarte;
  trSchutzKarte = function(x){
    const k = _trBd.call(this, x), titel = k.querySelector(".kx-titel");
    if (titel && typeof bkBox === "function"){ const b = k.querySelector(".bk-clip") || bkBox(); if (b) titel.after(b); }
    return k;
  };
}

/* ---------- Fokus-Timer: läuft auf dem Server (übersteht Neuladen), misst über den eigenen Zähler und die Handys ---------- */
const FK = {data:null, dur:store("cockpit.fokusMin") || 60, tick:null, n:0, title:document.title, stopArmed:null};
const hm = s => new Date(s).toLocaleTimeString("de-DE", {hour:"2-digit", minute:"2-digit"});
function fkFill(){
  const p = S.plan; if (!p) return;
  const ps = $("fkProj"), cur = ps.value || store("cockpit.fokusProj") || "";
  ps.replaceChildren(new Option("Ohne Projekt", ""), ...p.projekte.filter(x => x.aktiv).map(x => new Option(x.name, x.name)));
  ps.value = [...ps.options].some(o => o.value === cur) ? cur : "";
  fkTasks();
}
function fkTasks(want){
  const p = S.plan, pr = $("fkProj").value || null, ts = $("fkTask"), cur = want ?? ts.value;
  const seen = new Set(), groups = {};
  const add = (text, done, g) => { const k = key(text); if (done || seen.has(k)) return; seen.add(k);
    if (!groups[g]){ groups[g] = document.createElement("optgroup"); groups[g].label = g; } groups[g].append(new Option(text, text)); };
  p.heute.filter(t => (t.projekt || null) === pr).forEach(t => add(t.text, t.done, "Heute"));
  p.woche.filter(t => (t.projekt || null) === pr).forEach(t => add(t.text, t.done, "Diese Woche"));
  const x = p.projekte.find(x => x.name === pr);
  if (x?.phasen) openGoals(x).forEach(g => add(g.name, g.fertig, "Weitere Ziele"));
  else (x?.aufgaben || []).forEach(t => add(t.text, t.done, "Weitere Aufgaben"));
  ts.replaceChildren(new Option("Kein bestimmtes Ziel", ""), ...Object.values(groups));
  ts.value = seen.has(key(cur)) ? cur : "";
}
function fkDurChips(){
  const std = [25, 45, 60, 90], lbl = el("label","fk-eig"), eig = el("input");
  eig.type = "number"; eig.min = 1; eig.max = 240; eig.step = 1; eig.inputMode = "numeric"; eig.placeholder = "eigene";
  eig.setAttribute("aria-label", "Eigene Dauer in Minuten"); if (!std.includes(FK.dur)) eig.value = FK.dur;
  const set = () => { const m = Math.max(1, Math.min(240, Math.round(+eig.value || 0))); if (!+eig.value) return; FK.dur = m; store("cockpit.fokusMin", m); fkDurChips(); };
  eig.addEventListener("change", set); eig.addEventListener("keydown", e => { if (e.key === "Enter"){ e.preventDefault(); eig.blur(); } });
  lbl.append(eig, el("span", null, "Min"));
  if (!std.includes(FK.dur)) lbl.classList.add("on");
  $("fkDur").replaceChildren(...std.map(m => {
    const b = el("button","chip small", m + " Min"); b.type = "button"; b.setAttribute("aria-pressed", FK.dur === m);
    b.addEventListener("click", () => { FK.dur = m; store("cockpit.fokusMin", m); fkDurChips(); }); return b;
  }), lbl);
  $("fkStart").textContent = `Fokus starten · ${FK.dur} Min`;
}
function fkPrefill(it){
  if (FK.data?.aktiv) return;
  $("fkProj").value = it.projekt && [...$("fkProj").options].some(o => o.value === it.projekt) ? it.projekt : "";
  fkTasks(it.text);
  showTab("fokus"); window.scrollTo({top:0, behavior:"smooth"}); $("fkStart").focus({preventScroll:true});
}
const verdict = f => f >= 75 ? "Stark, du warst wirklich dran." : f >= 50 ? "Ganz okay, da geht noch mehr." : "Da ging viel Zeit für anderes drauf.";
function renderFokus(){
  const d = FK.data, a = d?.aktiv, lokal = S.mode === "lokal";
  $("fkStart").disabled = !lokal;
  if (!lokal) $("fkSub").textContent = "Misst über BlockEm auf deinem Mac. In dieser Vorschau nicht aktiv.";
  $("fkIdle").hidden = !!a; $("fkRun").hidden = !a;
  if (a){
    const w = $("fkWhat"); w.replaceChildren();
    if (a.projekt) w.append(el("b", null, a.projekt));
    if (a.aufgabe) w.append(a.projekt ? " · " : "", a.aufgabe);
    if (!a.projekt && !a.aufgabe) w.append("Freie Fokus-Session");
    w.append(` · bis ${hm(a.planEnde)}`);
    const L = a.live, st = $("fkStats"); st.replaceChildren();
    const part = (lbl, v) => { const s = el("span"); s.append(lbl + " ", el("b", null, v)); st.append(s); };
    part("Produktiv", minText(L.produktiv));
    part("Abgelenkt", `${L.anzahl ?? 0}× · ${minText(L.abgelenkt)}`);
    part(VB.modus === "handy" ? "Weg vom Handy" : "Weg vom Mac", minText(L.weg));
    part("Fokus", L.fokus + " %");
    $("fkMom").replaceChildren(...(L.momente || []).slice(-5).reverse().map(m => { const r = el("div"); r.append(el("b", null, hm(m.start)), ` ${m.name}, ${minText(m.sek)}`); return r; }));
    $("fkTime").className = L.dauer < 180 ? "" : L.fokus >= 70 ? "good" : L.fokus < 40 ? "bad" : "";
    fkTickStart();
  } else { fkTickStop(); document.title = FK.title; }
  const last = $("fkLast"); last.replaceChildren();
  const today = (d?.sessions || []).filter(s => s.start.slice(0, 10) === TODAY);
  if (today.length){
    const s = today[0], r = s.ergebnis, res = el("div","res");
    res.append(`Letzte Session ${hm(s.start)}–${hm(s.ende)}${s.projekt ? " (" + s.projekt + ")" : ""}: `,
      el("b", null, `${Math.round(r.produktiv/60)} von ${Math.round(r.dauer/60)} Min produktiv, ${r.fokus} %`), ". " + verdict(r.fokus));
    last.append(res);
    const abl = r.ablenkungen.filter(x => x.sek >= 30);
    if (r.anzahl != null) last.append(el("div", null, r.anzahl ? `${r.anzahl}× abgelenkt` + (r.momente?.length ? ": " + r.momente.slice(0, 5).map(m => `${hm(m.start)} ${m.name}`).join(", ") + "." : ".") : "Kein einziges Mal abgelenkt."));
    if (abl.length) last.append(el("div", null, "Abgelenkt durch " + abl.map(x => `${x.name} ${minText(x.sek)}`).join(", ") + "."));
    const tot = today.reduce((n, x) => n + x.ergebnis.produktiv, 0);
    last.append(el("div", null, `Heute ${today.length} Session${today.length === 1 ? "" : "s"}, zusammen ${minText(tot)} produktiv.` + (s.final ? "" : " Handy-Daten kommen bis zu 15 Minuten später dazu.")));
  }
}
function renderFkAus(){
  const a = FK.data?.auswertung, box = $("fkAusBox"); box.hidden = !a; if (!a) return;
  $("fkAus").replaceChildren(...[["Heute", a.heute], ["Diese Woche", a.woche]].map(([lbl, w]) => {
    const k = kpi(lbl, w.sessions ? minText(w.produktiv) : "–", "var(--good)"), z = el("div","fk-zeilen");
    const zeile = (n, v) => z.append(el("span", null, n), el("b", null, v));
    if (w.sessions){
      k.append(el("span","k-s", "echte Fokuszeit"), kpiBar(w.fokus, "var(--good)"));
      zeile("Sessions", `${w.sessions} · ${minText(w.dauer)}`); zeile("Fokus", w.fokus + " %");
      zeile("Abgelenkt", `${w.anzahl}× · ${minText(w.abgelenkt)}`);
      if (w.top.length) zeile("Am meisten", w.top.map(x => x.name.replace(/ \(.*\)$/, "")).join(", "));
      k.append(z);
    } else k.append(el("span","k-s", "Noch keine Fokus-Session."));
    return k;
  }));
}
function fkTickStart(){ if (!FK.tick){ FK.n = 0; FK.tick = setInterval(fkTick, 1000); } fkTick(); }
function fkTickStop(){ clearInterval(FK.tick); FK.tick = null; }
function fkTick(){
  const a = FK.data?.aktiv; if (!a) return fkTickStop();
  const start = new Date(a.start), end = new Date(a.planEnde), now = Date.now(), left = Math.max(0, end - now);
  const t = `${Math.floor(left / 60000)}:${pad(Math.floor(left / 1000) % 60)}`;
  $("fkTime").textContent = t; document.title = `${t} · Fokus`;
  $("fkProg").style.width = Math.min(100, (now - start) / (end - start) * 100) + "%";
  if (left <= 0){ fkTickStop(); beep(); setTimeout(fkLoad, 1500); return; }
  if (++FK.n % 30 === 0) fkLoad();
}
function beep(){
  try {
    const c = new AudioContext();
    [0, .4, .8].forEach(t => { const o = c.createOscillator(), g = c.createGain(); o.frequency.value = 880;
      g.gain.setValueAtTime(.0001, c.currentTime + t); g.gain.exponentialRampToValueAtTime(.2, c.currentTime + t + .02);
      g.gain.exponentialRampToValueAtTime(.0001, c.currentTime + t + .3); o.connect(g).connect(c.destination); o.start(c.currentTime + t); o.stop(c.currentTime + t + .32); });
  } catch {}
}
async function fkLoad(){
  if (S.mode !== "lokal") return;
  try {
    const d = await api("api/fokus");
    const wk = JSON.stringify(d.wocheProjekt) !== JSON.stringify(FK.data?.wocheProjekt);
    FK.data = d; renderFokus(); renderFkAus(); renderJetzt(); renderSperre(); if (wk) renderPlan();
  } catch {}
}
async function fkAction(body){
  try { FK.data = await api("api/fokus", body); renderFokus(); renderFkAus(); renderPlan(); }
  catch (e) { S.fehler = [`Fokus-Timer: ${e.message || e}`]; renderHeader(); }
}


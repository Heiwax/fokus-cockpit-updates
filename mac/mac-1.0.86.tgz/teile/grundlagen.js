const $ = id => document.getElementById(id);
const pad = n => String(n).padStart(2, "0");
const iso = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const NOW = new Date(), TODAY = iso(NOW);
const WD = ["So","Mo","Di","Mi","Do","Fr","Sa"];
const PERIOD_DB = {woche:"week", monat:"month", jahr:"year"};
const S = { mode:"demo", demoActivity:true, day:null, week:null, plan:null, fehler:[], goalMin:180, limitMin:60, period:"woche", db:null, sample:null, apiFresh:0,
  openDevs:new Set(store("cockpit.geraeteOffen") || []), openProj:new Set(store("cockpit.projekteOffen") || []), openPhase:new Map(), openGoals:new Set(), drafts:{} };

function el(tag, cls, text){ const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
function store(k, v){ try { if (v === undefined) return JSON.parse(localStorage.getItem(k)); localStorage.setItem(k, JSON.stringify(v)); } catch { return null; } }
function minText(sec){ const m = Math.round((sec||0)/60); return m < 60 ? `${m} Min` : `${Math.floor(m/60)} Std ${m%60} Min`; }
function bigText(min){
  if (min < 60) return `${Math.round(min)} Min`;
  if (min < 180) return `${Math.floor(min/60)} Std ${Math.round(min%60)} Min`;
  if (min < 6000) return `${Math.round(min/60)} Std`;
  return `${(min/1440).toLocaleString("de-DE",{maximumFractionDigits:1, minimumFractionDigits:1})} Tage`;
}
function isoWeek(d){
  const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); const day = t.getUTCDay() || 7;
  t.setUTCDate(t.getUTCDate() + 4 - day); const y0 = new Date(Date.UTC(t.getUTCFullYear(),0,1));
  return Math.ceil(((t - y0) / 864e5 + 1) / 7);
}

/* ---------- Beispieldaten (nur wenn keine echten Daten erreichbar sind) ---------- */
function rng(seed){ return () => (seed = (seed * 16807) % 2147483647) / 2147483647; }
function demoDay(dateStr, uptoHour){
  const r = rng([...dateStr].reduce((a,c) => a*31 + c.charCodeAt(0), 7) % 2147483647 || 1);
  const h = Array.from({length:24}, () => [0,0,0,0]);
  for (let i = 8; i <= Math.min(22, uptoHour); i++){
    const len = i === uptoHour ? NOW.getMinutes()*60 : 3600;
    const away = r() < .18 ? len*(.4+r()*.5) : len*r()*.15;
    const left = len - away, p = left*(i < 13 ? .45+r()*.4 : .2+r()*.45), pr = (left-p)*(i > 17 ? .4+r()*.5 : r()*.35);
    h[i] = [p, left-p-pr, pr, away].map(Math.round);
  }
  const sum = h.reduce((a,x) => ({produktiv:a.produktiv+x[0], neutral:a.neutral+x[1], prokrastination:a.prokrastination+x[2], afk:a.afk+x[3]}), {produktiv:0,neutral:0,prokrastination:0,afk:0});
  const apps = [["Visual Studio Code","produktiv",.45],["claude.ai","produktiv",.35],["TradingView","produktiv",.2],["YouTube","prokrastination",.6],["Instagram","prokrastination",.4],["Finder","neutral",.3],["Spotify","neutral",.7]]
    .map(([name,kat,f]) => ({name, kat, sek:Math.round(sum[kat]*f)})).sort((a,b) => b.sek-a.sek);
  // Aufteilung auf die Geräte (Mac, Pixel 8 Pro, Pixel 9 Pro XL), nur für die Beispielansicht
  const split = {"Visual Studio Code":[1,0,0], "claude.ai":[.85,.05,.1], "TradingView":[.7,.1,.2], "YouTube":[.5,.15,.35], "Instagram":[0,.3,.7], "Finder":[1,0,0], "Spotify":[.6,.15,.25]};
  const geraete = ["Computer","Handy","Tablet"].map((name, i) => {
    const g = {name, sek:0, produktiv:0, neutral:0, prokrastination:0, apps:[]};
    apps.forEach(a => { const s = Math.round(a.sek * split[a.name][i]); if (s){ g.apps.push({name:a.name, kat:a.kat, sek:s}); g[a.kat] += s; g.sek += s; } });
    g.apps.sort((a,b) => b.sek - a.sek); return g;
  });
  return {date:dateStr, quelle:"demo", summe:sum, stunden:h, apps, geraete};
}
function demoWeek(){
  const tage = [];
  for (let n = 6; n >= 0; n--){ const d = new Date(NOW); d.setDate(d.getDate()-n); const s = iso(d); tage.push({date:s, ...demoDay(s, n ? 23 : NOW.getHours()).summe}); }
  return {tage, serie:0};
}
const key = s => (s || "").trim().toLowerCase();
/* Prozente wie im Server: Ziel = erledigte Schritte, Meilenstein/Projekt = erledigter Aufwand / gesamter Aufwand (Ziel ohne Angabe = 1 Tag).
   Nur für die Beispielansicht; lokal rechnet der Server. */
function recalc(p){
  const pct = (d, t) => t ? Math.round(d / t * 100) : 0, avg = a => a.length ? Math.round(a.reduce((s, v) => s + v, 0) / a.length) : 0;
  const goals = new Map(), stones = new Map();
  p.projekte.forEach(x => {
    if (!x.phasen) return;
    x.phasen.forEach(ph => {
      stones.set(x.name + "|" + key(ph.name), ph);
      ph.ziele.forEach(g => { g.done = g.schritte.filter(s => s.done).length; g.total = g.schritte.length; g.prozent = pct(g.done, g.total);
        g.fertig = g.total > 0 && g.done === g.total; if (!g.einzel) goals.set(x.name + "|" + key(g.name), g); });
      ph.aufwand = ph.ziele.reduce((s, g) => s + (g.aufwand || 2), 0);
      ph.rest = Math.round(ph.ziele.reduce((s, g) => s + (g.aufwand || 2) * (100 - g.prozent) / 100, 0) * 10) / 10;
      ph.prozent = ph.ziele.length ? Math.round(100 - 100 * ph.rest / ph.aufwand) : ph.fertigMarke ? 100 : 0;
      ph.fertig = ph.prozent === 100 && ph.ziele.every(g => g.fertig);
    });
    const akt = x.phasen.find(f => f.marke) || x.phasen.find(f => !f.fertig);
    x.phasen.forEach(f => f.aktiv = f === akt);
    x.aufwand = x.phasen.reduce((s, f) => s + f.aufwand, 0); x.rest = Math.round(x.phasen.reduce((s, f) => s + f.rest, 0) * 10) / 10;
    x.prozent = x.aufwand ? Math.round(100 - 100 * x.rest / x.aufwand) : avg(x.phasen.map(f => f.fertigMarke ? 100 : 0)); x.phase = akt?.name || "";
    x.next = [...(akt ? [akt] : []), ...x.phasen].flatMap(f => f.ziele).find(g => !g.fertig)?.name || "";
    x.aufgaben = x.phasen.flatMap(f => f.ziele.flatMap(g => g.schritte)); x.done = x.aufgaben.filter(s => s.done).length; x.total = x.aufgaben.length;
  });
  [...p.heute, ...p.woche, ...p.monat, ...p.jahr, ...(p.tage || []).flatMap(d => d.items)].forEach(it => {
    const g = it.projekt && goals.get(it.projekt + "|" + key(it.text)), ms = !g && it.projekt && stones.get(it.projekt + "|" + key(it.text));
    if (g){ it.ziel = g; it.done = !!it.own || g.fertig; }
    if (ms){ it.meilenstein = {prozent:ms.prozent, done:ms.ziele.filter(z => z.fertig).length, total:ms.ziele.length, ziele:ms.ziele.map(z => ({name:z.name, fertig:z.fertig, prozent:z.prozent}))};
      it.done = !!it.own || (ms.fertig && ms.ziele.length > 0); }
  });
  return p;
}
const DEMO_PLAN = (() => {
  let n = 0;
  const t = (text, projekt = null, done = false, frist = null) => ({id:"d" + (++n), text, done, own:done, projekt, frist});
  const z = (name, steps) => ({name, einzel:false, schritte:steps.map(([text, done]) => ({id:"s" + (++n), text, done:!!done}))});
  const e = (text, done) => ({name:text, einzel:true, schritte:[{id:"s" + (++n), text, done:!!done}]});
  const ph = (name, ziele, marke = false, frist = null) => ({name, marke, frist, ziele});
  const pr = (name, status, aktiv, phasen, endziel = null) => ({name, status, aktiv, phasen, endziel});
  const C = "Browser-App Cockpit", K = "KI-Sales-Trainer", T = "TradingView Indikator";
  return recalc({
    heute:[t("Grundgerüst steht", C)],
    woche:[t("BlockEm 2.0 im Einsatz", C, true), t("Grundgerüst steht", C), t("Zielgruppe und Methode stehen", K)],
    monat:[t("Grundgerüst Konzeptionstool", C), t("Konzept fertig", K), t("Strategie mit Backtest", T)],
    jahr:[t("10.000 € pro Monat aus eigenem Business", null, false, "2027-12-31"), t("Closing stabil mind. 5.000 €/Monat", "Sales"), t("Trading auf Profi-Niveau", T, false, "2027-12-31")],
    tage:[],
    projekte:[
      pr(C, "aktiv", true, [
        ph("Erste Versionen", [z("Version 1 steht", [["Version 1 bauen", 1], ["Startdaten aus dem Vault eintragen", 1]]),
          z("BlockEm 2.0 im Einsatz", [["Bildschirmzeit von Mac und Handys", 1], ["Projekte, Planen und Fokus-Timer", 1], ["Autostart", 1], ["Handy-App 1.1 auf beiden Pixels", 1]])]),
        ph("Grundgerüst Konzeptionstool", [z("Grundgerüst steht", [["Reiter oben"], ["Fristen mit „noch X Tage“"], ["Monatsplaner"], ["Fokus-Timer mit eigener Dauer"], ["Endziel und Meilensteine"]]),
          z("Grundgerüst im Alltag geprüft", [["BlockEm täglich nutzen"], ["Sagen, was noch fehlt"]])], true),
        ph("Design", [z("Design, das mir gefällt", [["Claudes Fragen zum Design beantworten"]])]),
        ph("App-Entscheidung", [z("App-Idee bewertet", [["Nach zwei Wochen mit echten Zahlen bewerten"]])], false, "2026-10-27"),
        ph("Installierbare App", [])], {text:"Fertige App, die ich installieren kann, auch für Play Store oder App Store", frist:null}),
      pr(K, "Konzeption", true, [
        ph("Konzept fertig", [z("Zielgruppe und Methode stehen", [["Interview Block 1: Zielgruppe und Problem", 1], ["Klären, für wen der Trainer nicht gedacht ist"], ["Interview Block 2: deine Verkaufsmethode"]]),
          z("Markt und Übungs-Call durchdacht", [["Interview Block 3"], ["Interview Block 4"], ["Interview Block 5"]]),
          z("Preis, Marke und MVP geklärt", [["Interview Block 6"], ["Interview Block 7"], ["Interview Block 8"]]),
          z("Konzept Phase A aufgeschrieben", [["Konzept Phase A ausarbeiten"], ["Liste mit 5–10 Closern als erste Tester"]])], true),
        ph("Erster Prototyp", [z("Erster Übungs-Call läuft", [["Sprach-KI-Plattformen vergleichen"], ["Ersten Prototyp bauen"]])]),
        ph("Test mit Closern", []), ph("Launch", [])], null),
      pr("Sales", "laufend", true, [
        ph("Weg zu 5.000 €", [z("Plan für 5.000 € steht", [["Klären, was bis 5.000 € stabil fehlt"], ["Eigene Calls analysieren"]])], true),
        ph("Coaching", [z("Coaching-Thema steht", [["Coaching-Thema festlegen"]])])], {text:"Closing stabil mind. 5.000 € im Monat", frist:null}),
      pr(T, "aktiv", true, [
        ph("Strategie mit Backtest", [z("Indikator getestet", [["Pine Script in TradingView einfügen"], ["Indikator laden und testen"]]),
          z("Backtest-Strategie steht", [["Als Strategy mit Stop-Loss, Take-Profit und Backtest umbauen"], ["Strategie-Regeln aufschreiben"]])], true),
        ph("Trading-Bot", [z("Bot-Idee rechtlich geprüft", [["Rechtlich klären (BaFin)"]])])], {text:"Trading auf Profi-Niveau", frist:"2027-12-31"}),
      pr("Prayer App", "Idee", false, [ph("Aufgaben", [e("Offene Fragen klären"), e("Konkurrenz prüfen", 1)])])]
  });
})();


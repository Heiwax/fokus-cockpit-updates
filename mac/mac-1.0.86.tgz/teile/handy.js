/* ---------- Handy (3.0): untere Leiste mit 4 Bereichen + „Mehr“, kompakter Kopf, Rechte der Handy-App ---------- */
// Am Handy (schmal) stehen unten nur HAUPT_REITER, der Rest liegt hinter „Mehr“. Am Mac bleibt die Seitenleiste wie sie ist.
const HAUPT_REITER = ["heute", "ziele", "projekte", "fokus"];
const MEHR_REITER = [
  ["habits", "Habits", "Gewohnheiten abhaken, Consistency"],
  ["werte", "Werte", "Bildschirmzeit, Woche, Rückblick"],
  ["locker", "Locker", "Sperrzeiten und Tageslimits"],
  ["einstellungen", "Einstellungen", "KI, Kalender, Automatik, Handys, Daten"],
];
function mehrKnopf(){
  const nav = $("reiter"); if (!nav || $("mehrBtn")) return;
  nav.querySelectorAll("button[data-r]").forEach(b => { if (!HAUPT_REITER.includes(b.dataset.r)) b.classList.add("r-neben"); });
  const b = el("button", "r-mehr"); b.id = "mehrBtn"; b.type = "button"; b.setAttribute("aria-haspopup", "dialog");
  b.innerHTML = '<svg class="ri" viewBox="0 0 24 24" aria-hidden="true"><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg><span>Mehr</span>';
  b.addEventListener("click", mehrOeffnen);
  nav.append(b);
}
function mehrOeffnen(){
  let d = $("mehrDialog");
  if (!d){
    d = el("dialog", "mehr-blatt modern"); d.id = "mehrDialog"; d.setAttribute("aria-label", "Mehr");
    d.addEventListener("click", e => { if (e.target === d) d.close(); });
    document.body.append(d);
  }
  const liste = el("div", "mb-liste");
  const zeile = (icon, titel, sub, fn, an) => {
    const b = el("button", "mb-zeile" + (an ? " an" : "")); b.type = "button";
    const i = el("span", "mb-icon"); if (typeof icon === "string") i.innerHTML = icon; else i.append(icon);
    const t = el("span", "mb-text"); t.append(el("b", null, titel), el("small", null, sub));
    b.append(i, t); b.addEventListener("click", () => { d.close(); fn(); }); liste.append(b);
  };
  const aktiv = store("cockpit.reiter");
  MEHR_REITER.forEach(([r, titel, sub]) => {
    const svg = document.querySelector(`#reiter button[data-r="${r}"] svg`);
    zeile(svg ? svg.outerHTML : "", titel, sub, () => { showTab(r); window.scrollTo(0, 0); }, aktiv === r);
  });
  const extra = el("div", "mb-extra");
  const knopf = (text, fn) => { const b = el("button", "ghost", text); b.type = "button"; b.addEventListener("click", () => { d.close(); fn(); }); extra.append(b); };
  const nurTr = document.documentElement.classList.contains("nur-tracking");   // Tracking-App: keine Planung
  if (S.plan?.ki?.modell && !nurTr) knopf("✦ " + (fcName() === "Claude" ? "Frag Claude" : "Frag die KI"), fcOeffnen);
  if (!nurTr) knopf("＋ Schnell hinzufügen", snOeffnen);
  if (window.CockpitApp?.http && !window.CockpitApp.play?.()) knopf("⟳ Nach Updates suchen", updateSuchen);
  const griff = el("div", "mb-griff");
  d.replaceChildren(griff, el("h2", null, "Mehr"), liste, extra);
  d.showModal();
}
// „Mehr“ leuchtet, wenn gerade ein Bereich daraus offen ist
const _showTabAlt = showTab;
showTab = function(r){ _showTabAlt(r); $("mehrBtn")?.setAttribute("aria-selected", String(!HAUPT_REITER.includes(store("cockpit.reiter") || "heute"))); };

/* ----- Handy-App: Rechte und Fokus-Sperre (mit Erklärung vorher, wie Google Play es verlangt) ----- */
function handyRechte(){
  try { return JSON.parse(window.CockpitApp?.rechte?.() || "{}"); } catch { return {}; }
}
function handySperreErklaeren(){
  let d = $("sperreInfo");
  if (!d){ d = el("dialog", "planer modern ein-dialog"); d.id = "sperreInfo"; document.body.append(d); }
  const ok = eiKnopf("Verstanden, einschalten", "ask", () => { d.close(); window.CockpitApp.sperreEinrichten(); });
  const nein = eiKnopf("Nicht jetzt", "ghost small", () => d.close());
  if (window.CockpitApp.ios){   // iPhone: Apples Bildschirmzeit-Schnittstelle statt Bedienungshilfe
    d.replaceChildren(el("h2", null, "Fokus-Sperre: was sie tut"),
      el("p", null, "Auf dem iPhone nutzt die Sperre Apples Bildschirmzeit-Schnittstelle (Screen Time API)."),
      (() => { const ul = el("ul", "k-s"); [
        "Du wählst in Apples Dialog, welche Apps und Seiten im Fokus und in Locker-Regeln gesperrt sind. Die App erfährt keine App-Namen.",
        "Gesperrte Apps bekommen einen Schild, auch wenn BlockEm geschlossen ist. Der Filter für Erwachsenen-Inhalte ist in allen Browsern an.",
        "Minuten je App gibt Apple nicht heraus; BlockEm zählt in 5-Minuten-Schritten für die Gruppen „Ablenkende Apps“ und „iPhone gesamt“.",
        "Alles wird nur auf diesem iPhone ausgewertet. Ausschalten: Einstellungen › Bildschirmzeit › Apps mit Bildschirmzeit-Zugriff."].forEach(t => ul.append(el("li", null, t))); return ul; })(),
      el("p", "k-s", "Im nächsten Schritt fragt Apple einmal nach der Erlaubnis, dann wählst du die Apps."),
      (() => { const f = el("div", "ein-fuss"); f.append(nein, ok); return f; })());
    d.showModal(); return;
  }
  d.replaceChildren(el("h2", null, "Fokus-Sperre: was sie tut"),
    el("p", null, "Die Fokus-Sperre nutzt die Bedienungshilfen-Schnittstelle von Android (Accessibility API)."),
    (() => { const ul = el("ul", "k-s"); [
      "Sie erkennt, welche App gerade vorne ist, und bei Browsern die Adresse der Seite.",
      "Ist die App oder Seite in deinem Fokus, einer Locker-Regel oder der Sperrliste für Erwachsenen-Inhalte, schaltet sie zurück zum Startbildschirm.",
      "Für den Inhaltsschutz prüft sie sichtbaren Text und, wenn die Bild-Erkennung an ist, Bildschirmbilder. Das passiert nur auf diesem Handy. Bilder werden weder gespeichert noch verschickt.",
      "Sie liest keine Passwörter. Ins Internet geht nur eine kurze Meldung, falls du eine Vertrauensperson hast und den Schutz abschaltest.",
      "Ausschalten kannst du sie jederzeit in den Android-Einstellungen › Bedienungshilfen."].forEach(t => ul.append(el("li", null, t))); return ul; })(),
    el("p", "k-s", "Im nächsten Schritt öffnet sich Android: „BlockEm Fokus-Sperre“ antippen und einschalten."),
    (() => { const f = el("div", "ein-fuss"); f.append(nein, ok); return f; })());
  d.showModal();
}

/* ----- Export in der App: Datei landet im Download-Ordner des Handys ----- */
async function handyExport(){
  try {
    if (VB.modus === "handy"){ const j = await api("api/export"); window.CockpitApp.speichern(`BlockEm-Export-${TODAY}.zip`, j.zip); }
    else window.CockpitApp.datei("api/export", `BlockEm-Export-${TODAY}.zip`);
  } catch (e) { toast("Export ging nicht: " + (e.message || e)); }
}
mehrKnopf();

/* ----- Handy-App: Farbe der Systemleisten passend zum Aussehen (hell/dunkel) ----- */
function handyFarbe(){
  if (!window.CockpitApp?.farbe) return;
  // Frauen-Profil: Seite wird per Filter hell, die Leisten sollen hell mit dunklen Symbolen sein (05.11.)
  if (document.documentElement.classList.contains("r2-frau") && document.documentElement.classList.contains("nur-tracking")) { window.CockpitApp.farbe("#F4EDE7", true); return; }
  const m = getComputedStyle(document.body).backgroundColor.match(/\d+/g); if (!m) return;
  const hex = "#" + m.slice(0, 3).map(x => (+x).toString(16).padStart(2, "0")).join("");
  window.CockpitApp.farbe(hex, 0.299 * m[0] + 0.587 * m[1] + 0.114 * m[2] > 150);
}
new MutationObserver(() => setTimeout(handyFarbe, 50)).observe(document.documentElement, {attributes: true, attributeFilter: ["data-theme", "class"]});
matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", () => setTimeout(handyFarbe, 50));
setTimeout(handyFarbe, 0);

/* ----- Handy-App: nicht zoomen (sonst rutscht die Leiste unten aus dem Bild) ----- */
if (window.CockpitApp){
  const m = document.querySelector('meta[name="viewport"]');
  if (m) m.content = "width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover";
}

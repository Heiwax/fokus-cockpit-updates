/* ---------- Wo deine Daten liegen (3.4): nur am Handy, auf dem eigenen Computer (Mac oder Windows) oder auf einem Online-Server ---------- */
// Seite Einstellungen › „Wo deine Daten liegen“. Zeigt den jetzigen Ort, erklärt die anderen Schritt für Schritt und zieht samt Daten um:
// Handy → Computer/Server: Export aus Python im Handy, per App an /api/umzug des Ziels, dann App auf das Ziel umstellen (CockpitApp.verbinden).
// Computer/Server → Handy: /api/export-json holen, im Handy einspielen, App auf „nur Handy“ (CockpitApp.nurHandy).
// Computer → Server oder anderer Computer: der Computer schickt selbst (/api/umzug-senden). Gegenrichtung über „Aus einer Sicherung übernehmen“.
const ORT = {wahl:null, system:null, laeuft:false, meldung:null, sicherung:null, adr:"", code:""};
const ORT_DOWNLOAD = "";   // Adresse des Computer-Pakets, sobald es eine Download-Seite gibt
const ORT_ARTEN = [
  {k:"handy", t:"Nur auf diesem Handy", kurz:"Handy", s:"Kein Computer, kein Konto, auch ohne Internet. Alles bleibt in der App."},
  {k:"computer", t:"Auf deinem Computer", kurz:"Computer", s:"Ein Mac oder Windows-PC zu Hause hält die Daten. Handys verbinden sich im WLAN. Dazu kommt die Bildschirmzeit vom Computer."},
  {k:"server", t:"Auf einem Online-Server", kurz:"Online-Server", s:"Ein gemieteter Server im Internet, ab etwa 4 € im Monat. Von überall erreichbar, kein Computer muss laufen."},
  {k:"sync", t:"Fokus Sync (Pro)", kurz:"Sync", s:"Jedes Gerät behält seine Daten und gleicht sie verschlüsselt über unseren Dienst ab. Kein Computer muss laufen, wir können nichts lesen."},
];
const ortJetzt = () => VB.modus === "handy" ? "handy" : S.serverModus === "server" ? "server" : "computer";

const ORT_PAKET = ORT_DOWNLOAD ? `Lade das Computer-Paket herunter: ${ORT_DOWNLOAD}`
  : "Hol dir das Computer-Paket „Fokus-Cockpit-Computer.zip“. Eine Download-Seite gibt es noch nicht: Du bekommst die Datei von der Person, von der du die App hast.";
const ORT_ANLEITUNG = {
  windows: [
    ["Computer-Paket holen", ORT_PAKET],
    ["Python installieren", "Auf python.org/downloads „Download Python“ antippen und den Installer öffnen. Wichtig: unten den Haken bei „Add python.exe to PATH“ setzen, dann „Install Now“."],
    ["Entpacken", "Rechtsklick auf die ZIP-Datei › „Alle extrahieren“. Den Ordner „Fokus-Cockpit“ zum Beispiel in „Dokumente“ legen."],
    ["Starten", "Im Ordner doppelklicken auf „Cockpit starten (Windows)“. Warnt Windows mit „Der Computer wurde durch Windows geschützt“: „Weitere Informationen“ › „Trotzdem ausführen“. Das schwarze Fenster offen lassen, minimieren geht."],
    ["Firewall erlauben", "Fragt die Windows-Firewall nach Python: „Private Netzwerke“ anhaken › „Zugriff zulassen“. Sonst findet das Handy den Computer nicht."],
    ["Einrichten", "Der Browser öffnet BlockEm. Dort fragt es nach deinem Namen und dem Ordner für deine Daten."],
    ["Bildschirmzeit und Sperren", "Zählt und sperrt BlockEm am PC selbst, nichts extra zu installieren. Für die Bild-KI einmal in der Eingabeaufforderung: py -m pip install numpy"],
    ["Immer an", "Doppelklick auf „Autostart einrichten (Windows)“: Dann startet BlockEm bei jeder Anmeldung von selbst."],
    ["Handy verbinden", "Am Computer in BlockEm: Einstellungen › Handys & Geräte. Dort stehen Adresse und Zugangscode. Beides in der Handy-App unter „Wo deine Daten liegen“ eintragen."],
  ],
  mac: [
    ["Computer-Paket holen", ORT_PAKET],
    ["Entpacken", "ZIP-Datei doppelklicken und den Ordner „Fokus-Cockpit“ in „Dokumente“ ziehen."],
    ["Starten", "Im Ordner Rechtsklick auf „Fokus-Cockpit“ (die App) › „Öffnen“ › „Öffnen“. Das braucht es nur beim ersten Mal, wegen der Sicherheitsabfrage von macOS. Fragt der Mac nach „Entwicklerwerkzeugen“: „Installieren“ und danach noch einmal öffnen."],
    ["Einrichten", "BlockEm geht auf. Es fragt nach deinem Namen und dem Ordner für deine Daten. Nutzt du Obsidian, kannst du deinen Vault nehmen."],
    ["Bildschirmzeit und Sperren", "Zählt und sperrt BlockEm am Mac selbst. macOS fragt einmal nach Bedienungshilfen, Automation und (für die Bild-KI) Bildschirmaufnahme: erlauben."],
    ["Immer an", "Doppelklick auf „autostart-einrichten.command“: Dann startet BlockEm bei jeder Anmeldung von selbst."],
    ["Handy verbinden", "Am Mac in BlockEm: Einstellungen › Handys & Geräte. Dort stehen Adresse und Zugangscode. Beides in der Handy-App unter „Wo deine Daten liegen“ eintragen. Mac und Handy müssen im selben WLAN sein."],
  ],
  server: [
    ["Server mieten", "Einen kleinen Linux-Server mit Ubuntu, zum Beispiel Hetzner Cloud CX22 (etwa 4 € im Monat, Standort Deutschland). Dazu eine Adresse wie cockpit.deine-domain.de."],
    ["Computer-Paket hochladen", ORT_PAKET + " Darin liegt die genaue Anleitung: server/ANLEITUNG-SERVER.md."],
    ["Starten", "Auf dem Server Docker installieren und im Ordner server „docker compose up -d --build“ ausführen. BlockEm holt sich selbst ein HTTPS-Zertifikat."],
    ["Zugangscode", "„docker compose logs cockpit“ zeigt den langen Zugangscode. Ohne ihn kommt niemand an deine Daten."],
    ["Verbinden", "Adresse (https://…) und Zugangscode unten eintragen. Traust du dir das nicht zu: Jemand, der sich mit Servern auskennt, braucht dafür etwa 15 Minuten."],
  ],
};

function ortAdresse(a){
  a = String(a || "").trim().replace(/\/+$/, "");
  if (a && !/^https?:\/\//.test(a)) a = "http://" + a;
  return a;
}
// Anfrage an ein anderes Cockpit über die App (ohne Browser-Sperren für fremde Adressen)
function ortHttp(methode, url, code, body){
  const kopf = {"X-Cockpit-Code": code}; if (body) kopf["Content-Type"] = "application/json";
  const r = JSON.parse(APP.http(methode, url, JSON.stringify(kopf), body ? btoa(body) : ""));
  let j = {}; try { j = JSON.parse(atob(r.daten || "") || "{}"); } catch {}
  if (!r.status) throw new Error("Das andere BlockEm ist nicht erreichbar. Läuft es, stimmt die Adresse, und ist das Handy im selben WLAN?");
  if (r.status === 403) throw new Error("Der Zugangscode passt nicht zu diesem BlockEm.");
  if (r.status >= 400) throw new Error(j.fehler || `Das andere BlockEm meldet Fehler ${r.status}.`);
  return j;
}
const ortWarten = (text) => { ORT.laeuft = text; ORT.meldung = null; renderSpeicherort(); return new Promise(r => setTimeout(r, 60)); };
function ortFertig(text, gut){ ORT.laeuft = false; ORT.meldung = {text, gut}; renderSpeicherort(); }
const ortSpeichernHandy = () => VB.py ? new Promise(ok => VB.py.FS.syncfs(false, () => ok())) : Promise.resolve();

// Handy → Computer oder Online-Server
async function ortVomHandy(adresse, code, mit){
  const url = ortAdresse(adresse);
  if (!url || !code.trim()) return ortFertig("Bitte Adresse und Zugangscode eintragen.");
  try {
    await ortWarten("Verbinde …");
    const st = ortHttp("GET", url + "/api/status", code.trim());
    if (!st.ok) throw new Error("Unter dieser Adresse antwortet kein BlockEm.");
    if (mit){
      await ortWarten("Deine Daten werden übertragen …");
      const ex = await vbHandy("api/export-json");
      const r = ortHttp("POST", url + "/api/umzug", code.trim(), JSON.stringify({zip: ex.zip}));
      toast(`Übertragen: ${r.notizen || 0} Notizen und ${Math.max(0, (r.dateien || 0) - (r.notizen || 0))} weitere Dateien.`);
    }
    if (APP.verbinden){ await ortWarten("Stelle die App um …"); APP.verbinden(adresse.trim(), code.trim()); return; }
    ortFertig("Daten sind drüben. Jetzt in den Handy-App-Einstellungen Adresse und Code eintragen.", true); APP.einstellungen?.();
  } catch (e) { ortFertig(e.message || String(e)); }
}
// Computer oder Online-Server → nur dieses Handy
async function ortAufsHandy(mit){
  try {
    if (mit){
      await ortWarten("Hole deine Daten aufs Handy …");
      const ex = await api("api/export-json");
      await ortWarten("Richte BlockEm im Handy ein …");
      await vbHandy("api/umzug", {zip: ex.zip});
      await ortSpeichernHandy();
    }
    if (APP.nurHandy){ await ortWarten("Stelle die App um …"); APP.nurHandy(); return; }
    ortFertig("Daten sind auf dem Handy. Jetzt in den Handy-App-Einstellungen „Nur auf diesem Handy“ wählen.", true); APP.einstellungen?.();
  } catch (e) { ortFertig(e.message || String(e)); }
}
// Computer → Online-Server oder anderer Computer (der Computer schickt selbst)
async function ortSenden(adresse, code){
  if (!ortAdresse(adresse) || !code.trim()) return ortFertig("Bitte Adresse und Zugangscode eintragen.");
  try {
    await ortWarten("Deine Daten werden übertragen …");
    const r = await api("api/umzug-senden", {ziel: adresse.trim(), code: code.trim()});
    if (VB.inApp && APP.verbinden){ toast(`Übertragen: ${r.notizen || 0} Notizen.`); await ortWarten("Stelle die App um …"); APP.verbinden(adresse.trim(), code.trim()); return; }
    ortFertig(`Fertig: ${r.notizen || 0} Notizen und deine Einstellungen sind jetzt auch dort. Öffne ab jetzt ${ortAdresse(adresse)}. In der Handy-App trägst du die neue Adresse und den neuen Code ein. Hier bleibt alles, wie es war.`, true);
  } catch (e) { ortFertig(e.message || String(e)); }
}

function ortSchritte(liste){
  const ol = el("ol","ort-schritte");
  liste.forEach(([t, x]) => { const li = el("li"); li.append(el("b", null, t), el("span", null, x)); ol.append(li); });
  return ol;
}
function ortForm(knopfText, fn, mitDaten){
  const f = el("form","ort-form"), adr = el("input"), code = el("input");
  adr.id = "ortAdresse"; adr.placeholder = ORT.wahl === "server" ? "https://cockpit.deine-domain.de" : "z. B. 192.168.178.20:8765";
  adr.inputMode = "url"; adr.autocomplete = "off"; adr.setAttribute("aria-label", "Adresse");
  code.id = "ortCode"; code.placeholder = "Zugangscode"; code.autocomplete = "off"; code.autocapitalize = "characters"; code.setAttribute("aria-label", "Zugangscode");
  adr.value = ORT.adr; code.value = ORT.code;
  adr.addEventListener("input", () => { ORT.adr = adr.value; }); code.addEventListener("input", () => { ORT.code = code.value; });
  f.append(eiZeile("Adresse", adr), eiZeile("Zugangscode", code));
  let mit = null;
  if (mitDaten){
    const l = el("label","ort-haken"); mit = el("input"); mit.type = "checkbox"; mit.checked = true; mit.id = "ortMit";
    l.append(mit, el("span", null, "Meine Daten mitnehmen (Aufgaben, Projekte, Habits, Einstellungen, Bildschirmzeit)"));
    f.append(l, el("p","k-s","Was dort schon liegt, wird vorher gesichert. Gleichnamige Notizen werden durch deine ersetzt."));
  }
  const ok = el("button","ask", ORT.laeuft || knopfText); ok.type = "submit"; ok.disabled = !!ORT.laeuft;
  f.append(ok);
  f.addEventListener("submit", e => { e.preventDefault(); fn(adr.value, code.value, mit ? mit.checked : true); });
  return f;
}

function ortDetail(){
  const jetzt = ortJetzt(), w = ORT.wahl, box = el("div","ort-detail"), inApp = VB.inApp && typeof APP !== "undefined" && !!APP?.http;
  if (!w) return null;
  if (w === "sync") return syncDetail(box, jetzt, inApp);
  if (w === "handy"){
    if (jetzt === "handy"){ box.append(el("p", null, "Deine Daten liegen schon nur auf diesem Handy.")); return box; }
    if (!inApp){
      box.append(el("p", null, "So kommen deine Daten auf ein Handy, das ohne Computer läuft:"), ortSchritte([
        ["Handy-App installieren", "und beim ersten Start mit diesem BlockEm verbinden (Adresse und Code unter Einstellungen › Handys & Geräte)."],
        ["Umziehen", "In der App: Einstellungen › Wo deine Daten liegen › „Nur auf diesem Handy“ › „Daten aufs Handy holen“."],
      ]), el("p","k-s", "Danach läuft alles im Handy. Dieser " + (jetzt === "server" ? "Server" : "Computer") + " behält seinen Stand, bekommt aber keine Änderungen mehr."));
      return box;
    }
    box.append(el("p", null, `Deine Daten kommen vom ${jetzt === "server" ? "Online-Server" : "Computer"} aufs Handy. Ab dann läuft alles nur hier, auch ohne Internet.`),
      el("p","k-s", `Der ${jetzt === "server" ? "Server" : "Computer"} behält seinen Stand, bekommt aber keine Änderungen mehr. Die Bildschirmzeit vom Computer fehlt dann.`));
    const l = el("label","ort-haken"), mit = el("input"); mit.type = "checkbox"; mit.checked = true; mit.id = "ortMitHandy";
    l.append(mit, el("span", null, "Meine Daten mitnehmen"));
    const b = eiKnopf(ORT.laeuft || "Daten aufs Handy holen und umstellen", "ask", () => ortAufsHandy(mit.checked)); b.disabled = !!ORT.laeuft;
    box.append(l, b); return box;
  }
  if (w === "computer"){
    const sys = el("div","chips ort-system"); sys.setAttribute("role","group"); sys.setAttribute("aria-label","Welcher Computer?");
    [["windows","Windows-PC"],["mac","Mac"]].forEach(([k, n]) => { const c = el("button","chip", n); c.type = "button"; c.setAttribute("aria-pressed", String(ORT.system === k)); c.addEventListener("click", () => { ORT.system = k; renderSpeicherort(); }); sys.append(c); });
    box.append(el("p","ort-frage","Was für ein Computer ist es?"), sys);
    if (!ORT.system) return box;
    box.append(ortSchritte(ORT_ANLEITUNG[ORT.system]));
  } else box.append(ortSchritte(ORT_ANLEITUNG.server));
  // Verbinden und umziehen, je nachdem, wo die Daten gerade liegen
  if (jetzt === "handy" && inApp) box.append(el("h3","ort-h","Verbinden und umziehen"), ortForm("Verbinden", ortVomHandy, true));
  else if (jetzt === "handy") box.append(el("p","k-s","Verbinden geht in der Handy-App."));
  else if (jetzt === "computer") box.append(el("h3","ort-h", w === "computer" ? "Auf einen anderen Computer umziehen" : "Deine Daten auf den Server schicken"),
    el("p","k-s", "Dieser Computer schickt alles hinüber und behält seinen Stand."), ortForm("Daten hinüberschicken", (a, c) => ortSenden(a, c), false));
  else box.append(el("h3","ort-h","Deine Daten mitnehmen"), el("p", null, "Ein Online-Server kann deinen Computer zu Hause nicht erreichen. Darum so:"), ortSchritte([
    ["Sichern", "Hier unter Einstellungen › Daten & Export „Alle Daten exportieren (ZIP)“."],
    ["Übernehmen", "Am Computer: Einstellungen › Wo deine Daten liegen › „Aus einer Sicherung übernehmen“ und die ZIP-Datei wählen."],
    ["Umstellen", "In der Handy-App die Adresse und den Code vom Computer eintragen."],
  ]));
  return box;
}

// Eine Sicherung (Export-ZIP) hier einspielen, z. B. vom Online-Server auf den Computer
function ortSicherung(){
  const box = el("details","more ort-sicherung"), inp = el("input"), sum = el("summary", null, "Aus einer Sicherung übernehmen");
  if (ORT.sicherung) box.open = true;
  inp.type = "file"; inp.accept = ".zip,application/zip"; inp.id = "ortZip"; inp.setAttribute("aria-label","Sicherung (ZIP) wählen");
  box.append(sum, el("p","k-s","Eine ZIP-Datei aus „Alle Daten exportieren“, von einem anderen Gerät. Was hier liegt, wird vorher gesichert; gleichnamige Notizen und Einstellungen werden ersetzt."), inp);
  const los = eiKnopf("Ja, übernehmen", "ask small", async () => {
    const f = inp.files?.[0]; if (!f) return;
    try {
      await ortWarten("Spiele die Sicherung ein …");
      const b64 = await new Promise((ok, nein) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(",")[1] || ""); r.onerror = () => nein(new Error("Datei nicht lesbar")); r.readAsDataURL(f); });
      const r = await api("api/umzug", {zip: b64});
      if (VB.modus === "handy") await ortSpeichernHandy();
      ORT.sicherung = null; await loadLocal().catch(() => {});
      ortFertig(`Übernommen: ${r.notizen || 0} Notizen und ${Math.max(0, (r.dateien || 0) - (r.notizen || 0))} weitere Dateien. Der alte Stand liegt als Sicherung daneben.`, true);
    } catch (e) { ortFertig(e.message || String(e)); }
  });
  los.disabled = !!ORT.laeuft;
  inp.addEventListener("change", () => { ORT.sicherung = inp.files?.[0]?.name || null; los.hidden = !ORT.sicherung; });
  los.hidden = true;
  box.append(los);
  return box;
}

function renderSpeicherort(){
  const box = $("ortBox"); if (!box || !S.plan) return;
  const jetzt = ortJetzt();
  const wahl = el("div","ein-wahl ort-wahl");
  ORT_ARTEN.filter(a => a.k !== "sync" || SYNC.st?.sichtbar).forEach(a => {
    const b = el("button","ein-opt" + (ORT.wahl === a.k ? " an" : "")); b.type = "button";
    const kopf = el("b"); kopf.append(a.t); if (a.k === jetzt || (a.k === "sync" && SYNC.st?.an)) kopf.append(el("span","ort-jetzt", a.k === "sync" ? "an" : "jetzt"));
    b.append(kopf, el("span","k-s", a.s));
    b.addEventListener("click", () => { ORT.wahl = ORT.wahl === a.k ? null : a.k; ORT.meldung = null; renderSpeicherort(); });
    wahl.append(b);
  });
  const teile = [el("p","k-s ort-einl","Du kannst jederzeit umziehen. Deine Daten kommen mit.")];
  teile.push(wahl);
  if (ORT.meldung) teile.push(el("p", "ort-meldung " + (ORT.meldung.gut ? "gut" : "schlecht"), ORT.meldung.text));
  const d = ortDetail(); if (d) teile.push(d);
  if (ORT.laeuft) teile.push(el("p","ort-laeuft", ORT.laeuft));
  teile.push(ortSicherung());
  box.replaceChildren(...teile);
}
function ortOeffnen(wahl){ if (wahl) ORT.wahl = wahl; ORT.meldung = null; esOeffnen("speicherort"); renderSpeicherort(); syncLaden(); }
const _renderAutomatikOrt = renderAutomatik;
// Beim Neuladen des Plans (jede Minute) nur zeichnen, wenn die Seite gerade nicht offen ist: sonst gehen Eingaben verloren
renderAutomatik = function(){ _renderAutomatikOrt(); const b = $("ortBox"); if (b && (!b.childElementCount || b.closest(".es-page")?.hidden)) renderSpeicherort(); };

/* ---------- Fokus Sync (Pro, 3.12): Konto beim Sync-Dienst, Ende-zu-Ende verschlüsselt ---------- */
// Python (server.py, Abschnitt „Fokus Sync“) macht Schlüssel, Verschlüsselung und Abgleich; hier nur Anmelden, Status, Geräte.
// Am Computer gleicht ein Hintergrund-Faden jede Minute ab, im Handy (nur auf diesem Handy) stößt syncTakt() alle 2 Minuten an.
const SYNC = {st:null, konto:null, art:"neu", code:null, email:"", adr:"", name:""};
async function syncLaden(){
  try { SYNC.st = await api("api/sync"); } catch { SYNC.st = null; }
  if (ORT.wahl === "sync" || SYNC.st?.sichtbar) renderSpeicherort();
}
async function syncAktion(daten, warteText){
  try {
    await ortWarten(warteText || "Einen Moment …");
    const r = await api("api/sync", daten);
    SYNC.st = r; if (r.konto) SYNC.konto = r.konto;
    if (r.notfallCode) SYNC.code = r.notfallCode;
    if (VB.modus === "handy") await ortSpeichernHandy();
    if (r.geholt) await loadLocal().catch(() => {});
    ortFertig(r.hinweis || (r.fehler ? r.fehler : daten.aktion === "jetzt" ? `Abgeglichen: ${r.geholt || 0} geholt, ${r.hoch || 0} hochgeladen.` : "Angemeldet. Deine Geräte gleichen sich ab jetzt ab."), !r.fehler);
  } catch (e) { ortFertig(e.message || String(e)); }
}
function syncFeld(titel, typ, wert, platz, fn){
  const i = el("input"); i.type = typ; i.value = wert || ""; i.placeholder = platz || ""; i.autocomplete = typ === "password" ? "current-password" : "off";
  i.setAttribute("aria-label", titel); i.addEventListener("input", () => fn(i.value));
  return [eiZeile(titel, i), i];
}
function syncZeit(iso){ if (!iso) return "noch nie"; const d = new Date(iso); return d.toLocaleDateString("de-DE", {day:"2-digit", month:"2-digit"}) + ", " + d.toLocaleTimeString("de-DE", {hour:"2-digit", minute:"2-digit"}); }
function syncDetail(box, jetzt, inApp){
  const st = SYNC.st;
  if (!st){ box.append(el("p","k-s","Lade …")); syncLaden(); return box; }
  // Neuer Notfall-Code: genau einmal zeigen
  if (SYNC.code){
    box.append(el("h3","ort-h","Dein Notfall-Code"), el("p", null, "Schreib ihn auf Papier oder leg ihn in deinen Passwort-Manager. Hast du dein Passwort vergessen, kommst du nur mit diesem Code wieder an deine Daten. Wir können ihn nicht wiederherstellen."),
      el("p","sync-code", SYNC.code));
    const r = el("div","chips");
    r.append(eiKnopf("Kopieren","ghost small", () => navigator.clipboard?.writeText(SYNC.code).then(() => toast("Kopiert")).catch(() => {})),
      eiKnopf("Ich habe ihn sicher aufgeschrieben","ask small", () => { SYNC.code = null; renderSpeicherort(); }));
    box.append(r); return box;
  }
  box.append(el("p", null, "Mit BlockEm Sync behält jedes Gerät seine Daten selbst und gleicht sie über unseren Dienst ab. Alles wird schon auf dem Gerät verschlüsselt: Wir sehen weder deine Daten noch dein Passwort."));
  if (VB.inApp && jetzt !== "handy"){
    box.append(el("p","k-s", `Dieses Handy holt seine Daten gerade vom ${jetzt === "server" ? "Online-Server" : "Computer"}. Für BlockEm Sync wähle oben erst „Nur auf diesem Handy“ (deine Daten kommen mit) und melde dich dann hier an. Oder melde den Computer an: Dann sind alle Handys, die mit ihm verbunden sind, automatisch dabei.`));
    return box;
  }
  if (st.an){
    const info = el("div","sync-info");
    info.append(el("p", null, `Angemeldet als ${st.email}. Dieses Gerät heißt „${st.geraetName}“.`),
      el("p","k-s", `Zuletzt abgeglichen: ${syncZeit(st.zuletzt)} · ${st.dateien} Dateien` + (st.proBis ? ` · Pro bis ${new Date(st.proBis).toLocaleDateString("de-DE")}` : "")));
    if (st.fehler) info.append(el("p","ort-meldung schlecht", st.fehler));
    box.append(info);
    const knoepfe = el("div","chips");
    knoepfe.append(eiKnopf(ORT.laeuft || "Jetzt abgleichen","ask small", () => syncAktion({aktion:"jetzt"}, "Gleiche ab …")),
      eiKnopf("Geräte","ghost small", () => syncAktion({aktion:"konto"}, "Hole deine Geräte …")));
    box.append(knoepfe);
    if (SYNC.konto){
      const ul = el("ul","sync-geraete");
      SYNC.konto.geraete.forEach(g => {
        const li = el("li"); li.append(el("span", null, g.name + (g.dieses ? " (dieses Gerät)" : "")), el("span","k-s", "zuletzt " + syncZeit(g.zuletzt)));
        if (!g.dieses) li.append(eiKnopf("Entfernen","ghost small", () => { if (confirm(`„${g.name}“ abmelden? Das Gerät behält seine Daten, gleicht aber nicht mehr ab.`)) syncAktion({aktion:"geraetEntfernen", id:g.id}, "Entferne …"); }));
        ul.append(li);
      });
      box.append(ul);
    }
    const pw = el("details","more"), pwf = el("form","ort-form");
    pw.append(el("summary", null, "Passwort ändern"));
    let alt = "", neu = "", andere = false;
    const [z1] = syncFeld("Altes Passwort","password","","",v => alt = v), [z2, i2] = syncFeld("Neues Passwort","password","","mindestens 10 Zeichen",v => neu = v);
    i2.autocomplete = "new-password";
    const l = el("label","ort-haken"), h = el("input"); h.type = "checkbox"; h.addEventListener("change", () => andere = h.checked);
    l.append(h, el("span", null, "Alle anderen Geräte abmelden"));
    const ok = el("button","ask","Passwort ändern"); ok.type = "submit";
    pwf.append(z1, z2, l, ok); pwf.addEventListener("submit", e => { e.preventDefault(); syncAktion({aktion:"passwort", alt, neu, andereAbmelden:andere}, "Ändere das Passwort …"); });
    pw.append(pwf); box.append(pw);
    const weg = el("details","more"), wegf = el("form","ort-form");
    weg.append(el("summary", null, "Abmelden oder Konto löschen"));
    let pwWeg = "";
    const [z3] = syncFeld("Passwort (nur zum Löschen)","password","","",v => pwWeg = v);
    const ab = eiKnopf("Dieses Gerät abmelden","ghost small", () => syncAktion({aktion:"abmelden"}, "Melde ab …"));
    const lo = el("button","ghost small danger","Konto und alle Daten im Sync-Dienst löschen"); lo.type = "submit";
    wegf.append(el("p","k-s","Deine Daten auf den Geräten bleiben immer erhalten. Gelöscht wird nur, was beim Sync-Dienst liegt."), ab, z3, lo);
    wegf.addEventListener("submit", e => { e.preventDefault(); if (confirm("Konto wirklich löschen? Die Geräte gleichen danach nicht mehr ab.")) syncAktion({aktion:"kontoLoeschen", passwort:pwWeg}, "Lösche das Konto …"); });
    weg.append(wegf); box.append(weg);
    return box;
  }
  if (st.abgemeldet) box.append(el("p","ort-meldung schlecht","Dieses Gerät wurde abgemeldet, zum Beispiel weil das Passwort neu gesetzt wurde. Bitte melde dich neu an."));
  const arten = el("div","chips"); arten.setAttribute("role","group");
  [["neu","Neues Konto"],["anmelden","Anmelden"],["notfall","Passwort vergessen"]].forEach(([k, n]) => {
    const c = el("button","chip", n); c.type = "button"; c.setAttribute("aria-pressed", String(SYNC.art === k));
    c.addEventListener("click", () => { SYNC.art = k; renderSpeicherort(); }); arten.append(c);
  });
  box.append(arten);
  const f = el("form","ort-form");
  let pw = "", code = "";
  if (!st.standard){ const [z] = syncFeld("Adresse des Dienstes","url", SYNC.adr || st.adresse,"https://sync.…",v => SYNC.adr = v); f.append(z); }
  const [ze, ie] = syncFeld("E-Mail","email", SYNC.email || st.email,"du@beispiel.de",v => SYNC.email = v); ie.autocomplete = "email"; f.append(ze);
  if (SYNC.art === "notfall"){ const [z] = syncFeld("Notfall-Code","text","","XXXXX-XXXXX-…",v => code = v); f.append(z); }
  const [zp, ip] = syncFeld(SYNC.art === "anmelden" ? "Passwort" : "Neues Passwort","password","", SYNC.art === "anmelden" ? "" : "mindestens 10 Zeichen",v => pw = v);
  if (SYNC.art !== "anmelden") ip.autocomplete = "new-password";
  f.append(zp);
  const [zn] = syncFeld("Name dieses Geräts","text", SYNC.name || st.geraetName || (VB.modus === "handy" ? "Handy" : /Win/.test(navigator.platform) ? "Windows-PC" : "Mac"),"z. B. Pixel 8",v => SYNC.name = v);
  f.append(zn);
  f.append(el("p","k-s", SYNC.art === "neu" ? "Danach bekommst du einen Notfall-Code. Er ist der einzige Weg zurück, wenn du dein Passwort vergisst. 7 Tage gratis, danach gehört Sync zu Pro."
    : SYNC.art === "notfall" ? "Mit dem Notfall-Code setzt du ein neues Passwort. Alle anderen Geräte werden abgemeldet und brauchen das neue Passwort."
    : "Was schon auf diesem Gerät liegt, wird mit dem Konto zusammengeführt. Doppelt Geändertes landet vorher in der Sicherung."));
  const ok = el("button","ask", ORT.laeuft || (SYNC.art === "neu" ? "Konto anlegen" : SYNC.art === "notfall" ? "Neues Passwort setzen" : "Anmelden")); ok.type = "submit"; ok.disabled = !!ORT.laeuft;
  f.append(ok);
  f.addEventListener("submit", e => {
    e.preventDefault();
    const name = SYNC.name || f.querySelector('input[aria-label="Name dieses Geräts"]').value;
    syncAktion({aktion: SYNC.art === "neu" ? "registrieren" : SYNC.art, adresse: SYNC.adr || st.adresse, email: SYNC.email || st.email, passwort: pw, code, geraet: name},
      VB.modus === "handy" ? "Erzeuge die Schlüssel, das dauert im Handy bis zu 30 Sekunden …" : "Erzeuge die Schlüssel …");
  });
  box.append(f);
  return box;
}
// Im Handy ohne Computer: alle 2 Minuten (und beim Öffnen) abgleichen, solange angemeldet
async function syncTakt(){
  if (VB.modus !== "handy" || document.hidden) return;
  try {
    if (!SYNC.st) SYNC.st = await api("api/sync");
    if (!SYNC.st?.an) return;
    const r = await api("api/sync", {aktion:"jetzt"});
    SYNC.st = r;
    if (r.geholt || r.hoch) await ortSpeichernHandy();
    if (r.geholt) await loadLocal().catch(() => {});
  } catch {}
}
setTimeout(syncTakt, 8000); setInterval(syncTakt, 120000);
document.addEventListener("visibilitychange", () => { if (!document.hidden) syncTakt(); });

/* ---------- Bedienung ---------- */
$("dashMore").addEventListener("click", () => { showTab("werte"); wtZeigen("heute"); window.scrollTo(0, 0); });
$("reiter").addEventListener("click", e => {
  const b = e.target.closest("button[data-r]"); if (!b) return;
  // Projekte nochmal antippen: zurück zur Projektliste
  if (b.dataset.r === "projekte" && b.getAttribute("aria-selected") === "true" && PV.p){ PV.p = PV.ph = null; PV.anim = true; renderPlan(); }
  showTab(b.dataset.r);
});
window.addEventListener("popstate", () => { PV.anim = true; pvFromHash(); const r = location.hash.slice(1).split("/")[0]; if (REITER.includes(r)) showTab(r); renderPlan(); window.scrollTo(0, 0); });
pvFromHash();
document.addEventListener("click", e => { const b = e.target.closest(".plan-btn[data-plan]"); if (b) openPlaner(b.dataset.plan); });
showTab(REITER.includes(location.hash.slice(1).split("/")[0]) ? location.hash.slice(1).split("/")[0] : store("cockpit.reiter") || "heute");
$("taskForm").addEventListener("submit", e => { e.preventDefault(); const t = $("taskText").value.trim(); if (t){ $("taskText").value = ""; addItem("heute", t, $("taskProj").value); } });
$("askBtn").addEventListener("click", askClaude);
$("fkProj").addEventListener("change", () => fkTasks());
$("fkStart").addEventListener("click", () => { store("cockpit.fokusProj", $("fkProj").value);
  fkAction({aktion:"start", projekt:$("fkProj").value || null, aufgabe:$("fkTask").value || null, minuten:FK.dur}); });
$("fkStop").addEventListener("click", () => {
  const b = $("fkStop");
  if (FK.stopArmed){ clearTimeout(FK.stopArmed); FK.stopArmed = null; b.textContent = "Beenden"; fkAction({aktion:"stop"}); return; }
  b.textContent = "Wirklich beenden?"; FK.stopArmed = setTimeout(() => { FK.stopArmed = null; b.textContent = "Beenden"; }, 4000);
});
fkDurChips();
$("plOk").addEventListener("click", savePlaner);
$("plClaude").addEventListener("click", () => copyToast({
  monat:`Lass uns meinen Monat planen (${MONATE[NOW.getMonth()]}). Schlag mir für die Projekte, an denen ich diesen Monat arbeite, je eine Phase vor, stell mir Fragen und trag sie in BlockEm ein.`,
  woche:`Lass uns meine Woche planen (KW ${planKw()}). Schlag mir bis zu 3 Meilensteine aus meinen Phasen für diesen Monat als Wochenziele vor, stell mir Fragen dazu und trag sie in BlockEm ein.`,
  heute:"Lass uns meinen Tag planen. Schau auf meine Wochenziele und schlag mir vor, woran ich heute arbeite."}[PL.mode]));
$("plClose").addEventListener("click", () => $("planer").close());
$("plCancel").addEventListener("click", () => $("planer").close());
$("setBtn").addEventListener("click", () => { showTab("einstellungen"); window.scrollTo(0, 0); });
document.addEventListener("click", e => { const b = e.target.closest("[data-zu]"); if (b){ showTab(b.dataset.zu); window.scrollTo(0, 0); } });
$("settings").addEventListener("submit", e => { e.preventDefault();
  S.goalMin = Math.max(1, +$("setGoal").value || 180); S.limitMin = Math.max(1, +$("setLimit").value || 60);
  store("cockpit.ziele", {goalMin:S.goalMin, limitMin:S.limitMin}); $("settings").hidden = true; renderDay(); renderWeek(); limitAbgleich(); });

(async () => {
  const saved = store("cockpit.ziele"); if (saved){ S.goalMin = saved.goalMin; S.limitMin = saved.limitMin; }
  renderHeader();
  // 1. Cockpit-Server (Mac, WLAN, online) oder in der Handy-App ohne Server: Python im Handy. Zuerst sofort den letzten Stand zeigen.
  const zuletzt = vbCache("api/plan");
  if (VB.inApp && zuletzt){ S.mode = "lokal"; S.plan = zuletzt; renderPlan(); }
  try {
    const st = VB.modus === "handy" ? await vbHandy("api/status") : await vbServer("api/status", null, VB.inApp ? 6000 : 2500);
    if (st && st.ok){
      S.mode = "lokal"; S.serverModus = st.modus || "mac";
      if (!VB.inApp){
        const m = document.createElement("link"); m.rel = "manifest"; m.href = "manifest.webmanifest"; document.head.append(m);
        if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
      }
      await loadLocal();
      if (VB.modus === "handy"){ vbHandyNutzung().then(() => loadLocal()).catch(() => {}); setInterval(() => vbHandyNutzung().catch(() => {}), 300000); vbSperreAbgleich().catch(() => {}); }
      else vbNachreichen();
      setInterval(() => iso(new Date()) !== TODAY ? location.reload() : loadLocal().catch(e => { S.fehler = [VB.offline ? "Offline: du siehst den letzten Stand." : "BlockEm-Server nicht erreichbar. Läuft er noch?"]; renderHeader(); }), 60000);
      $("foot").textContent = VB.modus === "handy" ? "Deine Daten liegen nur auf diesem Handy. Sichern: Einstellungen › Deine Daten."
        : S.serverModus === "server" ? "Daten: dein BlockEm-Server, alle 60 Sekunden aktualisiert."
        : "Daten: eigener Zähler am Computer und dein Obsidian-Vault, alle 60 Sekunden aktualisiert. Kategorien änderst du in kategorien.json.";
      return;
    }
  } catch (e) {
    if (e.zugang && !VB.inApp){ vbAnmelden(CODE ? "Der Zugangscode stimmt nicht." : ""); return; }
    if (VB.inApp){
      vbStartText(e.zugang ? "Der Zugangscode stimmt nicht. Trag ihn in der Handy-App neu ein." : "BlockEm-Server nicht erreichbar und noch kein gespeicherter Stand. Ist das Handy im selben WLAN wie der Mac (bzw. online)?", true);
      return;
    }
  }
  // 2. Als Claude-Artefakt: Aufgaben, Ziele, Projekte aus der BlockEm-Datenbank
  S.day = demoDay(TODAY, NOW.getHours()); S.week = demoWeek(); S.plan = DEMO_PLAN;
  renderDay(); renderWeek(); renderPlan(); renderHeader(); renderFokus();
  if (window.claude?.use){
    const [db, sample] = await Promise.all([window.claude.use("db"), window.claude.use("sample")]);
    if (sample){ S.sample = sample; $("askBtn").hidden = false; }
    if (db){ S.mode = "claude"; startClaude(db); renderHeader();
      $("foot").textContent = "Aufgaben, Ziele und Projekte kommen aus der BlockEm-Datenbank, die Claude mit deinem Vault abgleicht."; }
  }
})();
// Handy-App: Einstellungen über die Kopfzeile statt über einen schwebenden Knopf (ab App 1.2)
if (window.CockpitApp){ $("appSet").hidden = false; $("appSet").addEventListener("click", () => window.CockpitApp.einstellungen()); }
// Neue Handy-App da? Zwei Quellen (ab 3.0 bringt die App das Cockpit selbst mit, darum zählt nicht diese Datei):
// 1. der verbundene Computer/Server (S.plan.profil.version, Update lädt dessen handy.apk),
// 2. der eigene Update-Check (3.4): eine Versions-Datei im Internet, alle 6 Std, auch ganz ohne Computer (für Tester ohne Play Store).
//    Format: {"version":"3.4","apk":"https://…/handy.apk","neu":"Was neu ist"}. Nicht in der Play-Store-Fassung.
// HANDY_APP bei jedem neuen Build von handy.apk hochzählen (gleich wie VERSION in MainActivity.java und APP_VERSION in server.py)
const HANDY_APP = "3.31";
const UPDATE_QUELLE = "https://raw.githubusercontent.com/Heiwax/fokus-cockpit-updates/main/version.json";   // öffentliches Update-Repo (store/update-vorbereiten.sh)
const vTupel = v => { const t = (String(v || "").match(/\d+/g) || []).slice(0, 3).map(Number); if (t.length && t[0] < 3) t[0] += 10; return t; };   // 1.0: Zählung fing neu an, 1.x zählt als 11.x (wie server version_tupel)
const vAelter = (a, b) => { const x = vTupel(a), y = vTupel(b); for (let i = 0; i < 3; i++){ if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) < (y[i] || 0); } return false; };
function updateOnline(nurGemerkt){
  const quelle = store("cockpit.updateQuelle") || UPDATE_QUELLE, A = window.CockpitApp;
  if (!quelle || !A?.http || A.play?.()) return null;
  const c = store("cockpit.updateCheck");
  if (c && c.quelle === quelle && Date.now() - c.zeit < 6 * 3600e3) return c.info;
  // Die Anfrage blockiert kurz: nicht beim Zeichnen, sondern ein paar Sekunden später
  if (nurGemerkt){ if (!updateOnline.geplant) updateOnline.geplant = setTimeout(() => { updateOnline(); updateOnline.geplant = 0; appUpdatePruefen(); }, 4000); return c?.info || null; }
  let info = null;
  try {
    const r = JSON.parse(A.http("GET", quelle + (quelle.includes("?") ? "&" : "?") + "t=" + Date.now(), "{}", ""));
    if (r.status === 200){ const j = JSON.parse(decodeURIComponent(escape(atob(r.daten || "")))); if (j && j.version && /^https:\/\//.test(j.apk || "")) info = {version:String(j.version), apk:j.apk, neu:String(j.neu || "").slice(0, 300)}; }
    updateOnline.fehler = info ? "" : (r.fehler || "Antwort " + r.status);
  } catch (e) { updateOnline.fehler = String(e?.message || e); }
  store("cockpit.updateCheck", {zeit: Date.now(), quelle, info: info || c?.info || null});
  return info || c?.info || null;
}
function appUpdatePruefen(){
  const box = $("appUpd"), A = window.CockpitApp, app = A?.version?.() || "";
  if (!box || !A) return;
  const server = VB.modus === "handy" ? "" : S.plan?.profil?.version || "";
  const online = updateOnline(true);
  // die neueste Quelle gewinnt; bei Gleichstand der verbundene Computer (geht auch ohne Internet)
  let neu = "", weg = null;
  if (server && vAelter(app, server)){ neu = server; weg = "server"; }
  if (online && vAelter(app, online.version) && (!neu || vAelter(neu, online.version))){ neu = online.version; weg = "online"; }
  if (!neu){ box.hidden = true; return; }
  if (box.dataset.v === neu + weg){ box.hidden = false; return; }
  box.dataset.v = neu + weg;
  const txt = el("span", null, `Neue Version der Handy-App (${neu}) ist da. Du hast ${app || "eine ältere"}.` + (weg === "online" && online.neu ? ` Neu: ${online.neu}` : ""));
  const knopf = fn => { const b = el("button","ask", "Update installieren"); b.type = "button"; b.addEventListener("click", fn); return b; };
  if (updKann() && (weg === "server" || A.updateVon)) box.replaceChildren(txt, knopf(() => updFenster(neu, weg === "online" ? online.apk : "", weg)));   // 3.15: Update-Fenster
  else if (weg === "online" && A.updateVon) box.replaceChildren(txt, knopf(() => A.updateVon(online.apk)));
  else if (weg === "server" && A.update) box.replaceChildren(txt, knopf(() => A.update()));
  else box.replaceChildren(txt, el("span", null, ` Einmal von Hand: im Handy-Browser ${weg === "online" ? online.apk : VB.inApp ? "die Adresse von BlockEm mit /handy.apk am Ende" : location.origin + "/handy.apk"} öffnen und installieren. Danach geht es hier mit einem Knopf.`));
  if (updKann() && updAutoSperre()) box.append(el("span", "k-s", "Samsung: Ist die Automatische Sperre an, vorher kurz ausschalten."));
  box.hidden = false;
}
// Knopf „Nach Updates suchen“ (Mehr-Blatt und Einstellungen › Systemcheck): fragt sofort statt erst nach 6 Std
function updateSuchen(){
  const A = window.CockpitApp;
  if (!A?.http || A.play?.()){ toast("Updates kommen über den Play Store."); return; }
  store("cockpit.updateCheck", null);
  const online = updateOnline(), app = A.version?.() || "";
  appUpdatePruefen();
  // 3.18: neuere Version auf dem verbundenen Computer (noch nicht auf GitHub) zählt auch
  const amPc = VB.modus === "handy" ? "" : S.plan?.profil?.version || "";
  if (amPc && vAelter(app, amPc) && !(online && vAelter(amPc, online.version))){
    if (updKann()) updFenster(amPc, "", "server"); else { toast(`Version ${amPc} ist auf deinem Computer. Oben auf „Update installieren“ tippen.`); window.scrollTo(0, 0); }
    return;
  }
  if (online && vAelter(app, online.version) && updKann()) updFenster(online.version, online.apk, "online");
  else if (online && vAelter(app, online.version)) { toast(`Version ${online.version} ist da. Oben auf „Update installieren“ tippen.`); window.scrollTo(0, 0); }
  else if (online && !updateOnline.fehler) toast(`Du hast die neueste Version (${app}).`);
  else toast(`Update-Server nicht erreichbar${updateOnline.fehler ? " (" + updateOnline.fehler.slice(0, 120) + ")" : ""}. Bist du online? Sonst die neue App von Hand laden: ${UPDATE_QUELLE.replace("version.json", "handy.apk")}`);
}
function updateKnopf(){
  const box = $("updSuche"); if (!box) return;
  box.hidden = !window.CockpitApp?.http || !!window.CockpitApp.play?.();
  if (box.hidden || box.firstChild) return;
  const b = el("button","ghost small","Nach Updates suchen"); b.type = "button"; b.addEventListener("click", updateSuchen);
  box.append(el("span","k-s",`Handy-App ${window.CockpitApp.version?.() || ""}`), b);
}
updateKnopf();
const _renderAutomatikUpd = renderAutomatik;
renderAutomatik = function(){ _renderAutomatikUpd(); appUpdatePruefen(); };

$("laeuftChip")?.addEventListener("click", () => esOeffnen("status"));

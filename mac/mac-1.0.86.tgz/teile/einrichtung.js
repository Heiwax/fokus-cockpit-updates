/* ---------- Ersteinrichtung: beim ersten Start in 5 Schritten (Name, Datenordner, Mein Tag, KI, Kalender) ---------- */
// Kommt nur, solange in config.json "eingerichtet" fehlt und es noch keine Cockpit-Notiz gibt. Jeder Schritt lässt sich überspringen.
const EIN = {schritt:1, nur:false, zu:false, wahl:null, pfad:""};
const EIN_SCHRITTE = 6;
function einrichtungPruefen(){
  const pr = S.plan?.profil;
  if (S.mode !== "lokal" || !pr || pr.eingerichtet || EIN.zu || $("einDialog")?.open) return;
  einrichtungOeffnen(1);
}
function einrichtungOeffnen(schritt, nur){
  EIN.schritt = schritt || 1; EIN.nur = !!(nur ?? (schritt === 2 && S.plan?.profil?.eingerichtet));
  let d = $("einDialog");
  if (!d){ d = el("dialog","planer modern ein-dialog"); d.id = "einDialog"; d.setAttribute("aria-labelledby","einTitel");
    d.addEventListener("cancel", e => { e.preventDefault(); einZu(); }); document.body.append(d); }
  einZeichnen(); if (!d.open) d.showModal();
}
function einZu(){ EIN.zu = true; $("einDialog")?.close(); }
async function einWeiter(body, pfad = "api/einstellungen"){
  try { if (body) { const r = await api(pfad, body); if (r?.heute) S.plan = r; renderPlan(); } }
  catch (e){ toast(e.message || String(e)); return false; }
  if (EIN.nur){ einZu(); return true; }
  EIN.schritt++; if (EIN.schritt > EIN_SCHRITTE) return einFertig();
  einZeichnen(); return true;
}
async function einFertig(){
  try { S.plan = await api("api/einstellungen", {eingerichtet:true}); } catch {}
  einZu(); renderPlan(); toast("Fertig eingerichtet. Viel Fokus!");
}
function einZeichnen(){
  const d = $("einDialog"), pr = S.plan?.profil || {}, ki = S.plan?.ki || {};
  const kopf = el("div","ein-kopf"), titel = el("h2"); titel.id = "einTitel";
  const punkte = el("div","ein-punkte"); if (!EIN.nur) for (let i = 1; i <= EIN_SCHRITTE; i++) punkte.append(el("i", i <= EIN.schritt ? "an" : ""));
  const inhalt = el("div","ein-inhalt"), fuss = el("div","ein-fuss");
  const weiter = (text, fn) => { const b = eiKnopf(text, "ask", fn); fuss.append(b); return b; };
  const spaeter = (text = "Später") => fuss.append(eiKnopf(text, "ghost small", () => einWeiter(null)));
  switch (EIN.schritt){
    case 1: {
      titel.textContent = "Willkommen in BlockEm";
      inhalt.append(el("p", null, "BlockEm weiß, was du dir vorgenommen hast, sieht, was du wirklich tust, und hält dich auf allen Geräten dabei. Alles bleibt auf deinem Gerät."),
        el("p","k-s","In ein paar kurzen Schritten ist es eingerichtet. Jeder Schritt geht auch später in den Einstellungen."));
      const inp = el("input"); inp.value = pr.name || ""; inp.placeholder = "Dein Vorname"; inp.maxLength = 40; inp.setAttribute("aria-label","Dein Vorname");
      inhalt.append(eiZeile("Wie heißt du?", inp));
      weiter("Los geht's", () => einWeiter({name:inp.value}));
      setTimeout(() => inp.focus(), 50); break;
    }
    case 2: {
      if (VB.modus === "handy" && VB.inApp){
        // Erste Frage am Handy: Wo sollen die Daten liegen? Computer und Online-Server führen zur Anleitung samt Umzug.
        titel.textContent = "Wo sollen deine Daten liegen?";
        inhalt.append(el("p","k-s","Du kannst später jederzeit umziehen. Deine Daten kommen dann mit."));
        const wahl = el("div","ein-wahl ort-wahl");
        ORT_ARTEN.forEach(a => {
          const b = el("button","ein-opt" + (a.k === "handy" ? " an" : "")); b.type = "button";
          b.append(el("b", null, a.t + (a.k === "handy" ? " (zum Start am einfachsten)" : "")), el("span","k-s", a.s));
          b.addEventListener("click", () => { if (a.k === "handy") return einWeiter(null); einZu(); ortOeffnen(a.k); });
          wahl.append(b);
        });
        inhalt.append(wahl); break;
      }
      if (VB.modus === "handy" || S.serverModus === "server"){
        titel.textContent = "Wo deine Daten liegen";
        inhalt.append(el("p", null, VB.modus === "handy" ? "Alles bleibt auf diesem Handy: Aufgaben, Ziele, Projekte, Habits und deine Bildschirmzeit. Kein Konto, kein Server."
          : "Deine Daten liegen auf deinem eigenen BlockEm-Server. Jedes Gerät mit dem Zugangscode sieht denselben Stand."),
          el("p","k-s", VB.modus === "handy" ? "Später kannst du das Handy mit BlockEm auf deinem Mac oder einem eigenen Server verbinden (oben „Handy-App“). Sichern geht jederzeit unter Einstellungen › Deine Daten." : "Sichern: Einstellungen › Deine Daten (Export als ZIP)."));
        weiter("Weiter", () => einWeiter(null)); break;
      }
      titel.textContent = "Wo sollen deine Daten liegen?";
      inhalt.append(el("p","k-s","Aufgaben, Ziele und Projekte speichert BlockEm als normale Notizen (Markdown) in einem Ordner auf deinem Computer. Nutzt du Obsidian, nimm deinen Vault: dann siehst du alles auch dort."));
      const opts = [];
      (pr.obsidianVaults || []).forEach(v => opts.push({art:"vault", pfad:v, titel:`Obsidian-Vault: ${v.split("/").pop()}`, sub:v}));
      if (pr.vault) opts.unshift({art:"vault", pfad:pr.vault, titel:"Aktueller Ordner behalten", sub:pr.vault});
      opts.push({art:"neu", pfad:pr.vorschlagOrdner, titel:"Neuer Ordner (ohne Obsidian)", sub:pr.vorschlagOrdner});
      opts.push({art:"vault", pfad:"", titel:"Anderer Ordner", sub:"Pfad selbst eintragen", eigen:true});
      if (!EIN.wahl) EIN.wahl = opts[0];
      const liste = el("div","ein-wahl");
      opts.forEach(o => { const b = el("button","ein-opt" + (EIN.wahl.titel === o.titel ? " an" : "")); b.type = "button";
        b.append(el("b", null, o.titel), el("span","k-s", o.sub));
        b.addEventListener("click", () => { EIN.wahl = o; einZeichnen(); }); liste.append(b); });
      inhalt.append(liste);
      let eigen = null;
      if (EIN.wahl.eigen){ eigen = el("input"); eigen.placeholder = "/Users/du/Documents/Notizen"; eigen.value = EIN.pfad; eigen.setAttribute("aria-label","Ordnerpfad");
        eigen.addEventListener("input", () => EIN.pfad = eigen.value); inhalt.append(eiZeile("Pfad", eigen)); }
      weiter("Weiter", () => einWeiter({ordner:{art:EIN.wahl.art, pfad:EIN.wahl.eigen ? eigen.value : EIN.wahl.pfad}}));
      if (EIN.nur) fuss.append(eiKnopf("Abbrechen", "ghost small", einZu));
      break;
    }
    case 3: {
      titel.textContent = "Wie sieht dein Tag aus?";
      const r = S.plan?.automatik?.tagRahmen || {von:8, bis:20}, z = zeitDaten();
      const sel = (wert, werte, label) => { const s = document.createElement("select"); s.setAttribute("aria-label", label); werte.forEach(h => s.append(new Option(`${pad(h)}:00`, h, false, h === wert))); return s; };
      const von = sel(r.von, [...Array(24).keys()], "Tag beginnt"), bis = sel(r.bis, [...Array(24).keys()].map(x => x + 1), "Tag endet");
      const std = document.createElement("select"); std.setAttribute("aria-label","Stunden für Projekte"); [1, 2, 3, 4, 5, 6, 8].forEach(n => std.append(new Option(`${n} Std`, n, false, n === z.std)));
      inhalt.append(el("p","k-s","In diesem Rahmen verteilt BlockEm deine Aufgaben zwischen die Termine. Die Stunden sind das, was du pro Tag für deine Projekte einplanen willst."),
        eiZeile("Mein Tag", von, el("span","k-s","bis"), bis), eiZeile("Für Projekte", std, el("span","k-s","pro Tag")));
      weiter("Weiter", async () => {
        try { await api("api/kalender", {von:+von.value, bis:+bis.value}); S.plan = await api("api/zeit", {standard:{std:+std.value}}); } catch (e){ toast(e.message || String(e)); return; }
        einWeiter(null); });
      spaeter("Überspringen"); break;
    }
    case 4: {
      titel.textContent = "Welche KI nutzt du?";
      inhalt.append(el("p","k-s", VB.modus === "handy" ? "Optional. Die KI plant mit dir, beantwortet Fragen zu deinen Zielen und fasst Ideen zusammen. Am Handy verbindest du sie mit einem API-Schlüssel (Claude, ChatGPT, Gemini, Mistral, OpenRouter)."
        : "Optional. Die KI plant mit dir, beantwortet Fragen zu deinen Zielen und fasst Ideen zusammen. Du verbindest die KI, die du schon hast: dein Claude-Abo, einen API-Schlüssel (Claude, ChatGPT, Gemini, Mistral, OpenRouter) oder Ollama, das komplett lokal läuft."));
      inhalt.append(el("p", ki.anbieter ? "ein-ok" : "k-s", ki.anbieter ? `✓ Gefunden und bereit: ${ki.modell}` : "Noch keine KI verbunden."));
      weiter(ki.anbieter ? "Weiter" : "Jetzt verbinden", () => { if (ki.anbieter) return einWeiter(null);
        // KI in den Einstellungen verbinden; oben im Reiter steht dann „Einrichtung fortsetzen“
        EIN.schritt = 5; einZu(); showTab("einstellungen"); window.scrollTo(0, 0); renderPlan(); });
      spaeter(); break;
    }
    case 5: {
      titel.textContent = "Deine Termine";
      inhalt.append(el("p","k-s","Optional. Mit deinem Kalender plant der Tag um deine Termine herum, und volle Tage bekommen weniger Stunden. Füge die iCal-Adresse ein (Google: Einstellungen › Kalender integrieren › Privatadresse im iCal-Format)."));
      const url = el("input"); url.type = "url"; url.placeholder = "https://calendar.google.com/…/basic.ics"; url.setAttribute("aria-label","iCal-Adresse");
      inhalt.append(eiZeile("iCal-Adresse", url));
      weiter("Verbinden", () => url.value.trim() ? einWeiter({neu:{name:"Kalender", url:url.value}}, "api/kalender") : (url.focus(), toast("Adresse einfügen oder „Später“.")));
      spaeter(); break;
    }
    case 6: {
      if (VB.inApp && VB.modus === "handy" && APP.nutzung){
        titel.textContent = "Fast fertig: Bildschirmzeit am Handy";
        const st = handyRechte();
        inhalt.append(el("p","k-s","Damit BlockEm sieht, wofür deine Zeit am Handy draufgeht, braucht es den Nutzungszugriff. Die Daten bleiben auf dem Handy."));
        inhalt.append(st.nutzung ? el("p","ein-ok", APP.ios ? "✓ Bildschirmzeit-Zugriff ist erlaubt." : "✓ Nutzungszugriff ist erlaubt.")
          : eiKnopf(APP.ios ? "Bildschirmzeit-Zugriff erlauben" : "Nutzungszugriff erlauben", "ask small", () => APP.nutzungErlauben()));
        inhalt.append(el("p","k-s","Optional: Die Fokus-Sperre schaltet ablenkende Apps und Seiten weg, solange du im Fokus bist oder eine Locker-Regel greift."));
        inhalt.append(st.sperre ? el("p","ein-ok","✓ Fokus-Sperre ist an.") : eiKnopf("Fokus-Sperre einrichten", "ghost small", () => handySperreErklaeren()));
        weiter("Fertig", einFertig); break;
      }
      titel.textContent = "Fast fertig: Bildschirmzeit";
      const aw = !S.demoActivity;
      inhalt.append(el("p", aw ? "ein-ok" : "k-s", aw ? "✓ Die Bildschirmzeit vom Computer kommt an." : "Die Bildschirmzeit am Computer zählt BlockEm selbst, sobald es läuft. Am Mac fragt macOS einmal nach Bedienungshilfen: erlauben."));
      inhalt.append(el("p","k-s","Android-Handy verbinden: Einstellungen › Handys & Geräte. Die Handy-App sendet deine Bildschirmzeit im WLAN an deinen Mac, und Sperren gelten auch dort."));
      const imp = el("p","k-s"); imp.append("Deine Projekte, Habits und Ziele liegen schon woanders (ChatGPT, Notion, Todoist …)? ",
        eiKnopf("Danach importieren", "zt-link", async () => { await einFertig(); importOeffnen(); }));
      inhalt.append(imp);
      weiter("Fertig", einFertig); break;
    }
  }
  kopf.append(titel, punkte);
  d.replaceChildren(kopf, inhalt, fuss);
}
// Im Reiter Einstellungen: solange die Einrichtung nicht abgeschlossen ist, ein Knopf zum Weitermachen
function renderEinWeiter(){
  const tab = document.querySelector('.tab[data-r="einstellungen"]'); if (!tab) return;
  let bar = $("einWeiter");
  const zeigen = S.mode === "lokal" && S.plan?.profil && !S.plan.profil.eingerichtet;
  if (!zeigen){ bar?.remove(); return; }
  if (!bar){ bar = el("div","notice ein-weiter"); bar.id = "einWeiter"; tab.prepend(bar); }
  bar.replaceChildren(el("span", null, "Die Einrichtung ist noch nicht fertig."), eiKnopf("Einrichtung fortsetzen", "ask small", () => { EIN.zu = false; einrichtungOeffnen(Math.max(2, EIN.schritt)); }));
}

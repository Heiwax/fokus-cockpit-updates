/* ---------- Update-Fenster (3.15): zeigt Schritt für Schritt, was beim Update der Handy-App passiert ----------
   Java meldet über window.__updStand(stufe, prozent, text): erlauben · laden · pruefen · bestaetigen · fehler · abgebrochen.
   Nach „Aktualisieren“ beendet Android die App; kommt sie stattdessen zurück, ohne dass etwas passiert ist, zeigt das Fenster Hilfe. */
const UPD = {version:"", apk:"", weg:"", stufe:"", prozent:0, text:"", bestaetigtAb:0};
const UPD_SCHRITTE = [["laden", "Herunterladen"], ["pruefen", "Prüfen"], ["bestaetigen", "In Android bestätigen"], ["installieren", "Installieren und neu starten"]];
const updKann = () => !!(window.CockpitApp && window.CockpitApp.hersteller);
const updSamsung = () => { try { return /samsung/i.test(window.CockpitApp.hersteller()); } catch { return false; } };
// Samsung „Automatische Sperre“ gibt es ab One UI 6 (Android 14). Android verrät Apps nicht, ob sie an ist, darum der Hinweis vorher.
const updAutoSperre = () => { try { const v = +(window.CockpitApp.hersteller().match(/Android (\d+)/) || [])[1]; return updSamsung() && (!v || v >= 14); } catch { return false; } };
function updSperreHinweis(fehler){
  const box = el("div", "upd-samsung" + (fehler ? " fehler" : ""));
  box.append(el("b", null, fehler ? "Wahrscheinlich die Automatische Sperre von Samsung" : "Samsung-Handy: Automatische Sperre prüfen"),
    el("span", "k-s", "Ist sie an, blockiert Samsung jedes Update, das nicht aus dem Store kommt, und beim Tippen auf „Aktualisieren“ passiert nichts. Unter Sicherheit und Datenschutz › Automatische Sperre kurz ausschalten, Update installieren, danach wieder einschalten."));
  if (window.CockpitApp?.sicherheitOeffnen){ const b = el("button", "ghost small", "Sicherheit und Datenschutz öffnen"); b.type = "button"; b.addEventListener("click", () => window.CockpitApp.sicherheitOeffnen()); box.append(b); }
  return box;
}

function updFenster(version, apk, weg){
  let d = document.getElementById("updFenster");
  if (!d){
    d = el("dialog", "planer modern upd-fenster"); d.id = "updFenster"; d.setAttribute("aria-labelledby", "updTitel");
    d.addEventListener("cancel", e => { if (["laden", "pruefen"].includes(UPD.stufe)) e.preventDefault(); });
    document.body.append(d);
  }
  Object.assign(UPD, {version, apk: apk || "", weg, stufe: "start", prozent: 0, text: "", bestaetigtAb: 0});
  updZeichnen();
  if (!d.open) d.showModal();
  updStarten();
}
function updStarten(){
  const A = window.CockpitApp;
  UPD.stufe = "laden"; UPD.prozent = 0; UPD.text = ""; updZeichnen();
  if (UPD.weg === "online" && A.updateVon) A.updateVon(UPD.apk); else A.update();
}
// Meldungen aus der App
window.__updStand = (stufe, prozent, text) => {
  if (!document.getElementById("updFenster")?.open) return;
  UPD.stufe = stufe; UPD.prozent = Math.max(0, Math.min(100, +prozent || 0)); UPD.text = text || "";
  if (stufe === "bestaetigen") UPD.bestaetigtAb = Date.now();
  updZeichnen();
};
// Kommt die App nach der Bestätigung wieder nach vorn und lebt noch, hat Android nicht installiert
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState !== "visible" || UPD.stufe !== "bestaetigen" || Date.now() - UPD.bestaetigtAb < 1500) return;
  setTimeout(() => { if (UPD.stufe === "bestaetigen"){ UPD.stufe = "haengt"; updZeichnen(); } }, 4000);
});

function updZeichnen(){
  const d = document.getElementById("updFenster"); if (!d) return;
  const s = UPD.stufe, fehler = ["fehler", "haengt", "abgebrochen"].includes(s);
  const index = {start: 0, laden: 0, pruefen: 1, bestaetigen: 2, haengt: 2, abgebrochen: 2, fehler: Math.max(0, UPD_SCHRITTE.findIndex(x => x[0] === UPD.vorher)), erlauben: 0}[s] ?? 0;
  if (!fehler) UPD.vorher = s;
  const kopf = el("div", "upd-kopf");
  kopf.append(el("h2", null, fehler ? "Update hat nicht geklappt" : `Update auf Version ${UPD.version}`), el("p", "k-s", `Du hast ${window.CockpitApp?.version?.() || "eine ältere Version"}.`));
  kopf.firstChild.id = "updTitel";
  const liste = el("ol", "upd-schritte");
  UPD_SCHRITTE.forEach(([k, name], i) => {
    const li = el("li", i < index ? "fertig" : i === index ? (fehler ? "fehler" : "jetzt") : "");
    li.append(el("span", "upd-punkt", i < index ? "✓" : i === index && fehler ? "!" : String(i + 1)), el("span", null, name));
    if (k === "laden" && i === index && s === "laden"){
      const balken = el("div", "upd-balken"), f = el("i"); f.style.width = UPD.prozent + "%"; balken.append(f);
      li.append(balken, el("span", "k-s upd-zahl", UPD.prozent ? UPD.prozent + " %" : "verbinde …"));
    }
    liste.append(li);
  });
  const info = el("div", "upd-info");
  if (updAutoSperre() && !fehler && s !== "erlauben") info.append(updSperreHinweis(false));
  if (s === "erlauben") info.append(el("p", null, "Android fragt einmal: „BlockEm“ darf Apps installieren. Schalte das ein, komm zurück und tippe auf „Nochmal versuchen“."));
  if (s === "pruefen") info.append(el("p", null, "Die Datei ist geladen. Android prüft sie gerade."));
  if (s === "bestaetigen") info.append(el("p", null, "Tippe im Android-Fenster auf „Aktualisieren“. Die App schließt sich dabei kurz und ist danach auf dem neuen Stand."));
  if (fehler){
    info.append(el("p", "c-bad", s === "haengt" ? "Android hat nach dem Bestätigen nichts installiert." : s === "abgebrochen" ? "Das Update wurde abgebrochen." : (UPD.text || "Unbekannter Fehler.")));
    if (updAutoSperre()) info.append(updSperreHinweis(true));
    const hilfe = el("ul", "upd-hilfe");
    if (!updAutoSperre() && s === "haengt") hilfe.append(el("li", null, "Bei Samsung: Einstellungen › Sicherheit und Datenschutz › Automatische Sperre ausschalten, nochmal versuchen, danach wieder einschalten."));
    hilfe.append(el("li", null, "Einstellungen › Apps › BlockEm › Unbekannte Apps installieren: erlauben."));
    hilfe.append(el("li", null, "Meldet Play Protect sich, auf „Trotzdem installieren“ tippen."));
    info.append(hilfe);
    try { info.append(el("p", "k-s", "Gerät: " + window.CockpitApp.hersteller())); } catch {}
  }
  const knoepfe = el("div", "upd-knoepfe");
  if (fehler || s === "erlauben"){
    const nochmal = el("button", "ask", "Nochmal versuchen"); nochmal.type = "button"; nochmal.addEventListener("click", updStarten);
    knoepfe.append(nochmal);
    if (UPD.weg === "online" && UPD.apk){ const a = el("a", "ghost", "Im Browser von Hand laden"); a.href = UPD.apk; a.target = "_blank"; a.rel = "noopener"; knoepfe.append(a); }
  }
  if (!["laden", "pruefen"].includes(s)){
    const zu = el("button", "ghost", "Schließen"); zu.type = "button"; zu.addEventListener("click", () => d.close()); knoepfe.append(zu);
  }
  d.replaceChildren(kopf, liste, info, knoepfe);
}

/* ---------- Guss (19.11.2026, ganz hinten): ein Design für alle Seiten, Handy und Mac, CSS in guss.css ----------
   Heute = Bild (oder Kreis) oben, darunter ein Blatt mit Panik-Knopf und „Noch frei heute“:
   Restzeit der Apps mit Tageslimit (Sperre › Apps), dieselben Zahlen wie auf den Limit-Karten (api/locker: verbraucht, minuten).
   Alles unter dem Bild (Panik-Knopf, Angebot fürs erste Bild, Porno-Schutz-Hinweis) wandert ins Blatt.
   Die Geschenk-Zeile ist raus aus Heute (john 19.11.), sie steht unter „Weg“. */
const GU = {lk:null, geladen:0, laedt:false};

function guLimits(){   // höchstens 3, die am meisten verbraucht haben zuerst
  const tag = (new Date().getDay() + 6) % 7;
  return lmGruppen((GU.lk?.regeln || []).filter(r => r.art === "limit" && +r.minuten > 0 && (!r.tage || r.tage.includes(tag))))
    .map(g => { const r = g.regeln.find(x => x.art === "limit"); return {apps:g.apps, ist:Math.round(r.verbraucht || 0), max:+r.minuten, zu:!!r.gesperrt}; })
    .sort((a, b) => b.ist / b.max - a.ist / a.max).slice(0, 3);
}
function guLaden(){
  if (GU.laedt || Date.now() - GU.geladen < 60000) return;
  GU.laedt = true;
  api("api/locker").then(d => { GU.lk = d; }).catch(() => {}).finally(() => { GU.laedt = false; GU.geladen = Date.now(); trHero(); });
}
function guKarte(d){
  const k = el("section","gu-karte"), kopf = el("div","gu-kopf");
  kopf.append(el("h3","gu-label","Noch frei heute")); k.append(kopf);
  const liste = guLimits();
  if (!liste.length) k.append(el("p","gu-leer","Gib Apps in Sperre › Apps ein Tageslimit, dann siehst du hier, wie viel Zeit noch frei ist."));
  liste.forEach(a => {
    const rest = Math.max(0, a.max - a.ist), z = el("div","gu-app" + (a.zu || rest <= 5 ? " knapp" : ""));
    const mitte = el("div","gu-mitte"), t = el("div","gu-t"), bar = el("div","gu-bar"), i = el("i");
    t.append(el("span", null, lmName(a.apps)), el("b", null, a.zu || !rest ? "aufgebraucht" : `noch ${rest} Min`));
    i.style.width = Math.min(100, a.ist / a.max * 100) + "%"; bar.append(i);
    mitte.append(t, bar, el("small", null, `${a.ist} von ${a.max} Min`));
    z.append(cmKachel(a.apps[0]), mitte); k.append(z);
  });
  const fuss = el("div","gu-fuss"), wo = d.sauber?.woche || 0, mehr = el("button","gu-mehr", liste.length ? "Alle Werte ›" : "Apps begrenzen ›"); mehr.type = "button";
  mehr.addEventListener("click", () => document.querySelector(`#reiter [data-r="${liste.length ? "werte" : "locker"}"]`)?.click());
  fuss.append(el("span", null, `Abgeblockt diese Woche: ${wo}×`), mehr); k.append(fuss);
  return k;
}
function guBlatt(h, d){
  if (!h) return;
  h.querySelector(".tue-next")?.remove();
  const teile = h.querySelector(".tue-hero-teile"), rahmen = h.querySelector(".tue-rahmen"), m = teile?.textContent.match(/(\d+)\D+(\d+)/);
  if (m && rahmen && !rahmen.querySelector(".gu-teile")){
    const bar = el("div","gu-teile"), i = el("i"); i.style.width = Math.min(100, 100 * m[1] / m[2]) + "%"; bar.append(i); rahmen.append(bar);
    teile.textContent = `Bild ${m[1]} / ${m[2]}`;
  }
  let b = $("guBlatt"); if (!b){ b = el("div","gu-blatt"); b.id = "guBlatt"; }
  b.replaceChildren(el("i","gu-griff"), ...[...h.children].filter(x => !x.classList.contains("cm-hero")), guKarte(d));
  h.after(b);
}
if (NUR_TRACKING){
  const guHeroAlt = trHeroZeichnen;
  trHeroZeichnen = function(h, d){ guHeroAlt(h, d); guBlatt(h, d); guLaden(); };
}

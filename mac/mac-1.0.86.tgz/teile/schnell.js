/* ---------- Schnell-Eingabe (⌘K / Strg+K oder Knopf ＋ im Kopf): Aufgabe, Fokus, Habit, KI-Frage oder Reiter/Projekt öffnen ---------- */
// Eingabe wie „Angebot schreiben #Sales 30m“: #Projekt (Anfang des Namens reicht) und Dauer (30m, 1h, 1,5 Std) werden erkannt.
const SN = {wahl:0, liste:[]};
const SN_REITER = [["heute","Heute"],["ziele","Ziele"],["habits","Habits"],["projekte","Projekte"],["fokus","Fokus"],["locker","Locker"],["werte","Werte"],["einstellungen","Einstellungen"]];
const snKey = s => (s || "").toLocaleLowerCase("de").normalize("NFD").replace(/[̀-ͯ]/g, "");
function snLesen(roh){
  let text = " " + roh + " ", projekt = null, min = null;
  const dm = text.match(/\s(\d+(?:[.,]\d+)?)\s*(m|min|minuten|h|std|stunden?)(?=\s)/i);
  if (dm){ const n = parseFloat(dm[1].replace(",", ".")); min = Math.round(/^m/i.test(dm[2]) ? n : n * 60); text = text.replace(dm[0], " "); }
  const hm = text.match(/\s#(\S[^#]*)$/) || text.match(/\s#(\S+)/);
  if (hm){
    const rest = snKey(hm[1].trim()), namen = (S.plan?.projekte || []).map(p => p.name).sort((a, b) => b.length - a.length);
    const treffer = namen.find(n => rest.startsWith(snKey(n))) || namen.find(n => snKey(n).startsWith(rest.split(/\s+/)[0]));
    if (treffer){ projekt = treffer;
      const lang = rest.startsWith(snKey(treffer)) ? treffer.length : rest.split(/\s+/)[0].length;
      text = text.replace(hm[0], " " + hm[1].trim().slice(lang)); }
  }
  return {text:text.replace(/\s+/g, " ").trim(), projekt, min};
}
function snAktionen(roh){
  const out = [], q = snKey(roh.trim()), lokal = S.mode === "lokal";
  if (q){
    const {text, projekt, min} = snLesen(roh);
    const zusatz = [projekt, min ? stdText(min / 60) : ""].filter(Boolean).join(" · ");
    const mitDauer = text + (min ? ` (${min < 60 ? min + " Min" : String(Math.round(min / 6) / 10).replace(".", ",") + " Std"})` : "");
    if (text){
      out.push({icon:"＋", t:`Für heute: ${text}`, s:zusatz, los:() => addItem("heute", mitDauer, projekt).then(() => toast(`Für heute: ${text}`))});
      out.push({icon:"＋", t:`Für diese Woche: ${text}`, s:zusatz, los:() => addItem("woche", mitDauer, projekt).then(() => toast(`Für diese Woche: ${text}`))});
      if (lokal){
        out.push({icon:"▶", t:`Fokus ${min || FK.dur} Min: ${text}`, s:projekt || "", los:() => fkAction({aktion:"start", projekt, aufgabe:text, minuten:Math.max(5, Math.min(240, min || FK.dur))}).then(() => showTab("fokus"))});
        out.push({icon:"↻", t:`Neuer Habit: ${text}`, s:"", los:() => api("api/habit", {aktion:"add", name:text}).then(r => { if (r?.heute) S.plan = r; renderPlan(); toast(`Habit „${text}“ angelegt.`); })});
      }
      if (S.plan?.ki?.anbieter) out.push({icon:"✦", t:`Frag ${fcName()}: ${roh.trim()}`, s:"", los:() => { fcOeffnen(); fcFragen(roh.trim()); }});
    }
  }
  SN_REITER.filter(([, n]) => !q || snKey(n).startsWith(q)).forEach(([r, n]) => out.push({icon:"→", t:n, s:"Reiter öffnen", los:() => { showTab(r); window.scrollTo(0, 0); }}));
  // Einstellungen-Seiten direkt öffnen („kalender“ → Einstellungen › Kalender)
  if (q && typeof ES_DEF !== "undefined") Object.values(ES_DEF).filter(x => !x.reiter && snKey(`${x.t} ${x.such}`).split(/\s+/).some(w => w.startsWith(q))).slice(0, 3)
    .forEach(x => out.push({icon:"⚙", t:x.t, s:"Einstellungen", los:() => esOeffnen(x.k)}));
  (S.plan?.projekte || []).filter(p => q && snKey(p.name).includes(q)).slice(0, 5)
    .forEach(p => out.push({icon:"→", t:p.name, s:"Projekt öffnen", los:() => { showTab("projekte"); pvGo(p.name); }}));
  return out;
}
function snOeffnen(){
  let d = $("snDialog");
  if (!d){
    d = el("dialog","planer modern sn-dialog"); d.id = "snDialog"; d.setAttribute("aria-label","Schnell-Eingabe");
    const inp = el("input"); inp.id = "snEingabe"; inp.autocomplete = "off"; inp.spellcheck = false;
    inp.placeholder = "Aufgabe, Fokus, Frage oder Reiter … z. B. „Angebot schreiben #Sales 30m“";
    inp.setAttribute("role","combobox"); inp.setAttribute("aria-controls","snListe"); inp.setAttribute("aria-expanded","true");
    const ul = el("ul","sn-liste"); ul.id = "snListe"; ul.setAttribute("role","listbox");
    const fuss = el("p","k-s sn-fuss","↵ ausführen · ↑↓ wählen · Esc schließen · #Projekt · 30m");
    inp.addEventListener("input", () => { SN.wahl = 0; snZeichnen(); });
    inp.addEventListener("keydown", e => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp"){ e.preventDefault(); const n = SN.liste.length; if (n){ SN.wahl = (SN.wahl + (e.key === "ArrowDown" ? 1 : n - 1)) % n; snZeichnen(); } }
      else if (e.key === "Enter"){ e.preventDefault(); snLos(SN.wahl); }
    });
    d.addEventListener("click", e => { if (e.target === d) d.close(); });
    d.append(inp, ul, fuss); document.body.append(d);
  }
  $("snEingabe").value = ""; SN.wahl = 0; snZeichnen();
  if (!d.open) d.showModal(); $("snEingabe").focus();
}
function snZeichnen(){
  SN.liste = snAktionen($("snEingabe").value);
  const ul = $("snListe");
  ul.replaceChildren(...SN.liste.map((a, i) => {
    const li = el("li","sn-e" + (i === SN.wahl ? " an" : "")); li.id = "sn" + i; li.setAttribute("role","option"); li.setAttribute("aria-selected", String(i === SN.wahl));
    li.append(el("span","sn-i", a.icon), el("span","sn-t", a.t)); if (a.s) li.append(el("span","k-s sn-s", a.s));
    li.addEventListener("mousedown", e => { e.preventDefault(); snLos(i); });
    return li;
  }));
  $("snEingabe").setAttribute("aria-activedescendant", SN.liste.length ? "sn" + SN.wahl : "");
  $("sn" + SN.wahl)?.scrollIntoView({block:"nearest"});
}
async function snLos(i){
  const a = SN.liste[i]; if (!a) return;
  $("snDialog").close();
  try { await a.los(); } catch (e){ toast(e.message || String(e)); }
}
function snKnopf(){
  if ($("snBtn")) return;
  const b = el("button","ghost sn-btn","＋"); b.id = "snBtn"; b.type = "button";
  b.title = "Schnell hinzufügen (" + (/Mac|iPhone|iPad/.test(navigator.platform) ? "⌘K" : "Strg+K") + ")"; b.setAttribute("aria-label","Schnell hinzufügen");
  b.addEventListener("click", snOeffnen);
  document.querySelector("header.top .meta")?.prepend(b);
}
document.addEventListener("keydown", e => {
  if ((e.metaKey || e.ctrlKey) && !e.shiftKey && !e.altKey && e.key.toLowerCase() === "k"){
    e.preventDefault(); const d = $("snDialog"); if (d?.open) d.close(); else snOeffnen();
  }
});
snKnopf();

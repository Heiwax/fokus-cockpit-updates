/* ---------- Import: Projekte, Phasen, Aufgaben, Habits und Ziele aus anderen Apps holen ---------- */
// 1. Prompt kopieren und bei ChatGPT/Claude (wo die alte Planung liegt) einfügen  2. Antwort hier einfügen  3. Vorschau prüfen, importieren.
// Mit verbundener KI geht auch normaler Text oder ein Export (Notion, Todoist …) direkt: die KI wandelt ihn um.
const IM = {schritt:1, prompt:"", text:"", vorschau:null, mitKi:false, laeuft:false, ergebnis:null};
async function importOeffnen(){
  let d = $("imDialog");
  if (!d){ d = el("dialog","planer modern ein-dialog im-dialog"); d.id = "imDialog"; d.setAttribute("aria-labelledby","imTitel");
    d.addEventListener("cancel", e => { e.preventDefault(); d.close(); }); document.body.append(d); }
  Object.assign(IM, {schritt:1, vorschau:null, ergebnis:null, laeuft:false});
  if (!IM.prompt){ try { IM.prompt = (await api("api/import", {prompt:true})).prompt; } catch (e){ toast(e.message || String(e)); return; } }
  imZeichnen(); if (!d.open) d.showModal();
  d.querySelector(".im-prompt")?.scrollTo(0, 0); d.querySelector(".ein-fuss .ask")?.focus();
}
function imZeichnen(){
  const d = $("imDialog"), kopf = el("div","ein-kopf"), titel = el("h2"); titel.id = "imTitel";
  const punkte = el("div","ein-punkte"); for (let i = 1; i <= 3; i++) punkte.append(el("i", i <= IM.schritt ? "an" : ""));
  const inhalt = el("div","ein-inhalt"), fuss = el("div","ein-fuss");
  const zu = eiKnopf(IM.ergebnis ? "Fertig" : "Abbrechen", IM.ergebnis ? "ask" : "ghost small", () => d.close());
  if (IM.schritt === 1){
    titel.textContent = "Deine Planung mitnehmen";
    inhalt.append(el("p", null, "Hol deine Projekte, Aufgaben, Habits und Ziele aus ChatGPT, Claude, Notion, Todoist oder deinen Notizen in BlockEm."),
      el("p","k-s","1. Kopiere den Prompt unten.\n2. Füge ihn bei ChatGPT oder Claude ein, am besten im Chat, in dem deine Planung steht. Einen Export (Notion, Todoist, Trello) oder Notizen kannst du dort mit anhängen.\n3. Kopiere die ganze Antwort und füge sie im nächsten Schritt ein."));
    const ta = el("textarea","im-prompt"); ta.value = IM.prompt; ta.readOnly = true; ta.rows = 7; ta.setAttribute("aria-label","Prompt zum Kopieren");
    const kopie = eiKnopf("Prompt kopieren", "ask small", async () => {
      try { await navigator.clipboard.writeText(IM.prompt); kopie.textContent = "✓ Kopiert"; }
      catch { ta.select(); document.execCommand("copy"); kopie.textContent = "✓ Kopiert"; }
    });
    inhalt.append(ta, kopie);
    if (S.plan?.ki?.anbieter) inhalt.append(el("p","hint kon-hint", `Ohne Umweg: Deine KI (${fcName()}) ist verbunden. Dann kannst du im nächsten Schritt auch einfach Notizen oder einen Export einfügen, sie ordnet alles selbst.`));
    fuss.append(eiKnopf("Weiter", "ask", () => { IM.schritt = 2; imZeichnen(); }), zu);
  } else if (IM.schritt === 2){
    titel.textContent = "Antwort einfügen";
    const ta = el("textarea","im-text"); ta.value = IM.text; ta.rows = 10; ta.placeholder = S.plan?.ki?.anbieter ? "Antwort von ChatGPT/Claude, Notizen oder einen Export hier einfügen" : "Die ganze Antwort von ChatGPT oder Claude hier einfügen";
    ta.setAttribute("aria-label","Antwort zum Importieren"); ta.addEventListener("input", () => IM.text = ta.value);
    inhalt.append(ta);
    if (IM.laeuft) inhalt.append(el("p","k-s", "Wird gelesen … bei normalem Text ordnet die KI alles, das kann eine Minute dauern."));
    const pruefen = eiKnopf(IM.laeuft ? "Prüft …" : "Prüfen", "ask", async () => {
      if (!IM.text.trim()){ ta.focus(); toast("Bitte zuerst die Antwort einfügen."); return; }
      IM.laeuft = true; imZeichnen();
      try { const r = await api("api/import", {text:IM.text, pruefen:true}); IM.vorschau = r.vorschau; IM.mitKi = r.mitKi; IM.schritt = 3; }
      catch (e){ toast(e.message || String(e)); }
      IM.laeuft = false; imZeichnen();
    });
    pruefen.disabled = IM.laeuft;
    fuss.append(pruefen, eiKnopf("Zurück", "ghost small", () => { IM.schritt = 1; imZeichnen(); }));
    setTimeout(() => ta.focus(), 50);
  } else if (IM.ergebnis){
    const e = IM.ergebnis;
    titel.textContent = "Importiert";
    const teile = [e.projekte.length && `${e.projekte.length} ${e.projekte.length === 1 ? "Projekt" : "Projekte"} mit ${e.aufgaben} Aufgaben`,
      e.habits && `${e.habits} Habits`, e.heute && `${e.heute} für heute`, e.woche && `${e.woche} für diese Woche`,
      e.monat && `${e.monat} für diesen Monat`, e.jahr && `${e.jahr} fürs Jahr`].filter(Boolean);
    inhalt.append(el("p","ein-ok", "✓ " + (teile.join(", ") || "Nichts Neues") + "."));
    if (e.uebersprungen.length) inhalt.append(el("p","k-s", `Übersprungen, weil es sie schon gibt: ${e.uebersprungen.join(", ")}.`));
    inhalt.append(el("p","k-s","Alles liegt als Notizen in deinem Datenordner. Projekte findest du im Reiter Projekte, Habits im Reiter Habits."));
    fuss.append(zu);
  } else {
    const v = IM.vorschau, neu = v.projekte.filter(p => !p.gibtEs);
    titel.textContent = "Passt das so?";
    if (IM.mitKi) inhalt.append(el("p","k-s", `${fcName()} hat deinen Text geordnet. Schau kurz drüber.`));
    const liste = el("div","im-liste");
    v.projekte.forEach(p => {
      const box = el("details","im-p" + (p.gibtEs ? " weg" : "")), sum = el("summary");
      const n = p.phasen.reduce((s, ph) => s + ph.aufgaben.length, 0);
      sum.append(el("b", null, p.name), el("span","k-s", p.gibtEs ? "gibt es schon, wird übersprungen" : `${p.phasen.length} Phasen · ${n} Aufgaben`));
      box.append(sum);
      if (p.endziel) box.append(el("p","k-s", "Ziel: " + p.endziel));
      p.phasen.forEach(ph => { const x = el("div","im-ph"); x.append(el("b", null, ph.name));
        const ul = el("ul"); ph.aufgaben.slice(0, 8).forEach(a => ul.append(el("li", a.done ? "erl" : "", a.text + (a.std ? ` (${stdText(a.std)})` : ""))));
        if (ph.aufgaben.length > 8) ul.append(el("li","k-s", `… und ${ph.aufgaben.length - 8} weitere`));
        x.append(ul); box.append(x); });
      liste.append(box);
    });
    const gruppe = (titel, xs, f) => { if (!xs.length) return; const g = el("div","im-g"); g.append(el("b", null, `${titel} (${xs.length})`));
      const ul = el("ul"); xs.forEach(x => ul.append(el("li", null, f(x)))); g.append(ul); liste.append(g); };
    gruppe("Habits", v.habits, h => h.name + (h.rhythmus ? ` · ${h.rhythmus}` : ""));
    [["heute","Für heute"],["woche","Diese Woche"],["monat","Dieser Monat"],["jahr","Dieses Jahr"]].forEach(([k, t]) => gruppe(t, v[k] || [], x => x.text + (x.projekt ? ` · ${x.projekt}` : "")));
    const leer = !neu.length && !v.habits.length && !["heute","woche","monat","jahr"].some(k => (v[k] || []).length);
    if (leer) liste.append(el("p","empty","Nichts Neues zum Importieren gefunden."));
    inhalt.append(liste, el("p","hint kon-hint","Nichts wird überschrieben: Projekte, die es schon gibt, bleiben, wie sie sind."));
    const los = eiKnopf(IM.laeuft ? "Importiert …" : "Importieren", "ask", async () => {
      IM.laeuft = true; imZeichnen();
      try { const r = await api("api/import", {text:JSON.stringify(v)}); IM.ergebnis = r.ergebnis; IM.text = ""; await loadLocal(); renderPlan(); }
      catch (e){ toast(e.message || String(e)); }
      IM.laeuft = false; imZeichnen();
    });
    los.disabled = IM.laeuft || leer;
    fuss.append(los, eiKnopf("Zurück", "ghost small", () => { IM.schritt = 2; imZeichnen(); }));
  }
  kopf.append(titel, punkte);
  d.replaceChildren(kopf, inhalt, fuss);
}

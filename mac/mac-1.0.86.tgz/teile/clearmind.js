/* ---------- BlockEm (02.11.2026, nach tracking.js): der neue Look in Funktion ----------
   Heute: Kopf-Karte mit Block-Balken bis zum nächsten Abzeichen. Fokus: Ring, große Dauer-Felder, riesiger Start-Knopf, was gesperrt ist.
   Locker: Reiter Sperrzeiten / Tageslimits / Freischalten, neue Regel als Assistent in drei Seiten (Dialog). Werte: Tag antippen → Tagesansicht.
   Alles hängt sich an die bestehenden Funktionen (Wrapper), nichts wird gelöscht. CSS in clearmind.css. */
const CM = {tab: store("cm.lockerTab") || "zeit", offen:false, schritt:1, tag:null, tagDaten:{}, laedt:false, fkAlle:false};

if (NUR_TRACKING){

/* ----- Heute: Kopf-Karte ----- */
trHeroZeichnen = function(h, d){
  // Design S: Ring „N Tage sauber“, darunter Satz und Abzeichen, dann der weiße Panik-Knopf. Die Versuche stehen dezent ganz unten (cmStill).
  const s = d.sauber || {}, tage = s.tage ?? 0;
  const naechster = TR_MEILENSTEINE.find(m => m > tage) || 365, vorher = [...TR_MEILENSTEINE].reverse().find(m => m <= tage) || 0;
  const anteil = Math.max(0, Math.min(1, (tage - vorher) / (naechster - vorher)));
  const hero = el("div","cm-hero"), ring = el("div","cm-ring"), inn = el("div");
  ring.style.setProperty("--cm-anteil", Math.round(anteil * 100) + "%");
  inn.append(el("b", null, String(tage)), el("small", null, tage === 1 ? "Tag sauber" : "Tage sauber")); ring.append(inn);
  const noch = naechster - tage;
  const sub = el("p","cm-sub", s.heute ? `Heute ${s.heute}× abgeblockt. Stark, dass du hier bist.` : tage < 365 ? `Noch ${noch} ${noch === 1 ? "Tag" : "Tage"} bis zum ${naechster}-Tage-Abzeichen` : "Alle Abzeichen geholt.");
  const abz = el("div","cm-abzeichen");
  TR_MEILENSTEINE.forEach(m => { const x = el("span", tage >= m ? "da" : m === naechster ? "next" : "", String(m)); x.title = tage >= m ? `${m} Tage geschafft` : `${m} Tage`; abz.append(x); });
  const panik = el("button","tr-panik","Panik-Knopf"); panik.type = "button"; panik.title = "Bei starkem Drang: 2 Minuten atmen, dann raus";
  panik.addEventListener("click", trPanik);
  hero.append(ring, sub, abz); h.replaceChildren(hero, panik); h.hidden = false;
  const erreicht = [...TR_MEILENSTEINE].reverse().find(m => tage >= m);
  if (erreicht && store("tracking.meilenstein") !== String(erreicht)){ store("tracking.meilenstein", String(erreicht)); setTimeout(() => toast(`${erreicht} Tage sauber. Abzeichen geholt.`), 400); }
  cmStill(d);
};
// Dezente Zeile ganz unten auf Heute: Versuche diese Woche, aufklappbar mit Vorwoche und Panik-Knopf
function cmStill(d){
  const heute = document.querySelector('.tab[data-r="heute"]'); if (!heute) return;
  let z = $("cmStill"); if (!z){ z = el("details","cm-still"); z.id = "cmStill"; }
  const s = d.sauber || {}, pk = d.panik || {}, wo = s.woche || 0, vw = s.vorwoche || 0, offen = z.open;
  const sum = el("summary"), i = el("i"), t = el("span"); t.append("Diese Woche ", el("b", null, `${wo} ${wo === 1 ? "Versuch" : "Versuche"}`), " abgeblockt" + (s.heute ? `, heute ${s.heute}` : "") + ".");
  sum.append(i, t);
  z.replaceChildren(sum, el("p", null, `Vorwoche ${vw}×` + (pk.woche ? `, Panik-Knopf ${pk.woche}× gedrückt, ${pk.wocheGeschafft || 0}× geschafft` : "") +
    (wo < vw ? ". Weniger Versuche als letzte Woche, das zeigt Wirkung." : wo > vw ? ". Mehr Versuche als letzte Woche: Was war anders? Der Panik-Knopf hilft im Moment selbst." : ".")));
  z.open = offen; heute.append(z);
}
// Kachel mit Symbol für Apps und Geräte (neutral, wie John die Mac/Handy-Kacheln mochte)
// Jede App eigenes Zeichen und dezenter Farbton (john 02.11.: „YouTube, Netflix, Paramount … sieht alles gleich aus“); Glas bleibt, Farbe nur als Hauch
// Jede App eigenes Zeichen und dezenter Farbton (john 02.11.: Mittelweg – getönte Glas-Kachel, darauf eine weiße Silhouette wie beim echten App-Symbol)
const CM_SVG = {
  instagram: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="5.5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.3" cy="6.7" r="1.3" fill="currentColor"/></svg>',
  youtube: '<svg viewBox="0 0 24 24"><rect x="2" y="5" width="20" height="14" rx="4.5" fill="currentColor"/><path d="M10 9l5 3-5 3z" fill="#000" opacity=".85"/></svg>',
  tiktok: '<svg viewBox="0 0 24 24"><path d="M14 3h3c.3 2.3 1.7 3.8 4 4v3c-1.5 0-2.9-.5-4-1.3V15a5.5 5.5 0 1 1-5.5-5.5h.5v3h-.5a2.5 2.5 0 1 0 2.5 2.5V3z" fill="currentColor"/></svg>',
  twitch: '<svg viewBox="0 0 24 24"><path d="M4 3h16v11l-4 4h-4l-3 3v-3H5V7z" fill="currentColor"/><path d="M10 8v5M15 8v5" stroke="#000" stroke-width="2" opacity=".85"/></svg>',
  reddit: '<svg viewBox="0 0 24 24"><ellipse cx="12" cy="14" rx="8" ry="5.5" fill="currentColor"/><circle cx="19" cy="9" r="1.8" fill="currentColor"/><circle cx="5" cy="9" r="1.8" fill="currentColor"/><circle cx="9.3" cy="13.5" r="1.1" fill="#000" opacity=".85"/><circle cx="14.7" cy="13.5" r="1.1" fill="#000" opacity=".85"/><path d="M12 8.5l1-4 3.5 1" stroke="currentColor" stroke-width="1.6" fill="none"/></svg>',
  facebook: '<svg viewBox="0 0 24 24"><path d="M13.5 21v-7h2.4l.4-3h-2.8V9.2c0-.9.3-1.5 1.5-1.5h1.4V5.1c-.3 0-1.1-.1-2.1-.1-2.1 0-3.6 1.3-3.6 3.7V11H8.3v3h2.4v7z" fill="currentColor"/></svg>',
  x: '<svg viewBox="0 0 24 24"><path d="M4 4l16 16M20 4L4 20" stroke="currentColor" stroke-width="2.4"/></svg>',
  whatsapp: '<svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 0 0-7.8 13.5L3 21l4.6-1.2A9 9 0 1 0 12 3z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9 8.5c.3 2.6 2.6 5 5.5 5.6l1.2-1.4-2-1-1 .8c-.9-.4-1.7-1.2-2.1-2.1l.8-1-1-2z" fill="currentColor"/></svg>',
  telegram: '<svg viewBox="0 0 24 24"><path d="M21 4L3 11l5.5 2 2 6 3-3.5 4.5 3.5z" fill="currentColor"/></svg>',
  snapchat: '<svg viewBox="0 0 24 24"><path d="M12 3c3 0 4.5 2.3 4.5 5v2.5l2 .8-1.8 1.4c.8 2 2.3 2.8 3.3 3-1 1-2.5 1-3.5 1.3-.5 1.3-1.3 1.3-2.2 1.2-.8 0-1.3.8-2.3.8s-1.5-.8-2.3-.8c-.9.1-1.7.1-2.2-1.2-1-.3-2.5-.3-3.5-1.3 1-.2 2.5-1 3.3-3L5.5 11.3l2-.8V8C7.5 5.3 9 3 12 3z" fill="currentColor"/></svg>',
  discord: '<svg viewBox="0 0 24 24"><path d="M5 6.5A14 14 0 0 1 9 5l.5 1a12 12 0 0 1 5 0l.5-1a14 14 0 0 1 4 1.5c2 3.5 2.5 7 2.2 10.5a14 14 0 0 1-4.5 2.2l-1-1.5a9 9 0 0 1-1.5.7l.3 1.3a13 13 0 0 1-5 0l.3-1.3a9 9 0 0 1-1.5-.7l-1 1.5A14 14 0 0 1 2.8 17C2.5 13.5 3 10 5 6.5z" fill="currentColor"/><circle cx="9" cy="13" r="1.6" fill="#000" opacity=".85"/><circle cx="15" cy="13" r="1.6" fill="#000" opacity=".85"/></svg>',
  spotify: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9" fill="currentColor"/><path d="M7.5 9.5c3-1 6.5-.8 9.5.8M8 12.5c2.5-.8 5.3-.6 7.5.7M8.5 15.3c2-.6 4.2-.5 6 .5" stroke="#000" stroke-width="1.6" fill="none" stroke-linecap="round" opacity=".85"/></svg>',
  play: '<svg viewBox="0 0 24 24"><path d="M8 5l11 7-11 7z" fill="currentColor"/></svg>',
  browser: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="3.2" fill="currentColor"/></svg>',
  mail: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M4 7l8 6 8-6" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  mac: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="12" rx="2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M2 19h20" stroke="currentColor" stroke-width="2"/></svg>',
  phone: '<svg viewBox="0 0 24 24"><rect x="7" y="2.5" width="10" height="19" rx="2.5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="18" r="1" fill="currentColor"/></svg>',
  clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 7v5l3 2" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  hourglass: '<svg viewBox="0 0 24 24"><path d="M6 3h12M6 21h12M8 3v3l4 5-4 5v5M16 3v3l-4 5 4 5v5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  pause: '<svg viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16" rx="1" fill="currentColor"/><rect x="14" y="4" width="4" height="16" rx="1" fill="currentColor"/></svg>',
  hash: '<svg viewBox="0 0 24 24"><path d="M9 3L7 21M17 3l-2 18M4 9h17M3 15h17" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  moon: '<svg viewBox="0 0 24 24"><path d="M15 3a9 9 0 1 0 6 15.5A8 8 0 0 1 15 3z" fill="currentColor"/></svg>',
  sun: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4.5" fill="currentColor"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
  work: '<svg viewBox="0 0 24 24"><rect x="3" y="7" width="18" height="13" rx="3" fill="none" stroke="currentColor" stroke-width="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2M3 12h18" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  game: '<svg viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="11" rx="5.5" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8 10v5M5.5 12.5h5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="16" cy="11" r="1.2" fill="currentColor"/><circle cx="18.5" cy="13.5" r="1.2" fill="currentColor"/></svg>',
  book: '<svg viewBox="0 0 24 24"><path d="M4 4h7a2 2 0 0 1 2 2v14a2 2 0 0 0-2-2H4zM20 4h-7a2 2 0 0 0-2 2v14a2 2 0 0 1 2-2h7z" fill="none" stroke="currentColor" stroke-width="2"/></svg>',
  bed: '<svg viewBox="0 0 24 24"><path d="M3 18V8M3 14h18v4M21 14v-3a2 2 0 0 0-2-2h-8v5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="7" cy="10.5" r="1.8" fill="currentColor"/></svg>',
  heart: '<svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" fill="currentColor"/></svg>',
  shield: '<svg viewBox="0 0 24 24"><path d="M12 2.8l7.5 3v5.6c0 4.6-3.1 8.4-7.5 9.8-4.4-1.4-7.5-5.2-7.5-9.8V5.8z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M8.6 12.2l2.4 2.4 4.6-4.8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>',
};
window.CM_SVG = CM_SVG;   // 1.0.17: blockem.js ergänzt Symbole (Einstellungen, Orts-Sperre)
const CM_APPS = [
  [/instagram/i, "instagram", "#e1306c"], [/youtube/i, "youtube", "#ff3333"], [/tiktok/i, "tiktok", "#25f4ee"], [/netflix/i, "N", "#e50914"], [/paramount/i, "P", "#0064ff"],
  [/twitch/i, "twitch", "#9146ff"], [/disney/i, "D+", "#4a90ff"], [/prime|amazon/i, "p", "#00a8e1"], [/reddit/i, "reddit", "#ff4500"], [/facebook/i, "facebook", "#1877f2"],
  [/twitter|^x$|x\.com/i, "x", "#ffffff"], [/whatsapp/i, "whatsapp", "#25d366"], [/telegram/i, "telegram", "#2aabee"], [/snapchat/i, "snapchat", "#fffc00"], [/discord/i, "discord", "#5865f2"],
  [/spotify|musik|music/i, "spotify", "#1db954"], [/pinterest/i, "P", "#e60023"], [/9gag/i, "9", "#ffffff"], [/steam/i, "S", "#66c0f4"], [/threads/i, "@", "#ffffff"],
  [/chrome/i, "browser", "#4285f4"], [/safari/i, "browser", "#1ea7ff"], [/firefox/i, "browser", "#ff7139"], [/brave/i, "browser", "#fb542b"], [/edge/i, "browser", "#0078d7"],
  [/mail|messages|nachrichten|signal/i, "mail", "#FFB39B"], [/^mac$|imac|macbook/i, "mac", null], [/windows|pc/i, "mac", null], [/pixel|handy|phone|iphone|galaxy/i, "phone", null],
];
function cmKachel(name, glyph){
  const k = el("i","cm-kachel"), t = CM_APPS.find(([re]) => re.test(name || "")), z = glyph || (t ? t[1] : null);
  if (z && CM_SVG[z]) k.innerHTML = CM_SVG[z];
  else { k.textContent = z || (name || "?").trim().charAt(0).toUpperCase(); if ((z || "").length > 1) k.style.fontSize = "11px"; }
  if (t && t[2]){ k.style.background = `color-mix(in srgb, ${t[2]} 22%, rgba(255,255,255,.06))`; k.style.borderColor = `color-mix(in srgb, ${t[2]} 40%, rgba(255,255,255,.12))`; }
  return k;
}
// Ablenkungs- und Geräte-Zeilen auf Heute bekommen die Kachel
if (typeof renderDash === "function"){
  const _rdS = renderDash;
  renderDash = function(...a){ const r = _rdS.apply(this, a);
    // Heute wie im Entwurf: Karte „Größte Ablenkungen“ mit den drei größten Apps (Kachel, Name, Minuten), ohne Klapp-Block und Checkbox
    const al = $("ablList"), sec = al?.closest("section");
    if (al && sec){
      const h2 = sec.querySelector("h2"); if (h2 && h2.firstChild?.nodeType === 3) h2.firstChild.textContent = "Größte Ablenkungen ";
      const zeilen = [...al.querySelectorAll(".abl")].slice(0, 3);
      zeilen.forEach(z => { if (!z.querySelector(".cm-kachel")) z.prepend(cmKachel(z.querySelector(".n span")?.textContent)); z.querySelector(".n small")?.remove(); });
      const box = el("div","cm-abl");
      if (zeilen.length) box.append(...zeilen); else box.append(el("p","cm-leer","Heute noch keine Ablenkung. Stark."));
      al.replaceChildren(box);
    }
    document.querySelectorAll("#gerList .ger").forEach(z => { if (!z.querySelector(".cm-kachel")) z.prepend(cmKachel(z.querySelector(".n")?.textContent)); });
    return r; };
}
// Zwei Lichtflecken hinter allem
if (!document.querySelector(".cm-blob")){ const a = el("i","cm-blob a"), b = el("i","cm-blob b"); document.body.prepend(a, b); }

/* ----- Fokus: Ring, große Dauer, Start ----- */
function cmFokus(){
  const idle = $("fkIdle"), dur = $("fkDur"), start = $("fkStart"); if (!idle || !dur || !start) return;
  if (dur.parentElement !== idle) idle.insertBefore(dur, start);
  let ring = $("cmFkRing"); if (!ring){ ring = el("div","cm-fk-ring"); ring.id = "cmFkRing"; const inn = el("div"); inn.append(el("b"), el("small", null, "Minuten")); ring.append(inn); idle.prepend(ring); }
  ring.querySelector("b").textContent = FK.dur; ring.style.setProperty("--cm-anteil", Math.min(100, FK.dur / 120 * 100) + "%");
  dur.className = "cm-dauer";
  dur.querySelectorAll("button.chip").forEach(b => { const m = parseInt(b.textContent); b.className = ""; b.textContent = String(m); });
  start.textContent = "Fokus starten";
  // Gesperrte Apps als Liste (wie iOS): Kachel, Name, An/Aus zum Umschalten, „Weitere Apps …“ klappt alle auf
  let sp = $("cmFkSperre"); if (!sp){ sp = el("div","cm-fk-sperre"); sp.id = "cmFkSperre"; start.after(sp); }
  const s = S.plan?.automatik?.sperre, an = s?.an || [], aus = typeof autoAn === "function" && !autoAn("sperre"), alle = CM.fkAlle;
  sp.replaceChildren(el("p","cm-fk-titel", aus ? "Sperre im Fokus ist aus" : "Im Fokus gesperrt"));
  if (!s || S.mode !== "lokal"){ sp.append(el("p","cm-sub","Nur am Computer mit den Daten einstellbar.")); return; }
  const liste = el("div","cm-fk-liste");
  if (aus){ const b = el("button","cm-mehr","Sperre im Fokus einschalten"); b.type = "button"; b.addEventListener("click", () => esOeffnen("automatik")); liste.append(b); sp.append(liste); return; }
  const anSet = new Set(an.map(x => x.toLowerCase())), kand = s.kandidaten || [];
  const namen = alle ? [...kand, ...an.filter(n => !kand.some(k => k.toLowerCase() === n.toLowerCase()))] : an.slice(0, 5);
  const schalten = async (n, on, b) => { b.disabled = true; try { S.plan = await api("api/sperre", {name:n, an:!on}); renderPlan(); } catch (e){ toast(e.message || String(e)); b.disabled = false; } };
  namen.forEach(n => { const on = anSet.has(n.toLowerCase()), z = el("div","cm-zeile"), b = el("button","cm-an" + (on ? "" : " aus"), on ? "An" : "Aus"); b.type = "button";
    b.addEventListener("click", () => schalten(n, on, b)); z.append(cmKachel(n), el("span","n", n), b); liste.append(z); });
  if (!namen.length) liste.append(el("p","cm-leer","Noch nichts gesperrt. Tippe auf „Weitere Apps …“."));
  const mehr = el("button","cm-mehr"); mehr.type = "button"; mehr.append(alle ? "Weniger anzeigen" : "Weitere Apps …", el("span", null, "›"));
  mehr.addEventListener("click", () => { CM.fkAlle = !CM.fkAlle; cmFokus(); }); liste.append(mehr);
  sp.append(liste);
  if (alle){
    const f = el("form","add sp-add"), inp = el("input"), plus = el("button", null, "+");
    inp.placeholder = "Weitere Seite oder App, z. B. Twitter"; inp.setAttribute("aria-label","Weitere Seite oder App sperren"); plus.type = "submit";
    f.append(inp, plus);
    f.addEventListener("submit", async ev => { ev.preventDefault(); if (!inp.value.trim()) return; try { S.plan = await api("api/sperre", {neu:inp.value}); renderPlan(); } catch (e){ toast(e.message || String(e)); } });
    const einst = el("button","ghost small","Alle Einstellungen zur Sperre"); einst.type = "button"; einst.addEventListener("click", () => esOeffnen("fokus"));
    sp.append(f, einst);
  }
}
if (typeof fkDurChips === "function"){ const _fkDur = fkDurChips; fkDurChips = function(...a){ const r = _fkDur.apply(this, a); cmFokus(); return r; }; }
if (typeof renderSperre === "function"){ const _rsp = renderSperre; renderSperre = function(...a){ const r = _rsp.apply(this, a); cmFokus(); return r; }; }
cmFokus();

/* ----- Locker: Reiter und Regel-Assistent ----- */
function cmDialog(){
  let d = $("cmRegel"); if (!d){ d = el("dialog","cm-regel"); d.id = "cmRegel"; document.body.append(d);
    d.addEventListener("cancel", ev => { ev.preventDefault(); cmRegelZu(true); }); }
  return d;
}
function cmRegelZu(abbrechen){
  CM.offen = false; CM.schritt = 1; const d = $("cmRegel"); if (d?.open) d.close();
  if (abbrechen && typeof lkAbbrechen === "function") lkAbbrechen();
}
function cmRegelAuf(art){
  if (art) LK.art = art; CM.offen = true; CM.schritt = 1; renderLocker(true);
}
function cmAssistent(f){
  const d = cmDialog(), schritte = [...f.querySelectorAll(".lk-schritt")], satz = f.querySelector(".lk-satz"), knoepfe = f.querySelector(".lk-knoepfe");
  if (!schritte.length) return;
  CM.schritt = Math.max(1, Math.min(schritte.length, CM.schritt));
  // Kopf mit Schließen-Kreuz und Fortschritt, nur einmal pro Formular bauen
  let kopfZeile = f.querySelector(".cm-kopf"), fort = f.querySelector(".cm-schritte");
  if (!kopfZeile){
    const kopf = f.querySelector("h3"), x = el("button","ghost small","✕"); x.type = "button"; x.setAttribute("aria-label","Schließen"); x.addEventListener("click", () => cmRegelZu(true));
    kopfZeile = el("div","cm-tag-kopf cm-kopf"); kopf.before(kopfZeile); kopfZeile.append(kopf, x);
    fort = el("div","cm-schritte"); schritte.forEach(() => fort.append(el("i"))); kopfZeile.after(fort);
    f.addEventListener("click", () => { const w = f.querySelector(".cm-weiter"); if (w) w.disabled = CM.schritt === 1 && !LK.apps.size; }, {passive:true});
  }
  [...fort.children].forEach((i, n) => i.classList.toggle("an", n < CM.schritt));
  cmAssistentSchmuck(f);
  schritte.forEach((s, i) => s.classList.toggle("cm-aktiv", i + 1 === CM.schritt));
  const letzte = CM.schritt === schritte.length;
  if (satz) satz.hidden = !letzte;
  if (knoepfe) knoepfe.hidden = !letzte;
  f.querySelector(".cm-nav")?.remove();
  const nav = el("div","lk-knoepfe cm-nav");
  if (CM.schritt > 1){ const z = el("button","ghost","‹ Zurück"); z.type = "button"; z.addEventListener("click", () => { CM.schritt--; cmAssistent(f); }); nav.append(z); }
  if (!letzte){ const w = el("button","ask cm-weiter","Weiter ›"); w.type = "button"; w.disabled = CM.schritt === 1 && !LK.apps.size; w.addEventListener("click", () => { CM.schritt++; cmAssistent(f); }); nav.append(w); }
  f.append(nav);
  if (d.firstChild !== f) d.replaceChildren(f);
  if (!d.open) d.showModal();
}
// Assistent im Glas-Look: App-Kacheln mit Symbol, Regelarten als Kacheln, Minuten-Vorgaben, Geräte-Kacheln (einmal pro Formular)
function cmAssistentSchmuck(f){
  if (f.dataset.cmSchmuck) return; f.dataset.cmSchmuck = "1";
  f.querySelectorAll(".sp-chips .chip").forEach(b => { const n = b.textContent.trim(); if (b.querySelector(".cm-kachel")) return;
    b.replaceChildren(cmKachel(n), el("span","cm-name", n)); b.title = n; });
  f.querySelectorAll(".lk-art").forEach(b => { const ic = b.querySelector(".lk-icon"), t = b.querySelector("b")?.textContent || "";
    const g = /Sperrzeit/.test(t) ? "clock" : /Stück/.test(t) ? "pause" : /Öffnungs/.test(t) ? "hash" : "hourglass";
    const k = cmKachel("", g); k.classList.add("gross"); if (ic) ic.replaceWith(k); else b.prepend(k);
    const txt = el("div"); [...b.querySelectorAll("b, .k-s")].forEach(x => txt.append(x)); b.append(txt); });
  const arten = f.querySelector(".lk-arten");
  if (arten){ const s1 = el("p","cm-abschnitt","Art der Regel"); arten.before(s1); const s2 = el("p","cm-abschnitt","An welchen Tagen?"); arten.after(s2); }
  const zeit = f.querySelector(".lk-zeit"), num = zeit?.querySelector('input[type="number"]');
  if (zeit && num){
    const titel = el("p","cm-abschnitt", LK.art === "zeit" ? "Von wann bis wann?" : LK.art === "oeffnen" ? "Wie oft am Tag?" : "Wie lange?"); zeit.before(titel);
    if (LK.art !== "zeit"){ const pre = el("div","cm-presets"), werte = LK.art === "oeffnen" ? [3, 5, 10, 20] : LK.art === "sitzung" ? [5, 10, 15, 30] : [15, 30, 60, 120];
      werte.forEach(v => { const b = el("button", null, LK.art === "oeffnen" ? v + "×" : v + " Min"); b.type = "button"; if (+num.value === v) b.classList.add("an");
        b.addEventListener("click", () => { num.value = v; num.dispatchEvent(new Event("input", {bubbles:true})); pre.querySelectorAll("button").forEach(x => x.classList.toggle("an", x === b)); }); pre.append(b); });
      zeit.after(pre); }
  }
  const ger = f.querySelectorAll(".lk-schritt")[2]?.querySelector(".chips");
  if (ger){ ger.classList.add("cm-geraete"); ger.querySelectorAll(".chip").forEach(b => { const n = b.textContent.replace(/^[💻📱]\s*/u, "").trim();
      b.replaceChildren(cmKachel(/alle/i.test(n) ? "" : n, /alle/i.test(n) ? "shield" : null), el("span", null, n)); }); }
}
if (typeof lkOffen === "function"){
  const _lkOffen = lkOffen;
  lkOffen = function(d){
    const out = _lkOffen.call(this, d);
    const timer = out.find(x => x.classList?.contains("lk-timer") || x.querySelector?.(".lk-timer")) || out[0];
    const liste = out.find(x => x.classList?.contains("lk-regeln")), form = out.find(x => x.classList?.contains("lk-neu")), unten = out.find(x => x.classList?.contains("lk-unten"));
    const rest = out.filter(x => ![timer, liste, form, unten].includes(x));
    if (!liste || !form) return out;
    if (LK.bearbeiten) CM.offen = true;
    // Reiter
    const tabs = el("div","cm-tabs"); tabs.setAttribute("role","tablist");
    [["zeit","Sperrzeiten"],["limit","Tageslimits"],["frei","Freischalten"]].forEach(([k, t]) => { const b = el("button", null, t); b.type = "button"; b.setAttribute("role","tab"); b.setAttribute("aria-selected", String(CM.tab === k));
      b.addEventListener("click", () => { CM.tab = k; store("cm.lockerTab", k); renderLocker(true); }); tabs.append(b); });
    const teile = [tabs];
    const regeln = d.regeln || [], karten = [...liste.querySelectorAll(".lk-regel")];
    const cmTage = t => { t = [...(t || [])].sort(); if (t.length === 7) return "täglich"; const folge = t.every((x, i) => !i || x === t[i - 1] + 1); return t.length >= 3 && folge ? `${LK_TAGE[t[0]]}–${LK_TAGE[t[t.length - 1]]}` : t.map(i => LK_TAGE[i]).join(", "); };
    const cmRegelKurz = r => { const tage = cmTage(r.tage), ger = r.geraete?.length ? r.geraete.join(" + ") : "alle Geräte";
      const wann = r.art === "zeit" ? `${r.von}–${r.bis}` : r.art === "sitzung" ? `${r.minuten} Min am Stück` : r.art === "oeffnen" ? `${r.anzahl}× öffnen` : `${r.minuten} Min/Tag`;
      return `${tage} ${wann} · ${ger}`; };
    const cmRegelStatus = (r, alt) => r.gesperrt ? (r.pauseBis ? `Pause bis ${r.pauseBis}` : r.art === "zeit" ? `läuft · bis ${r.bis}` : "gerade gesperrt") : r.art === "zeit" ? `frei · ab ${r.von}` : alt;
    // Regel-Karten wie im Entwurf: Kachel, Titel, Status in Violett, eine Zeile Apps · Zeiten · Geräte, Pfeil rechts; Bearbeiten/Löschen hinter dem Pfeil
    karten.forEach((k, i) => { const r = regeln[i]; if (!r || k.classList.contains("cm-kompakt")) return;
      const alt = k.querySelector(".lk-kopf"), status = alt?.querySelector(".lk-status")?.textContent || "", knoepfe = [...k.querySelectorAll(".lk-kopf > button")];
      const titel = r.name || (r.art === "zeit" ? "Sperrzeit" : r.art === "sitzung" ? "Am Stück" : r.art === "oeffnen" ? "Öffnungs-Limit" : "Tageslimit");
      const apps = r.apps.slice(0, 3).join(", ") + (r.apps.length > 3 ? ` +${r.apps.length - 3}` : "");
      const std = r.art === "zeit" ? "clock" : r.art === "sitzung" ? "pause" : r.art === "oeffnen" ? "hash" : "hourglass";
      const kachel = cmKachel("", store("cm.regelIcon." + r.id) || std); kachel.classList.add("gross", "waehlbar"); kachel.title = "Symbol ändern";
      const body = el("div","cm-regel-text"), pfeil = el("button","cm-pfeil","›"); pfeil.type = "button"; pfeil.setAttribute("aria-label","Bearbeiten oder löschen");
      body.append(el("b", null, titel), el("small", r.gesperrt ? "zu" : "", cmRegelStatus(r, status)), el("span","ap", apps + " · " + cmRegelKurz(r)));
      const akt = el("div","cm-regel-akt"); akt.hidden = true; akt.append(...knoepfe);
      const glyphs = el("div","cm-glyphs"); glyphs.hidden = true;
      ["clock","moon","sun","work","game","book","bed","heart","shield","hourglass","pause","hash"].forEach(g => { const x = cmKachel("", g); if ((store("cm.regelIcon." + r.id) || std) === g) x.classList.add("an");
        x.addEventListener("click", () => { store("cm.regelIcon." + r.id, g); renderLocker(true); }); glyphs.append(x); });
      kachel.addEventListener("click", () => { glyphs.hidden = !glyphs.hidden; });
      pfeil.addEventListener("click", () => { akt.hidden = !akt.hidden; });
      k.classList.add("cm-kompakt"); k.replaceChildren(kachel, body, pfeil, glyphs, akt);
    });
    if (CM.tab === "frei"){
      teile.push(timer, ...rest);
      if (unten) teile.push(unten);
    } else {
      const zeit = CM.tab === "zeit", passend = [];
      karten.forEach((k, i) => { const r = regeln[i]; if (r && (r.art === "zeit") === zeit) passend.push(k); });
      const box = el("div","lk-regeln");
      if (passend.length) box.append(...passend);
      else box.append(el("p","cm-leer", zeit ? "Noch keine Sperrzeit. Zu festen Zeiten sind die Apps dann ganz zu." : "Noch kein Limit. Erlaubt eine Zeit pro Tag, am Stück oder eine Zahl an Öffnungen."));
      teile.push(box);
      const neu = el("button","cm-neu", zeit ? "＋ Neue Sperrzeit" : "＋ Neues Limit"); neu.type = "button";
      neu.addEventListener("click", () => cmRegelAuf(zeit ? "zeit" : "limit")); teile.push(neu);
    }
    // Formular in den Dialog (Assistent), sonst versteckt im Reiter
    form.hidden = !CM.offen;
    if (CM.offen) setTimeout(() => cmAssistent(form), 0); else { const dl = $("cmRegel"); if (dl?.open) dl.close(); }
    teile.push(form);
    return teile;
  };
  if (typeof lkAktion === "function"){ const _lkAkt = lkAktion; lkAktion = async function(body){ const r = await _lkAkt.call(this, body); if (r && body?.regel) cmRegelZu(false); return r; }; }
  // App Locker (Regeln) zuerst, die Karten Innehalten/Schutz darunter (john: „Locker überladen“).
  // Scroll-Stand bleibt beim Neuzeichnen erhalten (john 02.11.: „springt nach oben“, wenn der Locker aufgeht)
  const _rl = renderLocker;
  renderLocker = function(...a){ const y = window.scrollY, r = _rl.apply(this, a);
    if (Math.abs(window.scrollY - y) > 2) window.scrollTo({top:y, behavior:"instant"});
    requestAnimationFrame(() => { if (!$("cmRegel")?.open && Math.abs(window.scrollY - y) > 2) window.scrollTo({top:y, behavior:"instant"}); });
    const tab = document.querySelector('.tab[data-r="locker"]'), lb = $("lockerBox"), karten = $("trLockerKarten");
    if (tab && lb && karten && tab.firstElementChild !== lb) tab.prepend(lb);
    if (lb && karten){ lb.classList.add("cm-locker"); karten.classList.add("cm-karten"); }
    $("locker")?.querySelectorAll("p.k-s.c-bad").forEach(p => { if (/^Gerade gesperrt/.test(p.textContent)) p.className = "cm-jetzt"; }); return r; };
}

/* ----- Locker: Innehalten und Schutz als aufklappbare Karten (john 02.11.), zu bleibt gemerkt ----- */
function cmKartenKlappen(){
  const box = $("trLockerKarten"); if (!box) return;
  const tab = document.querySelector('.tab[data-r="locker"]'), lb = $("lockerBox");
  if (tab && lb && tab.firstElementChild !== lb) tab.prepend(lb);
  [...box.querySelectorAll(".tr-karte")].forEach((k, i) => {
    const kopf = k.querySelector(".tr-karte-kopf"); if (!kopf || kopf.querySelector(".cm-pfeil")) return;
    // 1.0.14: Symbol und Auf/Zu nach Titel statt Platz (die Reihenfolge ordnet blockem.js)
    const titel = kopf.querySelector("b")?.textContent || String(i);
    const glyph = /^Nachfrage/.test(titel) ? "pause" : /regelt mit/.test(titel) ? "clock" : /^Orts/.test(titel) ? "pin" : "shield";
    const ico = kopf.querySelector(".tr-ico"); if (ico && CM_SVG[glyph]){ ico.innerHTML = CM_SVG[glyph]; ico.classList.add("cm-kachel"); }
    const key = "cm.karte." + titel.split(" ")[0], zu = store(key) !== "auf";
    k.classList.toggle("cm-zu", zu);
    const pfeil = el("button","cm-pfeil", "›"); pfeil.type = "button"; pfeil.setAttribute("aria-expanded", String(!zu)); pfeil.setAttribute("aria-label", zu ? "Aufklappen" : "Zuklappen");
    kopf.append(pfeil);
    const umschalten = () => { const jetztZu = !k.classList.contains("cm-zu"); k.classList.toggle("cm-zu", jetztZu); store(key, jetztZu ? "zu" : "auf"); pfeil.setAttribute("aria-expanded", String(!jetztZu)); };
    pfeil.addEventListener("click", umschalten);
    kopf.addEventListener("click", ev => { if (ev.target.closest("button, input, label, a, textarea, select")) return; umschalten(); });
    kopf.style.cursor = "pointer";
  });
}
if (typeof trLockerKarten === "function"){ const _tlk = trLockerKarten; trLockerKarten = async function(...a){ const y = window.scrollY, r = await _tlk.apply(this, a); cmKartenKlappen(); if (Math.abs(window.scrollY - y) > 2) window.scrollTo({top:y, behavior:"instant"}); return r; }; }
cmKartenKlappen();
// Die Karten kommen asynchron (trLaden); sobald sie im DOM sind, Pfeile anbauen
(function(){ const box = $("trLockerKarten") || document.querySelector('.tab[data-r="locker"]'); if (!box) return;
  new MutationObserver(() => cmKartenKlappen()).observe(box, {childList:true, subtree:true}); })();

/* ----- Werte: Tag antippen → Tagesansicht ----- */
const cmDatum = d => new Date(d + "T12:00").toLocaleDateString("de-DE", {weekday:"long", day:"numeric", month:"long"});
const cmVerschieben = (d, n) => { const t = new Date(d + "T12:00"); t.setDate(t.getDate() + n); return iso(t); };
async function cmTagLaden(datum, ziel){
  CM.tag = datum; CM.ziel = ziel || CM.ziel;
  let d = datum === TODAY ? S.day : CM.tagDaten[datum];
  if (!d && S.mode === "lokal"){ cmTagZeichnen(null); try { d = await api("api/today?date=" + datum); CM.tagDaten[datum] = d; } catch { d = null; } }
  if (CM.tag === datum) cmTagZeichnen(d);
  document.querySelectorAll(".week .col").forEach((c, i) => c.classList.toggle("cm-gewaehlt", S.week?.tage?.[i]?.date === datum));
  document.querySelectorAll("#rbInhalt .rb-tag").forEach(c => c.classList.toggle("cm-gewaehlt", c.dataset.datum === datum));
}
function cmTagZeichnen(d){
  const ziel = CM.ziel; if (!ziel) return;
  let box = ziel.querySelector(".cm-tag"); if (!box){ box = el("div","cm-tag cm-karte"); ziel.append(box); }
  const kopf = el("div","cm-tag-kopf"), nav = el("span"), zur = el("button","ghost small","‹"), vor = el("button","ghost small","›");
  zur.type = vor.type = "button"; zur.setAttribute("aria-label","Tag davor"); vor.setAttribute("aria-label","Tag danach"); vor.disabled = CM.tag >= TODAY;
  zur.addEventListener("click", () => cmTagLaden(cmVerschieben(CM.tag, -1))); vor.addEventListener("click", () => cmTagLaden(cmVerschieben(CM.tag, 1)));
  nav.append(zur, vor); kopf.append(el("h3", null, cmDatum(CM.tag) + (CM.tag === TODAY ? " (heute)" : "")), nav);
  if (!d){ box.replaceChildren(kopf, el("p","cm-leer", S.mode === "lokal" ? "Wird geladen …" : "Nur am Computer mit den Daten.")); return; }
  const s = d.summe || {}, bild = (s.produktiv || 0) + (s.prokrastination || 0) + (s.neutral || 0);
  const kpis = el("div","cm-kpis");
  [["Produktiv", s.produktiv, "var(--cm-mint)"], ["Ablenkung", s.prokrastination, "var(--cm-coral)"], ["Bildschirm", bild, ""]].forEach(([l, v, c]) => {
    const k = el("div"), b = el("b", null, bild ? minText(v || 0) : "–"); if (c) b.style.color = c; k.append(el("span","cm-lbl", l), b); kpis.append(k); });
  const teile = [kopf, kpis];
  const gers = d.geraete || [];
  if (gers.length){
    teile.push(el("h4", null, "Geräte"));
    const mx = Math.max(1, ...gers.map(g => g.sek || 0));
    gers.forEach(g => { const z = el("div","cm-zeile"), mix = el("div","mix"), tot = g.sek || 1;
      [["produktiv","var(--cm-mint)"],["neutral","var(--neutral)"],["prokrastination","var(--cm-coral)"]].forEach(([k, c]) => { if (!g[k]) return; const i = el("i"); i.style.width = g[k] / tot * 100 + "%"; i.style.background = c; mix.append(i); });
      mix.style.width = Math.max(30, g.sek / mx * 80) + "px";
      z.append(cmKachel(g.name), el("span","n", g.name), el("span","v", minText(g.sek)), mix); teile.push(z); });
  }
  const m = new Map();
  (gers.length ? gers : [{apps:d.apps || []}]).forEach(g => (g.apps || []).filter(a => a.kat === "prokrastination").forEach(a => { const k = a.name.toLowerCase(), e = m.get(k) || {name:a.name, sek:0}; e.sek += a.sek; m.set(k, e); }));
  const top = [...m.values()].sort((a, b) => b.sek - a.sek).slice(0, 6);
  teile.push(el("h4", null, "Größte Ablenkungen"));
  if (top.length){ const mx = top[0].sek || 1; top.forEach(a => { const z = el("div","cm-zeile"), b = el("div","b"), i = el("i"); i.style.width = a.sek / mx * 100 + "%"; b.append(i); z.append(cmKachel(a.name), el("span","n", a.name), el("span","v", minText(a.sek)), b); teile.push(z); }); }
  else teile.push(el("p","cm-leer","Keine Ablenkung an diesem Tag. Stark."));
  box.replaceChildren(...teile);
}
if (typeof renderWeek === "function"){
  const _rw = renderWeek;
  renderWeek = function(...a){
    const r = _rw.apply(this, a), w = S.week; if (!w) return r;
    const sec = $("week")?.closest("section"); if (!sec) return r;
    if (!sec.querySelector(".cm-karte")){ const k = el("div","cm-karte"); const h = sec.querySelector("h2"); k.append(...[h, $("week"), $("weekSum")].filter(Boolean)); sec.prepend(k); }
    [...document.querySelectorAll(".week .col")].forEach((c, i) => { c.tabIndex = 0; c.setAttribute("role","button"); c.title = "Tag ansehen";
      const go = () => cmTagLaden(w.tage[i].date, sec); c.addEventListener("click", go); c.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " "){ e.preventDefault(); go(); } }); });
    if (!CM.ziel || CM.ziel === sec) cmTagLaden(CM.tag && w.tage.some(t => t.date === CM.tag) ? CM.tag : TODAY, sec);
    return r;
  };
  if (S.week) renderWeek();
}
if (typeof renderRueckblick === "function"){
  const _rr = renderRueckblick;
  renderRueckblick = function(...a){
    const r = _rr.apply(this, a), rb = RB.daten, box = $("rbInhalt"); if (!rb || !box) return r;
    [...box.querySelectorAll(".rb-tag")].forEach((c, i) => { const datum = cmVerschieben(rb.von, i); c.dataset.datum = datum; c.tabIndex = 0; c.setAttribute("role","button");
      if (datum > TODAY) return;
      const go = () => cmTagLaden(datum, box); c.addEventListener("click", go); c.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " "){ e.preventDefault(); go(); } }); });
    return r;
  };
}

}

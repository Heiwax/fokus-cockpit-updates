// Ziele-Reiter: Heute | Woche | Monat | Jahr als Karten; Heute und Woche mit Stundenkonto und Wochentagen
function zKopf(titel, sub, plan){
  const h = el("h2", null, titel); h.append(el("span", null, sub));
  if (plan){ const b = el("button","act-btn plan-btn", {heute:"Heute planen", woche:"Woche planen", monat:"Monat planen"}[plan]); b.type = "button"; b.dataset.plan = plan; b.hidden = S.mode === "claude"; h.append(b); }
  return h;
}
function zListe(items, ctx, leer){
  const ul = el("ul","list"); byDone(items).forEach(i => ul.append(itemRow(i, {ctx})));
  if (!items.length) ul.append(el("li","empty", leer)); return ul;
}
const zErreicht = items => el("p","zhint", items.length ? `${items.filter(i => i.done).length} von ${items.length} erreicht` : "");
function renderZiele(p){
  const kh = kontoHeute(p), kw = kontoWoche(p), th = zeitTag(TODAY);
  // Heute
  const hs = el("section","hud zcard"), hb = el("div","konto-box");
  hs.append(zKopf("Heute", `${WD[NOW.getDay()]} ${NOW.getDate()}.${NOW.getMonth() + 1}.`, "heute"));
  if (!th.std && !p.heute.length) hb.append(el("p","konto-frei","Heute ist als frei eingetragen. Viel Erholung!"));
  else hb.append(kontoMeter("Stunden", kh.std, th.std, true), kontoMeter("Aufgaben", kh.n, th.aufgaben));
  const hsub = el("p","konto-sub");
  if (th.std || p.heute.length){
    hsub.append(kh.std > th.std ? el("span","c-warn", `${stdKurz(kh.std - th.std)} mehr als geplant`) : `noch ${stdKurz(th.std - kh.std)} frei`);
    if (kh.n > th.aufgaben) hsub.append(" · ", el("span","c-warn", "mehr Aufgaben als geplant"));
    if (kh.ohne) hsub.append(` · ${kh.ohne} ohne Stundenangabe`);
  }
  if (hsub.childNodes.length) hsub.append(" · ");
  hsub.append(ztLink(TODAY, "heute", "Zeit für heute ändern"));
  hs.append(hb, hsub);
  if (ZT.offen === TODAY && ZT.wo === "heute") hs.append(zeitPanel(TODAY));
  hs.append(zListe(p.heute, "h", "Für heute ist noch nichts geplant. Tipp auf „Heute planen“."), periodForm("heute", p.projekte));
  // Woche
  const ws = el("section","hud zcard"), wb = el("div","konto-box");
  ws.append(zKopf("Woche", `KW ${p.wocheKw || p.kw || isoWeek(NOW)} · ${leftText(weekEnd())}`, "woche"));
  wb.append(kontoMeter("Stunden diese Woche", kw.std, kw.zeit, true, "wide"));
  const wsub = el("p","konto-sub");
  wsub.append(kw.offen > kw.rest ? el("span","c-warn", `Offen ${stdKurz(kw.offen)}, aber nur ${stdKurz(kw.rest)} Zeit bis So`) : `Offen ${stdKurz(kw.offen)} · Zeit bis So ${stdKurz(kw.rest)}`);
  if (kw.ohne) wsub.append(` · ${kw.ohne} ohne Stundenangabe`);
  const strip = el("div","zt-strip");
  wochenTage().forEach(d => {
    const t = zeitTag(d.iso), b = el("button", "zt-tag" + (d.vorbei ? " vorbei" : "") + (d.heute ? " heute" : "") + (t.std ? "" : " frei") + (t.eigen ? " eigen" : "") + (ZT.offen === d.iso && ZT.wo === "woche" ? " on" : ""));
    b.type = "button"; b.title = `${d.label}: ${t.std ? stdKurz(t.std) + ", " + t.aufgaben + " Aufgaben" : "frei"} (antippen zum Ändern)`;
    b.setAttribute("aria-label", `${d.label}: ${t.std ? stdKurz(t.std) : "frei"}`);
    b.append(el("span","zt-wd", d.heute ? "Heute" : d.wd), el("b", null, t.std ? stdZahl(t.std) : "–"), el("small", null, t.std ? "Std" : "frei"));
    b.addEventListener("click", () => ztOeffnen(d.iso, "woche")); strip.append(b);
  });
  const z = zeitDaten(), std = el("p","zt-std");
  std.append(`Standard: ${stdKurz(z.std)} und ${z.aufgaben} Aufgaben pro Tag`, " · ", ztLink("standard", "woche", "Ändern"));
  ws.append(wb, wsub, strip, std);
  if (ZT.offen && ZT.wo === "woche") ws.append(zeitPanel(ZT.offen));
  ws.append(zErreicht(p.woche), zListe(p.woche, "zwoche", "Noch keine Wochenziele. Tipp auf „Woche planen“."), periodForm("woche", p.projekte));
  // Monat und Jahr
  const ms = el("section","hud zcard");
  ms.append(zKopf("Monat", `${p.monatName || `${MONATE[NOW.getMonth()]} ${NOW.getFullYear()}`} · ${leftText(monthEnd())}`, "monat"), zErreicht(p.monat),
    zListe(p.monat, "zmonat", "Noch keine Monatsziele. Tipp auf „Monat planen“ und wähl die Projekte für diesen Monat."), periodForm("monat", p.projekte));
  const js = el("section","hud zcard");
  js.append(zKopf("Jahr", `${NOW.getFullYear()} · ${leftText(yearEnd())}`), zErreicht(p.jahr), zListe(p.jahr, "zjahr", "Noch keine Jahresziele."), periodForm("jahr", p.projekte));
  $("zieleCols").replaceChildren(hs, ws, ms, js);
}

/* ---------- Zeit: Stunden und Aufgaben pro Tag, einzelne Tage frei oder anders (steht in der Cockpit-Notiz unter „## Zeit“) ---------- */
const ZT = {offen:null, wo:null};   // offener Tag (ISO-Datum oder "standard") und in welcher Karte
const stdZahl = h => String(Math.round(h * 10) / 10).replace(".", ",");
const stdKurz = h => stdZahl(h) + " Std";
function zeitDaten(){ if (S.plan && !S.plan.zeit) S.plan.zeit = {std:3, aufgaben:3, tage:{}}; return S.plan?.zeit || {std:3, aufgaben:3, tage:{}}; }
function zeitTag(d){ const z = zeitDaten(), t = z.tage[d] || {}; return {std:t.std ?? z.std, aufgaben:t.aufgaben ?? z.aufgaben, eigen:d in z.tage}; }
function wochenTage(){
  const mo = new Date(NOW); mo.setDate(mo.getDate() - (NOW.getDay() + 6) % 7);
  return [...Array(7)].map((_, i) => { const d = new Date(mo); d.setDate(mo.getDate() + i); const s = iso(d);
    return {iso:s, wd:WD[d.getDay()], label:`${WD[d.getDay()]} ${d.getDate()}.${d.getMonth() + 1}.`, vorbei:s < TODAY, heute:s === TODAY}; });
}
const stdSum = list => list.reduce((a, i) => a + (i.std || 0), 0);
function kontoHeute(p){ return {std:stdSum(p.heute), n:p.heute.length, ohne:p.heute.filter(i => !i.done && i.std == null).length}; }
function kontoWoche(p){
  const tage = wochenTage();
  return {zeit:tage.reduce((a, d) => a + zeitTag(d.iso).std, 0), rest:tage.filter(d => !d.vorbei).reduce((a, d) => a + zeitTag(d.iso).std, 0),
    std:stdSum(p.woche), offen:p.woche.reduce((a, i) => a + (i.done ? 0 : i.rest ?? i.std ?? 0), 0), ohne:p.woche.filter(i => !i.done && i.std == null).length};
}
function kontoMeter(label, wert, max, std = false, cls = ""){
  const box = el("div","konto" + (cls ? " " + cls : "")), over = wert > max + 1e-9, voll = !over && max > 0 && wert >= max - 1e-9;
  const top = el("div","konto-top"), f = std ? stdKurz : String;
  top.append(el("span","k-l", label), el("b", over ? "c-warn" : null, `${f(wert)} von ${f(max)}`));
  box.append(top, kpiBar(max ? Math.min(100, wert / max * 100) : (wert ? 100 : 0), over ? "var(--warn)" : voll ? "var(--good)" : "var(--cyan)"));
  return box;
}
function ztLink(ziel, wo, text){
  const b = el("button","zt-link", text); b.type = "button"; b.setAttribute("aria-expanded", ZT.offen === ziel && ZT.wo === wo);
  b.addEventListener("click", () => ztOeffnen(ziel, wo)); return b;
}
function ztOeffnen(ziel, wo){ const zu = ZT.offen === ziel && ZT.wo === wo; ZT.offen = zu ? null : ziel; ZT.wo = zu ? null : wo; renderZiele(S.plan); }
function zeitPanel(ziel){
  const z = zeitDaten(), standard = ziel === "standard", t = standard ? {std:z.std, aufgaben:z.aufgaben} : zeitTag(ziel);
  const d = !standard && new Date(ziel + "T12:00"), box = el("div","zt-panel");
  box.append(el("b","zt-titel", standard ? "Standard für jeden Tag" : `${ziel === TODAY ? "Heute, " : ""}${WD[d.getDay()]} ${d.getDate()}.${d.getMonth() + 1}.`));
  const reihe = (label, werte, aktiv, setze) => {
    const r = el("div","zt-row"), c = el("div","chips"); r.append(el("span","lbl", label));
    werte.forEach(([w, txt]) => { const b = el("button","chip small", txt); b.type = "button"; b.setAttribute("aria-pressed", w === aktiv);
      b.addEventListener("click", () => setze(w)); c.append(b); });
    r.append(c); return r;
  };
  const stunden = [...(standard ? [] : [[0, "frei"]]), ...[1, 2, 3, 4, 5, 6, 8].map(n => [n, n + " Std"])];
  box.append(reihe("Stunden", stunden, t.std, w => zeitSetzen(ziel, {std:w})));
  if (standard || t.std) box.append(reihe("Aufgaben", [1, 2, 3, 4, 5, 6].map(n => [n, String(n)]), t.aufgaben, w => zeitSetzen(ziel, {aufgaben:w})));
  const btns = el("div","zt-btns");
  if (!standard && t.eigen){ const r = el("button","ghost small", `Wie Standard (${stdKurz(z.std)})`); r.type = "button";
    r.addEventListener("click", () => zeitSetzen(ziel, {std:null, aufgaben:null})); btns.append(r); }
  const ok = el("button","ask", "Fertig"); ok.type = "button"; ok.addEventListener("click", () => { ZT.offen = ZT.wo = null; renderZiele(S.plan); });
  btns.append(ok); box.append(btns);
  return box;
}
async function zeitSetzen(ziel, werte){
  const z = zeitDaten();
  if (ziel === "standard") Object.assign(z, werte);
  else { const t = {...(z.tage[ziel] || {}), ...werte}; Object.keys(t).forEach(k => t[k] == null && delete t[k]);
    if (Object.keys(t).length) z.tage[ziel] = t; else delete z.tage[ziel]; }
  renderPlan();
  if (S.mode !== "lokal") return;
  try { S.plan = await api("api/zeit", ziel === "standard" ? {standard:werte} : {datum:ziel, std:z.tage[ziel]?.std ?? null, aufgaben:z.tage[ziel]?.aufgaben ?? null}); renderPlan(); }
  catch (e) { S.fehler = [`Zeit speichern hat nicht geklappt: ${e.message || e}`]; renderHeader(); }
}
function periodForm(liste, projekte){
  const was = {heute:"Ziel für heute", woche:"Wochenziel", monat:"Monatsziel", jahr:"Jahresziel"}[liste], k = "g|" + liste;
  const f = el("form","add period"), inp = el("input"), sel = document.createElement("select"), b = el("button", null, "+"), c = el("button","claude-btn","Mit Claude ausplanen");
  inp.placeholder = "Neues " + was; inp.autocomplete = "off"; inp.dataset.k = k; inp.value = S.drafts[k] || ""; inp.setAttribute("aria-label", "Neues " + was);
  inp.addEventListener("input", () => S.drafts[k] = inp.value);
  sel.setAttribute("aria-label", "Projekt"); projOptions(sel, projekte); sel.value = S.drafts[k + "|p"] || ""; sel.addEventListener("change", () => S.drafts[k + "|p"] = sel.value);
  b.type = "submit"; b.setAttribute("aria-label", was + " hinzufügen"); c.type = "button";
  c.title = "Ziel anlegen und den Satz für Claude kopieren: Claude stellt dir Fragen und trägt die Schritte ein";
  const go = t => { S.drafts[k] = ""; S.refocus = k; addItem(liste, t, sel.value); };
  f.addEventListener("submit", e => { e.preventDefault(); const t = inp.value.trim(); if (t) go(t); });
  c.addEventListener("click", async () => { const t = inp.value.trim(); if (!t){ inp.focus(); toast("Schreib zuerst das Ziel ins Feld."); return; }
    await copyToast(`Neues ${was}${sel.value ? ` im Projekt ${sel.value}` : ""}: „${t}“. Stell mir ein paar Fragen dazu und trag die Schritte ein.`); go(t); });
  if (S.mode === "claude" || liste === "heute") c.hidden = true;
  f.append(inp, sel, b, c); return f;
}


/* ---------- Verbindung (3.0): woher die Daten kommen ----------
   „server“: BlockEm-Server (Mac im WLAN oder Online-Server). In der Handy-App über die Brücke CockpitApp.anfrage, sonst fetch.
             Ohne Verbindung: letzter Stand aus dem Speicher, Abhaken/Hinzufügen/Habits/Ideen warten und gehen später raus.
   „handy“:  Kein Server. Dieselbe Logik (server.py) läuft als Python im Handy (Pyodide), Daten bleiben auf dem Gerät. */
const APP = window.CockpitApp || null;
const VB = {
  inApp: !!(APP && APP.modus),                        // Handy-App ab 3.0: Seite kommt aus der App selbst
  modus: APP && APP.modus ? APP.modus() : "server",
  offline: false, stand: null, py: null, pyLaden: null, n: 0, wartet: {},
};
const VB_WARTE = "cockpit.warteschlange", VB_CACHE = "cockpit.cache:";
const VB_NACHREICHEN = ["api/toggle", "api/add", "api/habit", "api/idee", "api/echt"];

function vbCache(path, j){
  if (j === undefined){ const c = store(VB_CACHE + path); return c && c.daten; }
  store(VB_CACHE + path, {zeit: Date.now(), daten: j});
}
function vbIstPlan(j){ return j && Array.isArray(j.heute) && Array.isArray(j.projekte); }

// Netz: im Browser fetch, in der App die Brücke (kein CORS, eigener Server-Eintrag in der App)
function vbNetz(path, body, ms){
  if (VB.inApp) return new Promise((ok, nein) => {
    const id = "a" + (++VB.n);
    const t = setTimeout(() => { delete VB.wartet[id]; const e = new Error("Keine Antwort von BlockEm-Server"); e.netz = true; nein(e); }, ms || 20000);
    VB.wartet[id] = (status, text) => {
      clearTimeout(t);
      if (!status){ const e = new Error(text || "Server nicht erreichbar"); e.netz = true; return nein(e); }
      let j; try { j = JSON.parse(text); } catch { j = {fehler: text}; }
      if (status === 403){ const e = new Error(j.fehler || "Zugangscode stimmt nicht"); e.zugang = true; return nein(e); }
      if (status >= 400) return nein(new Error(j.fehler || "Fehler " + status));
      ok(j);
    };
    APP.anfrage(id, body ? "POST" : "GET", path, body ? JSON.stringify(body) : "");
  });
  const headers = {"X-Cockpit-Code": CODE};
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), ms || 30000);
  return fetch(path, body ? {method:"POST", headers:{...headers, "Content-Type":"application/json"}, body:JSON.stringify(body), signal:ctl.signal}
                          : {cache:"no-store", headers, signal:ctl.signal})
    .catch(e => { e.netz = true; throw e; })
    .then(async r => {
      clearTimeout(t);
      let j; try { j = await r.json(); } catch { j = {fehler: "Antwort unlesbar (" + r.status + ")"}; }
      if (r.status === 403){ const e = new Error(j.fehler || "Zugangscode stimmt nicht"); e.zugang = true; throw e; }
      if (!r.ok) throw new Error(j.fehler || "Fehler");
      return j;
    });
}
// Antwort der Brücke (MainActivity ruft das auf)
window.__vbAntwort = (id, status, text) => { const f = VB.wartet[id]; if (f){ delete VB.wartet[id]; f(status, text); } };

async function vbServer(path, body, ms){
  try {
    const j = await vbNetz(path, body, ms);
    if (!body) vbCache(path, j); else if (vbIstPlan(j)) vbCache("api/plan", j);
    if (VB.offline){ VB.offline = false; vbBanner(); setTimeout(vbNachreichen, 300); setTimeout(() => vbLockerHolen(true), 600); }
    if (vbIstLocker(path)) setTimeout(() => vbLockerHolen(!!body), 50);
    return j;
  } catch (e) {
    if (!e.netz) throw e;
    VB.offline = true; vbBanner();
    if (vbIstLocker(path) && VB.inApp) return vbLockerOffline(path, body);
    if (!body){ const c = vbCache(path); if (c !== null && c !== undefined) return c; throw new Error("Offline und noch kein gespeicherter Stand"); }
    if (!VB_NACHREICHEN.includes(path)) throw new Error("Das geht erst wieder, wenn BlockEm erreichbar ist.");
    return vbMerken(path, body);
  }
}

// Offline: merken und sofort im gespeicherten Stand anzeigen
function vbMerken(path, body){
  const q = store(VB_WARTE) || []; q.push({path, body, zeit: Date.now()}); store(VB_WARTE, q);
  const p = vbCache("api/plan") || S.plan;
  if (p && path === "api/toggle"){
    const alle = [...(p.heute || []), ...(p.woche || []), ...(p.monat || []), ...(p.jahr || []), ...(p.tage || []).flatMap(d => d.items)];
    alle.filter(i => i.id === body.id || (body.text && i.text === body.text)).forEach(i => { i.done = !!body.done; i.own = !!body.done; });
    (p.projekte || []).forEach(x => (x.aufgaben || []).forEach(s => { if (s.id === body.id) s.done = !!body.done; }));
  }
  if (p && path === "api/add" && ["heute", "woche", "monat", "jahr"].includes(body.liste))
    p[body.liste].push({id: "offline-" + Date.now(), text: body.text, done: false, own: false, projekt: body.projekt || null});
  if (p) vbCache("api/plan", p);
  toast("Offline gespeichert. Geht raus, sobald BlockEm wieder erreichbar ist.");
  vbBanner();
  return p || {};
}
async function vbNachreichen(){
  if (VB.schickt) return;
  let q = store(VB_WARTE) || []; if (!q.length) return;
  VB.schickt = true;
  try {
    while (q.length){
      const x = q[0];
      try { await vbNetz(x.path, x.body); }
      catch (e) { if (e.netz) break; }   // Server-Fehler (z. B. Aufgabe gibt es nicht mehr): verwerfen, weiter
      q.shift(); store(VB_WARTE, q);
    }
    if (!q.length){ toast("Offline-Änderungen sind angekommen."); loadLocal().catch(() => {}); }
  } finally { VB.schickt = false; vbBanner(); }
}

/* ----- Locker auf jedem Gerät (3.14): Kopie vom Mac im Handy, ohne Verbindung rechnet Python im Handy ----- */
const VB_LOCKER = "cockpit.lockerKopie", VB_LOCKER_NEU = "cockpit.lockerOffline";
const vbIstLocker = p => p === "api/locker" || p.startsWith("api/locker?");
// Mit Verbindung: offline Geändertes zum Mac bringen, sonst den neuesten Stand holen (höchstens alle 30 s, außer nach einer Änderung)
async function vbLockerHolen(sofort){
  if (!VB.inApp || VB.modus === "handy" || VB.lockerHolt) return;
  const k = store(VB_LOCKER), neu = store(VB_LOCKER_NEU);
  if (!sofort && !neu && k && Date.now() - (k.zeit || 0) < 30000) return;
  VB.lockerHolt = true;
  try {
    const j = neu && k ? await vbNetz("api/locker-abgleich", {locker: k.locker, geraet: APP.geraet ? APP.geraet() : ""})
                       : await vbNetz("api/locker-kopie");
    store(VB_LOCKER, {...j, zeit: Date.now()});
    if (neu){ store(VB_LOCKER_NEU, null); toast("Locker-Änderungen vom Handy sind jetzt auch auf dem Mac."); }
  } catch {} finally { VB.lockerHolt = false; }
}
async function vbLockerOffline(path, body){
  const k = store(VB_LOCKER);
  if (!k) throw new Error("Der Locker war auf diesem Handy noch nie mit dem Mac verbunden. Einmal im selben WLAN öffnen, danach geht er auch unterwegs.");
  const py = await vbPython(), kern = py.globals.get("handy_kern");
  kern.locker_setzen(JSON.stringify(k.locker || {}), APP.fokusBis ? +APP.fokusBis() || 0 : 0);
  const [p, q] = path.split("?");
  const j = JSON.parse(kern.anfrage(body ? "POST" : "GET", "/" + p, q || "", body ? JSON.stringify(body) : ""));
  if (j && j.__fehler) throw new Error(j.__fehler);
  if (body){
    const neu = JSON.parse(kern.locker_lesen());
    if (JSON.stringify(neu) !== JSON.stringify(k.locker || {})){
      store(VB_LOCKER, {...k, locker: neu});
      store(VB_LOCKER_NEU, true);
      vbLockerAnSperre(kern);
    }
    vbSpeichern();
  }
  if (j.offen){ j.geraete = k.geraete || j.geraete; if (k.apps?.length) j.apps = k.apps; }
  j.offline = true;
  return j;
}
// Offline geänderte Regeln sofort an die Sperre im Handy; Minuten der anderen Geräte vom letzten Stand behalten
function vbLockerAnSperre(kern){
  if (!APP.lockerRegeln) return;
  try {
    const regeln = JSON.parse(kern.locker_fuer(APP.geraet ? APP.geraet() : "Handy"));
    let alt = []; try { alt = JSON.parse(APP.lockerJetzt ? APP.lockerJetzt() : "[]"); } catch {}
    regeln.forEach(r => { const a = alt.find(x => x.id === r.id); if (a && a.andereMin && r.art === "limit") r.andereMin = a.andereMin; });
    APP.lockerRegeln(JSON.stringify(regeln));
  } catch {}
}

/* ----- Handy ohne Server: server.py als Python im Handy ----- */
function vbPython(){
  if (VB.py) return Promise.resolve(VB.py);
  if (VB.pyLaden) return VB.pyLaden;
  VB.pyLaden = (async () => {
    vbStartText("BlockEm startet …");
    await new Promise((ok, nein) => { const s = document.createElement("script"); s.src = "py/pyodide.js"; s.onload = ok; s.onerror = () => nein(new Error("Python fehlt in der App")); document.head.append(s); });
    const py = await loadPyodide({indexURL: "py/"});
    py.FS.mkdirTree("/daten");
    py.FS.mount(py.FS.filesystems.IDBFS, {}, "/daten");
    await new Promise(ok => py.FS.syncfs(true, () => ok()));
    py.FS.mkdirTree("/app/teile");
    for (const f of ["server.py", "handy_kern.py", "kategorien.json"]){
      const r = await fetch("py/app/" + f); py.FS.writeFile("/app/" + f, new Uint8Array(await r.arrayBuffer()));
    }
    // Mit Mac/Server nur für den Locker ohne Verbindung: eigener Ordner, damit „Nur auf diesem Handy“ unberührt bleibt
    if (VB.modus !== "handy") py.runPython("import os; os.environ['COCKPIT_DATEN_HANDY'] = '/daten/locker-offline'");
    py.runPython("import sys; sys.path.insert(0, '/app'); import handy_kern");
    VB.py = py; vbStartText(null);
    return py;
  })();
  VB.pyLaden.catch(e => { vbStartText("BlockEm konnte nicht starten: " + e.message, true); VB.pyLaden = null; });
  return VB.pyLaden;
}
function vbSpeichern(){
  if (!VB.py || VB.speichert) return;
  VB.speichert = true;
  setTimeout(() => VB.py.FS.syncfs(false, () => { VB.speichert = false; }), 400);
}
async function vbHandy(path, body){
  const py = await vbPython();
  if (body) await new Promise(r => setTimeout(r, 30));   // „Lädt …“ zeichnen lassen, bevor Python rechnet
  const [p, q] = path.split("?");
  const roh = py.globals.get("handy_kern").anfrage(body ? "POST" : "GET", "/" + p, q || "", body ? JSON.stringify(body) : "");
  const j = JSON.parse(roh);
  if (body || p === "api/plan") vbSpeichern();
  if (j && j.__fehler) throw new Error(j.__fehler);
  if (!body) vbCache(path, j); else if (vbIstPlan(j)) vbCache("api/plan", j);
  // Fokus/Locker geändert: der Sperre im Handy sofort Bescheid geben
  if (body && (p === "api/fokus" || p === "api/locker" || p === "api/sperre")) vbSperreAbgleich().catch(() => {});
  return j;
}
// Handy ohne Server: Nutzung (UsageStats) in die eigene Auswertung, Fokus + Locker an die Sperre geben
async function vbHandyNutzung(){
  if (!VB.inApp || VB.modus !== "handy" || !APP.nutzung) return;
  const roh = APP.nutzung(+(store("cockpit.nutzungBis") || 0));
  if (!roh) return;
  const d = JSON.parse(roh);
  if (d.fehler) return;
  const r = await vbHandy("api/handy", d);
  store("cockpit.nutzungBis", d.bis || Date.now());
  if (r.fokus && APP.fokusSetzen) APP.fokusSetzen(JSON.stringify(r.fokus));
  if (r.hinweis && APP.mitteilung) APP.mitteilung(r.hinweis.titel || "BlockEm", r.hinweis.text || "");
}
async function vbSperreAbgleich(){
  if (!VB.inApp || !APP.fokusSetzen) return;
  const f = await vbHandy("api/fokus-handy?geraet=" + encodeURIComponent(APP.geraet ? APP.geraet() : "Handy"));
  APP.fokusSetzen(JSON.stringify(f));
}

/* ----- Anzeige: Startbild, Offline-Leiste, Anmelden ----- */
function vbStartText(t, fehler){
  let b = document.getElementById("vbStart");
  if (!t){ b?.remove(); return; }
  if (!b){ b = el("div", "vb-start"); b.id = "vbStart"; b.append(el("div", "vb-logo"), el("p")); document.body.append(b); }
  b.querySelector("p").textContent = t;
  b.querySelector(".vb-logo").hidden = !!fehler;
  b.querySelectorAll("button").forEach(x => x.remove());
  if (fehler){
    const nochmal = el("button", "ask", "Nochmal versuchen"); nochmal.type = "button"; nochmal.addEventListener("click", () => location.reload()); b.append(nochmal);
    if (APP){ const e = el("button", "ghost", "Handy-App einstellen"); e.type = "button"; e.addEventListener("click", () => APP.einstellungen()); b.append(e); }
  }
}
function vbBanner(){
  let b = document.getElementById("vbOffline");
  const n = (store(VB_WARTE) || []).length;
  if (!VB.offline && !n){ b?.remove(); return; }
  if (!b){ b = el("button", "vb-offline"); b.id = "vbOffline"; b.type = "button"; b.addEventListener("click", () => { loadLocal().catch(() => {}); vbNachreichen(); }); document.querySelector(".wrap")?.prepend(b); }
  const c = vbCache("api/plan") && store(VB_CACHE + "api/plan")?.zeit;
  b.textContent = VB.offline
    ? `Offline · Stand ${c ? new Date(c).toLocaleString("de-DE", {weekday:"short", hour:"2-digit", minute:"2-digit"}) : "–"}${n ? ` · ${n} Änderung${n > 1 ? "en" : ""} wartet` : ""} · Tippen zum Neu-Versuchen`
    : `${n} Änderung${n > 1 ? "en" : ""} wird nachgereicht …`;
}
// Online-Server im Browser: Zugangscode eingeben (statt leerer Beispielseite)
function vbAnmelden(fehler){
  const d = el("div", "vb-login modern"), f = el("form"), inp = el("input"), b = el("button", "ask", "Anmelden");
  inp.type = "password"; inp.placeholder = "Zugangscode"; inp.autocomplete = "current-password"; inp.required = true;
  f.append(el("h2", null, "BlockEm"), el("p", "hint", "Gib den Zugangscode deines BlockEm-Servers ein. Er steht beim Start des Servers im Protokoll bzw. in config.json (handyCode)."), inp, b);
  if (fehler) f.append(el("p", "vb-err", fehler));
  f.addEventListener("submit", e => { e.preventDefault(); store("cockpit.code", inp.value.trim()); location.href = location.pathname + location.hash; });
  d.append(f); document.body.append(d); inp.focus();
}
window.addEventListener("online", () => { if (VB.modus === "server") loadLocal().catch(() => {}); });

/* ---------- Werte in drei Teilen (3.1): Heute / Woche / Rückblick statt einer langen Seite ---------- */
const WT_TEILE = [
  ["heute", "Heute", ["hScore", "hDay", "hHours", "hApps"]],
  ["woche", "Woche", ["hWeek", "hFc"]],
  ["rueckblick", "Rückblick", ["hRb"]],
];
function wtZeigen(k){
  if (!WT_TEILE.some(([x]) => x === k)) k = "heute";
  store("cockpit.werteTeil", k);
  WT_TEILE.forEach(([x, , ids]) => ids.forEach(id => document.querySelector(`.tab[data-r="werte"] section[aria-labelledby="${id}"]`)?.classList.toggle("wt-aus", x !== k)));
  document.querySelectorAll("#wtLeiste button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.k === k)));
  if (k === "rueckblick" && S.mode === "lokal" && !RB.daten && !RB.laedt) rbLaden();
}
(function(){
  const tab = document.querySelector('.tab[data-r="werte"]'); if (!tab || $("wtLeiste")) return;
  const leiste = el("div","chips wt-leiste"); leiste.id = "wtLeiste"; leiste.setAttribute("role", "group"); leiste.setAttribute("aria-label", "Welche Werte");
  WT_TEILE.forEach(([k, n]) => { const b = el("button","chip", n); b.type = "button"; b.dataset.k = k; b.addEventListener("click", () => wtZeigen(k)); leiste.append(b); });
  tab.prepend(leiste);
  wtZeigen(store("cockpit.werteTeil") || "heute");
})();

/* ---------- Projekte: zugeklappt mit Prozent-Ring, darin Phasen -> Ziele -> Schritte ---------- */
function ringSvg(p, r){
  const c = 2 * Math.PI * r, s = r * 2 + 8, off = c * (1 - Math.max(0, Math.min(100, +p || 0)) / 100);
  return `<svg viewBox="0 0 ${s} ${s}" aria-hidden="true"><circle cx="${s/2}" cy="${s/2}" r="${r}" fill="none" stroke="var(--away)" stroke-width="4"/>` +
    `<circle cx="${s/2}" cy="${s/2}" r="${r}" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round" transform="rotate(-90 ${s/2} ${s/2})" stroke-dasharray="${c.toFixed(2)}" stroke-dashoffset="${off.toFixed(2)}"/></svg>`;
}
function ringEl(p){
  const w = el("span", "pring" + (p >= 100 ? " full" : "")); w.innerHTML = ringSvg(p, 20);
  w.append(el("b", null, `${+p || 0}%`)); w.setAttribute("role", "img"); w.setAttribute("aria-label", `${+p || 0} Prozent`); return w;
}
function miniRing(p, full){ const w = el("span", "mring" + (full ? " full" : "")); w.innerHTML = full ? "" : ringSvg(p, 7); if (full) w.textContent = "✓"; return w; }
function addForm(k, label, onAdd, satz){
  // satz: Text für Claude -> zusätzlicher Knopf „Mit Claude“: legt an und kopiert den Satz
  const f = el("form","add"), inp = el("input"), b = el("button", null, "+");
  inp.placeholder = label; inp.autocomplete = "off"; inp.dataset.k = k; inp.value = S.drafts[k] || ""; inp.setAttribute("aria-label", label);
  b.type = "submit"; b.setAttribute("aria-label", label);
  inp.addEventListener("input", () => S.drafts[k] = inp.value);
  f.addEventListener("submit", e => { e.preventDefault(); const t = inp.value.trim(); if (!t) return; S.drafts[k] = ""; S.refocus = k; onAdd(t); });
  f.append(inp, b);
  if (satz){
    const c = el("button","claude-btn","Mit Claude"); c.type = "button"; c.title = "Ziel anlegen und den Satz für Claude kopieren: Claude stellt dir Fragen und trägt die Schritte ein";
    c.addEventListener("click", async () => { const t = inp.value.trim(); if (!t){ inp.focus(); toast("Schreib zuerst das Ziel ins Feld."); return; }
      await copyToast(satz(t)); S.drafts[k] = ""; onAdd(t); });
    f.append(c);
  }
  return f;
}
function toast(msg){
  document.querySelector(".toast")?.remove();
  const t = el("div","toast", msg); t.setAttribute("role","status"); document.body.append(t);
  setTimeout(() => t.remove(), 6000);
}
async function copyToast(satz){
  toast(await copyText(satz) ? "Kopiert. Füg den Satz bei Claude ein." : "Kopieren ging nicht. Sag Claude: " + satz);
}
const satzNeu = (projekt, phase) => t => `Neuer Meilenstein im Projekt ${projekt}${phase ? `, Phase ${phase}` : ""}: „${t}“. Stell mir ein paar Fragen dazu und trag die Aufgaben ein.`;
function endzielBox(x){
  const box = el("div","endziel"), e = x.endziel;
  const form = () => {
    const f = el("form","add"), inp = el("input"), b = el("button", null, e ? "Speichern" : "+");
    inp.placeholder = "Endziel, z. B. Fertige App im Play Store (bis 31.12.2026)"; inp.autocomplete = "off"; inp.dataset.k = `e|${x.name}`;
    inp.value = e ? e.text + (e.frist ? ` (bis ${fmtFrist(e.frist)})` : "") : S.drafts[`e|${x.name}`] || ""; inp.setAttribute("aria-label", `Endziel für ${x.name}`);
    inp.addEventListener("input", () => S.drafts[`e|${x.name}`] = inp.value);
    b.type = "submit"; f.addEventListener("submit", ev => { ev.preventDefault(); const t = inp.value.trim(); if (t){ S.drafts[`e|${x.name}`] = ""; addItem("endziel", t, x.name); } });
    f.append(inp, b); return f;
  };
  const lbl = el("span","lbl","Endziel");
  if (!e){ box.append(lbl, el("p","empty","Noch kein Endziel. Wo soll das Projekt am Ende stehen?")); if (S.mode !== "claude") box.append(form()); return box; }
  const t = el("div","ez-t"); t.append(el("b", null, e.text)); if (e.frist) t.append(fristTag(e.frist));
  box.append(lbl, t);
  if (e.vision) box.append(el("small","vision", "Vision: " + e.vision));
  Object.entries(e.infos || {}).forEach(([k, v]) => box.append(el("small","vision", `${k}: ${v}`)));
  if (e.fertigWenn?.length) box.append(fertigWenn(e.fertigWenn));
  if (x.rest){
    // Tempo: verbleibende Arbeit (Aufwand offener Ziele) gegen verbleibende Tage bis zur Frist
    const tage = e.frist ? Math.max(0, dayDiff(e.frist) + 1) : null, zeit = tage !== null ? tage * TAG_STD : null, knapp = zeit !== null && x.rest > zeit;
    box.append(el("small", knapp ? "tempo warn" : "tempo", `Noch ${stdText(x.rest)} Arbeit` + (zeit !== null ? ` · ${tage} Tage × ${TAG_STD} Std = ${stdText(zeit)} Zeit · ${knapp ? "zu knapp, Plan anpassen" : "im Plan"}` : "")));
  }
  if (S.mode !== "claude"){ const c = el("button","ghost small","Ändern"); c.type = "button"; c.addEventListener("click", () => { const f = form(); c.replaceWith(f); f.querySelector("input").focus(); }); t.append(c); }
  return box;
}
// Löschen (nur lokal): Gelöschtes landet im Vault in „Claude Memory/Gelöscht.md“
async function loeschen(payload, frage){
  if (!confirm(frage + "\n\nEs landet in „Gelöscht.md“ im Vault und lässt sich von dort zurückholen.")) return;
  try { S.plan = await api("api/loeschen", payload); renderPlan(); } catch (e){ alert(e.message); }
}
function delBtn(label, payload, frage, cls = "ghost small del"){
  const b = el("button", cls, label); b.type = "button"; b.title = "Löschen";
  b.addEventListener("click", ev => { ev.preventDefault(); ev.stopPropagation(); loeschen(payload, frage); });
  return b;
}
async function renameGoal(projekt, alt, neu, art = "ziel", phase = null){
  neu = neu.trim(); if (!neu || neu === alt) return;
  try {
    if (S.mode === "lokal") S.plan = await api("api/umbenennen", {projekt, alt, neu, art, phase});
    else {
      const ph = S.plan.projekte.find(x => x.name === projekt)?.phasen || [];
      const g = art === "meilenstein" ? ph.find(f => key(f.name) === key(alt)) : ph.flatMap(f => f.ziele).find(g => key(g.name) === key(alt));
      if (g) g.name = neu;
      if (art === "meilenstein" && S.openPhase.has(`${projekt}|${alt}`)) S.openPhase.set(`${projekt}|${neu}`, S.openPhase.get(`${projekt}|${alt}`));
      [...S.plan.heute, ...S.plan.woche, ...S.plan.monat, ...S.plan.jahr].forEach(i => { if (i.projekt === projekt && key(i.text) === key(alt)) i.text = neu; });
      recalc(S.plan);
    }
    if (art === "meilenstein" && PV.p === projekt && PV.ph === alt){ PV.ph = neu; try { history.replaceState(history.state, "", pvHash()); } catch {} }
    // aufgeklappte Ziele bleiben aufgeklappt
    [...S.openGoals].forEach(k => { if (k.endsWith(`|${projekt}|${key(alt)}`)){ S.openGoals.delete(k); S.openGoals.add(k.slice(0, -key(alt).length) + key(neu)); } });
    renderPlan();
  } catch (e) { S.fehler = [`Umbenennen hat nicht geklappt: ${e.message || e}`]; renderHeader(); }
}
async function copyText(t){
  try { await navigator.clipboard.writeText(t); return true; } catch {}
  const ta = el("textarea"); ta.value = t; ta.style.cssText = "position:fixed;opacity:0"; document.body.append(ta); ta.select();
  let ok = false; try { ok = document.execCommand("copy"); } catch {} ta.remove(); return ok;
}
function claudeBtn(ziel, projekt, leer){
  // ohne Schritte: mit Claude ausplanen (Fragen, Schritte eintragen), sonst gemeinsam abarbeiten
  const im = projekt ? ` im Projekt ${projekt}` : "";
  return copyBtn(leer ? "Mit Claude ausplanen" : "Mit Claude angehen",
    leer ? `Lass uns das Ziel „${ziel}“${im} ausplanen. Stell mir ein paar Fragen dazu und trag die Schritte ein.` : `Lass uns das Ziel „${ziel}“${im} angehen.`);
}
function stoneBtn(name, projekt, leer){
  const im = projekt ? ` im Projekt ${projekt}` : "";
  return copyBtn(leer ? "Mit Claude ausplanen" : "Nächster Meilenstein mit Claude",
    leer ? `Lass uns die Phase „${name}“${im} ausplanen. Welche Meilensteine brauchen wir dafür? Stell mir Fragen und trag sie ein.`
         : `Lass uns an der Phase „${name}“${im} weitermachen. Was ist der nächste Meilenstein?`);
}
// Satz kopieren und Claude (dieses Projekt) in einem neuen Tab öffnen: dort einfügen, Claude legt einen Thread dafür an
const CLAUDE_URL = "https://claude.ai/code/project/chan_015VLGEnXNs3Mj34zz4hdXej";
function claudeLos(label, satz, cls = "claude-btn"){
  const b = el("button", cls, label); b.type = "button"; b.title = `Kopiert den Satz und öffnet Claude: ${satz}`;
  b.addEventListener("click", async () => {
    const ok = await copyText(satz);
    window.open(CLAUDE_URL, "_blank", "noopener");
    toast(ok ? "Kopiert. Füg den Satz bei Claude ein." : "Kopieren ging nicht. Sag Claude: " + satz);
  });
  return b;
}
function copyBtn(label, satz){
  const b = el("button","claude-btn", label); b.type = "button"; b.title = `Kopiert: ${satz}`;
  b.addEventListener("click", async () => {
    const ok = await copyText(satz);
    b.textContent = ok ? "Kopiert, jetzt bei Claude einfügen" : satz; b.classList.add("on");
    clearTimeout(b._t); b._t = setTimeout(() => { b.textContent = label; b.classList.remove("on"); }, 5000);
  });
  return b;
}
function stoneDetails(it, tags, ctx){
  const m = it.meilenstein, k = `${ctx}|${it.projekt}|${key(it.text)}`, det = el("details","t gd"); det.open = S.openGoals.has(k);
  det.addEventListener("toggle", () => det.open ? S.openGoals.add(k) : S.openGoals.delete(k));
  const sm = el("summary"); sm.append(el("span","gname", it.text), el("span","tag prog", `${m.done}/${m.total} Ziele`), ...tags);
  const box = el("div","steps-box"), ul = el("ul","list");
  m.ziele.forEach(z => { const li = el("li","item mini" + (z.fertig ? " done" : "")); li.append(miniRing(z.prozent, z.fertig), el("div","t", z.name)); ul.append(li); });
  if (!m.ziele.length) ul.append(el("li","empty","Noch keine Aufgaben in dieser Phase."));
  const acts = el("div","gacts"); acts.append(stoneBtn(it.text, it.projekt, !m.ziele.length));
  box.append(ul, acts); det.append(sm, box); return det;
}
function renameBtn(name, projekt, acts, art = "ziel", phase = null){
  const b = el("button","ghost small","Umbenennen"); b.type = "button";
  b.addEventListener("click", () => {
    const f = el("form","add rename"), inp = el("input"), ok = el("button", null, "Speichern"), no = el("button","ghost small","Abbrechen");
    inp.value = name; inp.setAttribute("aria-label", art === "meilenstein" ? "Neuer Name für die Phase" : art === "abschnitt" ? "Neuer Name für den Abschnitt" : "Neuer Name für den Meilenstein"); inp.dataset.k = `r|${projekt}|${key(name)}`;
    ok.type = "submit"; no.type = "button";
    no.addEventListener("click", () => f.replaceWith(acts));
    f.addEventListener("submit", e => { e.preventDefault(); renameGoal(projekt, name, inp.value, art, phase); });
    f.append(inp, ok, no); acts.replaceWith(f); inp.focus(); inp.select();
  });
  return b;
}
function stepsBox(name, z, projekt){
  const box = el("div","steps-box"), ul = el("ul","list");
  z.schritte.forEach(s => ul.append(itemRow(s, {noTag:true})));
  if (!z.schritte.length) ul.append(el("li","empty","Noch keine Schritte. Trag sie unten ein oder lass sie dir von Claude vorschlagen."));
  const acts = el("div","gacts");
  if (projekt && S.mode !== "claude") acts.append(addForm(`s|${projekt}|${key(name)}`, "Schritt hinzufügen", t => addItem("schritt", t, projekt, {ziel:name})));
  acts.append(claudeBtn(name, projekt, !z.schritte.length));
  if (projekt && S.mode !== "claude") acts.append(renameBtn(name, projekt, acts));
  if (projekt && S.mode === "lokal") acts.append(delBtn("Löschen", {art:"ziel", projekt, name}, `Meilenstein „${name}“ mit allen Aufgaben löschen?`));
  box.append(ul, acts); return box;
}
function goalDetails(name, z, projekt, ctx, tags = []){
  const k = `${ctx}|${projekt}|${key(name)}`, det = el("details","t gd"); det.open = S.openGoals.has(k);
  det.addEventListener("toggle", () => det.open ? S.openGoals.add(k) : S.openGoals.delete(k));
  const sm = el("summary"); sm.append(el("span","gname", name));
  if (z.total) sm.append(el("span","tag prog", `${z.done}/${z.total}`));
  sm.append(...tags);
  det.append(sm, stepsBox(name, z, projekt)); return det;
}
// Einfache Aufgabe in Unteraufgaben teilen: die erste Unteraufgabe macht daraus ein aufklappbares Ziel
function splitBtn(name, projekt, li){
  const b = el("button","today-btn split-btn","Unterteilen"); b.type = "button"; b.title = "Diese Aufgabe in Unteraufgaben aufteilen";
  b.addEventListener("click", () => {
    const f = addForm(`s|${projekt}|${key(name)}`, "Erste Unteraufgabe", t => { S.openGoals.add(`p|${projekt}|${key(name)}`); addItem("schritt", t, projekt, {ziel:name}); });
    f.classList.add("split-form"); b.remove(); li.append(f); f.querySelector("input").focus();
  });
  return b;
}
function goalRow(g, x, planned){
  if (g.einzel){
    const li = itemRow(g.schritte[0], {noTag:true, plan:planned.get(key(g.name)), project:x.name});
    const e = echtTag(g, !g.schritte[0].done || g.echt >= 60); if (e) li.querySelector(".t").append(e);
    if (!g.schritte[0].done && S.mode === "lokal") li.querySelector(".t").append(splitBtn(g.name, x.name, li));
    return li;
  }
  const li = el("li","item act goal" + (g.fertig ? " done" : ""));
  const gt = []; if (g.aufwand) gt.push(el("span","tag", stdText(g.aufwand))); if (g.frist && !g.fertig) gt.push(fristTag(g.frist)); const et = echtTag(g, true); if (et) gt.push(et);
  li.append(miniRing(g.prozent, g.fertig), goalDetails(g.name, g, x.name, "p", gt));
  const pl = planned.get(key(g.name));
  li.append(pl ? planTag(g.name, pl) : !g.fertig && S.mode !== "claude" ? todayBtn(g.name, x.name) : el("span"));
  return li;
}

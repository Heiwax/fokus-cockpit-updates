/* ---------- Limits pro App (03.11.2026, nach clearmind.js) ----------
   john: Tageslimit, Öffnungen pro Tag, „am Stück“ und Sperrzeit nicht mehr als vier Regeln einzeln anlegen.
   Locker-Reiter „Apps“: eine Karte pro App (bzw. App-Gruppe mit denselben Regeln), Antippen öffnet alles in einem Schritt,
   große Knöpfe und −/+ statt Zahlenfelder. Gespeichert wird weiter als einzelne Regeln (Server unverändert). CSS in limits.css. */
const LM = {e:null, fehler:"", speichert:false};
const LM_ARTEN = {
  limit:   {titel:"Pro Tag",          einheit:"Min", werte:[15, 30, 60, 120], schritt:5, max:1440, std:30, sym:"hourglass"},
  oeffnen: {titel:"Öffnen pro Tag",   einheit:"×",   werte:[3, 5, 10, 20],    schritt:1, max:100,  std:5,  sym:"hash"},
  sitzung: {titel:"Am Stück",         einheit:"Min", werte:[5, 10, 15, 30],   schritt:5, max:240,  std:15, sym:"pause"},
};
const LM_ZEITEN = [["Nachts","23:00","07:00"],["Abends","21:00","07:00"],["Arbeitszeit","09:00","17:00"]];

function lmSchluessel(apps){ return [...apps].map(a => a.toLowerCase()).sort().join("|"); }
// Regeln mit denselben Apps bilden eine Karte
function lmGruppen(regeln){
  const g = new Map();
  // 19.11.: Bindungen (art "bis") haben eine eigene Liste (bindung.js)
  (regeln || []).filter(r => r.art !== "bis").forEach(r => { const k = lmSchluessel(r.apps); if (!g.has(k)) g.set(k, {apps:r.apps, regeln:[]}); g.get(k).regeln.push(r); });
  return [...g.values()];
}
function lmName(apps){ return apps.length <= 2 ? apps.join(", ") : `${apps.slice(0, 2).join(", ")} +${apps.length - 2}`; }
function lmTage(t){
  t = [...(t || [])].sort(); if (t.length === 7) return "täglich";
  const folge = t.every((x, i) => !i || x === t[i - 1] + 1);
  return t.length >= 3 && folge ? `${LK_TAGE[t[0]]}–${LK_TAGE[t[t.length - 1]]}` : t.map(i => LK_TAGE[i]).join(", ");
}

/* ----- Karte im Reiter ----- */
function lmKarte(g){
  const k = el("button","lm-karte"); k.type = "button";
  const r = a => g.regeln.find(x => x.art === a), zu = g.regeln.find(x => x.gesperrt), lim = r("limit");
  const kopf = el("div","lm-kopf"), text = el("div","lm-titel");
  text.append(el("b", null, lmName(g.apps)),
    el("small", zu ? "zu" : "", zu ? (zu.pauseBis ? `Pause bis ${zu.pauseBis}` : zu.art === "zeit" ? `gesperrt bis ${zu.bis}` : "für heute gesperrt")
                                 : lim ? `heute ${lim.verbraucht || 0} von ${lim.minuten} Min` : "gerade frei"));
  kopf.append(cmKachel(g.apps[0]), text, el("span","lm-pfeil","›"));
  if (lim && !zu){ const b = el("div","lm-balken"), i = el("i"); i.style.width = Math.min(100, (lim.verbraucht || 0) / lim.minuten * 100) + "%"; b.append(i); kopf.append(b); }
  const werte = el("div","lm-werte"), zeiten = g.regeln.filter(x => x.art === "zeit");
  const feld = (titel, wert) => { const f = el("div","lm-wert" + (wert ? "" : " aus")); f.append(el("span", null, titel), el("b", null, wert || "–")); werte.append(f); };
  feld("Pro Tag", lim && `${lim.minuten} Min`);
  feld("Öffnen", r("oeffnen") && `${r("oeffnen").anzahl}×`);
  feld("Am Stück", r("sitzung") && `${r("sitzung").minuten} Min`);
  feld("Sperrzeit", zeiten.length ? zeiten.map(z => `${z.von}–${z.bis}`).join(", ") : "");
  const erste = g.regeln[0], ger = erste.geraete?.length ? erste.geraete.join(" + ") : "alle Geräte";
  k.append(kopf, werte, el("span","lm-fuss", `${lmTage(erste.tage)} · ${ger}`));
  k.addEventListener("click", () => lmAuf(g));
  return k;
}

/* ----- Bearbeiten: alles in einem Fenster ----- */
function lmAuf(g){
  const r = a => g?.regeln.find(x => x.art === a), erste = g?.regeln[0];
  LM.fehler = "";
  LM.e = {neu:!g, alt:g ? g.regeln : [], apps:new Set(g ? g.apps : []), appsZeigen:!g,
    werte:{limit:r("limit")?.minuten || 0, oeffnen:r("oeffnen")?.anzahl || 0, sitzung:r("sitzung")?.minuten || 0},
    pause:r("sitzung")?.pause || 30,
    zeiten:(g ? g.regeln.filter(x => x.art === "zeit") : []).map(z => ({id:z.id, von:z.von, bis:z.bis})),
    tage:new Set(erste ? erste.tage : [0,1,2,3,4,5,6]), geraete:new Set(erste?.geraete || []), tageGeaendert:false};
  lmZeichnen();
}
function lmDialog(){
  let d = $("lmDialog"); if (!d){ d = el("dialog","cm-regel lm-dialog"); d.id = "lmDialog"; document.body.append(d);
    d.addEventListener("cancel", ev => { ev.preventDefault(); lmZu(); }); }
  return d;
}
function lmZu(){ LM.e = null; const d = $("lmDialog"); if (d?.open) d.close(); }

// −/+ mit großer Zahl, darunter Schnellwahl; „Aus“ schaltet die Regel ab
function lmWahl(art){
  const A = LM_ARTEN[art], e = LM.e, s = el("section","lm-abschnitt"), wert = e.werte[art];
  const kopf = el("div","lm-akopf"); kopf.append(cmKachel("", A.sym), el("b", null, A.titel));
  const schalter = el("button","lm-an" + (wert ? " an" : ""), wert ? "An" : "Aus"); schalter.type = "button";
  schalter.addEventListener("click", () => { e.werte[art] = wert ? 0 : A.std; lmZeichnen(); });
  kopf.append(schalter); s.append(kopf);
  if (!wert){ s.classList.add("aus"); return s; }
  const stepper = el("div","lm-stepper"), minus = el("button", null, "−"), plus = el("button", null, "+");
  minus.type = plus.type = "button"; minus.setAttribute("aria-label","weniger"); plus.setAttribute("aria-label","mehr");
  const setzen = v => { e.werte[art] = Math.max(1, Math.min(A.max, v)); lmZeichnen(); };
  minus.addEventListener("click", () => setzen(wert - A.schritt * (wert > 60 && A.einheit === "Min" ? 3 : 1)));
  plus.addEventListener("click", () => setzen(wert + A.schritt * (wert >= 60 && A.einheit === "Min" ? 3 : 1)));
  const zahl = el("div","lm-zahl"); zahl.append(el("b", null, String(wert)), el("span", null, A.einheit === "×" ? "mal am Tag" : art === "limit" ? "Min am Tag" : "Min am Stück"));
  stepper.append(minus, zahl, plus);
  const schnell = el("div","lm-schnell");
  A.werte.forEach(v => { const b = el("button", v === wert ? "an" : "", A.einheit === "×" ? v + "×" : v + " Min"); b.type = "button";
    b.addEventListener("click", () => setzen(v)); schnell.append(b); });
  s.append(stepper, schnell);
  if (art === "sitzung"){
    const p = el("div","lm-schnell lm-pause"); p.append(el("span","lm-klein","danach Pause"));
    [15, 30, 60, 120].forEach(v => { const b = el("button", v === e.pause ? "an" : "", v < 60 ? v + " Min" : v / 60 + " Std"); b.type = "button";
      b.addEventListener("click", () => { e.pause = v; lmZeichnen(); }); p.append(b); });
    s.append(p);
  }
  return s;
}
function lmSperrzeit(){
  const e = LM.e, s = el("section","lm-abschnitt" + (e.zeiten.length ? "" : " aus"));
  const kopf = el("div","lm-akopf"); kopf.append(cmKachel("", "clock"), el("b", null, "Sperrzeit"));
  s.append(kopf);
  e.zeiten.forEach((z, i) => {
    const zeile = el("div","lm-zeit"), von = el("input"), bis = el("input"), x = el("button","lm-x","✕");
    von.type = bis.type = "time"; von.value = z.von; bis.value = z.bis; von.setAttribute("aria-label","gesperrt von"); bis.setAttribute("aria-label","gesperrt bis"); x.type = "button"; x.setAttribute("aria-label","Sperrzeit entfernen");
    von.addEventListener("change", () => { z.von = von.value; lmHinweis(); }); bis.addEventListener("change", () => { z.bis = bis.value; lmHinweis(); });
    x.addEventListener("click", () => { e.zeiten.splice(i, 1); lmZeichnen(); });
    zeile.append(von, el("span","lm-klein","bis"), bis, x); s.append(zeile);
  });
  const schnell = el("div","lm-schnell");
  LM_ZEITEN.forEach(([t, v, b]) => { const k = el("button", null, "＋ " + t); k.type = "button"; k.title = `${v}–${b}`;
    k.addEventListener("click", () => { e.zeiten.push({von:v, bis:b}); lmZeichnen(); }); schnell.append(k); });
  s.append(schnell);
  return s;
}
function lmTageGeraete(){
  const e = LM.e, d = LK.daten || {}, det = el("details","lm-mehr");
  if (LM.tageAuf) det.open = true;
  det.addEventListener("toggle", () => LM.tageAuf = det.open);
  det.append(el("summary", null, `Tage und Geräte · ${lmTage(e.tage)}, ${e.geraete.size ? [...e.geraete].join(" + ") : "alle Geräte"}`));
  const tage = el("div","lm-tage");
  LK_TAGE.forEach((t, i) => { const b = el("button", e.tage.has(i) ? "an" : "", t); b.type = "button";
    b.addEventListener("click", () => { e.tage.has(i) ? e.tage.delete(i) : e.tage.add(i); e.tageGeaendert = true; lmZeichnen(); }); tage.append(b); });
  const schnell = el("div","lm-schnell");
  [["Täglich",[0,1,2,3,4,5,6]],["Mo–Fr",[0,1,2,3,4]],["Wochenende",[5,6]]].forEach(([t, w]) => { const b = el("button", null, t); b.type = "button";
    b.addEventListener("click", () => { e.tage = new Set(w); e.tageGeaendert = true; lmZeichnen(); }); schnell.append(b); });
  const ger = el("div","lm-schnell");
  const alle = el("button", e.geraete.size ? "" : "an", "Alle Geräte"); alle.type = "button";
  alle.addEventListener("click", () => { e.geraete.clear(); e.tageGeaendert = true; lmZeichnen(); }); ger.append(alle);
  (d.geraete || []).forEach(n => { const b = el("button", e.geraete.has(n) ? "an" : "", n); b.type = "button";
    b.addEventListener("click", () => { e.geraete.has(n) ? e.geraete.delete(n) : e.geraete.add(n); e.tageGeaendert = true; lmZeichnen(); }); ger.append(b); });
  // 1.0.14: nur ein Handy, keine Geräte-Auswahl
  if ((d.geraete || []).length <= 1 && typeof beNurHandy === "function" && beNurHandy()) det.append(tage, schnell);
  else det.append(tage, schnell, el("span","lm-klein","Geräte"), ger);
  return det;
}
// App-Auswahl wie im alten Formular: ablenkende Apps zuerst, Suche, eigene Seite eintippen
function lmAppWahl(){
  const e = LM.e, d = LK.daten || {}, s = el("section","lm-abschnitt lm-apps");
  const namen = [], gesehen = new Set();
  const dazuName = n => { const k = n.toLowerCase().replace(/[^\p{L}\p{N}]/gu, ""); if (!k || gesehen.has(k)) return; gesehen.add(k); namen.push(n); };
  [...e.apps].forEach(dazuName); (d.apps || []).forEach(a => dazuName(a.name));
  const info = n => (d.apps || []).find(a => a.name === n);
  const sicht = namen.filter(n => e.apps.has(n) || !lkIstRauschen(n)).sort((a, b) => (e.apps.has(b) - e.apps.has(a)) || ((info(b)?.kat === "prokrastination") - (info(a)?.kat === "prokrastination")));
  const such = el("div","lm-such"), inp = el("input"), plus = el("button", null, "＋"); plus.type = "button"; plus.setAttribute("aria-label","Hinzufügen");
  inp.placeholder = "App oder Seite, z. B. reddit.com"; inp.setAttribute("aria-label","App oder Seite suchen oder eingeben");
  const gitter = el("div","lm-appgitter");
  sicht.forEach(n => { const b = el("button", e.apps.has(n) ? "an" : "", null); b.type = "button"; b.dataset.n = n.toLowerCase();
    b.append(cmKachel(n), el("span", null, n));
    b.addEventListener("click", () => { e.apps.has(n) ? e.apps.delete(n) : e.apps.add(n); lmZeichnen(); }); gitter.append(b); });
  const dazu = () => { const n = inp.value.trim().replace(/^https?:\/\//i, "").replace(/^www\./i, "").replace(/\/.*$/, ""); if (!n) return;
    e.apps.add(namen.find(x => x.toLowerCase() === n.toLowerCase()) || n); lmZeichnen(); };
  inp.addEventListener("input", () => { const q = inp.value.trim().toLowerCase(); gitter.querySelectorAll("button").forEach(b => b.hidden = !!q && !b.dataset.n.includes(q)); });
  inp.addEventListener("keydown", ev => { if (ev.key === "Enter"){ ev.preventDefault(); dazu(); } });
  plus.addEventListener("click", dazu); such.append(inp, plus);
  s.append(el("b", null, "Welche Apps?"), such, gitter);
  return s;
}

/* ----- Was ändert sich? Strenger geht sofort, lockern nur nach dem Timer ----- */
function lmPlan(){
  const e = LM.e, apps = [...e.apps], plan = [];
  const tage = a => e.tageGeaendert || !a ? [...e.tage].sort() : a.tage, ger = a => e.tageGeaendert || !a ? [...e.geraete] : (a.geraete || []);
  const basis = a => ({apps, tage:tage(a), geraete:ger(a)});
  Object.keys(LM_ARTEN).forEach(art => {
    const alt = e.alt.find(x => x.art === art), w = e.werte[art];
    if (!w){ if (alt) plan.push({loeschen:alt.id, alt}); return; }
    const regel = {...basis(alt), art, ...(art === "oeffnen" ? {anzahl:w} : {minuten:w}), ...(art === "sitzung" ? {pause:e.pause} : {})};
    if (alt) regel.id = alt.id;
    plan.push({regel, alt});
  });
  const altZeiten = e.alt.filter(x => x.art === "zeit");
  altZeiten.forEach(a => { if (!e.zeiten.some(z => z.id === a.id)) plan.push({loeschen:a.id, alt:a}); });
  e.zeiten.forEach(z => { const alt = altZeiten.find(a => a.id === z.id);
    plan.push({regel:{...basis(alt), art:"zeit", von:z.von, bis:z.bis, ...(alt ? {id:alt.id} : {})}, alt}); });
  // Unveränderte Regeln nicht schicken
  const gleich = (a, r) => a && JSON.stringify([lmSchluessel(a.apps), a.tage, a.geraete || [], a.von, a.bis, a.minuten, a.anzahl, a.pause])
                              === JSON.stringify([lmSchluessel(r.apps), r.tage, r.geraete, r.von, r.bis, r.minuten, r.anzahl, r.pause]);
  return plan.filter(p => p.loeschen || !gleich(p.alt, p.regel));
}
function lmLockert(p){
  if (p.loeschen) return true; if (!p.alt) return false;
  const merk = {art:LK.art, apps:LK.apps, tage:LK.tage, geraete:LK.geraete, von:LK.von, bis:LK.bis, min:LK.min, pause:LK.pause}, r = p.regel;
  Object.assign(LK, {art:r.art, apps:new Set(r.apps), tage:new Set(r.tage), geraete:new Set(r.geraete), von:r.von || "", bis:r.bis || "", min:String(r.anzahl ?? r.minuten ?? ""), pause:String(r.pause ?? "")});
  try { return !lkStrenger(p.alt); } finally { Object.assign(LK, merk); }
}
function lmHinweis(){
  const e = LM.e, d = LK.daten || {}, darf = d.immerFrei || d.frei > 0, box = $("lmHinweis"), ok = $("lmOk"); if (!e || !box || !ok) return;
  const plan = lmPlan(), lockert = plan.some(lmLockert), leer = !e.apps.size || !e.tage.size;
  const nichts = !Object.values(e.werte).some(Boolean) && !e.zeiten.length;
  box.replaceChildren();
  ok.disabled = LM.speichert || leer || !plan.length || (lockert && !darf) || (e.neu && nichts);
  ok.textContent = e.neu ? "Speichern" : plan.length ? "Änderungen speichern" : "Nichts geändert";
  if (leer) box.append(el("span","lm-klein", !e.apps.size ? "Wähle mindestens eine App." : "Wähle mindestens einen Tag."));
  else if (e.neu && nichts) box.append(el("span","lm-klein","Schalte mindestens ein Limit oder eine Sperrzeit an."));
  else if (lockert && !darf){
    const t = el("button","ghost small", d.wartet > 0 ? "Beantragt" : `Lockern beantragen (${bdWarte(d.warteJetzt ?? d.warteMin)})`); t.type = "button"; t.disabled = d.wartet > 0;
    t.addEventListener("click", async () => { await lkAktion({warten:true}); lmHinweis(); });
    box.append(el("span","lm-klein c-bad", bdLockernSatz(d, "deine Limits")), t);
  } else if (plan.length) box.append(el("span","lm-klein " + (lockert ? "" : "c-good"), lockert ? "Lockern ist gerade frei." : "Wird strenger und gilt sofort."));
  if (LM.fehler) box.append(el("span","lm-klein c-bad", LM.fehler));
}
async function lmSpeichern(){
  const plan = lmPlan().sort((a, b) => lmLockert(a) - lmLockert(b));   // strenger zuerst
  LM.speichert = true; LM.fehler = ""; lmHinweis();
  try {
    for (const p of plan){
      const r = await api("api/locker", {...(p.loeschen ? {loeschen:p.loeschen} : {regel:p.regel}), token:LK.token});
      LK.token = r.token || ""; LK.daten = r;
    }
    LM.speichert = false; lmZu(); toast("Gespeichert."); renderLocker(true);
  } catch (err){ LM.speichert = false; LM.fehler = err.message || String(err); renderLocker(true); lmZeichnen(); }
}
async function lmAllesLoeschen(){
  LM.speichert = true;
  try { for (const r of LM.e.alt){ const x = await api("api/locker", {loeschen:r.id, token:LK.token}); LK.token = x.token || ""; LK.daten = x; }
    LM.speichert = false; lmZu(); toast("Gelöscht."); renderLocker(true);
  } catch (err){ LM.speichert = false; LM.fehler = err.message || String(err); renderLocker(true); lmZeichnen(); }
}
function lmZeichnen(){
  const e = LM.e; if (!e) return;
  const d = lmDialog(), y = d.querySelector(".lm-body")?.scrollTop || 0, darf = LK.daten?.immerFrei || LK.daten?.frei > 0;
  const kopf = el("div","lm-dkopf"), x = el("button","ghost small","✕"); x.type = "button"; x.setAttribute("aria-label","Schließen"); x.addEventListener("click", lmZu);
  const apps = [...e.apps], titel = el("div","lm-titel");
  titel.append(el("b", null, e.neu && !apps.length ? "Neue App begrenzen" : lmName(apps) || "Keine App"));
  if (!e.neu){ const w = el("button","lm-link", e.appsZeigen ? "Apps fertig" : "Apps ändern"); w.type = "button"; w.addEventListener("click", () => { e.appsZeigen = !e.appsZeigen; lmZeichnen(); }); titel.append(w); }
  kopf.append(cmKachel(apps[0] || ""), titel, x);
  const body = el("div","lm-body");
  if (e.appsZeigen) body.append(lmAppWahl());
  body.append(lmWahl("limit"), lmWahl("oeffnen"), lmWahl("sitzung"), lmSperrzeit(), lmTageGeraete());
  if (!e.neu){ const del = el("button","lm-loeschen","Alle Limits dieser App löschen"); del.type = "button";
    if (darf) lkZweimal(del, "Wirklich alles löschen?", lmAllesLoeschen); else { del.disabled = true; del.title = "Erst den Timer zum Lockern abwarten"; }
    body.append(del); }
  const fuss = el("div","lm-dfuss"), hinweis = el("div","lm-hinweis"), ok = el("button","ask cm-violett lm-ok","Speichern");
  hinweis.id = "lmHinweis"; ok.id = "lmOk"; ok.type = "button"; ok.addEventListener("click", lmSpeichern);
  fuss.append(hinweis, ok);
  d.replaceChildren(kopf, body, fuss);
  if (!d.open) d.showModal();
  body.scrollTop = y;
  lmHinweis();
}

if (typeof NUR_TRACKING !== "undefined" && NUR_TRACKING && typeof lkOffen === "function"){
  // Reiter: „Apps“ (Karten) und „Freischalten“ (Timer, PIN, an/aus). Die alten Reiter Sperrzeiten/Tageslimits gehen in „Apps“ auf.
  const _lkOffenCm = lkOffen;
  lkOffen = function(d){
    if (CM.tab !== "frei") CM.tab = "apps";
    const out = _lkOffenCm.call(this, d);
    const tabs = el("div","cm-tabs"); tabs.setAttribute("role","tablist");
    [["apps","Apps"],["frei","Freischalten"]].forEach(([k, t]) => { const b = el("button", null, t); b.type = "button"; b.setAttribute("role","tab"); b.setAttribute("aria-selected", String(CM.tab === k));
      b.addEventListener("click", () => { CM.tab = k; store("cm.lockerTab", k); renderLocker(true); }); tabs.append(b); });
    if (CM.tab === "frei") return [tabs, ...out.filter(x => !x.classList?.contains("cm-tabs") && !x.classList?.contains("lk-neu"))];
    const box = el("div","lm-liste"), gruppen = lmGruppen(d.regeln);
    gruppen.forEach(g => box.append(lmKarte(g)));
    if (!gruppen.length) box.append(el("p","cm-leer","Noch keine App begrenzt. Tippe unten auf „App begrenzen“ und stell Tageslimit, Öffnungen, am Stück und Sperrzeit auf einmal ein."));
    const neu = el("button","cm-neu","＋ App begrenzen"); neu.type = "button"; neu.addEventListener("click", () => lmAuf(null));
    return [tabs, box, neu];
  };
  // Läuft der Timer ab oder ändert sich der Locker, bleibt das offene Fenster aktuell
  const _rlLm = renderLocker;
  renderLocker = function(...a){ const r = _rlLm.apply(this, a); if (LM.e && !LK.daten?.offen) lmZu(); else if (LM.e) lmHinweis(); return r; };
}

/* ---------- BlockEm 1.0.21: Android-Stil (Pixel-Einstellungen) für Einstellungen und Locker-Unterseiten ----------
   Aussehen in android.css. Hier: Symbolfarben, Wert in die Zweitzeile, Knöpfe und Segmente kennzeichnen,
   lange Erklärungen kürzen (john: „überladen“). Nur in der Tracking-App (html.nur-tracking). */
const mdAn = () => document.documentElement.classList.contains("nur-tracking");
// Pastellfarben für die runden Symbole (wie Pixel: Farbe hinter dunklem Zeichen)
const MD_FARBE = {profil:"#E6DDCF", aussehen:"#FFB39B", locker:"#FFB39B", fokus:"#FFB39B", automatik:"#E6DDCF", geraete:"#D9CBB6", speicherort:"#E6DDCF", status:"#D9CBB6",
  ki:"#FFB39B", kalender:"#FFB39B", daten:"#E6DDCF"};
// Zweitzeile: kurz, Wert hinten dran (Pixel: „Live-Übersetzung · An“)
const MD_ZWEIT = {profil:"Dein Name", aussehen:"Hell, dunkel oder wie das System", locker:"Sperrzeiten, Limits, Schutz",
  fokus:"Was im Fokus gesperrt ist", automatik:"Hinweise, Rückblick, Nacht-Sicherung", geraete:"Rechte, Schutz, Deinstallier-Sperre",
  speicherort:"Konto, Geräte, anmelden", status:"Sicherung, Updates, ob alles läuft"};
const MD_OHNE_WERT = new Set(["profil", "geraete", "speicherort", "locker"]);

if (typeof esListe === "function"){
  const _mdEs = esListe;
  esListe = function(...a){
    const r = _mdEs.apply(this, a);
    if (!mdAn()) return r;
    $("esListe")?.querySelectorAll(".es-zeile").forEach(z => {
      const k = z.dataset.k, ico = z.querySelector(".es-ico"), s = z.querySelector(".es-text small"), w = z.querySelector(".es-wert")?.textContent.trim();
      if (ico && MD_FARBE[k]) ico.style.setProperty("--md-ico", MD_FARBE[k]);
      if (s){ const t = MD_ZWEIT[k] || s.textContent; s.textContent = w && !MD_OHNE_WERT.has(k) ? `${t} · ${w}` : t; }
    });
    return r;
  };
}

// Automatik: kurze Erklärungen am Handy
const MD_AUTO = {hinweise:"Mitteilung, sobald dein Ablenkungs-Budget voll ist", rueckblick:"Kachel auf Heute am Wochenstart und am Monatsende",
  sperre:"Gesperrte Apps gelten in jeder Fokus-Session", sicherung:"Jede Nacht, 14 Tage lang"};
if (typeof renderSchalter === "function"){
  const _mdRs = renderSchalter;
  renderSchalter = function(...a){
    const r = _mdRs.apply(this, a);
    if (mdAn()) $("autoListe")?.querySelectorAll(".auto-row").forEach(z => {
      const n = z.querySelector("b")?.textContent, x = (typeof AUTOMATIKEN !== "undefined" ? AUTOMATIKEN : []).find(y => y.n === n), s = z.querySelector(".k-s");
      if (x && s && MD_AUTO[x.k]) s.textContent = MD_AUTO[x.k];
    });
    return r;
  };
}

// Schutz: kurze Titel und Erklärungen (die langen stehen in tracking.js und gelten am Computer weiter)
const MD_SCHUTZ = {
  "Erwachsenen-Suchen sperren, SafeSearch erzwingen":["SafeSearch erzwingen","Keine Porno-Suchen im Browser und in Apps"],
  "Bild-KI auch auf YouTube und Netflix":["Bild-KI auch bei YouTube und Netflix","Netflix wird oft schwarz aufgenommen, dann sieht sie dort nichts"],
  "Reels, Shorts und Explore sperren":[null,"In den Apps und im Browser, der Rest bleibt offen"],
  "VPN erkennen":[null,"Mit VPN gehen Browser und Social-Apps nicht auf"],
  "Erwachsenes in Apps erkennen":[null,"18+-Werbung und eindeutige Wörter auf dem Bildschirm"],
  "Nackte Haut auf Bildern erkennen":[null,"Die Bild-KI prüft den Bildschirm, nichts verlässt das Handy"],
  "Webcam- und Zufalls-Chat-Apps sperren":["Zufalls-Chat-Apps sperren","Omegle-Nachbauten, Monkey, Azar, Holla und Co."],
  "Nur Apps aus dem Play Store":[null,"Andere Quellen sind gesperrt, Ausnahmen unten"],
  "DNS-Filter am Handy ist Pflicht":["DNS-Filter ist Pflicht","Ohne Privates DNS gehen Browser und Social-Apps nicht auf"],
};
function mdSchutzKurz(){
  if (!mdAn()) return;
  document.querySelectorAll("#trLockerKarten .tr-schutz-zeile, #apSeite .tr-schutz-zeile").forEach(z => {
    const b = z.querySelector("b"), s = z.querySelector(".k-s"); if (!b || b.dataset.md) return;
    const e = MD_SCHUTZ[b.textContent.replace(/ •$/, "").trim()]; if (!e) return;
    b.dataset.md = "1"; if (e[0]) b.textContent = e[0] + (/ •$/.test(b.textContent) ? " •" : ""); if (s && e[1]) s.textContent = e[1];
  });
}
// Knöpfe und Segmente kennzeichnen, damit android.css sie als Pille / Material-Segment zeichnet
function mdKennzeichnen(){
  if (!mdAn()) return;
  document.querySelectorAll(".es-page .ei-form>button.ask, .es-page #ortBox form button.ask, .es-page #esHandyApp>button").forEach(b => b.classList.add("md-pille"));
  document.querySelectorAll(".es-page #laeuftListe button, .es-page #updSuche button, .ap-seite .bk-clip button, .ap-seite .tr-zeile button, .ap-seite .be-neu button").forEach(b => b.classList.add("md-text"));
  document.querySelectorAll(".es-page #eiThema .chips, .es-page #ortBox .chips, .ap-seite .be-dur, #locker .cm-tabs, .tab[data-r=werte] .wt-leiste").forEach(c => c.classList.add("md-segment"));
  mdSchutzKurz();
}
if (mdAn()){
  new MutationObserver(() => mdKennzeichnen()).observe(document.body, {childList:true, subtree:true});
  mdKennzeichnen();
  // Unterseiten-Kopf: Titel neben den Pfeil
  const _mdOeffnen = typeof apOeffnen === "function" ? apOeffnen : null;
  if (_mdOeffnen) apOeffnen = function(k){ const r = _mdOeffnen(k); const t = $("apSeiteTitel"), kopf = document.querySelector("#apSeite .ap-seite-kopf"); if (t && kopf && t.parentNode !== kopf) kopf.append(t); return r; };
}

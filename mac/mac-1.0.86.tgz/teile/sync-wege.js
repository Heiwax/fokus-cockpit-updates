/* ---------- Sync-Wege (04.11.2026, john): Nur dieses Handy · BlockEm Sync · Mein Google Drive. Der Mac ist kein Host mehr. ----------
   Release: nur diese drei Wege. „Auf deinem Computer“, „Online-Server“ und „Aus einer Sicherung übernehmen“ nur in der Entwicklerversion
   (oder solange ein Gerät noch so verbunden ist). Geräte verbinden per QR-Code (kp*), Google-Anmeldung über die App (sw*), Geräte-Frage in der Einrichtung (stGeraete). */
const SW = {kp:null, timer:null, kamera:null, scanTimer:null};
const swEntw = () => !!(SYNC.st?.entwickler || (typeof TR !== "undefined" && TR?.daten?.entwickler));
(function(){
  const s = ORT_ARTEN.find(a => a.k === "sync");
  if (s) Object.assign(s, {t:"BlockEm Sync", kurz:"BlockEm Sync", s:"Jedes Gerät hat alle Daten und läuft offline. Abgleich verschlüsselt über unseren Server in der EU, wir können nichts lesen."});
  const h = ORT_ARTEN.find(a => a.k === "handy"); if (h) h.s = "Nur ein Handy: kein Konto, kein Abgleich, auch ohne Internet.";
  ORT_ARTEN.push({k:"drive", t:"Mein Google Drive", kurz:"Google Drive", s:"Abgleich verschlüsselt über einen versteckten Ordner in deinem eigenen Google Drive. Wir speichern gar nichts."});
  if (typeof ES_DEF !== "undefined" && ES_DEF.speicherort) ES_DEF.speicherort.s = "Nur Handy oder BlockEm Sync";
})();
// Release: nur die drei Wege zeigen
const _swRenderSpeicherort = renderSpeicherort;
renderSpeicherort = function(){
  if (!SYNC.st && !SW.laedt){ SW.laedt = true; syncLaden().finally(() => { SW.laedt = false; }); }
  const alt = ORT_ARTEN.slice(), jetzt = ortJetzt();
  const sichtbar = alt.filter(a => ["handy","sync"].includes(a.k) || (a.k === "drive" && SYNC.st?.driveDa) || swEntw() || a.k === jetzt);
  ORT_ARTEN.splice(0, ORT_ARTEN.length, ...sichtbar);
  try { _swRenderSpeicherort(); } finally { ORT_ARTEN.splice(0, ORT_ARTEN.length, ...alt); }
  const box = $("ortBox");
  if (box && VB.inApp && window.CockpitApp?.entwicklerReset){
    if (swEntw() || swEntwFrei()) box.append(swEntwReset());
    else swEntwTipp(box);
  }
  // „an“ bei Drive anzeigen
  if (!box || SYNC.st?.art !== "drive" || !SYNC.st?.an) return;
  box.querySelectorAll(".ort-wahl .ein-opt b").forEach(b => { if (b.firstChild?.textContent === "Mein Google Drive" && !b.querySelector(".ort-jetzt")) b.append(el("span","ort-jetzt","an")); });
  box.querySelectorAll(".ort-wahl .ein-opt b").forEach(b => { if (b.firstChild?.textContent === "BlockEm Sync") b.querySelector(".ort-jetzt")?.remove(); });
};
const _swOrtSicherung = ortSicherung;
ortSicherung = function(){ return swEntw() ? _swOrtSicherung() : el("span"); };   // Import aus ZIP nur noch für Entwickler

/* ----- Google Drive ----- */
async function swDriveLogin(geraet){
  const A = window.CockpitApp, handy = VB.modus === "handy";
  if (handy && !A?.oauthStart) throw new Error("Bitte erst die neue Version der Handy-App installieren.");
  const r = await api("api/sync", {aktion:"driveAnmelden", geraet, umleitung: handy ? `http://127.0.0.1:${A.oauthStart()}/` : ""});
  if (handy){
    A.oauthOeffnen(r.url);
    for (let i = 0; i < 300; i++){
      await new Promise(ok => setTimeout(ok, 1000));
      const q = A.oauthErgebnis(); if (q) return api("api/sync", {aktion:"driveFertig", query:q});
    }
    throw new Error("Die Google-Anmeldung kam nicht zurück. Bitte nochmal versuchen.");
  }
  window.open(r.url, "_blank");
  for (let i = 0; i < 300; i++){
    await new Promise(ok => setTimeout(ok, 2000));
    const st = await api("api/sync"); if (st.driveAngemeldet) return st;
  }
  throw new Error("Die Google-Anmeldung kam nicht zurück. Bitte nochmal versuchen.");
}
function swDriveDetail(box, jetzt){
  const st = SYNC.st;
  if (!st){ box.append(el("p","k-s","Lade …")); syncLaden(); return box; }
  box.append(el("p", null, "Deine Daten liegen verschlüsselt in einem versteckten Ordner in deinem Google Drive. Nur deine Geräte haben den Schlüssel. BlockEm (also wir) speichert nichts davon."));
  if (!st.driveDa){ box.append(el("p","ort-meldung","Google Drive wird gerade bei Google freigeschaltet. Bis dahin: „Nur auf diesem Handy“ oder BlockEm Sync.")); return box; }
  if (VB.inApp && jetzt !== "handy"){ box.append(el("p","k-s","Dieses Handy holt seine Daten gerade vom Computer. Wähle oben erst „Nur auf diesem Handy“.")); return box; }
  if (st.art === "drive" && st.an){
    box.append(el("p", null, `Verbunden mit ${st.email || "Google"}. Dieses Gerät heißt „${st.geraetName}“.`),
      el("p","k-s", `Zuletzt abgeglichen: ${syncZeit(st.zuletzt)} · ${st.dateien} Dateien`));
    if (st.fehler) box.append(el("p","ort-meldung schlecht", st.fehler));
    const k = el("div","chips"); k.append(eiKnopf(ORT.laeuft || "Jetzt abgleichen","ask small", () => syncAktion({aktion:"jetzt"}, "Gleiche ab …"))); box.append(k);
    box.append(kpBereich());
    box.append(swAbmelden("Alle BlockEm-Daten in meinem Google Drive löschen", false));
    return box;
  }
  if (st.art === "drive" && st.driveAngemeldet){
    box.append(el("p", null, `Angemeldet als ${st.email}. Ist das dein erstes Gerät mit BlockEm?`));
    const k = el("div","sw-zwei");
    k.append(eiKnopf(ORT.laeuft || "Ja, hier anfangen","ask", () => syncAktion({aktion:"driveStart"}, "Lege den Schlüssel an …")),
      eiKnopf("Nein, mit einem anderen Gerät verbinden","ghost", () => { SW.kp = {modus:"zeigen", art:"drive"}; renderSpeicherort(); }));
    box.append(k);
    if (SW.kp?.art === "drive") box.append(kpNeuesGeraet("drive"));
    return box;
  }
  const b = eiKnopf(ORT.laeuft || "Mit Google anmelden","ask", async () => {
    try { await ortWarten("Google öffnet sich. Melde dich an und komm zurück …"); const r = await swDriveLogin(SYNC.name || "");
      SYNC.st = r.an !== undefined ? r : await api("api/sync"); ortFertig(r.hinweis || "Mit Google verbunden.", true); } catch (e){ ortFertig(e.message || String(e)); } });
  box.append(b, el("p","k-s","Nimm auf allen Geräten dasselbe Google-Konto. BlockEm sieht nur seinen eigenen Ordner, nicht deine Dateien."));
  return box;
}
function swAbmelden(loeschText, mitPasswort){
  const weg = el("details","more"), f = el("div","ort-form");
  weg.append(el("summary", null, "Abmelden oder Daten löschen"));
  f.append(el("p","k-s","Abmelden hebt keine Sperre auf: Regeln und Daten bleiben auf diesem Gerät."),
    eiKnopf("Dieses Gerät abmelden","ghost small", () => syncAktion({aktion:"abmelden"}, "Melde ab …")),
    eiKnopf(loeschText,"ghost small danger", () => { if (confirm("Wirklich löschen? Die Geräte gleichen danach nicht mehr ab, ihre Daten bleiben.")) syncAktion({aktion:"kontoLoeschen"}, "Lösche …"); }));
  weg.append(f); return weg;
}
const _swOrtDetail = ortDetail;
ortDetail = function(){
  if (ORT.wahl === "drive") return swDriveDetail(el("div","ort-detail"), ortJetzt());
  return _swOrtDetail();
};
// BlockEm Sync: Marktstart-Hinweis, „Weiteres Gerät verbinden“ und „Ich habe schon ein Konto“
const _swSyncDetail = syncDetail;
syncDetail = function(box, jetzt, inApp){
  const st = SYNC.st;
  if (st && !st.dienstDa && !(st.art === "dienst" && st.an)){
    box.append(el("p", null, "Mit BlockEm Sync hat jedes Gerät alle Daten und gleicht sich verschlüsselt über unseren Server in der EU ab."),
      el("p","ort-meldung","BlockEm Sync geht mit dem Marktstart online. Bis dahin: „Nur auf diesem Handy“."));
    return box;
  }
  if (st && st.art === "drive" && st.an){ box.append(el("p","k-s","Dieses Gerät gleicht gerade über Google Drive ab. Zum Wechseln dort erst abmelden.")); return box; }
  const r = _swSyncDetail(box, jetzt, inApp);
  if (!st || SYNC.code || (VB.inApp && jetzt !== "handy")) return r;
  if (st.an){ const geraete = box.querySelector(".sync-geraete") || box.querySelector(".chips"); (geraete || box).after(kpBereich()); }
  else {
    const n = el("div","sw-schon");
    n.append(el("h3","ort-h","Schon auf einem anderen Gerät?"), el("p","k-s","Dann verbinde dieses Gerät einfach per QR-Code, ohne Passwort."));
    if (SW.kp?.art === "dienst") n.append(kpNeuesGeraet("dienst"));
    else n.append(eiKnopf("Per QR-Code verbinden","ghost", () => { SW.kp = {modus:"zeigen", art:"dienst"}; renderSpeicherort(); }));
    box.prepend(n);
  }
  return r;
};

/* ----- Geräte per QR-Code verbinden ----- */
function kpStop(){ clearInterval(SW.timer); SW.timer = null; clearInterval(SW.scanTimer); SW.scanTimer = null; if (SW.kamera){ SW.kamera.getTracks().forEach(t => t.stop()); SW.kamera = null; } }
function kpQrBild(text){
  const q = qrcode(0, "M"); q.addData(text); q.make();
  const w = el("div","kp-qr"); w.innerHTML = q.createSvgTag({cellSize:6, margin:3, scalable:true}); w.setAttribute("role","img"); w.setAttribute("aria-label","QR-Code zum Verbinden");
  return w;
}
// 1.0.17: derselbe Code zum Eintippen, falls die Kamera nicht geht
function kpCodeText(code){
  if (!code) return [];
  return [el("p","k-s","Ohne Kamera: diesen Code am anderen Gerät eintippen."), el("p","sync-code kp-code", code)];
}
function kpRest(bis){ const s = Math.max(0, Math.round((bis - Date.now()) / 1000)); return `Gültig noch ${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")} Min.`; }
// Neues Gerät: Code zeigen und warten, bis ein verbundenes Gerät ihn scannt. Oder umgekehrt: Code des anderen Geräts scannen.
function kpNeuesGeraet(art, fertig){
  const box = el("div","kp-box"), info = el("p","k-s");
  if (SW.kp?.modus === "scannen") return kpKamera(box, "koppelnEinlesen", fertig, () => { SW.kp = {modus:"zeigen", art}; kpNeuZeichnen(box, art, fertig); });
  kpNeuZeichnen(box, art, fertig); return box;
}
async function kpNeuZeichnen(box, art, fertig){
  kpStop();
  box.replaceChildren(el("p","k-s","Erzeuge den Code …"));
  try {
    const r = await api("api/sync", {aktion:"koppelnZeigen", art, adresse:SYNC.adr || SYNC.st?.adresse || "", geraet:SYNC.name || ""});
    const bis = Date.now() + r.sekunden * 1000, rest = el("p","k-s", kpRest(bis));
    const scan = eiKnopf("Stattdessen den Code des anderen Geräts scannen oder eintippen","ghost small", () => { kpStop(); SW.kp = {modus:"scannen", art}; box.replaceWith(kpNeuesGeraet(art, fertig)); });
    box.replaceChildren(el("p", null, "Öffne BlockEm auf einem Gerät, das schon verbunden ist: Einstellungen › Geräte & Konto › „Weiteres Gerät verbinden“ › „Code des neuen Geräts scannen oder eintippen“. Halte es auf diesen QR-Code oder tippe dort den Code darunter ein."),
      kpQrBild(r.qr), ...kpCodeText(r.code), rest, scan);
    SW.timer = setInterval(async () => {
      if (Date.now() > bis){ kpStop(); box.replaceChildren(el("p","ort-meldung schlecht","Der Code ist abgelaufen."), eiKnopf("Neuen Code zeigen","ask small", () => kpNeuZeichnen(box, art, fertig))); return; }
      rest.textContent = kpRest(bis);
      if (SW.kp?.laeuft) return; SW.kp = {...(SW.kp || {}), laeuft:true};
      try {
        const w = await api("api/sync", {aktion:"koppelnWarten", id:r.id, geraet:SYNC.name || ""});
        if (w.verbunden){ kpStop(); SW.kp = null; await kpVerbunden(w, fertig); }
      } catch (e){ kpStop(); box.replaceChildren(el("p","ort-meldung schlecht", e.message || String(e)), eiKnopf("Nochmal","ask small", () => kpNeuZeichnen(box, art, fertig))); }
      finally { if (SW.kp) SW.kp.laeuft = false; }
    }, 3000);
  } catch (e){ box.replaceChildren(el("p","ort-meldung schlecht", e.message || String(e))); }
}
async function kpVerbunden(r, fertig){
  SYNC.st = r;
  if (VB.modus === "handy") await ortSpeichernHandy();
  await loadLocal().catch(() => {});
  toast("Verbunden. Deine Daten sind da.");
  if (fertig) return fertig(r);
  ORT.meldung = {text:"Verbunden. Dieses Gerät gleicht sich ab jetzt mit deinen anderen ab.", gut:true}; renderSpeicherort();
}
// Kamera: QR-Code lesen, dann aktion (koppelnSenden = neues Gerät aufnehmen, koppelnEinlesen = selbst beitreten)
function kpKamera(box, aktion, fertig, zurueck){
  kpStop();
  const video = el("video","kp-video"), info = el("p","k-s","Halte die Kamera auf den QR-Code."), leinwand = document.createElement("canvas");
  video.setAttribute("playsinline",""); video.muted = true;
  const ab = eiKnopf("Abbrechen","ghost small", () => { kpStop(); zurueck ? zurueck() : (SW.kp = null, renderSpeicherort()); });
  // Ohne Kamera: den 12-stelligen Code vom anderen Gerät eintippen
  const feld = el("input"); feld.placeholder = "Code, z. B. AB3D-7KQ2-XY9P"; feld.autocomplete = "off"; feld.autocapitalize = "characters"; feld.spellcheck = false; feld.setAttribute("aria-label","Code vom anderen Gerät");
  const los = eiKnopf("Mit Code verbinden","ask small", () => { const t = feld.value.trim(); if (t.replace(/[^0-9a-z]/gi, "").length !== 12) return toast("Der Code hat 12 Zeichen."); senden(t); });
  feld.addEventListener("keydown", e => { if (e.key === "Enter"){ e.preventDefault(); los.click(); } });
  const tipp = el("div","kp-tipp"); tipp.append(el("p","k-s","Kamera geht nicht? Tippe den Code ein, der unter dem QR-Code steht:"), feld, los);
  const senden = async text => {
    SW.kp = {...(SW.kp || {}), laeuft:true}; kpStop(); info.textContent = "Verbinde …";
    try {
      const r = await api("api/sync", {aktion, qr:text, art:SW.kp?.art || SYNC.st?.art || "", geraet:SYNC.name || ""});
      if (aktion === "koppelnEinlesen"){ SW.kp = null; return kpVerbunden(r, fertig); }
      SW.kp = null; SYNC.st = r; box.replaceChildren(el("p","ort-meldung gut", r.hinweis || "Erledigt."), eiKnopf("Noch ein Gerät","ghost small", () => box.replaceWith(kpBereich(true))));
      syncAktion({aktion:"konto"}, "Hole deine Geräte …");
    } catch (e){ SW.kp = null; box.replaceChildren(el("p","ort-meldung schlecht", e.message || String(e)), eiKnopf("Nochmal","ask small", () => kpKamera(box, aktion, fertig, zurueck))); }
  };
  box.replaceChildren(video, info, tipp, ab);
  if (!navigator.mediaDevices?.getUserMedia){ video.hidden = true; info.textContent = "Dieses Gerät kann hier keine Kamera öffnen."; return box; }
  navigator.mediaDevices.getUserMedia({video:{facingMode:"environment"}, audio:false}).then(strom => {
    SW.kamera = strom; video.srcObject = strom; video.play().catch(() => {});
    SW.scanTimer = setInterval(async () => {
      if (!video.videoWidth || SW.kp?.laeuft) return;
      const w = Math.min(640, video.videoWidth), h = Math.round(video.videoHeight * w / video.videoWidth);
      leinwand.width = w; leinwand.height = h; const c = leinwand.getContext("2d", {willReadFrequently:true}); c.drawImage(video, 0, 0, w, h);
      const code = jsQR(c.getImageData(0, 0, w, h).data, w, h, {inversionAttempts:"dontInvert"});
      if (!code?.data) return;
      if (!code.data.startsWith("clearmind:")){ info.textContent = "Das ist kein BlockEm-Code."; return; }
      info.textContent = "Code erkannt, verbinde …"; senden(code.data);
    }, 350);
  }).catch(() => { video.hidden = true; info.textContent = "Die Kamera ist nicht erlaubt. Tippe stattdessen den Code ein."; });
  return box;
}
// Verbundenes Gerät: ein neues aufnehmen
function kpBereich(offen){
  const d = el("details","more kp-bereich"); d.open = !!offen;
  d.append(el("summary", null, "Weiteres Gerät verbinden"));
  const box = el("div","kp-box");
  box.append(el("p","k-s","Installiere BlockEm auf dem neuen Gerät und wähle dort „Ich nutze BlockEm schon“. Dann eins von beiden:"));
  const k = el("div","sw-zwei");
  k.append(eiKnopf("Code des neuen Geräts scannen oder eintippen","ask small", () => kpKamera(box, "koppelnSenden", null, () => box.replaceWith(kpBereich(true)))),
    eiKnopf("Hier einen Code zeigen","ghost small", async () => {
      try { const r = await api("api/sync", {aktion:"koppelnAnbieten"}); const bis = Date.now() + r.sekunden * 1000, rest = el("p","k-s", kpRest(bis));
        box.replaceChildren(el("p", null, "Scanne diesen Code mit dem neuen Gerät (dort „Ich nutze BlockEm schon“ › „Code scannen oder eintippen“)."), kpQrBild(r.qr), ...kpCodeText(r.code), rest,
          eiKnopf("Fertig","ghost small", () => { kpStop(); box.replaceWith(kpBereich(false)); syncAktion({aktion:"konto"}, "Hole deine Geräte …"); }));
        kpStop(); SW.timer = setInterval(() => { rest.textContent = kpRest(bis); if (Date.now() > bis){ kpStop(); rest.textContent = "Abgelaufen."; } }, 1000);
      } catch (e){ toast(e.message || String(e)); } }));
  box.append(k); d.append(box); return d;
}
const _swOrtOeffnen = ortOeffnen;
ortOeffnen = function(w){ kpStop(); SW.kp = null; return _swOrtOeffnen(w); };


/* Kunden-Handy (john, 04.11.2026): 7× schnell auf eine leere Stelle im Bereich tippen zeigt das Code-Feld. Ohne Code tut es nichts. */
function swEntwFrei(){ try { return localStorage.getItem("swEntwFrei") === "1"; } catch(e){ return false; } }
function swEntwTipp(box){
  let n = 0, t0 = 0;
  box.addEventListener("click", e => {
    if (e.target.closest("button,input,a,summary,label,select,textarea,.ein-opt")) return;
    const jetzt = Date.now(); if (jetzt - t0 > 4000){ n = 0; t0 = jetzt; }
    if (++n < 7) return;
    try { localStorage.setItem("swEntwFrei","1"); } catch(e){}
    if (!box.querySelector(".sw-entw")) box.append(swEntwReset());
  });
}
/* ----- Nur Entwickler (john, 04.11.2026): Handy mit Einmalcode komplett zurücksetzen (Schutz aus + Speicher löschen), z. B. als Kunden-Handy ----- */
function swEntwReset(){
  const d = el("details","more sw-entw"), f = el("div","ort-form"), code = el("input");
  d.append(el("summary", null, "Entwickler: dieses Handy komplett zurücksetzen"));
  code.placeholder = "Entwickler-Code"; code.autocomplete = "off"; code.autocapitalize = "characters"; code.setAttribute("aria-label","Entwickler-Code");
  const b = eiKnopf("Schutz aus und alles löschen","ghost small danger", () => {
    if (!confirm("Wirklich? Deinstallier-Schutz geht sofort aus und die App startet leer, wie frisch installiert. Daten am Mac bleiben.")) return;
    const r = window.CockpitApp.entwicklerReset(code.value);
    if (r) return toast(r);
    toast("Wird zurückgesetzt, die App schließt sich gleich …");
  });
  // john 17.11.2026: Entwickler-Handy schaltet Schutz-Schalter frei um wie der Mac (Code wird in der App geprüft, danach Neustart der Oberfläche)
  const A = window.CockpitApp, an = !!A.entwickler?.();
  const m = A.entwicklerModus ? eiKnopf(an ? "Entwickler-Modus aus" : "Entwickler-Modus an (alle Schalter frei)", "ghost small", () => {
    const r = A.entwicklerModus(code.value, !an);
    if (r) return toast(r);
    toast(an ? "Entwickler-Modus aus." : "Entwickler-Modus an."); setTimeout(() => location.reload(), 800);
  }) : null;
  f.append(el("p","k-s","Wie „Speicher löschen“, nur ohne Wartezeit. Geht nur mit deinem Entwickler-Code."), code, b);
  if (m) f.append(el("p","k-s", an ? "Entwickler-Modus ist an: alle Schutz-Schalter frei, wie am Mac." : "Entwickler-Modus: alle Schutz-Schalter frei umschalten, wie am Mac."), m);
  d.append(f); return d;
}

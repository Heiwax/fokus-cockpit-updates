/* ---------- Dein Bild (11.11.2026, nach stile.js): Belohnung „Dein Bild“, Gesamttage, Dein Warum, Gemeinsam ----------
   Jeder saubere Tag (Gesamttage, d.sauber.gesamt aus server.py) bringt ein Teil mehr ins Bild (kein Türchen-Raster, john 11.11. 01:00: „Türchen“ war nur Metapher). 30 Teile = Bild fertig → Sammlung,
   12 Bilder im Jahr, Mann und Frau je eigene Reihe (Profil-Geschlecht). Nach einem Rückfall zeigt der Kreis die Gesamttage statt einer großen 0.
   Dein Warum: ab Tag 3 eine leise Zeile unter dem Panik-Knopf, Eingabe im Blatt „Deine Geschenke“ (tueBlatt: was es wann gibt, Farben, Sammlung). Karte „Gemeinsam“: alle sammeln anonym saubere Tage
   (Sync-Dienst /v1/gemeinsam, Zufalls-ID pro Gerät, kein Konto). Nur Anzeige, keine Sperrlogik. CSS in tuerchen.css.
   shortcut: tue.max liegt nur auf diesem Gerät (localStorage); jedes Gerät zählt seine eigenen Tage. Upgrade, wenn Bilder Geldwert bekommen: über den Server zählen.
   shortcut: bisher sind nur die ersten Bilder je Reihe gezeichnet; fehlende Bilder zeigen „kommt mit dem nächsten Update“, die Tage zählen trotzdem weiter. */
const TUE_N = 30, TUE_JAHR = 12;
const TUE_REIHEN = {m:TUE_BILDER.m, w:TUE_BILDER.w};   // Bilder in tuerchen-bilder.js (automatisch aus der Vorschau)

function tueStand(d){
  const s = d.sauber || {}, max = +(store("tue.max") || 0);
  const g = Math.max(s.gesamt ?? s.tage ?? 0, max);   // freigeschaltet bleibt freigeschaltet
  if (g > max) store("tue.max", g);
  const reihe = TUE_REIHEN[d.profil?.geschlecht === "w" ? "w" : "m"];
  const fertig = Math.floor(g / TUE_N), teile = g % TUE_N;
  return {g, reihe, fertig, teile, bild: reihe[fertig] || null, nr: fertig % TUE_JAHR + 1};
}
// Zeichnen wie in der Vorschau: Hintergrund, „hinten“-Teile, übrige Teile (ruhende mit Schatten), Vignette; Bewegung per Klasse aus TUE_BILDER.bew
function tueSvg(b, n, neu){
  const s = document.createElementNS("http://www.w3.org/2000/svg", "svg"), bew = TUE_BILDER.bew[b.name] || {};
  s.setAttribute("viewBox", "0 0 360 260"); s.setAttribute("role", "img"); s.setAttribute("aria-label", `${b.name}, ${n} von ${TUE_N} Teilen`); s.classList.add("tue-bild");
  const teil = hinten => b.teile.slice(0, n).map((t, i) => {
    if (!!t[2] !== hinten) return "";
    const a = bew[t[0]], ruht = (!a || a[0] === "a-schiff") && !/class="/.test(t[1]);   // wie Vorschau: Schatten nur für Ruhendes (Schiff schaukelt als Ganzes mit Schatten)
    return `<g${!hinten && ruht ? ' filter="url(#sch)"' : ""}><g${neu && i === n - 1 ? ' class="tue-neu"' : ""}><g${a ? ` class="${a[0]}"` + (a[1] ? ` style="transform-origin:${a[1]}"` : "") : ""}>${t[1]}</g></g></g>`;
  }).join("");
  s.innerHTML = TUE_BILDER.rahmen + b.grund + teil(true) + teil(false) + `<rect width="360" height="260" fill="url(#vig)" pointer-events="none"/>`;
  return s;
}
function tueKarte(d, knopf = true){
  const st = tueStand(d), k = el("section","tue-karte"); k.id = "tueKarte";
  const neu = st.g > +(store("tue.gesehen") || 0); store("tue.gesehen", st.g);
  const kopf = el("div","tue-kopf"); kopf.append(el("b", null, "Dein Bild"), el("span","k-s", `Bild ${st.nr} von ${TUE_JAHR} · ${st.teile} von ${TUE_N}`));
  k.append(kopf);
  const rahmen = el("div","tue-rahmen");
  if (st.teile === 0 && st.fertig > 0){   // gerade fertig geworden: das fertige Bild noch einmal zeigen
    const alt = st.reihe[st.fertig - 1];
    if (alt) rahmen.append(tueSvg(alt, TUE_N, false)); else rahmen.append(el("div","tue-leer","✓"));
    k.append(rahmen, el("p","tue-heute", `Bild ${st.nr - 1 || TUE_JAHR} ist fertig und liegt in deiner Sammlung. Morgen beginnt das nächste.`));
  } else if (st.bild){
    rahmen.append(tueSvg(st.bild, st.teile, neu));
    const t = el("p","tue-heute");
    if (st.teile){ t.append(el("small", null, "Heute neu"), st.bild.teile[st.teile - 1][0]); } else t.append(el("small", null, "Noch leer"), "Morgen kommt das erste Teil dazu.");
    k.append(rahmen, t);
  } else {
    rahmen.append(el("div","tue-leer", `${st.teile} von ${TUE_N}`));
    k.append(rahmen, el("p","tue-heute", `Bild ${st.nr} kommt mit dem nächsten Update. Deine Tage zählen schon mit.`));
  }
  const n = tueGeschenke(d).find(g => !g.da), zeile = el("button","tue-weiter"); zeile.type = "button";
  const txt = el("span"); txt.append(el("small", null, n ? `Nächstes Geschenk ${n.noch === 1 ? "morgen" : "in " + n.noch + " Tagen"}` : "Alle Geschenke geholt"), el("b", null, n ? n.t : "Deine Geschenke ansehen"));
  zeile.append(el("i","tue-gesch-ico", "🎁"), txt, el("span","tue-pfeil","›")); zeile.addEventListener("click", () => tueBlatt(d));
  if (knopf) k.append(zeile);
  return k;
}

/* ----- Gesamttage statt Null ----- */
function tueGesamt(h, d){
  const s = d.sauber || {}, g = s.gesamt ?? 0, tage = s.tage ?? 0;
  if (g <= tage) return;
  const ring = h.querySelector(".cm-ring > div");
  if (tage === 0 && ring){   // nach einem Rückfall keine große 0 (Silverman & Barasch 2023)
    ring.replaceChildren(el("b", null, String(g)), el("small", null, g === 1 ? "Tag insgesamt" : "Tage insgesamt"));
  }   // john 11.11.: zwei Zähler nebeneinander verwirren. Gesamttage stehen nur nach einem Rückfall da.
}

/* ----- Dein Warum: ab Tag 3 einmal fragen, der Satz steht beim Panik-Knopf ----- */
/* Schlanke Fassung (john 11.11. 12:39): EINE Zeile sagt, wann das nächste Geschenk kommt (statt Abzeichen-Satz + Abzeichen + Geschenk-Zeile).
   Das Bild ist das erste Geschenk: einmal einschalten, dann steht es anstelle des Kreises, die Tage stehen im Bild. */
const TUE_H = {abz:null};
function tueNaechstes(h, d){
  const sub = h.querySelector(".cm-sub"), abz = h.querySelector(".cm-abzeichen");
  if (abz){ TUE_H.abz = abz; abz.remove(); }   // Abzeichen stehen im Blatt
  const n = tueGeschenke(d).find(g => !g.da), z = el("button","tue-next"); z.type = "button";
  z.append(el("i", null, "🎁"), n ? `Nächstes Geschenk ${n.noch === 1 ? "morgen" : "in " + n.noch + " Tagen"}` : "Dein Weg", el("span","tue-pfeil","›"));
  z.addEventListener("click", () => { if (typeof wegOeffnen === "function") wegOeffnen(); else tueBlatt(d); });
  sub?.after(z);
  sub?.remove();   // john 17.11.2026: Heute war überladen, unter dem Bild steht nur noch die Geschenk-Zeile
}
/* Bild groß ansehen und zurückspulen (john 11.11. 16:54): Leiste von Teil 1 bis heute, Abspielen-Knopf.
   b = Bild, max = sichtbare Teile, ab = Gesamttag vor Teil 1 (für die Anzeige „Tag N“). */
const TUE_GR = {lauf:0};
function tueGross(b, max, ab){
  if (!b || max < 1) return;
  let g = $("tueGross");
  if (!g){ g = el("dialog","tue-gross"); g.id = "tueGross"; g.addEventListener("click", e => { if (e.target === g) g.close(); }); g.addEventListener("close", () => clearInterval(TUE_GR.lauf)); document.body.append(g); }
  clearInterval(TUE_GR.lauf);
  const kopf = el("div","tue-blatt-kopf"), zu = el("button","tue-zu","Fertig"); zu.type = "button"; zu.addEventListener("click", () => g.close());
  kopf.append(el("h2", null, b.name), zu);
  const buehne = el("div","tue-rahmen tue-gross-bild"), info = el("p","tue-heute"), leiste = el("input","tue-leiste"), spiel = el("button","tue-spiel","▶"); spiel.type = "button";
  leiste.type = "range"; leiste.min = "1"; leiste.max = String(max); leiste.value = String(max); leiste.setAttribute("aria-label", "Tag wählen");
  const zeig = (n, neu) => { leiste.value = String(n); buehne.replaceChildren(tueSvg(b, n, neu));
    info.replaceChildren(el("small", null, `Tag ${ab + n}`), b.teile[n - 1][0]); leiste.style.setProperty("--wert", ((n - 1) / Math.max(1, max - 1) * 100) + "%"); };
  leiste.addEventListener("input", () => { clearInterval(TUE_GR.lauf); spiel.textContent = "▶"; zeig(+leiste.value, true); });
  spiel.addEventListener("click", () => {
    if (TUE_GR.lauf){ clearInterval(TUE_GR.lauf); TUE_GR.lauf = 0; spiel.textContent = "▶"; return; }
    let n = +leiste.value >= max ? 0 : +leiste.value; spiel.textContent = "❚❚"; spiel.setAttribute("aria-label", "Anhalten");
    TUE_GR.lauf = setInterval(() => { n++; zeig(n, true); if (n >= max){ clearInterval(TUE_GR.lauf); TUE_GR.lauf = 0; spiel.textContent = "▶"; } }, 450);
  });
  spiel.setAttribute("aria-label", "Von Tag 1 abspielen");
  const reihe = el("div","tue-leiste-reihe"); reihe.append(spiel, leiste);
  const skala = el("div","tue-skala"); skala.append(el("span", null, `Tag ${ab + 1}`), el("span", null, `Tag ${ab + max}`));
  g.replaceChildren(kopf, buehne, info, reihe, skala);
  zeig(max, false);
  if (!g.open) g.showModal();
}
function tueHeroBild(h, d){
  const ring = h.querySelector(".cm-ring"); if (!ring) return;
  const k = tueKarte(d, false), rahmen = k.querySelector(".tue-rahmen"), heute = k.querySelector(".tue-heute"), st = tueStand(d);
  if (!rahmen?.querySelector("svg")) return;   // Bild noch nicht gezeichnet (ab Bild 4): Kreis bleibt stehen
  const zahl = el("div","tue-hero-zahl"); zahl.append(...ring.querySelectorAll("b, small"));
  rahmen.append(zahl, el("span","tue-hero-teile", `Teil ${st.teile} von ${TUE_N}`));
  const box = el("div","tue-hero-bild"); box.append(rahmen); if (heute) box.append(heute); ring.replaceWith(box);
  const [b, max, ab] = st.bild && st.teile ? [st.bild, st.teile, st.fertig * TUE_N] : [st.reihe[st.fertig - 1], TUE_N, (st.fertig - 1) * TUE_N];
  rahmen.classList.add("tue-tippbar"); rahmen.setAttribute("role", "button"); rahmen.tabIndex = 0; rahmen.setAttribute("aria-label", "Bild groß ansehen und zurückspulen");
  rahmen.addEventListener("click", () => tueGross(b, max, ab));
  rahmen.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " "){ e.preventDefault(); tueGross(b, max, ab); } });
}
function tueAngebot(h, d){   // erstes Geschenk: das Bild einschalten (einmalig, danach im Blatt umschaltbar)
  const a = el("div","tue-angebot"), t = el("span"), ja = el("button","tue-an","Einschalten"); ja.type = "button";
  t.append(el("b", null, "Dein erstes Geschenk"), el("small", null, "Ein Bild, das jeden sauberen Tag wächst."));
  ja.addEventListener("click", () => { store("tue.hero", "bild"); trHero(); });
  a.append(el("i","tue-gesch-ico","🎁"), t, ja); h.append(a);
}
function tueWarum(h, d){
  const s = d.sauber || {}, w = store("tue.warum");
  if (w){ try { if (!TUE_W.gesendet && window.CockpitApp?.panikGrund){ CockpitApp.panikGrund(w); TUE_W.gesendet = true; } } catch {} }
  else if (Math.max(s.gesamt ?? 0, s.tage ?? 0) < 3) return;
  // john 17.11.2026: keine Warum-Zeile mehr auf Heute, sie steht unter Weg › Dein Warum
}
function tueWarumSetzen(t){
  store("tue.warum", t || null); TUE_W.gesendet = false;
  try { CockpitApp?.panikGrund?.(t || ""); TUE_W.gesendet = true; } catch {}
}

/* ----- Geschenke: was es wann gibt (Farben nach Tagen am Stück wie stile.js, Bilder nach Gesamttagen) ----- */
function tueGeschenke(d){
  const st = tueStand(d), frau = d.profil?.geschlecht === "w", liste = [], max = Math.max(+(store("stil.max") || 0), d.sauber?.tage ?? 0);
  if (!frau && typeof STILE !== "undefined") STILE.filter(x => x.ab > 0).forEach(x => liste.push({tag:x.ab, t:`Farbe ${x.t}`, ico:"🎨", farbe:x.farbe, da:max >= x.ab, noch:x.ab - (d.sauber?.tage ?? 0)}));   // frei erst nach x.ab Tagen am Stück (stile.js), auch nach einem Rückfall
  for (let i = 0; i < Math.max(TUE_JAHR, st.fertig + 1); i++){ const b = st.reihe[i], tag = (i + 1) * TUE_N;
    liste.push({tag, t:`Bild „${b ? b.name : "Überraschung"}“ fertig`, ico:"🖼", da:st.g >= tag, noch:tag - st.g}); }
  return liste.sort((a, b) => a.da === b.da ? a.noch - b.noch || a.tag - b.tag : a.da ? 1 : -1);   // offene zuerst, das nächste oben
}
// Blatt „Deine Geschenke“: nächstes Geschenk, Weg, Farbe der App, Sammlung, Dein Warum, Mitteilung
const TUE_G = {};   // Gruppen im Blatt, damit der Reiter „Weg“ direkt hinspringen kann
function tueBlatt(d, zu){
  let b = $("tueBlatt");
  if (!b){ b = el("dialog","tue-blatt"); b.id = "tueBlatt"; b.setAttribute("aria-label", "Deine Geschenke"); b.addEventListener("click", e => { if (e.target === b) b.close(); }); document.body.append(b); }
  const st = tueStand(d);
  const kopf = el("div","tue-blatt-kopf"), zuK = el("button","tue-zu","Fertig"); zuK.type = "button"; zuK.addEventListener("click", () => b.close());
  kopf.append(el("h2", null, "Deine Geschenke"), zuK);
  const teile = [kopf, el("p","k-s","Was du hast, bleibt dir, auch nach einem Rückfall.")];
  const gruppe = (titel, ...inhalt) => { const g = el("section","tue-gruppe"); g.append(el("h3", null, titel), ...inhalt); teile.push(g); return g; };
  if (store("tue.hero")){   // Bild oder Kreis auf Heute
    const wahl = el("div","tue-knoepfe");
    [["bild","Bild"],["kreis","Kreis"]].forEach(([k, t]) => { const c = el("button","chip", t); c.type = "button"; c.setAttribute("aria-pressed", String(store("tue.hero") === k));
      c.addEventListener("click", () => { store("tue.hero", k); trHero(); tueBlatt(d); }); wahl.append(c); });
    if (store("tue.hero") === "bild") gruppe("Auf Heute zeigen", wahl); else gruppe("Dein Bild", tueKarte(d, false), wahl);
  }
  if (d.profil?.geschlecht !== "w" && typeof stilReihe === "function") TUE_G.farbe = gruppe("Farbe der App", stilReihe(d.sauber?.tage ?? 0), el("p","k-s","Tipp eine freie Farbe an. Die Zahl zeigt, ab wie vielen Tagen am Stück sie frei wird."));
  if (TUE_H.abz) TUE_G.abzeichen = gruppe("Abzeichen", TUE_H.abz.cloneNode(true));
  const sam = el("div","tue-sammlung");
  for (let i = 0; i < st.fertig; i++){ const bi = st.reihe[i], f = el("figure"); if (bi){ f.append(tueSvg(bi, TUE_N, false), el("figcaption", null, bi.name)); f.classList.add("tue-tippbar"); f.tabIndex = 0; f.setAttribute("role", "button"); f.addEventListener("click", () => tueGross(bi, TUE_N, i * TUE_N)); } else f.append(el("div","tue-leer","✓"), el("figcaption", null, `Bild ${i % TUE_JAHR + 1}`)); sam.append(f); }
  TUE_G.sammlung = gruppe(st.fertig ? `Sammlung · ${st.fertig} ${st.fertig === 1 ? "Bild" : "Bilder"}` : "Sammlung", st.fertig ? sam : el("p","k-s", `Hier landen deine fertigen Bilder. Das erste ist in ${TUE_N - st.teile} ${TUE_N - st.teile === 1 ? "Tag" : "Tagen"} fertig.`));
  const wf = el("input","tue-feld"); wf.maxLength = 140; wf.placeholder = "z. B. Für meine Frau und meine Kinder"; wf.value = store("tue.warum") || ""; wf.setAttribute("aria-label", "Wofür machst du das?");
  const ws = el("button","ask small","Speichern"); ws.type = "button";
  ws.addEventListener("click", () => { tueWarumSetzen(wf.value.trim()); toast(wf.value.trim() ? "Gemerkt. Dein Satz steht beim Panik-Knopf." : "Entfernt."); trHero(); });
  const wz = el("div","tue-knoepfe"); wz.append(ws);
  const wg = gruppe("Dein Warum", el("p","k-s","Wofür machst du das? Ein Satz reicht. Er erscheint, wenn du den Panik-Knopf drückst."), wf, wz);
  if (window.CockpitApp?.tuerchenMorgen){   // nur am Handy: Mitteilung um 8 Uhr (Momente.java)
    const z = el("label","tue-schalter"), c = el("input"); c.type = "checkbox"; c.checked = store("tue.morgen") !== false;
    c.addEventListener("change", () => { store("tue.morgen", c.checked); try { CockpitApp.tuerchenMorgen(c.checked); } catch {} });
    z.append(c, " Morgens Bescheid sagen, wenn ein neues Teil da ist"); gruppe("Mitteilung", z);
  }
  b.replaceChildren(...teile);
  if (!b.open) b.showModal();
  if (zu === "warum"){ wg.scrollIntoView({block:"center"}); wf.focus(); } else if (TUE_G[zu]) TUE_G[zu].scrollIntoView({block:"start"}); else b.scrollTop = 0;
}
const TUE_W = {gesendet:false};
if (typeof trPanik === "function"){   // Web/Mac: eigener Satz im Panik-Fenster (am Handy zeigt Panik.java panikGrund)
  const tuePanikAlt = trPanik;
  trPanik = function(...a){
    const r = tuePanikAlt.apply(this, a), w = store("tue.warum"), p = document.querySelector("#trPanik .tr-pause-text");
    if (w && p) p.textContent = w;
    return r;
  };
}

/* ----- Gemeinsam: alle sammeln anonym saubere Tage für ein Spendenziel ----- */
const GM = {stand:null, zeit:0, laeuft:false, fehler:"", pause:0};   // pause: nach einem Fehler 30 Min nichts senden (Handy-Brücke ist synchron, Prüfung 11.11. M5)
function gmId(){
  let id = store("gm.id");
  if (!/^[0-9a-f]{32}$/.test(id || "")){ id = [...crypto.getRandomValues(new Uint8Array(16))].map(x => x.toString(16).padStart(2, "0")).join(""); store("gm.id", id); }
  return id;
}
async function gmAnfrage(was, extra){
  const id = gmId();
  if (window.CockpitApp?.gmAnfrage){
    const a = JSON.parse(CockpitApp.gmAnfrage(was === "stand" ? "GET" : "POST", was === "stand" ? `/v1/gemeinsam?id=${id}` : `/v1/gemeinsam/${was}`, was === "stand" ? "" : JSON.stringify({id, ...extra})));
    if (a.status === 200) return a.daten;
    throw new Error((a.daten && a.daten.fehler) || a.fehler || "Das ging gerade nicht.");
  }
  return api("api/gemeinsam", {was, id, ...extra});
}
const gmTag = n => { const t = new Date(Date.now() - n * 864e5); return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")}`; };
// Heute (sauber, solange heute kein Versuch) und gestern (endgültig) melden, nur wenn sich etwas geändert hat.
// shortcut: wer die App am Abend nicht mehr öffnet, meldet einen späten Versuch erst am nächsten Tag (über „gestern“).
async function gmMelden(d){
  const s = d.sauber || {}, v = s.verlauf || {};
  if (s.gesamt == null || GM.laeuft || Date.now() < GM.pause) return;   // john 20.11.: Verzicht zählt auch ohne Porno-Schutz (Porno-Seiten werden dann nur gezählt, ein Besuch macht den Tag unsauber)
  const jetzt = [[gmTag(1), !(v[gmTag(1)] > 0)], [gmTag(0), !(s.heute > 0)]], alt = store("gm.gemeldet") || {}, neu = {};
  const offen = jetzt.filter(([t, ok]) => alt[t] !== ok);
  if (!offen.length){ if (Date.now() - GM.zeit > 30 * 60000) gmHolen(); return; }
  GM.laeuft = true;
  try {
    for (const [tag, sauber] of offen){ GM.stand = await gmAnfrage("tag", {tag, sauber}); neu[tag] = sauber; }
    jetzt.forEach(([t, ok]) => { if (!(t in neu) && t in alt) neu[t] = alt[t]; });
    store("gm.gemeldet", neu); GM.zeit = Date.now(); GM.fehler = "";
  } catch (e){ GM.fehler = e.message || String(e); GM.zeit = GM.pause = Date.now() + 30 * 60000; }
  GM.laeuft = false; gmZeichnen();
}
async function gmHolen(){
  if (GM.laeuft || Date.now() < GM.pause) return; GM.laeuft = true;
  try { GM.stand = await gmAnfrage("stand"); GM.zeit = Date.now(); GM.fehler = ""; } catch (e){ GM.fehler = e.message || String(e); GM.zeit = GM.pause = Date.now() + 30 * 60000; }
  GM.laeuft = false; gmZeichnen();
}
function gmZeichnen(){ $("gmVoll")?.replaceWith(gmKarte()); }
function gmKarte(){
  const k = el("section","gm-karte"), st = GM.stand; k.id = "gmVoll";
  const kopf = el("div","tue-kopf"); kopf.append(el("b", null, "Gemeinsam"), el("span","k-s","anonym, ohne Namen")); k.append(kopf);
  if (!st){ k.append(el("p","k-s", GM.fehler ? "Gerade keine Verbindung. Deine Tage zählen trotzdem." : "Lädt …")); return k; }
  const anteil = Math.min(1, st.summe / Math.max(1, st.ziel)), balken = el("div","gm-balken"), fuell = el("i");
  fuell.style.width = Math.round(anteil * 100) + "%"; balken.append(fuell);
  balken.setAttribute("role", "progressbar"); balken.setAttribute("aria-valuemin", "0"); balken.setAttribute("aria-valuemax", String(st.ziel)); balken.setAttribute("aria-valuenow", String(st.summe));
  k.append(el("p","gm-zahl", `${st.summe.toLocaleString("de-DE")} von ${st.ziel.toLocaleString("de-DE")} sauberen Tagen`), balken,
    el("p","k-s", st.erreicht ? "Ziel erreicht. Diesen Monat geht eine Spende raus." :
      `${st.aktive} ${st.aktive === 1 ? "Mensch macht" : "Menschen machen"} mit. Schaffen wir das Ziel, spendet BlockEm.` + (st.topf ? ` Dazu kommt der Topf aus ${st.topf} ${st.topf === 1 ? "Monat" : "Monaten"} davor.` : "")));
  if (st.orgs?.length){
    const wahl = el("div","gm-orgs"); wahl.append(el("span","k-s", st.meineStimme ? "Deine Stimme (änderbar):" : "Wer soll die Spende bekommen?"));
    st.orgs.forEach(o => { const b = el("button","chip", `${o.name} · ${o.stimmen}`); b.type = "button"; b.setAttribute("aria-pressed", String(st.meineStimme === o.k));
      b.addEventListener("click", async () => { b.disabled = true; try { GM.stand = await gmAnfrage("stimme", {org:o.k}); gmZeichnen(); } catch (e){ toast(e.message || String(e)); b.disabled = false; } });
      wahl.append(b); });
    k.append(wahl);
  }
  const belege = Object.entries(st.belege || {}).sort().reverse();
  if (belege.length){ const a = el("a","gm-beleg", `Quittung der letzten Spende (${belege[0][0]})`); a.href = belege[0][1]; a.target = "_blank"; a.rel = "noopener"; k.append(a); }
  return k;
}

if (NUR_TRACKING){
  const tueHeroAlt = trHeroZeichnen;
  trHeroZeichnen = function(h, d){
    tueHeroAlt(h, d);
    h.querySelector(".st-reihe")?.remove();   // john 11.11.: Farben nicht lose auf Heute, sondern im Blatt „Deine Geschenke“
    tueGesamt(h, d);
    tueNaechstes(h, d);
    if (store("tue.hero") === "bild") tueHeroBild(h, d);
    tueWarum(h, d);
    if (!store("tue.hero")) tueAngebot(h, d);
    // „Gemeinsam“ steht im Reiter „Weg“ (weg.js), gemeldet wird trotzdem von hier.
    setTimeout(() => gmMelden(d), 1500);   // erst zeichnen, dann (am Handy synchron) melden
  };
}

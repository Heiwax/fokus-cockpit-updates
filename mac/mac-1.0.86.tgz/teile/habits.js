/* ---------- Habits (tägliche Gewohnheiten) und Consistency-Auswertung, im Heute-Reiter ---------- */
async function habitApi(body){
  try { S.plan = await api("api/habit", body); renderPlan(); }
  catch (e) { S.fehler = [`Habit: ${e.message || e}`]; renderHeader(); }
}
// Wie viele Tage in Folge (bis heute bzw. gestern) ein Habit erledigt war; Tage, an denen er nicht dran ist, zählen nicht
function habitSerie(log, name, tage){
  const k = key(name), d = new Date(NOW), da = x => (log[iso(x)] || []).some(y => key(y) === k), dran = x => !tage || tage.includes((x.getDay() + 6) % 7);
  let n = 0;
  if (!da(d)) d.setDate(d.getDate() - 1);
  for (let i = 0; i < 400; i++, d.setDate(d.getDate() - 1)){ if (da(d)) n++; else if (dran(d)) break; }
  return n;
}
const TAGE_KURZ = ["Mo","Di","Mi","Do","Fr","Sa","So"];
function rhythmusText(r){ return r?.tage ? r.tage.map(i => TAGE_KURZ[i]).join(", ") : r?.proWoche ? `${r.proWoche}x pro Woche` : ""; }
// Wochentage zum Anklicken (Mo–So); alle an = täglich, mindestens ein Tag bleibt an
function tageWahl(an, onChange){
  const box = el("div","chips wt-wahl"), wahl = new Set(an);
  TAGE_KURZ.forEach((t, i) => {
    const b = el("button","chip small", t); b.type = "button"; b.setAttribute("aria-pressed", String(wahl.has(i)));
    b.addEventListener("click", () => {
      if (wahl.has(i)){ if (wahl.size === 1) return; wahl.delete(i); } else wahl.add(i);
      b.setAttribute("aria-pressed", String(wahl.has(i))); info.textContent = tageInfo(wahl); onChange([...wahl].sort());
    });
    box.append(b);
  });
  const info = el("span","k-s wt-info", tageInfo(wahl)); box.append(info);
  return box;
}
function tageInfo(w){ return !w.size ? "keine festen Tage" : w.size === 7 ? "jeden Tag" : `${w.size} ${w.size === 1 ? "Tag" : "Tage"} pro Woche`; }
const tageRhythmus = t => t.length === 7 ? "" : t.map(i => TAGE_KURZ[i]).join(", ");
const ALLE_TAGE = [0,1,2,3,4,5,6];
let neueTage = ALLE_TAGE;
const habOffen = new Set();   // bei welchen Habits die Tagesauswahl aufgeklappt ist
// Wie oft diese Woche (ab Montag) erledigt
function habitWoche(log, name){
  const k = key(name), d = new Date(NOW); d.setDate(d.getDate() - (d.getDay() + 6) % 7); let n = 0;
  for (; iso(d) <= TODAY; d.setDate(d.getDate() + 1)) if ((log[iso(d)] || []).some(x => key(x) === k)) n++;
  return n;
}
function renderHabits(p){
  const box = $("habBox"); if (!box) return;
  box.hidden = !p.habits; if (!p.habits) return;
  const h = p.habits, heute = new Set((h.log[TODAY] || []).map(key)), ul = $("habits"); ul.replaceChildren();
  const dran = new Set((h.dran || h.liste).map(key));
  // erst was heute dran ist, dann der Rest (z. B. Sport an Tagen ohne Sport)
  [...h.liste.filter(n => dran.has(key(n))), ...h.liste.filter(n => !dran.has(key(n)))].forEach(n => {
    const done = heute.has(key(n)), r = h.rhythmus?.[n], auto = h.auto?.[n];
    const li = el("li", "item" + (done ? " done" : "") + (!dran.has(key(n)) && !done ? " nichtdran" : "")), cb = document.createElement("input"), t = el("div","t", n);
    cb.type = "checkbox"; cb.checked = done; cb.setAttribute("aria-label", n);
    cb.addEventListener("change", () => habitApi({aktion:"abhaken", name:n, done:cb.checked}));
    if (r?.proWoche) t.append(el("span", "tag" + (habitWoche(h.log, n) >= r.proWoche ? " good" : ""), `${habitWoche(h.log, n)}/${r.proWoche} diese Woche`));
    else if (r?.tage) t.append(el("span","tag", dran.has(key(n)) ? rhythmusText(r) : `heute nicht dran · ${rhythmusText(r)}`));
    const s = r?.proWoche ? 0 : habitSerie(h.log, n, r?.tage); if (s >= 2) t.append(el("span","tag on", `${s} Tage in Folge`));
    if (auto){
      const a = el("span", "tag auto" + (auto.ok ? " good" : ""), auto.hand ? "von Hand" : `automatisch · ${auto.text}`);
      a.title = auto.hand ? "Heute von Hand geändert, BlockEm hakt ihn heute nicht mehr selbst um." : "BlockEm hakt diesen Habit selbst ab (aus Fokus-Sessions, Bildschirmzeit und Projekt-Erkennung).";
      t.append(a);
    }
    const offen = habOffen.has(key(n)), rh = el("button","ghost small hab-rh", offen ? "Fertig" : "Tage");
    rh.type = "button"; rh.title = "An welchen Tagen?"; rh.setAttribute("aria-expanded", String(offen)); rh.setAttribute("aria-label", `Tage für „${n}“ wählen`);
    rh.addEventListener("click", () => { offen ? habOffen.delete(key(n)) : habOffen.add(key(n)); renderHabits(S.plan); });
    const x = el("button","x-del","×"); x.type = "button"; x.title = "Habit löschen"; x.setAttribute("aria-label", `Habit „${n}“ löschen`);
    x.addEventListener("click", () => { if (confirm(`Habit „${n}“ löschen?\n\nEs landet in „Gelöscht.md“ im Vault, die erledigten Tage bleiben im Log.`)) habitApi({aktion:"weg", name:n}); });
    li.classList.add("act"); li.append(cb, t, rh, x);
    if (offen){
      // Feste Tage anklicken; oder ohne feste Tage x-mal pro Woche
      const p2 = el("div","hab-tage"), pw = el("div","chips wt-pw");
      p2.append(tageWahl(r?.tage || (r?.proWoche ? [] : ALLE_TAGE), t2 => habitApi({aktion:"rhythmus", name:n, rhythmus:tageRhythmus(t2)})));
      pw.append(el("span","k-s","Oder x-mal pro Woche, egal wann:"));
      [1,2,3,4,5,6].forEach(k => { const b = el("button","chip small", `${k}×`); b.type = "button"; b.setAttribute("aria-pressed", String(r?.proWoche === k));
        b.addEventListener("click", () => habitApi({aktion:"rhythmus", name:n, rhythmus:`${k}x pro Woche`})); pw.append(b); });
      p2.append(pw); li.append(p2);
    }
    ul.append(li);
  });
  if (!h.liste.length) ul.append(el("li","empty","Noch keine Habits. Leg unten einen an, z. B. „10 Min lesen“."));
  const d = h.liste.filter(n => dran.has(key(n)) && heute.has(key(n))).length;
  $("habSub").textContent = h.liste.length ? `${d} von ${dran.size} heute` : "";
  renderKonsistenz(p);
}
// Score eines Tages: Schnitt aus Habits, Heute-Zielen und Fokuszeit (nur was es an dem Tag gab); freie Tage haben keinen Score
function konTeile(v){
  if (!v || v.frei) return [];
  return [v.habitsVon ? ["Habits", v.habits / v.habitsVon, `${v.habits}/${v.habitsVon}`] : null,
    v.zieleVon ? ["Ziele", v.ziele / v.zieleVon, `${v.ziele}/${v.zieleVon}`] : null,
    v.fokusZielMin ? ["Fokus", Math.min(1, (v.fokusMin || 0) / v.fokusZielMin), `${v.fokusMin || 0}/${v.fokusZielMin} Min`] : null].filter(Boolean);
}
function konScore(v){ const t = konTeile(v); return t.length ? Math.round(t.reduce((a, x) => a + x[1], 0) / t.length * 100) : null; }
// Serie: Tage in Folge ab der Schwelle; freie Tage und Tage ohne Plan unterbrechen nicht, heute zählt erst, wenn geschafft
function konSerie(k, gut){
  const d = new Date(NOW); let serie = 0;
  for (let i = 0; i < 400; i++, d.setDate(d.getDate() - 1)){
    const v = k[iso(d)], s = konScore(v);
    if (v?.frei || (v && s == null)) continue;
    if (s != null && s >= gut){ serie++; continue; }
    if (i === 0) continue;
    break;
  }
  return serie;
}
function renderKonsistenz(p){
  const box = $("konBox"), k = p.konsistenz || {}, gut = p.habits?.schwelle || 80; if (!box) return;
  const mo = new Date(NOW); mo.setDate(mo.getDate() - (mo.getDay() + 6) % 7);
  const tage = [...Array(7)].map((_, i) => { const d = new Date(mo); d.setDate(d.getDate() + i); const s = iso(d); return {s, d, frei: !!k[s]?.frei, score: s <= TODAY ? konScore(k[s]) : null}; });
  const mit = tage.filter(t => t.score != null), woche = mit.length ? Math.round(mit.reduce((a, t) => a + t.score, 0) / mit.length) : null;
  const serie = konSerie(k, gut);
  const farbe = s => s == null ? "var(--line-hi)" : s >= gut ? "var(--good)" : s >= 50 ? "var(--cyan)" : "var(--bad)";
  const kz = (lbl, wert, sub, f) => { const x = kpi(lbl, wert, f); x.append(el("span","k-s", sub)); return x; };
  const v = k[TODAY], tag = konScore(v), teile = konTeile(v).map(x => `${x[0]} ${x[2]}`);
  const top = el("div","kon-top");
  top.append(kz("Heute", v?.frei ? "frei" : tag == null ? "–" : tag + " %", v?.frei ? "Zählt nicht mit" : teile.join(" · ") || "Noch nichts geplant", farbe(tag)),
    kz("Diese Woche", woche == null ? "–" : woche + " %", `Schnitt aus ${mit.length} ${mit.length === 1 ? "Tag" : "Tagen"}, freie Tage zählen nicht`, farbe(woche)),
    kz("Serie", `${serie} ${serie === 1 ? "Tag" : "Tage"}`, `in Folge ab ${gut} %`));
  const bar = el("div","kon-tage");
  tage.forEach(t => {
    const c = el("div","kon-tag" + (t.s === TODAY ? " heute" : "") + (t.frei ? " frei" : "")), s = el("div","kon-s"), i = el("i");
    if (t.frei) s.append(el("small", null, "frei"));
    else { i.style.height = Math.max(4, t.score ?? 0) + "%"; i.style.background = farbe(t.score); s.append(i); }
    c.title = t.frei ? "freier Tag" : t.score == null ? "keine Daten" : t.score + " %";
    c.append(s, el("span", null, ["Mo","Di","Mi","Do","Fr","Sa","So"][(t.d.getDay() + 6) % 7])); bar.append(c);
  });
  const set = el("label","kon-set"), inp = el("input");
  inp.type = "number"; inp.min = 1; inp.max = 100; inp.step = 5; inp.value = gut; inp.inputMode = "numeric"; inp.setAttribute("aria-label", "Durchgezogen ab Prozent");
  inp.disabled = S.mode !== "lokal";
  inp.addEventListener("change", () => { const w = Math.max(1, Math.min(100, Math.round(+inp.value || 80))); if (w !== gut) habitApi({aktion:"schwelle", wert:w}); });
  set.append("Ein Tag gilt als durchgezogen ab ", inp, " %");
  const wie = el("details","more kon-wie"); wie.append(el("summary", null, "Wie wird gerechnet?"), set);
  box.replaceChildren(top, bar, wie);
  wie.append(el("p","hint kon-hint", "Score = Schnitt aus erledigten Habits, erledigten Heute-Zielen und Fokuszeit (Fokus-Sessions gegen deine geplanten Stunden für den Tag). Freie Tage zählen nicht mit und unterbrechen die Serie nicht."));
  $("konSub").textContent = v?.frei ? "heute frei" : tag != null && tag >= gut ? "heute durchgezogen" : "";
}
$("habForm")?.addEventListener("submit", e => {
  e.preventDefault(); const t = $("habText").value.trim(); if (!t || S.mode !== "lokal") return;
  $("habText").value = ""; habitApi({aktion:"add", name:t, rhythmus:tageRhythmus(neueTage)});
  neueTage = ALLE_TAGE; $("habTage")?.replaceChildren(tageWahl(neueTage, t2 => { neueTage = t2; }));
});
$("habTage")?.replaceChildren(tageWahl(neueTage, t2 => { neueTage = t2; }));

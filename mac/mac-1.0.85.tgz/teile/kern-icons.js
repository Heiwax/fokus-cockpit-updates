/* BlockEm Kern (19.11.2026): gezeichnete Kern-Piktogramme aus der Designübergabe (kern-icons.js, unverändert) + Namensvarianten der echten App-Namen. */
// Original Kern pictograms. Paths use a shared 24-unit drawing grid.
const kernPaths={
 Instagram:"M6 5h12l2 2v11l-2 2H6l-2-2V7z M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M17 8h.1",
 TikTok:"M14 4v12a4 4 0 1 1-4-4 M14 4q1 5 6 6",
 Facebook:"M10 20V8q0-5 7-4 M6 12h10",
 Reddit:"M4 12q8-8 16 0v3q-8 8-16 0z M12 8l2-5 5 1 M8 13h.2m7 0h.2 M9 16q3 2 6 0",
 Threads:"M17 7q-7-7-11 2-3 11 7 11 7-1 5-7-2-5-9-2-4 4 1 5 6 0 4-7",
 Snapchat:"M6 12V9a6 6 0 0 1 12 0v3l3 4-4 1-1 2-4-1-4 1-1-2-4-1z",
 Pinterest:"M8 21l3-13 M7 14q-5-8 4-10 8-2 9 5 1 9-7 8l-2-2",
 Bluesky:"M12 12Q5 2 3 5q-1 8 5 9-5 4 0 6l4-5 4 5q5-2 0-6 6-1 5-9-2-3-9 7z",
 Tumblr:"M10 4q0 5-5 6h4v6q0 5 8 3 M10 9h7",
 Mastodon:"M5 18V8q0-4 7-4t7 4v7q-3 3-10 2 M7 17q0 4 7 4 M8 13V9q2-3 4 0v4-4q2-3 4 0v4",
 LinkedIn:"M5 10v9 M5 5v1 M10 19v-9m0 3q6-7 8 0v6",BeReal:"M4 7h16v11H4z M7 10h4v4H7z M15 11h2",
 Discord:"M5 7l4-2 1 2h4l1-2 4 2 2 10-5 2-2-3h-4l-2 3-5-2z M8 12h1m6 0h1",
 Telegram:"M3 11l18-7-4 16-6-5-3 3v-5l9-6-11 6z",
 WhatsApp:"M5 16a8 8 0 1 1 3 3l-5 2z M9 8q-1 5 6 8l2-2-3-2-1 1-2-3 1-1z",
 Signal:"M6 18l-3 2 1-5 M4 11l1-3m3-3 3-1m4 0 3 2m2 3 1 3m-1 4-2 3m-4 1h-4",
 Messenger:"M4 16a8 8 0 1 1 5 4l-4 1z M7 14l4-5 3 3 4-3-4 6-3-3z",
 X:"M4 4h4l12 16h-4z M19 4l-6 7m-3 3-5 6",
 YouTube:"M5 6h14l2 3v7l-2 2H5l-2-2V9z M10 9l5 3-5 3z",
 Netflix:"M6 20V4l12 16V4 M9 4l9 12",Spotify:"M4 9q7-4 16 0 M5 13q7-3 13 0 M7 17q5-2 9 0",
 Twitch:"M4 4h17v11l-5 4h-5l-4 3v-4H4z M10 8v5m5-5v5",
 "Disney+":"M3 10q8-11 17-3 M7 18V9q14 1 7 8-4 3-9 1 M18 13h4m-2-2v4",
 "Prime Video":"M9 5l7 4-7 4z M3 16q7 7 17 0 M16 15l5-1-1 5",
 "Apple TV":"M4 6h16v12H4z M9 21h6 M10 9l5 3-5 3z",
 WOW:"M3 7l4 11 5-8 5 8 4-11",DAZN:"M4 4h16v16H4z M7 8h9l-8 8h9",
 Deezer:"M4 15v3m4-8v8m4-12v12m4-9v9m4-5v5",
 SoundCloud:"M3 12v4m3-6v8m3-9v9m3 0V8q6-6 7 3 5 1 2 7z",
 Vimeo:"M3 9q6-8 7 3l2 5q3-1 5-7l-3 1q3-9 7-5 1 6-8 14-5 3-6-8z",
 Crunchyroll:"M19 7A8 8 0 1 0 16 20 7 7 0 0 1 19 7z",
 Plex:"M6 4h6l7 8-7 8H6l7-8z",Arte:"M4 17l4-10 3 10 M6 14h4 M13 8l5 8m-4-2 6-4",ZDFmediathek:"M4 9q4-6 8 0l-7 8h8 M16 7v10l5-5z",
 Minecraft:"M3 8l9-5 9 5v10l-9 4-9-4z M3 8l9 5 9-5 M12 13v9 M6 11v2m3 0v2",
 Roblox:"M7 3l15 4-5 15-15-5z M10 9l5 1-2 5-4-2z",
 "Pokémon GO":"M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0 M3 12h6m6 0h6 M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0",
 "Clash Royale":"M4 8l5 4 3-8 4 8 5-4-3 11H7z M8 16h9",
 "Clash of Clans":"M4 4l5 2 10 13-2 2L5 8z M20 4l-5 2-4 5m-3 3-5 6m11-3 6-5",
 "Brawl Stars":"M12 3l3 5 6 1-4 5 1 6-6-2-6 2 1-6-4-5 6-1z M9 12h1m4 0h1",
 "Among Us":"M6 19V9q1-8 9-5l3 4v12h-4v-4h-4v4z M12 7h7v5h-7z M5 10H3v7h2",
 "Subway Surfers":"M8 3h8l3 4v9H5V7z M7 8h10 M8 13h1m6 0h1 M8 17l-4 4m12-4 4 4",
 "Candy Crush":"M7 9l-4-3v9l4-1 M17 9l4-3v9l-4-1 M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0 M9 15l5-6",
 "Monument Valley":"M3 18L12 3l9 15z M7 16l5-8 5 8z",
 "Stardew Valley":"M5 17l7-5 7 5-7 4z M12 14V8q-6 1-7-4 6-1 7 4 2-6 8-5-1 6-8 6",
 "Chess.com":"M6 19h12v2H5z M7 17l5-6-6 1-1-3 7-6 1 3 4-1 1 12 M11 8h1",
 UNO:"M7 4l11 2-3 15-11-2z M9 9q5-3 5 2t-5 5q-3-1 0-7z",
 "Hay Day":"M6 21L17 4 M13 11q-6-1-4-6 5 0 4 6 M10 16q-5-1-5-5 5-1 5 5 M12 13q4-6 8-4-1 5-8 4",
 Wordfeud:"M3 5h13v11H9l-4 4v-4H3z M16 9h5v11l-3-2h-5 M6 9h7",
 "Geometry Dash":"M4 5h16v15H4z M7 9h2v2H7zm8 0h2v2h-2z M8 16h8",
 Audible:"M3 13l9 7 9-7 M5 10q7-7 14 0 M8 12q4-4 8 0",
 Duolingo:"M4 5l4 3q4-2 8 0l4-3-1 10q-7 11-14 0z M7 11h3m4 0h3m-6 3 1 2 1-2",
 Kindle:"M3 7q5-2 9 2 4-4 9-2v11q-5-1-9 2-4-3-9-2z M12 9v11",
 Strava:"M3 15l6-12 6 12h-4l-2-4-2 4z M12 16h3l2 4 2-4h3l-5 7z",
 Komoot:"M4 17a9 9 0 1 1 15 0l-7-5-5 8z M12 12l4-5",
 Notion:"M4 5l12-2 5 4v13l-14 1-3-4z M7 7l14-1 M9 17V9l7 8V9",
 Slack:"M8 3v9m5-8v4h7 M4 12h4m4 0v8m5-8h4m-4 4v5 M3 16h5",
 Teams:"M3 8h12v11H3z M6 11h6m-3 0v5 M17 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4 M16 10h5v6l-3 2",
 Zoom:"M3 7h12v11H6l-3-3z M15 10l6-4v13l-6-4z",
 Shazam:"M8 14q-6-2-2-7l3-3q4-2 6 1 M16 10q6 2 2 7l-3 3q-4 2-6-1 M8 15l8-8",
 "Pocket Casts":"M12 21a9 9 0 1 1 9-9 M12 17a5 5 0 1 1 5-5 M12 13v7",
 Letterboxd:"M10 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0 M22 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0",
 Dokumente:"M6 3h8l5 5v13H6z M14 3v6h5 M9 13h7m-7 4h5",Kalender:"M4 6h16v15H4z M8 3v6m8-6v6 M4 11h16 M8 15h2m3 0h2",Notizen:"M5 4h14v12l-5 5H5z M14 21v-5h5 M8 9h8m-8 3h6",Browser:"M20 12a8 8 0 1 1-16 0 8 8 0 0 1 16 0 M15 8l-2 6-5 2 2-6z",Karten:"M3 7l6-3 6 3 6-3v14l-6 3-6-3-6 3z M9 4v14m6-11v14",Wetter:"M7 18a4 4 0 0 1 0-8q4-6 9 0a4 4 0 0 1 1 8z M15 5l1-2m3 5 2-1"
};
const kernAliases={"reddit.com":"Reddit","youtube.com":"YouTube","instagram.com":"Instagram","twitch.tv":"Twitch",Chrome:"Browser"};
kernPaths["news.ycombinator.com"]="M5 4h14v16H5z M8 8l4 5 4-5m-4 5v4";
function kernLogo(name){
 const path=kernPaths[kernAliases[name]||name]||"M3 7l9-4 9 4v11l-9 4-9-4z M3 7l9 5 9-5m-9 5v10";
 return '<svg class="kern-glyph" viewBox="0 0 30 30" aria-hidden="true"><path class="glyph-face" d="M3 7l5-5h17l3 3v19l-4 4H5l-3-3z"/><path class="glyph-edge" d="M2 24l4 1h17l5-4v3l-4 4H5z"/><path class="glyph-mark" transform="translate(4 4) scale(.92)" d="'+path+'"/></svg>';
}
Object.assign(kernAliases, {twitter:"X","Twitter":"X","X (Twitter)":"X",Paramount:"Prime Video","Paramount+":"Prime Video","Paramount+ Deutschland":"Prime Video",
  "Google Chrome":"Browser",Safari:"Browser",Firefox:"Browser",Edge:"Browser","Microsoft Edge":"Browser",Brave:"Browser",Arc:"Browser",Opera:"Browser",
  snapchat:"Snapchat",pinterest:"Pinterest",discord:"Discord","candy crush":"Candy Crush",clash:"Clash of Clans",YouTube_Music:"YouTube","YouTube Music":"Spotify",
  "tiktok.com":"TikTok","netflix.com":"Netflix","x.com":"X","twitter.com":"X","facebook.com":"Facebook","threads.net":"Threads","pinterest.com":"Pinterest",
  Kalender:"Kalender",Calendar:"Kalender","Google Kalender":"Kalender",Notizen:"Notizen",Notes:"Notizen","Google Maps":"Karten",Maps:"Karten",Wetter:"Wetter",
  Word:"Dokumente","Microsoft Word":"Dokumente",Pages:"Dokumente","Google Docs":"Dokumente",Obsidian:"Notizen",Gmail:"Messenger",Mail:"Messenger"});
// Groß/klein egal: echte Namen kommen vom Gerät („youtube“, „Instagram Lite“ …)
const KERN_KEYS = Object.keys(kernPaths).map(k => [k.toLowerCase(), k]);
function kernName(n){
  const s = String(n || ""); if (kernPaths[s] || kernAliases[s]) return s;
  const l = s.toLowerCase(), a = Object.keys(kernAliases).find(k => k.toLowerCase() === l); if (a) return a;
  const k = KERN_KEYS.find(([x]) => x === l) || KERN_KEYS.find(([x]) => x.length > 3 && l.startsWith(x)); return k ? k[1] : s;
}
function kernIcon(n){ return kernLogo(kernName(n)); }

#!/usr/bin/env python3
"""Messmodus auswerten (john 25.11.2026, „prüf die Daten“). Liest messung/*.jsonl (Mac: DATEN/messung, Handys kommen beim Sync dazu)
und schreibt eine Markdown-Übersicht: Watt je App, BlockEm-Rechenzeit, Bild-KI, Akku-Verlust. Watt je App = Watt des ganzen Geräts,
während die App vorne war (inkl. Bildschirm und allem Hintergrund) – eine Schätzung, kein Messwert der App allein.

  python3 messung-auswerten.py <ordner> [--von 2026-11-25] [--bis 2026-11-27]
  python3 messung-auswerten.py --test
"""
import collections, json, statistics, sys
from pathlib import Path

LUECKE = 10   # s: größerer Abstand = Handy schlief / Mac aus, zählt nicht als Messzeit


def lesen(ordner, von="", bis="9"):
    geraete = collections.defaultdict(list)
    for f in sorted(Path(ordner).glob("*.jsonl")):
        name, tag = f.stem[:-11], f.stem[-10:]
        if not (von <= tag <= bis):
            continue
        for z in f.read_text("utf-8").splitlines():
            try:
                o = json.loads(z)
            except ValueError:
                continue
            o["t"] = o["t"] / 1000 if o["t"] > 1e11 else o["t"]
            geraete[name].append(o)
    for v in geraete.values():
        v.sort(key=lambda o: o["t"])
    return geraete


def auswerten(zeilen, handy):
    """Jede Zeile gilt für die Zeit bis zur nächsten (höchstens LUECKE s)."""
    app = collections.defaultdict(lambda: {"s": 0.0, "ws": 0.0, "wS": 0.0, "cpu": 0, "bild": 0, "ax": 0})
    teile, pm, top = collections.Counter(), collections.Counter(), collections.Counter()
    an_aus = {True: [0.0, 0.0], False: [0.0, 0.0]}   # Bildschirm an/aus: Sekunden, Watt·s
    luecken = 0.0
    bild_w = {True: [], False: []}
    for a, b in zip(zeilen, zeilen[1:]):
        dt = b["t"] - a["t"]
        if dt > LUECKE or dt <= 0:
            luecken += max(0.0, dt)
            continue
        if a.get("laden"):
            continue   # am Ladegerät sagt der Akkustrom nichts über den Verbrauch
        name = a.get("app") or "?"
        x = app[name]
        x["s"] += dt
        w = a.get("w")
        if isinstance(w, (int, float)) and w > 0:
            x["ws"] += w * dt
            x["wS"] += dt
            an_aus[bool(a.get("an", True))][0] += dt
            an_aus[bool(a.get("an", True))][1] += w * dt
            bild_w[bool(b.get("bild"))].append((name, w))
        x["cpu"] += b.get("cpuMs") or 0
        x["bild"] += b.get("bild") or 0
        x["ax"] += b.get("ax") or 0
        teile.update(b.get("teile") or {})
        for n, e, _ in a.get("pmTop") or []:
            pm[n] += e * dt * 5   # pmTop steht in jeder 5. Zeile
        for t in a.get("top") or []:
            top[t["name"]] += t["anteil"] * 15
    out = []
    gesamt = sum(x["s"] for x in app.values())
    if not gesamt:
        return "Keine verwertbaren Zeilen (zu wenige oder nur am Ladegerät).\n"
    ws = sum(x["ws"] for x in app.values())
    wS = sum(x["wS"] for x in app.values())
    out.append(f"Messzeit {gesamt / 3600:.2f} h (ohne Ladegerät), Lücken {luecken / 3600:.2f} h (Schlaf/aus), "
               f"Ø {ws / wS if wS else 0:.2f} W, Energie {ws / 3600:.2f} Wh, BlockEm {sum(x['cpu'] for x in app.values()) / gesamt:.1f} ms CPU je s\n")
    if handy:
        for k, txt in ((True, "Bildschirm an"), (False, "Bildschirm aus")):
            s, w = an_aus[k]
            if s:
                out.append(f"- {txt}: {s / 3600:.2f} h, Ø {w / s:.2f} W")
        akku = [(o["t"], o["akku"]) for o in zeilen if isinstance(o.get("akku"), int) and not o.get("laden")]
        if len(akku) > 1 and akku[-1][0] > akku[0][0]:
            h = (akku[-1][0] - akku[0][0]) / 3600
            out.append(f"- Akku {akku[0][1]} % → {akku[-1][1]} % in {h:.1f} h = {(akku[0][1] - akku[-1][1]) / h:.2f} %/h (Rechnung: Differenz / Stunden, inkl. Schlaf; Laden dazwischen verfälscht)")
        out.append("")
    out.append("| App (vorne) | Zeit min | Ø W | Wh | BlockEm CPU ms/s | Bild-KI/min | Bedienungshilfe-Ereign./s |")
    out.append("|---|---:|---:|---:|---:|---:|---:|")
    for n, x in sorted(app.items(), key=lambda kv: -kv[1]["ws"])[:20]:
        out.append(f"| {n} | {x['s'] / 60:.1f} | {x['ws'] / x['wS'] if x['wS'] else 0:.2f} | {x['ws'] / 3600:.3f} | {x['cpu'] / x['s']:.1f} | "
                   f"{x['bild'] / x['s'] * 60:.1f} | {x['ax'] / x['s']:.1f} |")
    mit, ohne = [w for _, w in bild_w[True]], [w for _, w in bild_w[False]]
    if len(mit) > 5 and len(ohne) > 5:
        out.append(f"\nBild-KI: Ø {statistics.mean(mit):.2f} W in Takten mit Prüfung ({len(mit)}), {statistics.mean(ohne):.2f} W ohne ({len(ohne)}). "
                   "Grober Hinweis, keine Ursache (Prüfungen kommen beim Scrollen, das selbst Strom kostet).")
    if teile:
        out.append("\n| BlockEm-Teil (Mac) | CPU s | ms je s Messzeit |\n|---|---:|---:|")
        for n, ms in teile.most_common(12):
            out.append(f"| {n} | {ms / 1000:.1f} | {ms / gesamt:.2f} |")
    if pm:
        out.append("\n| Prozess (powermetrics, Energie-Wirkung) | Anteil |\n|---|---:|")
        s = sum(pm.values())
        for n, e in pm.most_common(12):
            out.append(f"| {n} | {e / s * 100:.1f} % |")
    elif top:
        out.append("\n| Prozess (ps, CPU-Anteil am Mac) | Anteil der CPU-Zeit |\n|---|---:|")
        s = sum(top.values())
        for n, e in top.most_common(12):
            out.append(f"| {n} | {e / s * 100:.1f} % |")
    return "\n".join(out) + "\n"


def bericht(ordner, von="", bis="9"):
    teile = []
    for name, zeilen in sorted(lesen(ordner, von, bis).items()):
        teile.append(f"## {name} ({len(zeilen)} Zeilen)\n\n" + auswerten(zeilen, name.startswith("handy-")))
    return "\n".join(teile) or "Keine Messdateien gefunden.\n"


def _test():
    import tempfile
    d = Path(tempfile.mkdtemp())
    t0 = 1764072000000
    z = []
    for i in range(100):   # 200 s YouTube mit 2 W, dann 60 s Pause (Schlaf), dann 100 s Chrome mit 1 W
        z.append({"t": t0 + i * 2000, "w": 2.0, "akku": 80, "laden": False, "an": True, "app": "com.google.android.youtube", "cpuMs": 20, "bild": 1, "ax": 4})
    for i in range(50):
        z.append({"t": t0 + 260000 + i * 2000, "w": 1.0, "akku": 79, "laden": False, "an": True, "app": "com.android.chrome", "cpuMs": 10, "bild": 0, "ax": 2})
    (d / "handy-Pixel-2025-11-25.jsonl").write_text("\n".join(json.dumps(o) for o in z) + "\nkaputt\n")
    r = bericht(d)
    assert "| com.google.android.youtube | 3.3 | 2.00 | 0.110 | 10.0 | 30.0 | 2.0 |" in r, r   # 99 Takte × 2 s = 198 s
    assert "| com.android.chrome | 1.6 | 1.00 | 0.027 | 5.0 | 0.0 | 1.0 |" in r, r          # 49 × 2 s = 98 s
    assert "Lücken 0.02 h" in r, r                                                             # 62 s Abstand
    print("Test ok")


if __name__ == "__main__":
    a = sys.argv[1:]
    if a[:1] == ["--test"]:
        _test()
    else:
        kw = {k[2:]: a[a.index(k) + 1] for k in ("--von", "--bis") if k in a}
        print(bericht(a[0], **kw))

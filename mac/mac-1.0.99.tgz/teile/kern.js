/* ---------- BlockEm Kern (19.11.2026, john: „Redesign Kern in die App einbauen“) ----------
   Eine Oberfläche für Handy, Tablet, Mac und Windows nach der Designübergabe im Vault (BlockEm Kern – Designübergabe).
   Liegt als letzte Teildatei über der alten Oberfläche: Daten, Regeln und Sperrlogik bleiben unverändert (api/*, CockpitApp-Brücke),
   gezeichnet wird nur neu. Ältere Detailseiten (Konto & Sync, Systemcheck, Datenschutz) öffnen in der alten Ansicht mit „‹ BlockEm“.
   Bauteile/Klassen aus der Galerie (kern-basis.css), Piktogramme aus kern-icons.js. */
const K = {fehlt:{}, tagFehlt:{}, v:"today", zurueck:[], tr:null, lk:null, fk:null, day:null, week:null, rb:{}, tage:{}, info:null, gm:null, fehler:"", hinweis:"",
  laedt:{}, zeit:{}, periode:store("kern.werte") || "Heute", geraet:store("kern.geraet") || "", wTag:6, rbArt:"woche", rbVersatz:0,
  fokusMin:+(store("cockpit.fokusMin") || 60), fokusArt:store("kern.fokusArt") || "Social", fokusApps:store("kern.fokusApps") || [],
  fokusGeraete:store("kern.fokusGeraete") || "dieses", tick:0, wahl:null, regel:null, bindung:null, offline:false, panik:null};
const K_ICON = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" rx="23" fill="#231D1C"/><path d="m18 31 30-14 36 12-5 43-28 13-34-15z" fill="#D94336"/><path d="m18 31 30-14-4 55-27-2z" fill="#F07458"/><path d="m44 72 35 0-28 13-34-15z" fill="#7D2D2A"/><path d="m48 17 36 12-21 16-19-11z" fill="#F3A77D"/><path d="m33 49 8-6 8 6-8 6z" fill="#2D1B1A"/><circle cx="64" cy="49" r="6" fill="#2D1B1A"/></svg>');
const K_NAV = [["today","Heute",'<circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/>'], ["focus","Fokus",'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/>'],
  ["lock","Sperre",'<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>'], ["values","Werte",'<path d="M4 20V12m5 8V7m5 13v-5m5 5V4"/>'],
  ["journey","Weg",'<path d="M4 19c2-4 5-5 8-7s4-4 8-7M16 5h4v4"/>']];
// Unterseite → Hauptbereich (für die Navigation und den Zurück-Pfeil)
const K_ELTERN = {attempts:"today", limitsHeute:"today", panic:"today", focusApps:"focus", focusDevices:"focus", active:"focus", result:"focus",
  protection:"lock", devices:"lock", schedule:"lock", timeRule:"lock", limits:"lock", limitEdit:"lock", groups:"lock", groupEdit:"lock", binding:"lock",
  newBinding:"lock", shorts:"lock", schutzDetail:"lock", permissions:"lock", uninstall:"lock", picker:"", dayDetail:"values", valuesWeek:"values",
  valuesReview:"values", gifts:"journey", colors:"journey", why:"journey", donations:"journey", community:"journey", badges:"journey",
  settings:"", profile:"settings", appearance:"settings", notifications:"settings", export:"settings", pro:"settings", trusted:"settings"};
const K_TITEL = {attempts:"Abgeblockte Versuche", limitsHeute:"Tageslimits", panic:"Panik", focusApps:"Apps wählen", focusDevices:"Fokus-Geräte", active:"Fokus läuft",
  result:"Fokus beendet", protection:"Schutz", devices:"Geräte", schedule:"Sperrzeiten", timeRule:"Sperrzeit", limits:"Tageslimits", limitEdit:"Tageslimit",
  groups:"Gruppen", groupEdit:"Gruppe", binding:"Feste Sperren", newBinding:"Feste Sperre anlegen", shorts:"Kurzvideos", schutzDetail:"Schutz",
  permissions:"Berechtigungen", uninstall:"Deinstallationsschutz", picker:"Apps wählen", dayDetail:"Wochentag", valuesWeek:"Woche", valuesReview:"Rückblick",
  gifts:"Geschenke", colors:"Farbe der App", why:"Dein Warum", donations:"Spenden", community:"Gemeinsam", badges:"Abzeichen", settings:"Einstellungen",
  profile:"Profil", appearance:"Aussehen", notifications:"Mitteilungen", export:"Daten & Export", pro:"BlockEm Pro", trusted:"Vertrauensperson"};
const K_TAGE = ["Mo","Di","Mi","Do","Fr","Sa","So"];
const K_WEB = ["youtube.com","instagram.com","tiktok.com","reddit.com","x.com","facebook.com","twitch.tv","netflix.com","pinterest.com"];
const K_GRUPPEN_STD = {   // Galerie-Katalog: Gruppen der bekannten Apps (ergänzt die Listen vom Server)
  Social:"Instagram|TikTok|Facebook|Reddit|Threads|Snapchat|Pinterest|Bluesky|Tumblr|Mastodon|LinkedIn|BeReal|Discord|Telegram|WhatsApp|Signal|Messenger|X",
  Streaming:"YouTube|Netflix|Spotify|Twitch|Disney+|Prime Video|Apple TV|WOW|DAZN|Deezer|SoundCloud|Vimeo|Crunchyroll|Plex|Arte|ZDFmediathek",
  Spiele:"Minecraft|Roblox|Pokémon GO|Clash Royale|Clash of Clans|Brawl Stars|Among Us|Subway Surfers|Candy Crush|Monument Valley|Stardew Valley|Chess.com|UNO|Hay Day|Wordfeud|Geometry Dash"};

/* ---------- kleine Helfer ---------- */
const kEsc = v => String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const kSicher = u => /^https:\/\/[^\s"'<>]+$/i.test(String(u || ""));   // Belege nur als echte https-Adresse verlinken
const kLow = s => String(s || "").toLocaleLowerCase("de");
function kHm(sek){ const m = Math.round((sek || 0) / 60); return m < 60 ? `${m} Min` : `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}`; }
function kStd(sek){ const m = Math.round((sek || 0) / 60); return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, "0")}`; }
function kUhr(d){ return d.toLocaleTimeString("de-DE", {hour:"2-digit", minute:"2-digit"}); }
function kDatum(d, wd = true){ return d.toLocaleDateString("de-DE", wd ? {weekday:"long", day:"numeric", month:"long"} : {day:"numeric", month:"long"}); }
function kIso(d){ return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; }
function kZeitpunkt(ms){   // „heute, 18:00 Uhr“ / „morgen, 06:30 Uhr“ / „Freitag, 18:00 Uhr“ / „28.11., 09:00 Uhr“
  const d = new Date(ms), h = new Date(); h.setHours(0, 0, 0, 0); const t = Math.round((new Date(d).setHours(0, 0, 0, 0) - h) / 864e5);
  const tag = t === 0 ? "heute" : t === 1 ? "morgen" : t > 1 && t < 7 ? d.toLocaleDateString("de-DE", {weekday:"long"}) : d.toLocaleDateString("de-DE", {day:"2-digit", month:"2-digit"}) + (SPRACHE === "de" ? "." : "");
  return `${tag.replace(/\.\.$/, ".")}, ${kUhr(d)} Uhr`;
}
const kMain = (eyebrow, title, body, intro = "") => `<div class="detail-view"><div class="page-title"><div class="overline">${eyebrow}</div><h2>${title}</h2>${intro ? `<p>${intro}</p>` : ""}</div>${body}</div>`;
const kSection = (title, content, note = "") => `<section class="sub-section"><div class="section-head"><h3>${title}</h3>${note ? `<span>${note}</span>` : ""}</div>${content}</section>`;
const kJump = (title, sub, to, glyph = "◈", extra = "") => `<button class="sub-row" data-k="${to}" ${extra}><span class="sub-glyph">${glyph}</span><span class="sub-text"><b>${kEsc(title)}</b><small>${kEsc(sub)}</small></span><span class="sub-chevron">›</span></button>`;
const kNote = (label, body, cls = "") => `<div class="detail-note ${cls}"><b>${label}</b><p>${body}</p></div>`;
const kChip = (label, on, attrs) => `<button class="sub-chip ${on ? "selected" : ""}" aria-pressed="${!!on}" ${attrs}>${label}</button>`;
const kFigur = (cls = "") => `<img class="${cls}" src="${K_ICON}" alt="BlockEm">`;
function kGeraetHier(){   // Name dieses Geräts, wie der Server ihn kennt
  try { if (window.CockpitApp?.geraet) return CockpitApp.geraet() || "Handy"; } catch {}
  return "Mac";   // der Server nennt den Computer immer „Mac“ (geraete_namen, locker_sperre), auch unter Windows
}
const kGeraetText = g => g === "Mac" && !window.CockpitApp && /Win/.test(navigator.platform) ? "Windows-PC" : g;
function kPlattform(){
  const breit = Math.min(screen.width, screen.height) >= 600 && innerWidth >= 700;
  if (window.CockpitApp) return breit ? "Tablet" : "Handy";
  if (innerWidth < 700) return "Handy";
  if (/iPad/.test(navigator.userAgent) || (navigator.maxTouchPoints > 1 && /Mac/.test(navigator.platform) && innerWidth < 1100)) return "Tablet";
  return /Win/.test(navigator.platform) ? "Windows" : "Mac";
}
function kThema(){
  const t = store("kern.thema") || "System", dunkel = t === "Dunkel" || (t === "System" && matchMedia("(prefers-color-scheme: dark)").matches);
  const h = document.documentElement; h.classList.add("kern"); h.classList.toggle("k-dark", dunkel); h.dataset.theme = dunkel ? "dark" : "light";
  const s = kStilAktiv(); ["ozean","smaragd","gold","rose"].forEach(k => h.classList.toggle("k-" + k, s === k));
  document.body.dataset.platform = kPlattform(); kMassstab();
  const bg = getComputedStyle(h).getPropertyValue("--bg").trim() || (dunkel ? "#1b1918" : "#f1ece7");
  document.querySelector('meta[name="theme-color"]')?.setAttribute("content", bg);
  try { window.CockpitApp?.farbe?.(bg, !dunkel); } catch {}
}
// john 20.11.: „die App muss sich an jeden Handy-Bildschirm automatisch anpassen“. Die Galerie zeichnet das Handy 312 pt breit;
// auf echten Handys (360–480 pt) wachsen alle Kern-Maße im selben Verhältnis mit (kern-mass.py → calc(Npx*var(--k))), Tablet/Computer bleiben 1:1.
function kMassstab(){
  const b = Math.min(innerWidth || 312, screen.width || 9999, screen.height || 9999);
  const beruehrung = !!window.CockpitApp || matchMedia("(pointer: coarse)").matches;   // schmales Fenster am Computer bleibt 1:1
  const k = document.body.dataset.platform === "Handy" && beruehrung ? Math.min(1.6, Math.max(1, b / 312)) : 1;
  document.documentElement.style.setProperty("--k", k.toFixed(4));
}
function kStilAktiv(){ const w = store("stil.wahl"); const s = typeof STILE !== "undefined" && STILE.find(x => x.k === w); return s && s.ab <= (store("stil.max") || 0) ? s.k : "orange"; }

/* ---------- Daten (dieselben Endpunkte wie bisher; nichts Neues auf dem Server) ---------- */
async function kHole(name, pfad, maxAlter = 30000){
  if (K.laedt[name] || Date.now() - (K.zeit[name] || 0) < maxAlter) return K[name];
  K.laedt[name] = true;
  try { K[name] = await api(pfad); K.zeit[name] = Date.now(); K.offline = !!(typeof VB !== "undefined" && VB.offline); K.fehlt[name] = ""; }
  catch (e){ K.fehler = e.message || String(e); K.offline = true; K.zeit[name] = Date.now(); K.fehlt[name] = K.fehler; }   // Zeit merken: sonst fragt jedes Neuzeichnen sofort wieder
  finally { K.laedt[name] = false; }
  return K[name];
}
async function kLaden(alles){
  const t = alles ? 0 : 30000;
  await Promise.all([kHole("tr", "api/tracking", t), kHole("lk", "api/locker", t), kHole("fk", "api/fokus", t), kHole("day", "api/today", t)]);
  if (S?.plan) K.plan = S.plan; else await kHole("plan", "api/plan", t);
  if (K.lk && typeof GU !== "undefined"){ GU.lk = K.lk; GU.geladen = Date.now(); }
  if (K.tr && typeof TR !== "undefined"){ TR.daten = K.tr; }
  if (K.fk && typeof FK !== "undefined"){ FK.data = K.fk; }
  if (K.tr?.sauber && (K.tr.sauber.tage || 0) > (store("stil.max") || 0)) store("stil.max", K.tr.sauber.tage);
  kZeichnen();
}
const kSperre = () => (K.plan || S?.plan)?.automatik?.sperre || {};
const kKat = () => K.tr?.kategorien || {social:[], streaming:[]};
function kSpiele(){
  let a = []; try { a = JSON.parse(window.CockpitApp?.spiele?.() || "[]"); } catch {}
  const r = (K.lk?.regeln || []).filter(x => /spiel/i.test(x.gruppe || "")).flatMap(x => x.apps);
  return [...new Set([...a, ...r])];
}
function kInstalliert(){ try { return JSON.parse(window.CockpitApp?.apps?.() || "[]"); } catch { return []; } }

/* ---------- Rahmen ---------- */
function kRahmen(){
  if (document.getElementById("kern")) return;
  const k = el("div"); k.id = "kern"; document.body.append(k);
  const bar = el("div"); bar.id = "kernAltBar"; bar.innerHTML = '<button type="button" class="back" data-k-alt-zu aria-label="Zurück"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></button><span>BlockEm / <span id="kernAltTitel"></span></span>';   // 21.11.: wie der Kern-Kopf
  document.body.prepend(bar);
  document.addEventListener("click", kKlick, true);
  document.addEventListener("input", kEingabe);
  document.addEventListener("change", kAenderung);
  addEventListener("resize", () => { const p = kPlattform(); kMassstab(); if (document.body.dataset.platform !== p){ document.body.dataset.platform = p; kMassstab(); kZeichnen(); } });
  matchMedia("(prefers-color-scheme: dark)").addEventListener?.("change", () => { kThema(); });
  addEventListener("popstate", () => { const h = location.hash.match(/^#k\/(\w+)/); if (h && h[1] !== K.v){ K.v = h[1]; kZeichnen(); } });
}
function kNav(){
  const aktiv = K_NAV.some(([id]) => id === K.v) ? K.v : (K_ELTERN[K.v] && K_NAV.some(([id]) => id === K_ELTERN[K.v]) ? K_ELTERN[K.v] : (K.zurueck.find(v => K_NAV.some(([id]) => id === v)) || ""));
  return `<nav class="bottom" aria-label="Hauptnavigation">${K_NAV.map(([id, t, ic]) => `<button type="button" data-k-nav="${id}" class="${aktiv === id ? "selected" : ""}" aria-current="${aktiv === id ? "page" : "false"}"><svg viewBox="0 0 24 24" aria-hidden="true">${ic}</svg><span>${t}</span></button>`).join("")}</nav>`;
}
function kKopf(){
  const unter = !K_NAV.some(([id]) => id === K.v), titel = K.v === "limitEdit" && K.limit?.art && K.limit.art !== "limit" ? ({sitzung:"Am Stück", oeffnen:"Öffnen"})[K.limit.art] || "Tageslimit" : K_TITEL[K.v];   // 24.11.: „am Stück“ nutzt den Limit-Editor
  const zur = unter ? `<button class="back" type="button" data-k-zurueck aria-label="Zurück"><svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg></button>` : kFigur();
  return `<header class="app-head"><div class="brand">${zur}<span>${unter && titel ? "BlockEm / " + titel : "BlockEm"}</span></div><button class="menu" type="button" data-k="settings" aria-label="Einstellungen"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v.1a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button></header>`;
}
function kBaender(){   // Fehlerfälle oben: offline, fehlende Rechte, Abgleich
  const b = [];
  if (K.offline) b.push(`<div class="k-band warn" role="status"><span><b>Keine Verbindung</b>Du siehst den letzten Stand. Regeln und Sperren wirken auf dem Gerät weiter.</span><button type="button" data-k-neu>Erneut versuchen</button></div>`);
  if (window.CockpitApp?.rechte && ["today","lock","focus"].includes(K.v)){
    const r = handyRechte(), fehlt = [!r.nutzung && "Nutzungsdaten", !r.sperre && "Bedienungshilfe"].filter(Boolean);
    if (fehlt.length) b.push(`<div class="k-band warn" role="status"><span><b>Berechtigung fehlt: ${fehlt.join(", ")}</b>Ohne sie kann BlockEm nichts sperren oder messen.</span><button type="button" data-k="permissions">Ansehen</button></div>`);
  }
  return b.join("");
}
function kZeichnen(){
  const k = document.getElementById("kern"); if (!k) return;
  if (K.lk?.geplant && window.CockpitApp?.lockerGeplant){   // 24.11.: Handy meldet „Lockerung gilt jetzt“ (Wecker in Momente.java); auch gerade erledigte, sonst geht die Meldung verloren, wenn die App erst danach öffnet
    const g = JSON.stringify([...Object.values(K.lk.geplant), ...Object.values(K.lk.geplantFertig || {})].map(x => ({ab:Math.round(x.ab * 1000), satz:x.satz})));
    if (g !== K.geplantGesendet){ K.geplantGesendet = g; try { CockpitApp.lockerGeplant(g); } catch {} } }
  const f = K_SEITEN[K.v] || K_SEITEN.today; let inhalt;
  try { inhalt = f(); } catch (e){ console.error(e); inhalt = kMain("BLOCKEM", "Das ging gerade nicht", `<p class="k-fehler">${kEsc(e.message || e)}</p><button class="action" data-k-nav="today">Zu Heute</button>`); }
  const s = k.querySelector(".screen"), y = s && s.dataset.v === K.v ? s.scrollTop : 0;
  const fokus = document.activeElement?.closest?.("#kern") && document.activeElement.dataset.kFeld ? [document.activeElement.dataset.kFeld, document.activeElement.selectionStart] : null;
  k.innerHTML = kKopf() + `<main class="screen" data-v="${K.v}" data-bereich="${K_ELTERN[K.v] || K.v}">${kBaender()}${inhalt}</main>` + kNav();
  k.querySelector(".screen").scrollTop = y;
  // Monat: beim ersten Öffnen die letzten Tage zeigen, danach die Wischposition behalten (Neuzeichnen setzt sie sonst auf den 1.)
  k.querySelectorAll(".trend.monat").forEach(t => { const sc = t.parentElement, key = K.rbArt + K.rbVersatz; sc.scrollLeft = K.rbWisch?.[key] ?? sc.scrollWidth;
    sc.addEventListener("scroll", () => { (K.rbWisch ||= {})[key] = sc.scrollLeft; }, {passive:true}); });
  if (fokus){ const f2 = k.querySelector(`[data-k-feld="${fokus[0]}"]`); if (f2){ f2.focus(); try { f2.setSelectionRange(fokus[1], fokus[1]); } catch {} } }
  clearInterval(K.tick); if (K.v === "active" || K.v === "panic") K.tick = setInterval(kTick, 1000);
}
function kGeh(v, ohneVerlauf){
  if (!K_SEITEN[v]) return;
  (K.pos ||= {})[K.v] = document.querySelector("#kern .screen")?.scrollTop || 0;   // Scrollposition für den Schritt zurück
  if (!ohneVerlauf && v !== K.v){ if (K_NAV.some(([id]) => id === v)) K.zurueck = []; else K.zurueck.push(K.v); }
  K.v = v; K.hinweis = "";
  try { history.replaceState(null, "", "#k/" + v); } catch {}
  kZeichnen(); document.querySelector("#kern .screen")?.scrollTo(0, 0);
}
function kZurueck(){ const v = K.zurueck.pop() || K_ELTERN[K.v] || "today"; K.v = v; K.hinweis = "";
  try { history.replaceState(null, "", "#k/" + v); } catch {}
  kZeichnen(); const s = document.querySelector("#kern .screen"); if (s) s.scrollTop = K.pos?.[v] || 0; }
// Android-Zurück (Geste/Taste, MainActivity.zurueck): erst offene Blätter, dann eine Seite zurück, dann zu Heute. false = oberste Ebene (App darf gehen).
function kSystemZurueck(){
  const offen = [...document.querySelectorAll("dialog[open]")], oben = document.elementFromPoint(innerWidth / 2, innerHeight / 2)?.closest?.("dialog[open]");
  const d = oben || offen.pop();   // oberstes Blatt zuerst (Blätter werden wiederverwendet, die Reihenfolge im Dokument sagt nichts)
  if (d){ const ev = new Event("cancel", {cancelable:true}); d.dispatchEvent(ev); if (!ev.defaultPrevented && d.open) d.close(); return true; }
  if (document.documentElement.classList.contains("kern-alt")){ document.documentElement.classList.remove("kern-alt"); kLaden(true); return true; }
  if (store("kern.aus") === true || !document.getElementById("kern")) return null;   // alte Oberfläche: Android nimmt den WebView-Verlauf
  if (K.v === "picker" && K.wahl?.menue){ K.wahl.menue = false; kZeichnen(); return true; }
  if (K.v === "picker" && K.wahl){ kWahlFertig(false); return true; }
  if (K.zurueck.length || !K_NAV.some(([id]) => id === K.v)){ kZurueck(); return true; }
  if (K.v !== "today"){ kGeh("today"); return true; }
  return false;
}
function kAlt(titel, oeffnen){   // ältere Detailseite in der bisherigen Oberfläche
  document.documentElement.classList.add("kern-alt"); const t = document.getElementById("kernAltTitel"); if (t) t.textContent = titel;
  try { oeffnen(); } catch (e){ toast(e.message || String(e)); }
  scrollTo(0, 0);
}
async function kPost(pfad, body, okText){
  try { const r = await api(pfad, body); if (okText) toast(okText); return r; }
  catch (e){ K.hinweis = e.message || String(e); kZeichnen(); return null; }
}

/* ---------- Heute ---------- */
function kNaechstesGeschenk(){
  const tage = K.tr?.sauber?.tage || 0, max = Math.max(+(store("stil.max") || 0), tage);
  const s = (typeof STILE !== "undefined" ? STILE : []).find(x => x.ab > max);
  return s ? {name:s.t, tag:s.ab, noch:s.ab - tage} : null;
}
function kLimits(){
  const tag = (new Date().getDay() + 6) % 7, regeln = (K.lk?.regeln || []).filter(r => r.art === "limit" && +r.minuten > 0 && (!r.tage || r.tage.includes(tag)));
  return regeln.map(r => ({r, name:r.gruppe || r.apps[0], apps:r.apps, ist:Math.round(r.verbraucht || 0), max:+r.minuten, zu:!!r.gesperrt}))
    .sort((a, b) => b.ist / b.max - a.ist / a.max);
}
function kToday(){
  const s = K.tr?.sauber || {}, tage = s.tage || 0, sum = K.day?.summe, g = kNaechstesGeschenk(), lim = kLimits();
  const woche = tage % 7 || (tage ? 7 : 0);
  return `<div class="today today-clean">
   <div class="hero"><div><div class="overline">HEUTE · ${kDatum(new Date(), false).toUpperCase()}</div><h2>Tag ${tage}</h2>${g ? `<button class="mini-gift" data-k="colors">✦ Geschenk in ${g.noch} ${g.noch === 1 ? "Tag" : "Tagen"} <span>›</span></button>` : ""}${!tage && s.gesamt ? `<p class="small">Insgesamt ${s.gesamt} saubere Tage</p>` : ""}</div><div class="facet">${kFigur()}</div></div>
   <div class="dayline" role="img" aria-label="${woche} von 7 Tagen">${Array.from({length:7}, (_, i) => `<i class="${i < woche ? "done" : ""}"></i>`).join("")}</div>
   <div class="metrics"><div class="metric"><b>${sum ? kHm(sum.produktiv) : "–"}</b><small>produktiv</small></div><div class="metric"><b>${sum ? kHm(sum.prokrastination) : "–"}</b><small>Ablenkung</small></div></div>
   ${kUpdateKann() && kUpdateNeu() ? `<button class="attempt-line k-upd-da" data-k-update><span>Update ${kEsc(kUpdateNeu())} ist da · jetzt installieren</span><span>›</span></button>` : kPlayUpdHeute()}
   <button class="panic-btn" data-k-panik><span>Panik-Knopf</span></button>
   <section class="free-flat"><div class="section-head"><h3>Noch frei heute</h3><button class="text-link" data-k="limits">Limits ›</button></div>
    ${lim.slice(0, 4).map(x => `<button class="free-line" data-k-limit="${kEsc(x.r.id)}">${kernIcon(x.apps[0])}<span>${kEsc(x.name)}</span><b>${x.zu || x.ist >= x.max ? "aufgebraucht" : Math.max(0, x.max - x.ist) + " Min"}</b></button>`).join("") || `<button class="free-line free-leer" data-k-limit="neu"><span>Noch keine Tageslimits</span><b>Limit anlegen ›</b></button>`}
   </section>
   <button class="attempt-line" data-k="attempts"><span>${s.heute || 0} ${s.heute === 1 ? "Versuch" : "Versuche"} heute abgeblockt</span><span>›</span></button>
  </div>`;
}
function kAttempts(){
  const s = K.tr?.sauber || {}, p = K.tr?.panik || {};
  return kMain("HEUTE", "Abgeblockte Versuche", `<div class="k-sum"><div><small>Heute</small><b>${s.heute || 0}</b></div><div><small>Diese Woche</small><b>${s.woche || 0}</b></div><div><small>Vorwoche</small><b>${s.vorwoche || 0}</b></div></div>`
    + kSection("Panik-Knopf", `<div class="k-sum"><div><small>Diese Woche</small><b>${p.woche || 0}×</b></div><div><small>davon geschafft</small><b>${p.wocheGeschafft || 0}</b></div><div><small>insgesamt geschafft</small><b>${p.gesamtGeschafft || 0}</b></div></div>`)
    + kNote("Saubere Tage", `${s.tage || 0} am Stück · ${s.gesamt || 0} insgesamt · bester Lauf ${s.beste || 0}`));
}
function kPanik(){
  const w = store("tue.warum");
  const p = K.panik || {start:Date.now()}, rest = Math.max(0, 120 - Math.floor((Date.now() - p.start) / 1000));
  return `<div class="panic-screen"><div class="page-title"><div class="overline">PANIK-KNOPF</div><h2>Der Drang geht vorbei.</h2><p>Zwei Minuten atmen. Danach kurz rausgehen.</p></div>
   <div class="breath"><b id="kPanikUhr">${String(Math.floor(rest / 60)).padStart(2, "0")}:${String(rest % 60).padStart(2, "0")}</b></div>
   <p class="small" id="kPanikAtem">${rest ? (Math.floor((120 - rest) / 5) % 2 ? "langsam ausatmen …" : "einatmen …") : "Geschafft. Der Drang ist kleiner geworden."}</p>
   ${w ? `<p class="small">Dein Satz: „${kEsc(w)}“</p>` : ""}
   <div class="binding-card"><h3>10 Minuten Schutz</h3><p>${p.fokus === false ? "Ein Fokus läuft schon, die Ablenker bleiben bis zu seinem Ende gesperrt." : "Die Ablenker bleiben auch dann gesperrt, wenn du diese Ansicht schließt."}</p></div>
   <button class="action" data-k-panik-fertig>${rest ? "Zurück zu Heute" : "Geschafft, der Drang ist weg"}</button></div>`;
}
async function kPanikBreit(){   // Prüfer 19.11.: sonst gilt der Panik-Schutz nur für die zuletzt gewählte Fokus-Auswahl
  try { const sp = kSperre(), alle = [...new Set([...(sp.kandidaten || []), ...(kKat().social || []), ...(kKat().streaming || []), ...kSpiele()])];
    if (alle.length) await api("api/sperre", {liste:alle, an:true});
    if ((sp.gilt || []).length) await api("api/sperre", {geraete:[]});
    const pl = K.plan || S?.plan; if (!pl?.automatik?.schalter || pl.automatik.schalter.sperre === false) await api("api/automatik", {schalter:{sperre:true}});
  } catch {}
}
async function kPanikStart(){
  if (window.CockpitApp?.panik){ await kPanikBreit(); trPanik(); return; }   // Handy: eigene Vollbild-Ansicht (Panik.java) inkl. 10 Min Fokus über runde4-Hülle
  K.panik = {start:Date.now()}; kGeh("panic");
  api("api/panik", {was:"gedrückt"}).then(r => { if (r?.panik && K.tr) K.tr.panik = r.panik; }).catch(() => {});
  await kPanikBreit();
  try { await api("api/fokus", {aktion:"start", minuten:10, aufgabe:"Panik-Knopf"}); K.zeit.fk = 0; kHole("fk", "api/fokus"); }
  catch { K.panik.fokus = false; kZeichnen(); }
}
function kTick(){
  if (K.v === "panic"){
    const rest = Math.max(0, 120 - Math.floor((Date.now() - (K.panik?.start || Date.now())) / 1000)), u = document.getElementById("kPanikUhr");
    if (u) u.textContent = `${String(Math.floor(rest / 60)).padStart(2, "0")}:${String(rest % 60).padStart(2, "0")}`;
    const a = document.getElementById("kPanikAtem"); if (a) a.textContent = rest ? (Math.floor((120 - rest) / 5) % 2 ? "langsam ausatmen …" : "einatmen …") : "Geschafft. Der Drang ist kleiner geworden.";
    if (!rest){ clearInterval(K.tick); kZeichnen(); }
    return;
  }
  const a = K.fk?.aktiv; if (!a) return;
  const rest = Math.max(0, Math.round((new Date(a.planEnde) - Date.now()) / 1000)), u = document.getElementById("kFokusUhr");
  if (u) u.textContent = `${String(Math.floor(rest / 60)).padStart(2, "0")}:${String(rest % 60).padStart(2, "0")}`;
  const t = document.getElementById("kFokusTrack"); if (t) t.style.width = Math.min(100, 100 * (1 - rest / (a.minuten * 60))) + "%";
  if (!rest){ clearInterval(K.tick); setTimeout(async () => { K.zeit.fk = 0; await kHole("fk", "api/fokus"); kGeh("result", true); }, 1500); }
}

/* ---------- Fokus ---------- */
// 25.11. (john): Social, Streaming und Spiele frei kombinierbar (z. B. Streaming + Spiele, Social bleibt offen); gespeichert als „Streaming+Spiele“
const K_FOKUS_KAT = ["Social","Streaming","Spiele"];
const kFokusArten = (art = K.fokusArt) => String(art || "").split("+").filter(x => K_FOKUS_KAT.includes(x));
const kFokusWas = () => K.fokusArt === "Alles" || K.fokusArt === "Apps" ? K.fokusArt : kFokusArten().join(", ");
function kFokusListe(art = K.fokusArt){
  const kat = kKat(), sp = kSperre();
  if (art === "Apps") return K.fokusApps;
  if (art !== "Alles") return [...new Set(kFokusArten(art).flatMap(t => t === "Social" ? kat.social || [] : t === "Streaming" ? kat.streaming || [] : kSpiele()))];
  return [...new Set([...(sp.kandidaten || []), ...(kat.social || []), ...(kat.streaming || []), ...kSpiele(), ...(sp.an || [])])];
}
function kFokusGeraeteText(){
  const g = K.fokusGeraete; if (g === "alle") return "Alle Geräte"; if (g === "dieses") return window.CockpitApp ? "Dieses Handy" : "Dieser Computer";
  return (Array.isArray(g) ? g : []).join(", ") || "Alle Geräte";
}
function kFocus(){
  if (K.fk?.aktiv) return kActive();
  const m = K.fokusMin, ende = new Date(Date.now() + m * 60000), liste = kFokusListe();
  const quick = [25, 45, 60, 90].map(n => `<button data-k-min="${n}" class="${m === n ? "sel" : ""}" aria-pressed="${m === n}">${n}</button>`).join("");
  const arten = [["Alles","Alles"],["Social","Social"],["Streaming","Streaming"],["Spiele","Spiele"]].map(([k, t]) => `<button data-k-art="${k}" class="${(k === "Alles" ? K.fokusArt === k : kFokusArten().includes(k)) ? "sel" : ""}" aria-pressed="${k === "Alles" ? K.fokusArt === k : kFokusArten().includes(k)}">${t}</button>`).join("")
    + `<button data-k-wahl="focus" class="${K.fokusArt === "Apps" ? "sel" : ""}" aria-pressed="${K.fokusArt === "Apps"}">${K.fokusArt === "Apps" ? K.fokusApps.length + " Apps" : "Apps wählen"}</button>`;
  const ger = [["dieses", window.CockpitApp ? "Dieses Handy" : "Dieser Computer"],["alle","Alle Geräte"]].map(([k, t]) => `<button data-k-ger="${k}" class="${K.fokusGeraete === k ? "sel" : ""}" aria-pressed="${K.fokusGeraete === k}">${t}</button>`).join("")
    + `<button data-k="focusDevices" class="${Array.isArray(K.fokusGeraete) ? "sel" : ""}">Geräte wählen</button>`;
  const lauf = K.lk?.fokus;
  return `<div class="focus"><div class="focus-head"><div><div class="overline">JETZT EINE SACHE</div><h2>Fokus</h2></div>${kFigur()}</div>
   <div class="field"><span class="field-label">Dauer · Minuten</span><div class="quick">${quick}</div><label class="custom-minutes"><span>Oder selbst einstellen</span><input type="number" class="minute-input" data-k-feld="min" min="5" max="240" step="5" value="${m}" aria-label="Fokusdauer in Minuten"><b>Min</b></label></div>
   <div class="field"><span class="field-label">Was wird gesperrt?</span><div class="seg">${arten}</div></div>
   <div class="field"><span class="field-label">Auf welchem Gerät?</span><div class="seg">${ger}</div></div>
   ${K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>` : ""}
   <button class="action full" data-k-fokus-start ${!liste.length || lauf ? "disabled" : ""}>Fokus für ${m} Min starten</button>
   <p class="focus-note">${liste.length ? `Verbindlich bis ${kUhr(ende)} Uhr · ${K.fokusArt === "Apps" ? liste.length + " Apps" : kFokusWas()} · ${kFokusGeraeteText()}` : "Wähle mindestens eine App."}</p>
   ${K.fk?.sessions?.length ? `<button class="taprow" data-k="result"><b>Letzte Sitzung</b><small>${kEsc(kSitzungText(K.fk.sessions[0]))}</small></button>` : ""}
  </div>`;
}
function kSitzungText(s){ const e = s?.ergebnis || {}; return `${Math.round((e.dauer || 0) / 60)} Min · ${e.anzahl || 0} Ablenkungen · ${e.fokus ?? 0} % Fokus`; }
function kFocusDevices(){
  const alle = [...new Set([...(kSperre().alleGeraete || []), ...(K.lk?.geraete || []), kGeraetHier()])], wahl = new Set(Array.isArray(K.fokusGeraete) ? K.fokusGeraete : []);
  return kMain("FOKUS", "Geräte wählen", `<div class="catalog-list">${alle.map(g => `<button class="catalog-item" data-k-fger="${kEsc(g)}" aria-pressed="${wahl.has(g)}">${kernIcon(/mac|pc|windows|computer/i.test(g) ? "Browser" : "Notizen")}<span>${kEsc(kGeraetText(g))}${g === kGeraetHier() ? " · dieses Gerät" : ""}</span><b>${wahl.has(g) ? "✓" : "＋"}</b></button>`).join("")}</div>
   <div class="k-tools"><button class="sub-chip" data-k-zurueck>Abbrechen</button><button class="action" data-k-fger-ok ${wahl.size ? "" : "disabled"}>${wahl.size} übernehmen</button></div>`, "Die Fokus-Sperre gilt nur auf den gewählten Geräten.");
}
async function kFokusStarten(){
  const ziel = kFokusListe(), sp = kSperre(), an = sp.an || [], zielKl = new Set(ziel.map(kLow));
  if (!ziel.length) return;
  const geraete = K.fokusGeraete === "alle" ? [] : K.fokusGeraete === "dieses" ? [kGeraetHier()] : K.fokusGeraete;
  K.hinweis = "";
  try {
    const weg = an.filter(x => !zielKl.has(kLow(x)));
    if (weg.length) await api("api/sperre", {liste:weg, an:false});
    await api("api/sperre", {liste:ziel, an:true});
    await api("api/sperre", {geraete});
    const pl = K.plan || S?.plan; if (!pl?.automatik?.schalter || pl.automatik.schalter.sperre === false) await api("api/automatik", {schalter:{sperre:true}});
    K.fk = await api("api/fokus", {aktion:"start", minuten:K.fokusMin}); K.zeit.fk = Date.now();
    if (typeof FK !== "undefined") FK.data = K.fk;
    try { S.plan = await api("api/plan"); K.plan = S.plan; } catch {}
    try { if (typeof vbSperreAbgleich === "function") vbSperreAbgleich(); } catch {}
    kGeh("active", true);
  } catch (e){ K.hinweis = e.message || String(e); kZeichnen(); }
}
function kActive(){
  const a = K.fk?.aktiv; if (!a) return kFocus();
  const ende = new Date(a.planEnde), rest = Math.max(0, Math.round((ende - Date.now()) / 1000)), gesperrt = a.gesperrt || kSperre().an || [];
  return `<div class="session"><div class="overline">FOKUS LÄUFT · VERBINDLICH</div><div class="session-surface"><div class="mini-facet">${kFigur()}</div>
   <div class="session-clock" id="kFokusUhr">${String(Math.floor(rest / 60)).padStart(2, "0")}:${String(rest % 60).padStart(2, "0")}</div>
   <div class="track"><i id="kFokusTrack" style="width:${Math.min(100, 100 * (1 - rest / (a.minuten * 60)))}%"></i></div>
   <div class="session-meta"><span>${a.minuten} Minuten gewählt</span><span>Ende ${kUhr(ende)}</span></div></div>
   <h2>Die Sperre läuft.</h2><p class="session-explain">${gesperrt.length ? kEsc(gesperrt.slice(0, 4).join(", ")) + (gesperrt.length > 4 ? ` und ${gesperrt.length - 4} weitere` : "") : "Die gewählten Apps"} ${gesperrt.length === 1 ? "bleibt" : "bleiben"} bis ${kUhr(ende)} Uhr zu${kSperre().gilt?.length ? " auf " + kEsc(kSperre().gilt.join(", ")) : " auf allen Geräten"}.</p>
   <div class="binding"><b>Verbindlich bis zum Ende</b>Ein vorzeitiger Abbruch ist in dieser Sitzung nicht vorgesehen.</div>
   ${a.live ? `<div class="result-grid" style="margin-top:calc(14px*var(--k))"><div><b>${Math.round((a.live.produktiv || 0) / 60)} Min</b><small>produktiv bisher</small></div><div><b>${a.live.anzahl || 0}</b><small>Ablenkungsversuche</small></div></div>` : ""}</div>`;
}
function kResult(){
  const s = K.fk?.sessions?.[0]; if (!s) return kMain("FOKUS", "Noch keine Sitzung", `<p class="k-leer">Nach deinem ersten Fokus steht hier die Auswertung.</p>`);
  const e = s.ergebnis || {}, start = new Date(s.start), ende = new Date(s.ende);
  return `<div class="session"><div class="overline">FOKUS · ABGESCHLOSSEN</div><h2>${Math.round((e.dauer || 0) / 60)} Minuten<br>geschützt.</h2><p class="small">${kDatum(start)} · ${kUhr(start)}–${kUhr(ende)}${s.final ? "" : " · Handydaten kommen noch dazu"}</p>
   <div class="result-grid"><div><b>${Math.round((e.produktiv || 0) / 60)} Min</b><small>echte Fokuszeit</small></div><div><b>${e.anzahl || 0}</b><small>${e.anzahl === 1 ? "Ablenkungsversuch" : "Ablenkungsversuche"}</small></div></div>
   ${(e.ablenkungen || []).filter(x => x.sek >= 30).length ? kSection("Ablenkungen", e.ablenkungen.filter(x => x.sek >= 30).map(x => `<div class="k-rank">${kernIcon(x.name)}<span>${kEsc(x.name)}</span><b>${kHm(x.sek)}</b></div>`).join("")) : ""}
   ${kSection("Letzte Sitzungen", (K.fk.sessions || []).slice(0, 6).map(x => `<div class="k-rank"><span>${kDatum(new Date(x.start), false)}, ${kUhr(new Date(x.start))}</span><b>${kSitzungText(x)}</b></div>`).join(""))}
   <button class="action full" data-k-nav="focus" style="margin-top:calc(16px*var(--k))">Neuer Fokus</button></div>`;
}

/* ---------- App-Auswahl: eine Liste für Fokus, Gruppen, Zeitregeln, feste Sperren ---------- */
const K_ANSICHTEN = ["Alle Apps & Webseiten","Ausgewählt","Installiert","Weitere Apps","Webseiten","Social","Streaming","Spiele"];
function kKatalog(){
  const inst = kInstalliert(), kat = kKat(), sp = kSperre(), gross = new Map();
  const dazu = (n, quelle) => { const s = String(n || "").trim(); if (s.replace(/[^\w]/g, "").length < 2) return; const k = kLow(s); if (!gross.has(k)) gross.set(k, {name:s, quelle}); };
  inst.forEach(n => dazu(n, "Installiert"));
  [...(K.lk?.konsumApps || []), ...(sp.kandidaten || []), ...(kat.social || []), ...(kat.streaming || []), ...kSpiele(), ...(K.lk?.apps || []).map(a => a.name),
   ...(K.lk?.regeln || []).flatMap(r => r.apps), ...Object.values(K_GRUPPEN_STD).flatMap(x => x.split("|"))].forEach(n => dazu(n, /\./.test(n) ? "Webseiten" : inst.length ? "Weitere Apps" : "Apps"));
  K_WEB.forEach(n => dazu(n, "Webseiten"));
  (K.wahl?.dazu || []).forEach(n => dazu(n, /\./.test(n) ? "Webseiten" : "Weitere Apps"));
  const gr = {Social:new Set([...(kat.social || []), ...K_GRUPPEN_STD.Social.split("|")].map(kLow)), Streaming:new Set([...(kat.streaming || []), ...K_GRUPPEN_STD.Streaming.split("|")].map(kLow)),
    Spiele:new Set([...kSpiele(), ...K_GRUPPEN_STD.Spiele.split("|")].map(kLow))};
  return [...gross.values()].map(a => ({...a, gruppen:Object.keys(gr).filter(g => gr[g].has(kLow(a.name)))})).sort((a, b) => (a.quelle === "Installiert" ? 0 : 1) - (b.quelle === "Installiert" ? 0 : 1) || a.name.localeCompare(b.name, "de"));
}
function kWahlStart(ctx, start, zurueck){ K.wahl = {ctx, draft:new Set(start), such:"", ansicht:K_ANSICHTEN[0], menue:false, zurueck, dazu:[...start]}; kGeh("picker"); }
function kPasst(a, ans){
  if (ans === K_ANSICHTEN[0]) return true; if (ans === "Ausgewählt") return K.wahl.draft.has(a.name);
  if (ans === "Installiert" || ans === "Weitere Apps" || ans === "Webseiten") return a.quelle === ans || (ans === "Weitere Apps" && a.quelle === "Apps");
  return a.gruppen.includes(ans);
}
function kTreffer(){ const w = K.wahl, q = kLow(w.such).trim(); return kKatalog().filter(a => kPasst(a, w.ansicht) && (!q || kLow(a.name).includes(q))); }
function kPicker(){
  const w = K.wahl; if (!w) return kFocus();
  const kat = kKatalog(), liste = kTreffer(), q = w.such.trim(), neu = q.length >= 3 && !kat.some(a => kLow(a.name) === kLow(q));
  const menue = `<button class="group-trigger" data-k-menue aria-expanded="${w.menue}"><b>${kEsc(w.ansicht)}</b><span aria-hidden="true">⌄</span></button>`
    + (w.menue ? `<div class="catalog-menu" role="listbox">${K_ANSICHTEN.filter(x => x !== "Installiert" || kat.some(a => a.quelle === "Installiert")).map(x => `<button class="sub-chip ${x === w.ansicht ? "selected" : ""}" role="option" aria-selected="${x === w.ansicht}" data-k-ansicht="${kEsc(x)}">${x === w.ansicht ? "✓　" : ""}${x} · ${kat.filter(a => kPasst(a, x)).length}</button>`).join("")}</div>` : "");
  const eyebrow = {focus:"FOKUS", rule:"SPERRZEIT", group:"GRUPPE", binding:"FESTE SPERRE", limit:"TAGESLIMIT"}[w.ctx] || "AUSWAHL";
  return kMain(eyebrow, "Apps wählen", `<div class="picker"><input class="catalog-search" data-k-feld="such" type="search" placeholder="App oder Webseite suchen" aria-label="App oder Webseite suchen" value="${kEsc(w.such)}" autocomplete="off">${menue}
    <div class="catalog-tools">${kChip(`Treffer wählen (${liste.length})`, false, "data-k-alle")}${kChip("Treffer abwählen", false, "data-k-keine")}</div>
    <div class="catalog-list">${neu ? `<button class="catalog-item" data-k-neu-app="${kEsc(q)}" aria-pressed="false">${kernIcon(q)}<span>„${kEsc(q)}“ hinzufügen</span><b>＋</b></button>` : ""}${liste.map(a => `<button class="catalog-item" data-k-app="${kEsc(a.name)}" aria-pressed="${w.draft.has(a.name)}">${kernIcon(a.name)}<span>${kEsc(a.name)}</span><b>${w.draft.has(a.name) ? "✓" : "＋"}</b></button>`).join("") || (neu ? "" : `<p class="small">Keine Treffer</p>`)}</div>
    <div class="catalog-tools">${kChip("Abbrechen", false, "data-k-wahl-ab")}<button class="action" data-k-wahl-ok>${w.draft.size} übernehmen</button></div></div>`);
}
function kWahlFertig(ok){
  const w = K.wahl; if (!w) return; const apps = [...w.draft];
  if (ok){
    if (w.ctx === "focus"){ K.fokusApps = apps; store("kern.fokusApps", apps); K.fokusArt = "Apps"; store("kern.fokusArt", "Apps"); }
    else if (w.ctx === "rule" && K.regel) K.regel.apps = apps;
    else if (w.ctx === "binding" && K.bindung) K.bindung.apps = apps;
    else if (w.ctx === "group" && K.gruppe) K.gruppe.apps = apps;
    else if (w.ctx === "limit" && K.limit) K.limit.apps = apps;
  }
  const z = w.zurueck; K.wahl = null; K.zurueck.pop(); K.v = z; kZeichnen(); const sc = document.querySelector("#kern .screen"); if (sc) sc.scrollTop = K.pos?.[z] || 0;
}

/* ---------- Sperre ---------- */
function kLockTabs(a){ return `<div class="period-tabs">${[["lock","Sperren"],["protection","Schutz"],["devices","Geräte"]].map(([id, n]) => `<button data-k="${id}" class="${a === id ? "sel" : ""}" aria-pressed="${a === id}">${n}</button>`).join("")}</div>`; }
function kGruppen(){
  const m = new Map();
  // Gruppe = Regeln mit demselben Namen; Regeln ohne Namen stehen einzeln (sonst würde Speichern Apps in fremde Regeln kopieren)
  for (const r of K.lk?.regeln || []){ if (r.art === "bis") continue; const key = r.gruppe ? "g:" + r.gruppe : "r:" + r.id;
    const n = r.gruppe || (r.art === "zeit" ? `Sperrzeit ${r.von}–${r.bis}` : r.apps.slice(0, 2).join(", "));
    if (!m.has(key)) m.set(key, {key, name:n, regeln:[], apps:new Set()}); const g = m.get(key); g.regeln.push(r); (r.konsum ? r.extra || [] : r.apps).forEach(a => g.apps.add(a)); }
  return [...m.values()].map(g => ({...g, apps:[...g.apps], zu:g.regeln.some(r => r.gesperrt)}));
}
function kRegelSatz(r){
  if (r.art === "zeit") return `${r.von}–${r.bis} Uhr`;
  if (r.art === "limit") return `${r.minuten} Min am Tag${r.verbraucht != null ? ` · ${Math.round(r.verbraucht)} genutzt` : ""}`;
  if (r.art === "sitzung") return `${r.minuten} Min am Stück, dann ${r.pause} Min Pause`;
  if (r.art === "oeffnen") return `${r.anzahl}× öffnen am Tag`;
  if (r.art === "bis") return r.satz || `bis ${kZeitpunkt(r.ende * 1000)}`;
  return "";
}
function kLockerKarte(){
  const d = K.lk || {};
  if (d.wartet > 0) return `<div class="binding-card"><div class="top"><h3>Lockern beantragt</h3><span class="pill">wartet</span></div><p>Frühestens ${kEsc(d.freiAbText || kZeitpunkt(Date.now() + d.wartet * 1000))} kannst du Regeln lockern.</p><button class="text-link" data-k-lk="abbrechen">Doch nicht ›</button></div>`;
  if (d.frei > 0) return `<div class="binding-card"><div class="top"><h3>Lockern ist offen</h3><span class="pill">frei</span></div><p>Bis ${kEsc(d.freiBisText || "")} kannst du Regeln lockern oder löschen.</p><button class="text-link" data-k-lk="schliessen">Wieder schließen ›</button></div>`;
  return "";
}
function kFrühestens(){ const d = K.lk || {}; return d.immerFrei ? "sofort" : kZeitpunkt(Date.now() + (d.warteJetzt ?? d.warteMin ?? 720) * 60000); }
function kTageText(t){   // [0,1,2,3,4] → „Mo–Fr“
  const s = [...new Set(t || [])].map(Number).sort((a, b) => a - b), k = s.join("");
  if (!s.length || k === "0123456") return "täglich"; if (k === "01234") return "Mo–Fr"; if (k === "56") return "Sa + So";
  if (s.length > 2 && s.every((x, i) => !i || x === s[i - 1] + 1)) return `${K_TAGE[s[0]]}–${K_TAGE[s.at(-1)]}`;
  return s.map(x => K_TAGE[x]).join(" ");
}
const kAppsKurz = l => l.length <= 2 ? l.join(", ") : `${l.slice(0, 2).join(", ")} +${l.length - 2}`;
const kRegelApps = r => r.konsum ? r.extra || [] : r.apps;   // gespeicherte Apps (bei Ruhezeit nur die zusätzlichen)
function kRegelStatus(r){ const zeit = r.art === "zeit"; return `<span class="pill ${r.gesperrt && !r.pausiert ? "zu" : ""}">${r.pausiert ? "pausiert" : r.gesperrt ? (zeit ? "jetzt zu" : "aufgebraucht") : zeit ? "frei" : "läuft"}</span>`; }
function kWerKurz(r){ const n = r.apps.length; return `${r.gruppe ? "" : kAppsKurz(r.apps) + " · "}${n} ${n === 1 ? "App" : "Apps"}${r.konsum ? " + Konsum-Apps" : ""} · ${r.geraete?.length ? r.geraete.map(kGeraetText).join(" + ") : "alle Geräte"}${K.lk?.entfernen?.[r.id] ? " · wird entfernt" : ""}`; }
function kRegelZeile(r){   // Sperrzeit: Uhrzeit-Block vorn; Tageslimit: Verbrauchsbalken (john 20.11.: beide Arten sollen sich sichtbar unterscheiden)
  if (r.art === "zeit") return `<button class="sub-row k-regel k-zeit" data-k-regel="${kEsc(r.id)}"><span class="k-uhr"><b>${kEsc(r.von)}</b><small>bis ${kEsc(r.bis)}</small></span><span class="sub-text"><b>${kEsc(r.gruppe || kAppsKurz(r.apps) || "Konsum-Apps")}</b><small>${kEsc(kTageText(r.tage))} · ${kEsc(kWerKurz(r))}</small></span>${kRegelStatus(r)}</button>`;
  const ist = Math.round(r.verbraucht || 0), max = r.minuten || 1;
  return `<button class="sub-row k-regel k-lim" data-k-limit="${kEsc(r.id)}">${kernIcon(r.apps[0] || "")}<span class="sub-text"><b>${kEsc(r.gruppe || kAppsKurz(r.apps))}</b><small>${ist} von ${max} Min heute · ${kEsc(kTageText(r.tage))}</small><span class="k-balken" aria-hidden="true"><i style="width:${Math.min(100, Math.round(100 * ist / max))}%"></i></span><small>${kEsc(kWerKurz(r))}</small></span>${kRegelStatus(r)}</button>`;
}
function kGruppenZeile(g){
  const regeln = g.regeln.map(r => r.art === "zeit" ? `Sperrzeit ${kTageText(r.tage)}, ${r.von}–${r.bis}` : r.art === "limit" ? `Tageslimit ${r.minuten} Min, heute ${Math.round(r.verbraucht || 0)} genutzt` : ({sitzung:"Am Stück", oeffnen:"Öffnen"})[r.art] || r.art);
  const lim = g.regeln.find(r => r.art === "limit"), balken = lim ? `<span class="k-balken" aria-hidden="true"><i style="width:${Math.min(100, Math.round(100 * (lim.verbraucht || 0) / (lim.minuten || 1)))}%"></i></span>` : "";
  return `<button class="sub-row k-gruppe" data-k-gruppe="${kEsc(g.key)}"><span class="k-icons">${g.apps.slice(0, 3).map(kernIcon).join("")}${g.apps.length > 3 ? `<i>+${g.apps.length - 3}</i>` : ""}</span><span class="sub-text"><b>${kEsc(g.name)}</b><small>${g.apps.length} ${g.apps.length === 1 ? "App" : "Apps"}${g.zu ? " · jetzt zu" : ""}</small>${regeln.map(t => `<small>${kEsc(t)}</small>`).join("")}${balken}</span><span class="sub-chevron">›</span></button>`;
}
const K_LK_TEILE = [["zeiten","Sperrzeiten"],["gruppen","Gruppen"],["apps","Apps"]];   // wie die Play-Fassung 1.0.76: Zeiten | Gruppen | Apps (john 20.11.)
function kZeitKreis(r){   // Sperrzeit als Kreis, nur Uhrzeiten (john 20.11. 11:01: Namen liefen über den Kreis); Antippen klappt darunter auf, was gesperrt ist
  const offen = K.kreis === r.id;
  return `<button class="time-circle ${r.gesperrt && !r.pausiert ? "an" : ""} ${offen ? "offen" : ""}" data-k-kreis="${kEsc(r.id)}" aria-expanded="${offen}" aria-label="${kEsc((r.gruppe || kAppsKurz(kRegelApps(r)) || "Konsum-Apps") + ", " + kTageText(r.tage) + " " + r.von + " bis " + r.bis)}"><span class="k-kreis-zeit">${kEsc(r.von)}</span><small>bis ${kEsc(r.bis)}</small><i class="k-pfeil" aria-hidden="true">${offen ? "▴" : "▾"}</i></button>`;
}
function kKreisInfo(r){   // aufgeklappt: was zu dieser Zeit gesperrt ist
  const apps = kRegelApps(r);
  return `<div class="k-kreis-info"><div class="k-kreis-kopf"><span class="sub-text"><b>${kEsc(r.gruppe || (apps.length ? kAppsKurz(apps) : "Konsum-Apps"))}</b><small>${kEsc(kTageText(r.tage))} · ${kEsc(r.von)}–${kEsc(r.bis)} Uhr · ${r.geraete?.length ? kEsc(r.geraete.map(kGeraetText).join(" + ")) : "alle Geräte"}</small></span>${kRegelStatus(r)}</div>
   <div class="k-kreis-apps">${apps.map(a => `<span>${kernIcon(a)}<small>${kEsc(a)}</small></span>`).join("")}${r.konsum ? `<span class="k-konsum"><small>+ alle Konsum-Apps</small></span>` : ""}</div>
   <button class="sub-chip" data-k-regel="${kEsc(r.id)}">Bearbeiten</button></div>`;
}
function kAppZeilen(regeln){   // Reiter „Apps“: jede einzeln begrenzte App eine Zeile (ohne Gruppe, ohne Sperrzeiten; john 20.11.)
  const m = new Map();
  regeln.filter(r => !r.gruppe && !["zeit","bis"].includes(r.art)).forEach(r => kRegelApps(r).forEach(a => { if (!m.has(a)) m.set(a, []); m.get(a).push(r); }));
  return [...m].sort((a, b) => a[0].localeCompare(b[0], "de")).map(([a, rs]) => {
    const lim = rs.find(r => r.art === "limit"), auf = lim ? `data-k-limit="${kEsc(lim.id)}"` : `data-k-gruppe="r:${kEsc(rs[0].id)}"`;
    const mit = r => { const o = kRegelApps(r).filter(x => x !== a); return o.length ? ` · gemeinsam mit ${kAppsKurz(o)}` : ""; };   // eine Regel für mehrere Apps: Minuten gelten zusammen
    const text = rs.map(r => (r.art === "limit" ? `Tageslimit ${r.minuten} Min · heute ${Math.round(r.verbraucht || 0)} genutzt` : kRegelSatz(r)) + mit(r));
    return `<button class="sub-row k-gruppe" ${auf}>${kernIcon(a)}<span class="sub-text"><b>${kEsc(a)}</b>${text.map(t => `<small>${kEsc(t)}</small>`).join("")}${lim ? `<span class="k-balken" aria-hidden="true"><i style="width:${Math.min(100, Math.round(100 * (lim.verbraucht || 0) / (lim.minuten || 1)))}%"></i></span>` : ""}</span>${lim?.gesperrt && !lim.pausiert ? `<span class="pill zu">aufgebraucht</span>` : ""}<span class="sub-chevron">›</span></button>`;
  }).join("");
}
function kLock(){
  const d = K.lk || {}, gr = kGruppen(), regeln = d.regeln || [], bis = regeln.filter(r => r.art === "bis" && r.gesperrt).sort((a, b) => a.ende - b.ende);
  const zeiten = regeln.filter(r => r.art === "zeit").sort((a, b) => a.von.localeCompare(b.von)), limits = regeln.filter(r => r.art === "limit");
  const benannt = gr.filter(g => g.key.startsWith("g:"));
  const jetzt = new Date(), geladen = Array.isArray(d.regeln), pause = !!d.sofort && (d.pauseBis || 0) * 1000 > Date.now();   // Pause wirkt nur in der Entwicklerversion (sofort)
  const teil = K_LK_TEILE.some(([k]) => k === K.lkTeil) ? K.lkTeil : "zeiten";
  const status = gr.slice(0, 4).map(g => { const z = g.regeln.find(r => r.gesperrt); return `<button class="status-card ${g.zu ? "closed" : ""}" data-k-gruppe="${kEsc(g.key)}"><span class="state">${g.zu ? "GESPERRT" : "FREI"}</span><b>${kEsc(g.name)}</b><small>${z ? (z.art === "zeit" ? `bis ${z.bis} Uhr` : z.art === "limit" ? "Limit erreicht" : kEsc(kRegelSatz(z))) : g.apps.length + " Apps"}</small></button>`; }).join("");
  const leer = (t, knopf) => `<p class="k-leer">${t}</p>${knopf}`;
  const inhalt = {
    zeiten: () => { const auf = zeiten.find(r => r.id === K.kreis);
      return (zeiten.length ? "" : leer("Noch keine Sperrzeit. Sie macht Apps zu festen Zeiten ganz zu, zum Beispiel abends ab 21 Uhr.", ""))
      + `<div class="time-circles k-kreise">${zeiten.map(kZeitKreis).join("")}<button class="time-circle neu" data-k-regel="neu" aria-label="Sperrzeit anlegen"><b>+</b><small>Neu</small></button></div>`
      + (auf ? kKreisInfo(auf) : zeiten.length ? `<p class="small k-kreis-tipp">Tippe auf eine Zeit, dann siehst du, was gesperrt ist.</p>` : `<button class="action full k-neu" data-k-regel="neu">Sperrzeit anlegen</button>`); },
    gruppen: () => (benannt.map(kGruppenZeile).join("") || leer("Noch keine Gruppe. Eine Gruppe fasst Apps zusammen, zum Beispiel „Social“, und bekommt eigene Sperrzeiten und Tageslimits.", ""))
      + `<button class="action full k-neu" data-k-gruppe-neu>Neue Gruppe</button>`,
    apps: () => (kAppZeilen(regeln) || leer("Noch keine einzelne App begrenzt. Hier stehen Apps mit eigenem Tageslimit, ohne Gruppe.", ""))
      + `<button class="action full k-neu" data-k-neu-apps="limit">App begrenzen</button>`};
  return `<div class="lock"><div class="page-title"><div class="overline">DEIN SCHUTZ</div><h2>Sperre</h2><p>Was jetzt gilt und was du festgelegt hast.</p></div>${kLockTabs("lock")}
   ${d.offline ? kNote("Offline", "Die Regeln wirken auf dem Gerät weiter. Ändern geht, sobald die Verbindung zurück ist.") : ""}
   ${d.fokus ? kNote("Fokus läuft", "Während des Fokus bleiben alle Regeln, wie sie sind. Ändern geht nach dem Fokus.") : ""}
   ${pause ? kNote("Regeln pausiert", `Entwickler-Pause bis ${kEsc(kZeitpunkt(d.pauseBis * 1000))}. Deine Regeln bleiben gespeichert und gelten danach wieder.`) + `<button class="action full k-neu" data-k-pause-aus>Pause beenden, Regeln gelten sofort</button>` : ""}
   ${!geladen ? `<p class="k-leer">${K.fehlt.lk ? "Regeln ließen sich gerade nicht laden." : "Regeln werden geladen …"}</p>` : `
   ${pause || !gr.length ? "" : `<div class="values-block"><h3>Jetzt · ${jetzt.toLocaleDateString("de-DE", {weekday:"long"})}, ${kUhr(jetzt)}</h3><div class="status-grid">${status}</div></div>`}
   <div class="values-block k-lkteil"><h3>Deine Regeln</h3><div class="device-pills" role="tablist">${K_LK_TEILE.map(([k, t]) => `<button role="tab" data-k-lkteil="${k}" class="${teil === k ? "sel" : ""}" aria-pressed="${teil === k}">${t}</button>`).join("")}</div>
   <div class="k-regeln">${inhalt[teil]()}</div></div>`}
   ${bis[0] ? `<button class="binding-card" data-k="binding" style="width:100%;text-align:left;border:0;color:inherit"><div class="top"><h3>Verbindlich ${kEsc(bis[0].endeText ? "bis " + bis[0].endeText : "")}</h3><span class="pill">Aktiv</span></div><p>${kEsc(bis[0].satz || kRegelSatz(bis[0]))}</p><small>Früher lockern: Antrag mit 12 Std Wartezeit</small></button>` : ""}
   ${kLockerKarte()}
   <div class="lock-links">${kJump("Reels, Shorts und Explore", K.tr?.schutz?.kurzvideos ? "gesperrt" : "Sperre für Kurzvideos", "shorts", "▶")}${kJump("Feste Sperren", bis.length ? bis.length + " aktiv" : "Wartezeit und Schutzstatus", "binding", "⌑")}</div>
  </div>`;
}
function kSchedule(){
  const z = (K.lk?.regeln || []).filter(r => r.art === "zeit").sort((a, b) => a.von.localeCompare(b.von));
  return kMain("SPERRE", "Sperrzeiten", `<div class="k-regeln">${z.map(kRegelZeile).join("") || `<p class="k-leer">Noch keine Sperrzeiten.</p>`}</div>`)
    + `<button class="sub-chip" data-k-regel="neu" style="margin-top:calc(12px*var(--k))">+ Sperrzeit hinzufügen</button>`;
}
const K_ZEITEN = [["Abends","21:00","07:00"],["Nachts","23:00","07:00"],["Arbeitszeit","09:00","17:00"]];
const kBenannt = () => kGruppen().filter(g => g.key.startsWith("g:"));
/* 24.11. (john): Tageslimit/Sperrzeit/Am Stück entschlackt. Neu anlegen = Schritt für Schritt, bearbeiten = Zusammenfassung zum Aufklappen.
   Für wen: eine oder mehrere Gruppen (je Gruppe eine eigene Regel), Mitglieder direkt von hier ändern. */
function kWerStart(r){   // „Für wen“: Gruppen (vorhandene oder neue) oder einzelne Apps
  if (r) return {wer:r.gruppe ? "gruppe" : "apps", gwahl:r.gruppe ? [r.gruppe] : [], g0:r.gruppe || "", gneu:""};
  return {wer:kBenannt().length ? "gruppe" : "apps", gwahl:kBenannt().length ? [] : ["+neu"], g0:"", gneu:""};
}
const kEdStand = o => JSON.stringify([o.wer, o.gwahl, o.gneu, o.apps, o.von, o.bis, [...(o.tage || [])].sort(), o.geraete, +o.minuten, +o.pause, +o.anzahl]);
function kEdStart(o){ o.start = kEdStand(o); o.auf = ""; o.schritt = 0; return o; }
function kRegelOeffnen(id, vorlage){
  const r = (K.lk?.regeln || []).find(x => x.id === id);
  K.regel = kEdStart(r ? {id:r.id, alt:r, ...kWerStart(r), von:r.von, bis:r.bis, tage:[...(r.tage || [0,1,2,3,4,5,6])], apps:[...kRegelApps(r)], geraete:[...(r.geraete || [])], konsum:r.konsum, erlaubt:r.erlaubt}
    : {...kWerStart(null), von:"21:00", bis:"07:00", tage:[0,1,2,3,4,5,6], apps:[], geraete:[], ...vorlage});
  K.hinweis = ""; kGeh("timeRule");
}
function kGeraeteWahl(attr, aktuell){
  const alle = [...new Set([...(K.lk?.geraete || []), kGeraetHier()])], wahl = new Set(aktuell || []);
  return kChip("Alle Geräte", !wahl.size, `data-${attr}=""`) + alle.map(g => kChip(kEsc(kGeraetText(g)) + (g === kGeraetHier() ? " (dieses)" : ""), wahl.has(g), `data-${attr}="${kEsc(g)}"`)).join("");
}
function kWerBlock(o, a){
  const ctx = a === "r" ? "rule" : "limit", wahl = t => kChip(o.apps.length ? `${o.apps.length} gewählt: ${kEsc(kAppsKurz(o.apps))}` : t, !!o.apps.length, `data-k-wahl="${ctx}"`);
  const seg = `<div class="chip-wrap k-seg">${kChip("Gruppe", o.wer === "gruppe", 'data-k-wer="gruppe"')}${kChip("Einzelne Apps", o.wer === "apps", 'data-k-wer="apps"')}</div>`;
  if (o.wer !== "gruppe") return seg + wahl("Apps und Webseiten wählen");
  const zeile = (key, titel, sub, ic) => `<button class="sub-row k-wahlzeile" data-k-gsel="${kEsc(key)}" aria-pressed="${o.gwahl.includes(key)}">${ic}<span class="sub-text"><b>${titel}</b><small>${sub}</small></span><span class="k-radio" aria-hidden="true"></span></button>`;
  const gew = kBenannt().filter(g => o.gwahl.includes(g.name));
  return seg + kBenannt().map(g => zeile(g.name, kEsc(g.name), `${g.apps.length} Apps: ${kEsc(kAppsKurz(g.apps))}`, kernIcon(g.apps[0]))).join("")
    + zeile("+neu", "+ Neue Gruppe", "Name und Apps festlegen", `<span class="sub-glyph">▦</span>`)
    + (o.gwahl.includes("+neu") ? `<label class="form-label">Name der Gruppe<input type="text" data-k-feld="gneu" data-k-${a}="gneu" maxlength="40" placeholder="z. B. Social" value="${kEsc(o.gneu)}"></label>${wahl("Apps für die Gruppe wählen")}` : "")
    + (gew.length ? `<div class="chip-wrap k-gedit">${gew.map(g => kChip(`Apps in ${kEsc(g.name)} ändern ›`, false, `data-k-gedit="${kEsc(g.name)}"`)).join("")}</div>` : "")
    + (o.gwahl.length > 1 ? `<p class="small">Jede Gruppe bekommt ihre eigene Regel mit denselben Werten.</p>` : "");
}
function kWerListe(o){   // → [{gruppe, apps}] (eine Regel je Gruppe) oder Fehlertext
  if (o.wer === "apps") return o.apps.length || o.konsum ? [{gruppe:"", apps:o.apps}] : "Wähle mindestens eine App oder Webseite.";
  if (!o.gwahl.length) return "Wähle mindestens eine Gruppe oder lege eine neue an.";
  const out = [];
  for (const k of o.gwahl){
    if (k === "+neu"){ const n = (o.gneu || "").trim().replace(/\s+/g, " "); if (!n) return "Gib der neuen Gruppe einen Namen."; if (!o.apps.length) return "Wähle die Apps für die neue Gruppe.";
      const da = kBenannt().find(g => kLow(g.name) === kLow(n)); if (da) return `Die Gruppe „${da.name}“ gibt es schon. Wähle sie oben aus.`; out.push({gruppe:n, apps:o.apps}); continue; }
    const g = kBenannt().find(x => x.name === k); if (g) out.push({gruppe:g.name, apps:g.apps});
  }
  return out.length ? out : "Wähle mindestens eine Gruppe oder lege eine neue an.";
}
function kWerWert(o){
  if (o.wer === "apps") return o.apps.length ? `${o.apps.length} ${o.apps.length === 1 ? "App" : "Apps"}: ${kAppsKurz(o.apps)}` : o.konsum ? "Konsum-Apps" : "Noch keine Apps gewählt";
  const n = o.gwahl.map(k => k === "+neu" ? (o.gneu || "Neue Gruppe") : k);
  const z = new Set(kBenannt().filter(g => o.gwahl.includes(g.name)).flatMap(g => g.apps).concat(o.gwahl.includes("+neu") ? o.apps : []).map(kLow)).size;
  return n.length ? `${n.join(" + ")} · ${z} ${z === 1 ? "App" : "Apps"}` : "Noch keine Gruppe gewählt";
}
const kGross = s => s ? s[0].toUpperCase() + s.slice(1) : s;
const kWarteText = () => { const m = K.lk?.warteJetzt ?? K.lk?.warteMin ?? 720; return m >= 60 ? `${Math.round(m / 60)} Std.` : `${m} Min`; };
const kFehlerText = () => K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>` : "";
const kTageWahl = o => { const v = [...o.tage].sort().join(), k = [["Täglich","0,1,2,3,4,5,6"],["Mo–Fr","0,1,2,3,4"],["Sa + So","5,6"]], eigen = o.tageEigen || !k.some(x => x[1] === v);
  return `<div class="chip-wrap">${k.map(([t, w]) => kChip(t, !eigen && v === w, `data-k-tage="${w}"`)).join("")}${kChip("Eigene Tage", eigen, 'data-k-tage="eigen"')}</div>`
    + (eigen ? `<div class="chip-wrap">${K_TAGE.map((t, i) => kChip(t, o.tage.includes(i), `data-k-tag="${i}"`)).join("")}</div>` : ""); };
function kEdTeile(o, a){   // [Schlüssel, Titel, Zusammenfassung, Inhalt]
  const art = a === "r" ? "zeit" : o.art || "limit", ger = o.geraete?.length ? o.geraete.map(kGeraetText).join(" + ") : "Alle Geräte";
  const wie = art === "zeit" ? (() => { const eigen = o.zeitEigen || !K_ZEITEN.some(([, v, b]) => o.von === v && o.bis === b);
      return ["wann", "Wann ist alles zu?", `${o.von}–${o.bis} Uhr`, () => `<div class="chip-wrap">${K_ZEITEN.map(([t, v, b]) => kChip(`${t} ${v.slice(0, 2)}–${b.slice(0, 2)}`, !eigen && o.von === v && o.bis === b, `data-k-zvor="${v}|${b}"`)).join("")}${kChip("Eigene Zeit", eigen, 'data-k-zvor="eigen"')}</div>`
        + (eigen ? `<div class="k-zeit2"><label class="form-label">Von<input type="time" data-k-r="von" value="${kEsc(o.von)}"></label><label class="form-label">Bis<input type="time" data-k-r="bis" value="${kEsc(o.bis)}"></label></div>` : "")]; })()
    : art === "sitzung" ? ["wie", "Wie lange am Stück?", `${o.minuten || "?"} Min am Stück, dann ${o.pause || "?"} Min Pause`, () => `<label class="form-label">Minuten am Stück<input type="number" data-k-l="minuten" min="1" max="240" value="${kEsc(o.minuten)}"></label><label class="form-label">Pause danach (Minuten)<input type="number" data-k-l="pause" min="1" max="1440" value="${kEsc(o.pause)}"></label>`]
    : art === "oeffnen" ? ["wie", "Wie oft am Tag?", `${o.anzahl || "?"}× öffnen am Tag`, () => `<label class="form-label">Öffnen am Tag<input type="number" data-k-l="anzahl" min="1" max="100" value="${kEsc(o.anzahl)}"></label>`]
    : (() => { const eigen = o.minEigen || ![15, 30, 60, 120].includes(+o.minuten);
      return ["wie", "Wie lange pro Tag?", `${o.minuten} Min am Tag, danach bis morgen zu`, () => `<div class="chip-wrap">${[15, 30, 60, 120].map(m => kChip(`${m} Min`, !eigen && +o.minuten === m, `data-k-lmin="${m}"`)).join("")}${kChip("Andere", eigen, 'data-k-lmin="andere"')}</div>`
        + (eigen ? `<label class="form-label">Minuten am Tag<input type="number" data-k-l="minuten" min="1" max="1440" value="${kEsc(o.minuten)}"></label>` : "")]; })();
  return [["wer", "Für wen", kWerWert(o), () => kWerBlock(o, a)], wie,
    ["tage", "An welchen Tagen", kGross(kTageText(o.tage)), () => kTageWahl(o)],
    ["wo", "Auf welchen Geräten", ger, () => `<div class="chip-wrap">${kGeraeteWahl(a === "r" ? "k-rger" : "k-lger", o.geraete)}</div>`]];
}
function kEditor(o, a, eyebrow, titel, unter, extra, loeschText){
  const teile = kEdTeile(o, a), neu = !o.id, auf = neu ? teile[o.schritt]?.[0] : o.auf, letzter = neu && o.schritt >= teile.length - 1;
  const weg = o.id && K.lk?.entfernen?.[o.id], gp = o.id && K.lk?.geplant?.[o.id];
  const acc = teile.map(([key, t, wert, inhalt], i) => { if (neu && i > o.schritt) return ""; const offen = key === auf;
    return `<div class="k-acc${offen ? " auf" : ""}"><button class="sub-row k-acc-kopf" data-k-auf="${key}" aria-expanded="${offen}"><span class="sub-text"><b>${t}</b><small>${kEsc(offen && neu ? `Schritt ${i + 1} von ${teile.length}` : wert)}</small></span><span class="sub-chevron" aria-hidden="true">›</span></button>`
      + (offen ? `<div class="k-acc-inhalt">${inhalt()}${neu && !letzter ? `<button class="action k-weiter" data-k-weiter>Weiter</button>` : ""}</div>` : "") + `</div>`; }).join("");
  const geaendert = neu ? letzter : kEdStand(o) !== o.start;
  return kMain(eyebrow, titel, (gp ? kNote("Lockern beantragt", `${kEsc(gp.satz || "Deine Änderung")} gilt ${kEsc(gp.abText || "")}. Bis dahin bleibt alles wie jetzt.`) + kChip("Doch nicht", false, `data-k-geplant-ab="${kEsc(o.id)}"`) : "")
   + `<div class="k-accs">${acc}</div>` + (extra || "")
   + (weg ? kNote("Wird entfernt", `Gilt noch bis ${kZeitpunkt(weg * 1000)}.`) : "") + kFehlerText()
   + (geaendert ? `<div class="k-tools">${kChip("Abbrechen", false, "data-k-zurueck")}<button class="action" data-k-${a === "r" ? "regel" : "limit"}-speichern>Speichern</button></div>` : "")
   + (o.id && !weg ? `<button class="text-link" data-k-${a === "r" ? "regel" : "limit"}-loeschen style="margin-top:calc(16px*var(--k))">${loeschText} (wirkt nach 24 Std) ›</button>` : ""),
   neu ? unter : `Tippe an, was du ändern willst. Strenger wirkt sofort, lockern erst nach ${kWarteText()} Wartezeit.`);
}
function kTimeRule(){
  const r = K.regel; if (!r) return kSchedule();
  return kEditor(r, "r", "SPERRE · SPERRZEIT", r.id ? "Sperrzeit bearbeiten" : "Neue Sperrzeit", "In dieser Zeit sind die Apps ganz zu.",
    r.konsum ? kNote("Ruhezeit", "Gilt außerdem für alle Konsum-Apps.") : "", "Sperrzeit entfernen");
}
function kNachNeuerGruppe(name){   // nach jedem Speichern: Gruppenseite dahinter frisch (bei „Neue Gruppe“ die fertige Gruppe)
  if (!K.gruppe) return; const key = K.gruppe.neu ? "g:" + name : K.gruppe.key, g = kGruppen().find(x => x.key === key);
  K.gruppe = g ? {...g, apps:[...g.apps], start:[...g.apps]} : null;
}
async function kEdSpeichern(o, bau){   // eine Regel je Gruppe: die eigene (o.id) für die bisherige Gruppe, weitere Gruppen bekommen eine neue (fremde Regeln bleiben unberührt)
  const liste = kWerListe(o);
  K.hinweis = typeof liste === "string" ? liste : !o.tage.length ? "Wähle mindestens einen Tag." : ""; if (K.hinweis){ kZeichnen(); return false; }
  const eigen = liste.find(w => w.gruppe === o.g0) || liste[0], texte = [];
  for (const w of [eigen, ...liste.filter(x => x !== eigen)]){
    const regel = bau(w);
    if (w === eigen && o.id) regel.id = o.id;
    const x = await kPost("api/locker", {regel}); if (!x) return false;
    K.lk = x; if (x.hinweis) texte.push(x.hinweis);
  }
  K.zeit.lk = Date.now(); kNachNeuerGruppe(eigen.gruppe); toast(texte[0] || "Gespeichert."); return true;
}
async function kRegelSpeichern(){
  const r = K.regel; if (!r) return;
  if (r.von === r.bis){ K.hinweis = "Von und Bis dürfen nicht gleich sein."; return kZeichnen(); }
  const ok = await kEdSpeichern(r, w => { const regel = {art:"zeit", apps:w.apps, von:r.von, bis:r.bis, tage:[...r.tage].sort(), geraete:r.geraete, gruppe:w.gruppe};
    if (r.konsum){ regel.konsum = true; regel.erlaubt = r.erlaubt || []; } return regel; });
  if (ok){ K.regel = null; kZurueck(); }
}
function kLimitsSeite(){
  const l = (K.lk?.regeln || []).filter(r => r.art === "limit");
  return kMain("SPERRE", "Tageslimits", `<div class="k-regeln">${l.map(kRegelZeile).join("") || `<p class="k-leer">Noch keine Tageslimits.</p>`}</div>`)
    + `<button class="sub-chip" data-k-limit="neu" style="margin-top:calc(12px*var(--k))">+ Tageslimit hinzufügen</button>`;
}
function kLimitEdit(){
  const l = K.limit; if (!l) return kLimitsSeite();
  const art = l.art || "limit";   // 24.11.: derselbe Editor auch für „am Stück“ und „Öffnen“
  if (art !== "limit") return kEditor(l, "l", "SPERRE · REGEL", art === "sitzung" ? "Am Stück bearbeiten" : "Öffnen bearbeiten", "Strenger stellen wirkt sofort, lockern erst nach der Wartezeit.", "", "Regel entfernen");
  return kEditor(l, "l", "SPERRE · TAGESLIMIT", l.id ? "Tageslimit bearbeiten" : "Neues Tageslimit", "Die Apps dürfen zusammen so lange pro Tag offen sein.",
    l.id ? `<p class="small">Heute genutzt: ${Math.round(l.alt?.verbraucht || 0)} Min auf allen Geräten.</p>` : "", "Limit entfernen");
}
function kLimitOeffnen(id, vorlage){
  const r = (K.lk?.regeln || []).find(x => x.id === id);
  K.limit = kEdStart(r ? {id:r.id, alt:r, ...kWerStart(r), art:r.art, minuten:r.minuten, pause:r.pause, anzahl:r.anzahl, apps:[...r.apps], geraete:[...(r.geraete || [])], tage:[...(r.tage || [0,1,2,3,4,5,6])]}
    : {...kWerStart(null), minuten:30, apps:[], geraete:[], tage:[0,1,2,3,4,5,6], ...vorlage});
  K.hinweis = ""; kGeh("limitEdit");
}
async function kLimitSpeichern(){
  const l = K.limit, art = l.art || "limit";
  const ok = await kEdSpeichern(l, w => { const regel = {art, apps:w.apps, minuten:Math.max(1, Math.min(art === "sitzung" ? 240 : 1440, +l.minuten || 1)), tage:[...l.tage].sort(), geraete:l.geraete, gruppe:w.gruppe};
    if (art === "sitzung") regel.pause = Math.max(1, Math.min(1440, +l.pause || 30));
    if (art === "oeffnen") regel.anzahl = Math.max(1, Math.min(100, +l.anzahl || 5));
    return regel; });
  if (ok){ K.limit = null; kZurueck(); }
}
const kRegelKurz = r => r.art === "zeit" ? `Sperrzeit ${kTageText(r.tage)} ${r.von}–${r.bis}` : r.art === "limit" ? `${r.minuten} Min am Tag` : r.art === "sitzung" ? `${r.minuten} Min am Stück` : r.art === "oeffnen" ? `${r.anzahl}× öffnen am Tag` : r.art;   // 24.11.: „Am Stück“ ohne Minuten war unsichtbar (john)
function kGroupsSeite(){
  const g = kGruppen(), zeile = x => `<button class="sub-row" data-k-gruppe="${kEsc(x.key)}">${kernIcon(x.apps[0] || "")}<span class="sub-text"><b>${kEsc(x.name)}</b><small>${x.apps.length} ${x.apps.length === 1 ? "App" : "Apps"} · ${kEsc(x.regeln.map(kRegelKurz).join(", "))}</small></span><span class="sub-chevron">›</span></button>`;
  return kMain("SPERRE", "Gruppen & Apps", kSection("Gruppen", g.filter(x => x.key.startsWith("g:")).map(zeile).join("") || `<p class="k-leer">Noch keine Gruppe. Eine Gruppe fasst Apps zusammen, z. B. „Social“, und bekommt eigene Sperrzeiten und Tageslimits.</p>`)
    + `<button class="sub-chip" data-k-gruppe-neu>+ Neue Gruppe</button>`
    + kSection("Einzelne Apps", g.filter(x => !x.key.startsWith("g:")).map(zeile).join("") || `<p class="k-leer">Keine einzeln begrenzte App.</p>`));
}
function kGroupEdit(){
  const g = K.gruppe; if (!g) return kGroupsSeite();
  const mitglieder = (g.regeln?.some(r => r.konsum) ? `<div class="flat-app">${kernIcon("")}Alle Konsum-Apps (Ruhezeit)</div>` : "") + g.apps.map(n => `<div class="flat-app">${kernIcon(n)}${kEsc(n)}</div>`).join("");
  if (g.neu) return kMain("SPERRE · GRUPPE", "Neue Gruppe", `<label class="form-label">Name der Gruppe<input type="text" data-k-feld="gname" data-k-g="name" maxlength="40" placeholder="z. B. Social" value="${kEsc(g.name)}"></label>`
    + kSection("Mitglieder", mitglieder || `<p class="k-leer">Noch keine Apps.</p>`, g.apps.length + " Apps") + kChip(g.apps.length ? "Mitglieder ändern" : "Apps wählen", false, 'data-k-wahl="group"')
    + kFehlerText() + kSection("Was soll für die Gruppe gelten?", `<div class="k-tools"><button class="action" data-k-gregel="zeit">Sperrzeit festlegen</button><button class="sub-chip" data-k-gregel="limit">Tageslimit festlegen</button></div><p class="small">Die Gruppe wird gespeichert, sobald sie eine Sperrzeit oder ein Tageslimit hat.</p>`));
  const benannt = g.key.startsWith("g:");
  return kMain("SPERRE · " + (benannt ? "GRUPPE" : "APPS"), kEsc(g.name), kSection("Mitglieder", mitglieder || kNote("Noch keine Apps", "Füge die erste App hinzu."), g.apps.length + " Apps")
    + (g.dirty ? `<div class="k-tools">${kChip("Abbrechen", false, "data-k-gruppe-ab")}<button class="action" data-k-gruppe-speichern>Speichern</button></div>` : kChip("Mitglieder bearbeiten", false, 'data-k-wahl="group"'))
    + kFehlerText()
    + kSection("Regeln", g.regeln.map(r => `<button class="sub-row" ${r.art === "zeit" ? `data-k-regel="${kEsc(r.id)}"` : ["limit", "sitzung", "oeffnen"].includes(r.art) ? `data-k-limit="${kEsc(r.id)}"` : "disabled"}><span class="sub-text"><b>${({zeit:"Sperrzeit", limit:"Tageslimit", sitzung:"Am Stück", oeffnen:"Öffnen"})[r.art] || r.art}</b><small>${kEsc(r.art === "zeit" ? `${kTageText(r.tage)} · ${r.von}–${r.bis} Uhr` : kRegelSatz(r))}</small></span><span class="sub-chevron">›</span></button>`).join(""))
    + `<div class="chip-wrap">${kChip("+ Sperrzeit", false, 'data-k-gregel="zeit"')}${kChip("+ Tageslimit", false, 'data-k-gregel="limit"')}</div>`);
}
async function kGruppeSpeichern(){
  // Nur die Änderung schreiben: dazu gekommene Apps in jede Regel der Gruppe, entfernte heraus. Erst alles Strengere, dann das Lockern.
  const g = K.gruppe, lo = x => kLow(x), dazu = g.apps.filter(a => !g.start.some(b => lo(b) === lo(a))), weg = new Set(g.start.filter(a => !g.apps.some(b => lo(b) === lo(a))).map(lo));
  const regel = (r, apps) => { const neu = {...r, apps}; ["gesperrt","verbraucht","geoeffnet","pauseBis","satz","endeText","geaendert","extra"].forEach(k => delete neu[k]); return neu; };
  const basis = r => r.konsum ? r.extra || [] : r.apps, mit = (l, d) => [...l, ...d.filter(a => !l.some(b => lo(b) === lo(a)))];
  let fehler = "", geplant = "";
  const frisch = r0 => (K.lk?.regeln || []).find(x => x.id === r0.id) || r0;   // Prüfer 20.11.: nie alte Kopien zurückschreiben (Zeit/Gruppe könnten inzwischen geändert sein)
  if (dazu.length) for (const r0 of g.regeln){ const r = frisch(r0); try { K.lk = await api("api/locker", {regel:regel(r, mit(basis(r), dazu))}); } catch (e){ fehler = e.message || String(e); } }
  if (weg.size) for (const r0 of g.regeln){ const r = frisch(r0), apps = mit(basis(r), dazu).filter(a => !weg.has(lo(a)));
    if (!apps.length && !r.konsum){ fehler = "Eine Regel braucht mindestens eine App. Entferne stattdessen die Regel."; continue; }
    try { K.lk = await api("api/locker", {regel:regel(r, apps)}); geplant ||= K.lk?.hinweis || ""; } catch (e){ fehler = e.message || String(e); } }
  K.zeit.lk = Date.now();
  if (fehler){ const neu = kGruppen().find(x => x.key === g.key); if (neu) K.gruppe = {...neu, apps:[...neu.apps], start:[...neu.apps]}; K.hinweis = fehler + (dazu.length ? " Hinzugefügte Apps sind gespeichert." : ""); kZeichnen(); return; }
  toast(geplant || "Gespeichert."); K.gruppe = null; kZurueck();
}
function kBinding(){
  const d = K.lk || {}, bis = (d.regeln || []).filter(r => r.art === "bis").sort((a, b) => a.ende - b.ende);
  return kMain("SPERRE", "Feste Sperren", bis.map(r => { const weg = d.entfernen?.[r.id];
      return `<div class="detail-note"><b>${kEsc(r.apps.join(", "))} gesperrt</b><p>${kEsc(r.satz || kRegelSatz(r))}${weg ? `<br>Früheres Ende beantragt: frühestens ${kZeitpunkt(weg * 1000)}.` : ""}</p>${weg ? kChip("Doch nicht", false, `data-k-bis-ab="${kEsc(r.id)}"`) : kChip("Früheres Ende beantragen", false, `data-k-bis-weg="${kEsc(r.id)}"`)}</div>`; }).join("")
    + kJump("Feste Sperre anlegen", "App und Endzeit wählen", "newBinding", "+")
    + kSection("Früheres Ende", kNote(`${Math.round((d.warteMin ?? 720) / 60)} Stunden Wartezeit`, `Strengere Regeln gelten sofort. Eine Lockerung gilt frühestens zwölf Stunden nach deinem Antrag, also jetzt beantragt ${kFrühestens()}.`))
    + (K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>` : ""));
}
function kNewBinding(){
  if (!K.bindung){ const f = new Date(); f.setDate(f.getDate() + ((4 - f.getDay() + 7) % 7 || 7)); f.setHours(18, 0, 0, 0); K.bindung = {apps:[], ende:f}; }
  const b = K.bindung, v = new Date(b.ende.getTime() - b.ende.getTimezoneOffset() * 60000).toISOString().slice(0, 16), min = new Date(Date.now() + 60000 - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  return kMain("SPERRE", "Feste Sperre anlegen", kSection("Apps", kChip(b.apps.length ? `${b.apps.length} gewählt: ${kEsc(b.apps.slice(0, 3).join(", "))}` : "Apps wählen", !!b.apps.length, `data-k-wahl="binding"`))
    + `<label class="form-label">Gesperrt bis<input type="datetime-local" data-k-b="ende" min="${min}" value="${v}"></label>`
    + `<div class="chip-wrap">${[["Heute 22 Uhr",0,22],["Morgen 18 Uhr",1,18],["Sonntag 20 Uhr","so",20],["1 Woche",7,null]].map(([t, d, h]) => kChip(t, false, `data-k-bschnell="${d}|${h}"`)).join("")}</div>`
    + (K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>` : "")
    + `<p class="small">Bis ${kZeitpunkt(b.ende.getTime())} bleiben die Apps auf allen Geräten zu. Früher beenden geht nur mit 12 Stunden Wartezeit.</p>`
    + `<div class="k-tools">${kChip("Abbrechen", false, "data-k-zurueck")}<button class="action" data-k-bis-ok ${b.apps.length ? "" : "disabled"}>Sperre festlegen</button></div>`);
}
function kShorts(){
  const s = K.tr?.schutz || {};
  return kMain("SPERRE", "Reels, Shorts und Explore", `<label class="k-switch"><span>Kurzvideos sperren<small>Reels, Shorts, Explore und Für dich</small></span><input type="checkbox" data-k-schutz="kurzvideos" ${s.kurzvideos ? "checked" : ""}></label>`
    + (K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>` : "") + kNote("Ausschalten", "Einschalten wirkt sofort. Ausschalten geht nur, wenn Lockern frei ist (12 Std Wartezeit)."));
}
const K_SCHUTZ = [["bilder","Bild-KI","Social Media · Beta","▧"],["texte","Erotische Texte","Erkennung","≋"],["zeichnungen","Hentai und Zeichnungen","Erkennung","◇"],["kiBegleiter","KI-Begleiter","Erkennung","✦"],
  ["geschichten","Geschichten und Audio","Erkennung","♪"],["vpn","VPN-Erkennung","Umgehung","⌁"],["inApps","Erwachsenes in Apps","Erkennung","▣"],["webcam","Zufalls-Chats","Erkennung","◎"],["nurStore","Nur Apps aus dem Play Store","Android","▤"]];
function kProtection(){
  const s = K.tr?.schutz || {}, an = K_SCHUTZ.filter(([k]) => s[k]).length;
  return `<div class="lock"><div class="page-title"><div class="overline">DEIN SCHUTZ</div><h2>Schutz</h2><p>Inhalte und schwache Momente abfangen.</p></div>${kLockTabs("protection")}
   <div class="safety-hero"><div><div class="overline">INHALTSSCHUTZ</div><h3>${s.liste !== false ? "Schutz ist aktiv." : "Schutz ist aus."}</h3><p>${an} von ${K_SCHUTZ.length} Bereichen an${K.tr?.profil?.pornoSchutz === false ? " · Porno-Schutz zählt nur" : ""}.</p></div><div class="safety-mark">◈</div></div>
   <div class="section-head"><h3>Was geschützt wird</h3><span>${K_SCHUTZ.length} Bereiche</span></div><div class="protection-grid">
   ${K_SCHUTZ.map(([k, t, sub, g]) => `<button class="protect-tile" data-k-schutzd="${k}"><span class="block-icon">${g}</span><b>${t}</b><small>${s[k] ? "an" : "aus"} · ${sub}</small></button>`).join("")}
   <button class="protect-tile" data-k-alt="innehalten"><span class="block-icon">◷</span><b>Pause vor dem Öffnen</b><small>${K.tr?.innehalten?.an ? "an" : "aus"} · kurz innehalten</small></button></div>
   <div class="lock-links">${kJump("Vertrauensperson", "Begleitung bei Änderungen", "trusted", "♙")}${kJump("Schutz vor Deinstallieren", window.CockpitApp ? "Löschen erschweren" : "auf Mac und Windows-PC", "uninstall", "⌫")}</div></div>`;
}
function kSchutzDetail(){
  const k = K.schutzKey, e = K_SCHUTZ.find(x => x[0] === k) || K_SCHUTZ[0], s = K.tr?.schutz || {}, fest = (s.immer || []).includes(k);
  return kMain("SCHUTZ", e[1], `<label class="k-switch"><span>${e[1]}<small>${fest ? "Fest an, gehört zum Grundschutz" : e[2]}</small></span><input type="checkbox" data-k-schutz="${k}" ${s[k] ? "checked" : ""} ${fest ? "disabled" : ""}></label>`
    + (K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>${/Wartezeit|lockern/i.test(K.hinweis) && !(K.lk?.wartet > 0) ? `<button class="sub-chip" data-k-lk="warten">Lockern beantragen · frühestens ${kFrühestens()}</button>` : ""}` : "")
    + kNote("So wirkt es", "Einschalten wirkt sofort auf allen Geräten. Ausschalten geht nur, wenn Lockern frei ist."));
}
function kDevices(){
  if (!K.laedt.info && Date.now() - (K.zeit.info || 0) > 30000) setTimeout(() => kHole("info", "api/handy-info").then(() => K.v === "devices" && kZeichnen()), 0);
  const info = K.info || {}, hier = kGeraetHier(), liste = [...(info.geraete || [])];
  // john 20.11.: Mac fehlte. handy-info nennt nur Handys; läuft der Server auf dem Mac/PC (modus ≠ handy), ist er die Zentrale
  if (info.modus === "handy") (typeof SYNC !== "undefined" && SYNC.konto?.geraete || []).forEach(x => { if (x.name && !x.dieses && !liste.some(g => g.name === x.name)) liste.push({name:x.name, letzterSync:x.zuletzt}); });   // nur ohne Mac-Zentrale: Konto-Namen weichen sonst ab (doppelt)
  if (info.modus && info.modus !== "handy" && !liste.some(g => g.name === "Mac")) liste.unshift({name:"Mac", zentrale:true, label:info.modus === "mac" ? K.tr?.pc || "Mac" : "BlockEm-Server"});
  if (!liste.some(g => g.name === hier)) liste.unshift({name:hier, hier:true});
  const zeile = g => { const alt = g.letzterSync ? (Date.now() - new Date(g.letzterSync)) / 6e4 : null, stale = alt != null && alt > 120;
    return `<div class="device-card"><span class="block-icon">${/mac|pc|windows/i.test(g.name) ? "▣" : "▯"}</span><div><b>${kEsc(g.label || kGeraetText(g.name))}${g.name === hier ? " · dieses Gerät" : ""}</b><small>${g.zentrale || (g.name === "Mac" && g.name === hier && info.modus && info.modus !== "handy") ? "Zentrale · verbindet deine Geräte" : g.letzterSync ? `letzter Abgleich ${kZeitpunkt(new Date(g.letzterSync).getTime())}` : g.name === hier ? "Schutz und Bildschirmzeit" : "noch kein Abgleich"}</small></div><span class="device-state">${stale ? "PRÜFEN" : "AKTIV"}</span></div>`; };
  return `<div class="lock"><div class="page-title"><div class="overline">DEIN SCHUTZ</div><h2>Geräte</h2><p>Wo BlockEm gerade wirkt.</p></div>${kLockTabs("devices")}
   <div class="section-head"><h3>Verbunden</h3><span>${liste.length} ${liste.length === 1 ? "Gerät" : "Geräte"}</span></div>${liste.map(zeile).join("")}
   ${liste.some(g => g.letzterSync && (Date.now() - new Date(g.letzterSync)) / 6e4 > 120) ? kNote("Abgleich unterbrochen", "Ein Gerät hat sich länger nicht gemeldet. Es sperrt mit dem letzten Stand weiter. Öffne BlockEm dort einmal, dann gleicht es ab.", "warn") : ""}
   <button class="action full" data-k-alt="speicherort" style="margin:calc(12px*var(--k)) 0">Weiteres Gerät verbinden</button>
   <div class="section-head"><h3>Direkter Zugriff</h3></div>
   <div class="lock-links">${kJump("Berechtigungen", window.CockpitApp ? "auf diesem Handy" : "auf diesem Computer", "permissions", "✓")}${kJump("Systemcheck", "Schutzdienste und Updates", "", "✳", 'data-k-alt="status"')}${kJump("Schutz vor Deinstallieren", window.CockpitApp ? "Löschen erschweren" : "nur Mac und Windows-PC", "uninstall", "⌫")}</div></div>`;
}
function kPermissions(){
  if (window.CockpitApp?.rechte){
    const r = handyRechte(), z = (ok, t, s) => `<div class="k-switch"><span>${t}<small>${s}</small></span><b class="${ok ? "k-ok" : "k-fehler"}">${ok ? "erteilt" : "fehlt"}</b></div>`;
    return kMain("GERÄTE", "Berechtigungen", z(r.nutzung, "Nutzungsdaten", "für Werte und Tageslimits") + z(r.sperre, "Bedienungshilfe", "zum Sperren und Abdecken") + z(r.schutz, "Löschen erschweren", "Geräteadministrator")
      + `<button class="action full" data-k-rechte style="margin-top:calc(16px*var(--k))">${r.nutzung && r.sperre ? "Einstellungen öffnen" : "Fehlende Freigabe nachholen"}</button>` + kNote("Zurück zu BlockEm", "Nach dem Erteilen kommst du mit der Zurück-Taste hierher. Der Status aktualisiert sich von selbst."));
  }
  const pc = K.tr?.pc || (/Win/.test(navigator.platform) ? "Windows-PC" : "Mac");
  return kMain("GERÄTE", "Berechtigungen", kNote(pc === "Mac" ? "Mac" : "Windows-PC", pc === "Mac" ? "BlockEm braucht am Mac Bedienungshilfen und Automation (Chrome/Safari), für die Bild-KI zusätzlich Bildschirmaufnahme. Die Freigaben stehen in Systemeinstellungen › Datenschutz & Sicherheit." : "BlockEm braucht den Schutzdienst und den Autostart. Beides richtet der Systemcheck ein.")
    + kJump("Systemcheck öffnen", "Schutzdienste prüfen", "", "✳", 'data-k-alt="status"'));
}
function kUninstall(){
  if (window.CockpitApp?.schutzAn) return kMain("GERÄTE", "Löschen erschweren", kNote("Android", "BlockEm wird Geräteadministrator. Deinstallieren geht dann nur über BlockEm, mit Wartezeit.") + `<button class="action full" data-k-schutzan>Einrichten</button>`);
  return kMain("GERÄTE", "Schutz vor Deinstallieren", kNote("Am Computer", "BlockEm lässt sich dann nur mit Wartezeit entfernen.") + `<button class="action full" data-k-alt="schutzpc">Einrichten oder Status ansehen</button>`);
}

/* ---------- Werte ---------- */
function kGeraetDaten(day, name){   // Summen eines Tages, auf ein Gerät gefiltert
  if (!day) return null; if (!name) return {summe:day.summe || {}, stunden:day.stunden || [], apps:day.apps || []};
  const g = (day.geraete || []).find(x => x.name === name); if (!g) return {summe:{produktiv:0, neutral:0, prokrastination:0, afk:0}, stunden:[], apps:[]};
  const afk = (g.stunden || []).reduce((s, h) => s + (h?.[3] || 0), 0);
  return {summe:{produktiv:g.produktiv || 0, neutral:g.neutral || 0, prokrastination:g.prokrastination || 0, afk}, stunden:g.stunden || [], apps:g.apps || []};
}
function kTagesteile(stunden){
  const teile = [["Morgen","6–12 Uhr",[6,7,8,9,10,11]],["Mittag","12–17 Uhr",[12,13,14,15,16]],["Abend","17–22 Uhr",[17,18,19,20,21]],["Nacht","22–6 Uhr",[22,23,0,1,2,3,4,5]]];
  const w = teile.map(([n, t, hs]) => [n, t, [0,1,2].map(k => hs.reduce((s, h) => s + (stunden?.[h]?.[k] || 0), 0))]);
  const max = Math.max(1, ...w.map(x => x[2][0] + x[2][1] + x[2][2]));
  return w.map(([n, t, v]) => `<div class="daypart" aria-label="${n} ${t}"><span class="name"><b>${n}</b><small>${t}</small></span><span class="mix"><i style="width:${100 * v[0] / max}%"></i><i class="neutral" style="width:${100 * v[1] / max}%"></i><i class="away" style="width:${100 * v[2] / max}%"></i></span><span class="dur">${kStd(v[0] + v[1] + v[2])}</span></div>`).join("");
}
const kAppName = n => String(n || "").replace(/ \((Handy|Mac|PC|Windows-PC|Tablet)\)$/, "");   // Server hängt „(Handy)“ an; dieselbe App auf mehreren Geräten zählt zusammen
const K_KATS = [["produktiv","Produktiv"],["neutral","Neutral"],["prokrastination","Ablenkung"]];
function kUmstufen(name, kat){   // 24.11. (john): App antippen und selbst einordnen; raus aus Ablenkung wartet wie jedes Lockern
  const g = K.katGeplant?.[kLow(name)] || K.lk?.geplant?.["kat:" + kLow(name)];
  return `<div class="k-umstufen">${g ? `<p class="small">Beantragt: zählt ${kEsc(g.abText)} als ${kEsc(K_KATS.find(x => x[0] === g.kat)?.[1] || (g.satz || "").split(" als ").pop())}.</p>` : ""}<div class="chip-wrap">${K_KATS.map(([k, t]) => kChip(t, k === kat, `data-k-kat="${k}" data-k-kat-app="${kEsc(name)}"`)).join("")}</div>`
    + (kat === "prokrastination" ? `<p class="small">Rein in Ablenkung gilt sofort, raus erst nach ${kWarteText()} Wartezeit.</p>` : "") + `</div>`;
}
function kRangliste(titel, apps, ton, kat){
  const m = new Map(); apps.forEach(a => { const n = kAppName(a.name); m.set(n, (m.get(n) || 0) + (a.sek || 0)); });
  const l = [...m].map(([name, sek]) => ({name, sek})).filter(a => a.sek >= 60).sort((a, b) => b.sek - a.sek);
  const zeile = a => `<button class="k-rank" data-k-umstufen="${kEsc(a.name)}" aria-expanded="${K.umstufen === a.name}">${kernIcon(a.name)}<span>${kEsc(a.name)}</span><b>${kHm(a.sek)}</b><span class="k-bar"><i class="${ton}" style="width:${100 * a.sek / l[0].sek}%"></i></span></button>${K.umstufen === a.name ? kUmstufen(a.name, kat) : ""}`;
  return kSection(titel, l.slice(0, 3).map(zeile).join("") + (l.length > 3 ? `<details class="k-mehr"><summary>${l.length - 3} weitere</summary>${l.slice(3).map(zeile).join("")}</details>` : "") || `<p class="k-leer">Keine Nutzung erfasst.</p>`);
}
function kRanglisten(apps){ return kRangliste("Produktiv", apps.filter(a => a.kat === "produktiv"), "tone-0", "produktiv") + kRangliste("Neutral", apps.filter(a => a.kat === "neutral"), "tone-1", "neutral") + kRangliste("Ablenkung", apps.filter(a => a.kat === "prokrastination"), "tone-2", "prokrastination")
  + `<p class="small" style="margin-top:calc(8px*var(--k))">Tippe eine App an, um sie selbst einzuordnen.</p>`; }
function kPerioden(a){ return `<div class="period-tabs">${[["values","Heute"],["valuesWeek","Woche"],["valuesReview","Rückblick"]].map(([v, t]) => `<button data-k-periode="${v}" class="${a === v ? "sel" : ""}" aria-pressed="${a === v}">${t}</button>`).join("")}</div>`; }
function kGeraetePillen(){
  const namen = [...new Set((K.day?.geraete || []).map(g => g.name))];
  if (namen.length < 2) return "";
  return `<div class="device-pills">${["", ...namen].map(n => `<button data-k-wger="${kEsc(n)}" class="${K.geraet === n ? "sel" : ""}" aria-pressed="${K.geraet === n}">${n ? kEsc(n) : "Alle Geräte"}</button>`).join("")}</div>`;
}
function kValues(){
  const d = kGeraetDaten(K.day, K.geraet), s = d?.summe || {};
  if (!K.day) return kMain("DEINE ZEIT · HEUTE", "Werte", kPerioden("values") + `<p class="k-leer">${K.offline ? "Keine Verbindung, noch keine Werte geladen." : "Werte werden geladen …"}</p>`);
  const neutral = s.neutral || 0, geraete = (K.day.geraete || []).filter(g => g.sek > 0);
  return kMain("DEINE ZEIT · HEUTE", "Werte", kPerioden("values")
    + `<div class="values-block"><h3>${K.geraet ? kEsc(K.geraet) : "Alle Geräte"}</h3>${kGeraetePillen()}<div class="numbers"><div><b>${kHm(s.produktiv)}</b><small>Produktiv</small></div><div><b>${kHm(s.prokrastination)}</b><small>Ablenkung</small></div><div><b>${kHm(s.afk)}</b><small>Nicht am Gerät</small></div></div><p class="small" style="margin-top:calc(8px*var(--k))">Neutral ${kHm(neutral)} · ${kDatum(new Date())}</p></div>`
    + `<div class="values-block"><h3>Dein Tag · ${K.geraet ? kEsc(K.geraet) : "alle Geräte"}</h3>${kTagesteile(d.stunden)}${kLegende()}</div>`
    + (!K.geraet && geraete.length > 1 ? kSection("Geräte", geraete.map(g => `<details class="device-sum"><summary>${kEsc(g.name)}<b>${kHm(g.sek)}</b></summary><div class="time-summary"><div><small>Produktiv</small><b>${kHm(g.produktiv)}</b></div><div><small>Neutral</small><b>${kHm(g.neutral)}</b></div><div><small>Ablenkung</small><b>${kHm(g.prokrastination)}</b></div></div></details>`).join("")) : "")
    + kRanglisten(d.apps));
}
async function kWocheLaden(){
  if (K.laedt.week || K.wocheLaedt) return; K.wocheLaedt = true;
  try { if (!K.week || Date.now() - (K.zeit.week || 0) > 300000) await kHole("week", "api/week", 0); }
  finally { K.wocheLaedt = false; }
  if (!K.week) return kZeichnen();
  if (K.geraet){ const tage = (K.week?.tage || []).map(t => t.date); await Promise.all(tage.map(t => kTagLaden(t))); }
  kZeichnen();
}
async function kTagLaden(datum){
  if (K.tage[datum] && (datum !== kIso(new Date()) || Date.now() - K.tage[datum].t < 60000)) return K.tage[datum].d;
  if (K.tagFehlt[datum] && Date.now() - K.tagFehlt[datum] < 60000) return null;
  try { const d = await api("api/today?date=" + datum); K.tage[datum] = {d, t:Date.now()}; delete K.tagFehlt[datum]; return d; } catch { K.tagFehlt[datum] = Date.now(); return null; }
}
function kWochenTage(){
  return (K.week?.tage || []).slice(-7).map(t => {
    if (!K.geraet) return {date:t.date, v:[t.produktiv || 0, t.neutral || 0, t.prokrastination || 0]};
    const d = kGeraetDaten(K.tage[t.date]?.d, K.geraet)?.summe || {}; return {date:t.date, v:[d.produktiv || 0, d.neutral || 0, d.prokrastination || 0]};
  });
}
function kSaeulen(rows, gestapelt, aktiv){
  const max = Math.max(1, ...rows.map(r => gestapelt ? r.v[0] + r.v[1] + r.v[2] : Math.max(r.v[0], r.v[2])));
  return `<div class="trend-scroll"><div class="trend ${gestapelt ? "stacked" : "paired"}${rows.length > 7 ? " monat" : ""}" style="--days:${rows.length}">${rows.map((r, i) => {
    const d = new Date(r.date + "T12:00:00"), lab = rows.length > 7 ? String(d.getDate()) : d.toLocaleDateString("de-DE", {weekday:"short"}).slice(0, 2);
    const bars = (gestapelt ? [2,1,0] : [0,2]).map(k => `<i class="tone-${k}" style="height:${100 * r.v[k] / max}%"></i>`).join("");
    const besch = `${d.toLocaleDateString("de-DE", {weekday:"long", day:"numeric", month:"long"})} · Produktiv ${kHm(r.v[0])}, Neutral ${kHm(r.v[1])}, Ablenkung ${kHm(r.v[2])}`;
    return gestapelt ? `<button class="trend-day" data-k-wtag="${i}" aria-pressed="${aktiv === i}" aria-label="${besch}"><span>${bars}</span><small>${lab}</small></button>` : `<div class="trend-day" title="${besch}"><span>${bars}</span><small>${lab}</small></div>`; }).join("")}</div></div>`;
}
const kLegende = () => `<div class="activity-key"><span><i class="tone-0"></i>Produktiv</span><span><i class="tone-1"></i>Neutral</span><span><i class="tone-2"></i>Ablenkung</span></div>`;
const kSumme = v => `<div class="time-summary"><div><small>Produktiv</small><b>${kStd(v[0])} Std</b></div><div><small>Neutral</small><b>${kStd(v[1])} Std</b></div><div><small>Ablenkung</small><b>${kStd(v[2])} Std</b></div></div>`;
function kValuesWeek(){
  const fehlt = !K.week || (K.geraet && !(K.week.tage || []).every(t => K.tage[t.date]));
  if (fehlt && (K.fehlt.week || (K.week && K.week.tage.some(t => K.tagFehlt[t.date])))) return kMain("DEINE ZEIT", "Woche", kPerioden("valuesWeek") + `<p class="k-fehler">Die Woche ließ sich gerade nicht laden.</p>${kChip("Erneut versuchen", false, "data-k-neu")}`);
  if (fehlt){ setTimeout(kWocheLaden, 0); return kMain("DEINE ZEIT", "Woche", kPerioden("valuesWeek") + `<p class="k-leer">Woche wird geladen …</p>`); }
  const rows = kWochenTage(); if (!rows.length) return kMain("DEINE ZEIT", "Woche", kPerioden("valuesWeek") + `<p class="k-leer">Noch keine Werte in dieser Woche.</p>`);
  const i = Math.min(K.wTag, rows.length - 1), r = rows[i], all = [0,1,2].map(k => rows.reduce((s, x) => s + x.v[k], 0)), d = new Date(r.date + "T12:00:00");
  const tag = K.tage[r.date]?.d; if (!tag && !K.tagFehlt[r.date] && !K.laedt["tag" + r.date]){ K.laedt["tag" + r.date] = true; kTagLaden(r.date).then(() => { K.laedt["tag" + r.date] = false; if (K.v === "valuesWeek") kZeichnen(); }); }
  const td = kGeraetDaten(tag, K.geraet);
  return kMain("DEINE ZEIT", "Woche", kPerioden("valuesWeek") + kGeraetePillen()
    + kSection("Letzte 7 Tage", kSaeulen(rows, true, i) + kLegende() + kSumme(all))
    + `<section class="sub-section"><div class="section-head"><h3>${d.toLocaleDateString("de-DE", {weekday:"short", day:"2-digit", month:"2-digit"}) + (r.date === kIso(new Date()) ? " · Heute" : "")}</h3><div class="rb-pfeile"><button data-k-wtag="${Math.max(0, i - 1)}" aria-label="Tag davor" ${i ? "" : "disabled"}>‹</button><button data-k-wtag="${Math.min(rows.length - 1, i + 1)}" aria-label="Tag danach" ${i < rows.length - 1 ? "" : "disabled"}>›</button></div></div>`
    + kSumme(r.v) + `<p class="values-note">Bildschirmzeit ${kHm(r.v[0] + r.v[1] + r.v[2])}</p></section>`
    + (td && !K.geraet && (td.geraete || []).filter(g => g.sek > 0).length > 1 ? kSection("Geräte", td.geraete.filter(g => g.sek > 0).map(g => `<details class="device-sum"><summary>${kEsc(g.name)}<b>${kHm(g.sek)}</b></summary>${kSumme([g.produktiv || 0, g.neutral || 0, g.prokrastination || 0])}</details>`).join("")) : "")
    + (td ? kRanglisten(td.apps) : K.tagFehlt[r.date] ? `<p class="k-fehler">Die Apps dieses Tages ließen sich nicht laden.</p>` : `<p class="k-leer">Apps werden geladen …</p>`)
    + kJump("Wiederkehrende Zeiten", "Muster ansehen", "", "⌁", 'data-k-alt="muster"') + kJump("Rückblick", "Woche oder Monat", "valuesReview", "›"));
}
async function kRbLaden(){
  const key = K.rbArt + K.rbVersatz; if (K.rb[key]) return;
  const d = new Date(); if (K.rbArt === "woche") d.setDate(d.getDate() - 7 * (K.rbVersatz + 1)); else d.setMonth(d.getMonth() - (K.rbVersatz + 1), 15);
  try { K.rb[key] = await api(`api/rueckblick?art=${K.rbArt}&datum=${kIso(d)}`); } catch (e){ K.rb[key] = {fehler:e.message || String(e)}; }
  kZeichnen();
}
function kValuesReview(){
  const r = K.rb[K.rbArt + K.rbVersatz]; if (!r){ kRbLaden(); return kMain("DEINE ZEIT", "Rückblick", kPerioden("valuesReview") + `<p class="k-leer">Rückblick wird geladen …</p>`); }
  if (r.fehler) return kMain("DEINE ZEIT", "Rückblick", kPerioden("valuesReview") + `<p class="k-fehler">${kEsc(r.fehler)}</p><button class="sub-chip" data-k-rb-neu>Erneut versuchen</button>`);
  const rows = (r.tage || []).map(t => ({date:t.date, v:[t.produktiv || 0, t.neutral || 0, t.prokrastination || 0]})), v = [0,1,2].map(k => rows.reduce((s, x) => s + x.v[k], 0));
  const apps = [...(r.produktiv || []).map(a => ({...a, kat:"produktiv"})), ...(r.neutral || []).map(a => ({...a, kat:"neutral"})), ...(r.ablenkung || []).map(a => ({...a, kat:"prokrastination"}))];
  return kMain("DEINE ZEIT", "Rückblick", kPerioden("valuesReview")
    + `<div class="rb-steuer"><div class="rb-art">${["woche","monat"].map(a => `<button data-k-rbart="${a}" class="${K.rbArt === a ? "sel" : ""}" aria-pressed="${K.rbArt === a}">${a === "woche" ? "Woche" : "Monat"}</button>`).join("")}</div>`
    + `<div class="rb-pfeile"><button data-k-rb="1" aria-label="${K.rbArt === "woche" ? "Woche" : "Monat"} davor">‹</button><button data-k-rb="-1" aria-label="${K.rbArt === "woche" ? "Woche" : "Monat"} danach" ${K.rbVersatz ? "" : "disabled"}>›</button></div></div>`
    + `<h3 class="rb-titel">${kEsc(r.titel || "")}</h3>` + kSumme(v) + kSaeulen(rows, false) + `<div class="activity-key"><span><i class="tone-0"></i>Produktiv</span><span><i class="tone-2"></i>Ablenkung</span></div>`
    + kRanglisten(apps) + `<details class="device-sum"><summary>Alle Tage im Detail</summary>${kTagListe(rows)}</details>`
    + kJump("Wiederkehrende Zeiten", "Laufende Woche öffnen", "", "⌁", 'data-k-alt="muster"'));
}
function kTagListe(rows){   // Galerie activityList: je Tag eine Spur Produktiv/Neutral/Ablenkung
  const max = Math.max(1, ...rows.map(r => r.v[0] + r.v[1] + r.v[2])), namen = ["Produktiv","Neutral","Ablenkung"];
  return `<div class="activity-list">${rows.map(r => `<div class="activity-day"><span class="activity-date">${new Date(r.date + "T12:00:00").toLocaleDateString("de-DE", {weekday:"short", day:"2-digit", month:"2-digit"})}</span>${r.v[0] + r.v[1] + r.v[2] ? `<span class="activity-stats"><span class="activity-track">${r.v.map((v, i) => `<i class="tone-${i}" style="width:${100 * v / max}%"></i>`).join("")}</span><span class="activity-values">${r.v.map((v, i) => `<span title="${namen[i]}"><i class="tone-${i}"></i>${kHm(v)}</span>`).join("")}</span></span>` : "<small>nichts erfasst</small>"}</div>`).join("")}</div>`;
}

/* ---------- Weg ---------- */
function kJourney(){
  const s = K.tr?.sauber || {}, tage = s.tage || 0, g = kNaechstesGeschenk(), sp = [90,180,270,365].find(n => n > tage), mon = new Date().toLocaleDateString("de-DE", {month:"long"});
  const stil = (typeof STILE !== "undefined" ? STILE : []).find(x => x.k === kStilAktiv());
  return kMain("DEIN WEG", `Tag ${tage}`, kSection("Nächstes Geschenk", g ? kJump(g.name, `Tag ${g.tag} · noch ${g.noch} ${g.noch === 1 ? "Tag" : "Tage"}`, "gifts", "✦") : kNote("Alle Farben frei", "Du hast jede Farbe freigeschaltet."))
    + kSection("Spenden", kJump(sp ? (tage < 90 ? "Deine erste Spendenetappe" : "Nächste Spendenetappe") : "Alle Spendenetappen erreicht", sp ? `Tag ${sp} · noch ${sp - tage} Tage` : "Tag 365 erreicht", "donations", "♡") + kJump(`Gemeinsam im ${mon}`, "Monatsziel der Gemeinschaft", "community", "◎"))
    + kSection("Dein Weg", kJump("Abzeichen", "Deine nächsten Etappen", "badges", "✦") + kJump("Farbe der App", (stil?.t === "Orange" ? "Kern · Standard" : stil?.t || "Kern"), "colors", "◈") + kJump("Dein Warum", store("tue.warum") ? String(store("tue.warum")) : "Dein persönlicher Satz", "why", "♡"))
    + (!tage && s.gesamt ? kNote("Neuer Anfang", `Insgesamt ${s.gesamt} saubere Tage. Freigeschaltete Farben bleiben.`) : ""));
}
function kGifts(){
  const max = Math.max(+(store("stil.max") || 0), K.tr?.sauber?.tage || 0);
  return kMain("WEG", "Geschenke", (typeof STILE !== "undefined" ? STILE : []).map(x => kJump(x.t === "Orange" ? "Kern" : x.t, x.ab ? (max >= x.ab ? `frei seit Tag ${x.ab}` : `ab Tag ${x.ab}`) : "Ab Start", "colors", "◈")).join("") + kJump("Abzeichen", "Deine Etappen", "badges", "✦"));
}
function kColors(){
  const max = +(store("stil.max") || 0), akt = kStilAktiv(), farbe = {orange:"#d43e30", ozean:"#2f6fd9", smaragd:"#0f7f62", gold:"#b65f00", rose:"#c2477f"};
  return kMain("WEG", "Farbe der App", `<div class="k-swatches">${(typeof STILE !== "undefined" ? STILE : []).map(x => { const frei = x.ab <= max;
    return `<button class="k-swatch" data-k-stil="${x.k}" aria-pressed="${akt === x.k}" ${frei ? "" : "disabled"}><i style="background:${farbe[x.k] || x.farbe}"></i><span>${x.t === "Orange" ? "Kern" : x.t}<small>${x.ab ? (frei ? `frei seit Tag ${x.ab}` : `frei ab ${x.ab} sauberen Tagen`) : "Standard"}</small></span></button>`; }).join("")}</div>`
    + kNote("Bleibt frei", "Eine freigeschaltete Farbe bleibt auch nach einem Neuanfang."));
}
function kWhy(){
  return kMain("WEG", "Dein Warum", `<label class="form-label">Wofür machst du das?<textarea data-k-feld="warum" maxlength="140" placeholder="z. B. Für meine Familie">${kEsc(store("tue.warum") || "")}</textarea></label>
    <button class="action full" data-k-warum>Speichern</button><p class="small" style="margin-top:calc(10px*var(--k))">Ein Satz reicht. Er erscheint, wenn du den Panik-Knopf drückst. Er bleibt auf diesem Gerät.</p>`);
}
function kDonations(){
  const t = K.tr?.sauber?.tage || 0, belege = K.gm?.belege || {};
  return kMain("WEG", "Spenden", kNote(`${t} von ${[90,180,270,365].find(n => n > t) || 365} Tagen`, "Persönliche Etappen zählen Tage am Stück ohne Versuch. Das gilt auch ohne Porno-Schutz: Porno-Seiten werden dann nicht gesperrt, aber gezählt.")
    + kSection("Ab Veröffentlichung", [90,180,270,365].map(n => `<div class="flat-app"><b>Tag ${n}</b><small>${t >= n ? (kSicher(belege["tag" + n]) ? `<a href="${kEsc(belege["tag" + n])}" target="_blank" rel="noopener">Beleg ansehen</a>` : "erreicht · Spende folgt mit Beleg") : "vorgesehen"}</small></div>`).join(""))
    + kNote("Geplante Spende", "Vorgesehen sind 10 % des im Zeitraum gezahlten Beitrags. Du wählst die Organisation. Eine Spende gilt erst mit veröffentlichtem Beleg als erfolgt. Spenden starten mit der Veröffentlichung.")
    + kJump("Gemeinsames Monatsziel", "Anonyme Tage und Abstimmung", "community", "◎"));
}
async function kGmLaden(){ if (K.gmLaedt || Date.now() - (K.zeit.gm || 0) < (K.gm ? 300000 : 60000)) return; K.gmLaedt = true;
  try { K.gm = typeof gmAnfrage === "function" ? await gmAnfrage("stand") : null; K.zeit.gm = Date.now(); K.gmFehler = ""; } catch (e){ K.gmFehler = e.message || String(e); K.zeit.gm = Date.now(); }
  K.gmLaedt = false; if (K.v === "community") kZeichnen(); }
function kCommunity(){
  setTimeout(kGmLaden, 0); const g = K.gm, mon = new Date().toLocaleDateString("de-DE", {month:"long"});
  if (!g) return kMain("WEG", "Gemeinsam", K.gmFehler ? kNote("Gerade nicht erreichbar", kEsc(K.gmFehler)) + kChip("Erneut versuchen", false, "data-k-gm") : `<p class="k-leer">Wird geladen …</p>`);
  const n = x => Math.max(0, Math.round(+x || 0)), orgs = g.orgs || [], belege = Object.entries(g.belege || {}).filter(([, u]) => kSicher(u));
  return kMain("WEG", "Gemeinsam", kNote(mon, `${n(g.summe)} von ${n(g.ziel)} sauberen Tagen gemeinsam gesammelt · ${n(g.aktive)} machen mit.`) + `<div class="k-progress"><i style="width:${Math.min(100, 100 * (g.summe || 0) / Math.max(1, g.ziel || 1))}%"></i></div>`
    + kSection("Monatsziel", kNote(g.erreicht ? "Ziel erreicht" : `Noch ${Math.max(0, (g.ziel || 0) - (g.summe || 0))} Tage`, "Das Ziel richtet sich nach der Teilnehmerzahl. Ein verfehlter Topf geht in das nächste Ziel über." + (g.topf ? ` Im Topf: ${kEsc(g.topf)}.` : "")))
    + kSection("Organisation", orgs.length ? orgs.map(o => kChip(`${g.meineStimme === o.k ? "✓ " : ""}${kEsc(o.name)} · ${n(o.stimmen)}`, g.meineStimme === o.k, `data-k-stimme="${kEsc(o.k)}"`)).join("") : kNote("Noch keine Organisation zur Wahl", "Sobald die Liste vorliegt, kannst du nach einem sauberen Tag eine Stimme abgeben und ändern."))
    + kSection("Belege", belege.length ? belege.map(([k, u]) => `<a class="sub-row" href="${kEsc(u)}" target="_blank" rel="noopener"><span class="sub-text"><b>${kEsc(k)}</b><small>Quittung ansehen</small></span><span class="sub-chevron">›</span></a>`).join("") : `<p class="k-leer">Noch keine Spende ausgezahlt. Ein erreichtes Ziel bekommt hier erst mit Quittung einen Beleg.</p>`)
    + (K.hinweis ? `<p class="k-fehler">${kEsc(K.hinweis)}</p>` : ""));
}
function kBadges(){
  const s = K.tr?.sauber || {}, t = s.tage || 0, best = Math.max(s.beste || 0, t);
  return kMain("WEG", "Abzeichen", kNote(`Tag ${t}`, `Dein aktueller Stand · bester Lauf ${best} ${best === 1 ? "Tag" : "Tage"}`) + `<div class="k-badges">${[7,14,30,90,180,365].map(n => `<div class="${best >= n ? "da" : ""}"><b>${n}</b>${best >= n ? "erreicht" : `noch ${n - t}`}</div>`).join("")}</div>`);
}

/* ---------- Einstellungen ---------- */
function kUpdateNeu(){   // bekannte neuere Version aus dem Update-Check (alle 6 Std, update-fenster/bedienung.js), sonst ""
  const A = window.CockpitApp, v = kUpdateKann() ? updateOnline(true)?.version : "";   // nurGemerkt: fragt höchstens alle 6 Std, ein paar Sekunden später
  return v && A?.version && typeof vAelter === "function" && vAelter(A.version(), v) ? v : "";
}
const kUpdateKann = () => !!window.CockpitApp?.http && !window.CockpitApp.play?.() && typeof updateSuchen === "function";
// Play-Fassung (john 25.11.): Google Play meldet über die App, ob ein Update bereitsteht (In-App Updates, flexibel). Stand: "" · da · laedt · fertig
function kPlayUpd(){ if (!K.playUpd){ try { K.playUpd = JSON.parse(window.CockpitApp?.playUpdate?.() || "{}"); } catch { K.playUpd = {}; } } return K.playUpd.stufe ? K.playUpd : null; }
window.__playUpd = s => { K.playUpd = s || {}; if (K.v === "today" || K.v === "settings") kZeichnen(); };
const kPlayText = p => p.stufe === "da" ? ["Update ist da · jetzt laden", "Update laden", "Neue Version im Play Store. BlockEm läuft beim Laden weiter."]
  : p.stufe === "laedt" ? [`Update wird geladen · ${p.prozent || 0} %`, `Update wird geladen · ${p.prozent || 0} %`, "Du kannst BlockEm weiter nutzen."]
  : ["Update geladen · jetzt neu starten", "Neu starten und Update installieren", "BlockEm startet dabei kurz neu."];
function kPlayUpdHeute(){ const p = window.CockpitApp?.play?.() && kPlayUpd(); if (!p) return "";
  return `<button class="attempt-line k-upd-da" data-k-play-upd><span>${kEsc(kPlayText(p)[0])}</span><span>${p.stufe === "laedt" ? "" : "›"}</span></button>`; }
function kUpdateZeile(){   // john 20.11.: Update-Knopf in der GitHub-Fassung (Play aktualisiert selbst, zeigt aber ab 25.11. den Stand aus Google Play)
  const p = window.CockpitApp?.play?.() && kPlayUpd();
  if (p){ const t = kPlayText(p); return `<button class="sub-row k-upd-da" data-k-play-upd><span class="sub-glyph">↻</span><span class="sub-text"><b>${kEsc(t[1])}</b><small>${kEsc(t[2])}</small></span><span class="sub-chevron">${p.stufe === "laedt" ? "" : "›"}</span></button>`; }
  if (!kUpdateKann()) return "";
  const neu = kUpdateNeu();
  return `<button class="sub-row ${neu ? "k-upd-da" : ""}" data-k-update><span class="sub-glyph">↻</span><span class="sub-text"><b>${neu ? `Update auf ${kEsc(neu)} installieren` : "Nach Updates suchen"}</b><small>Du hast ${kEsc(CockpitApp.version?.() || "")}</small></span><span class="sub-chevron">›</span></button>`;
}
function kSettings(){
  const pro = window.CockpitApp?.kasse || typeof kaOeffnen === "function";
  return kMain("BLOCKEM", "Einstellungen", kUpdateZeile() + kSection("Du", kJump("Profil", "Name und App-Farbe", "profile", "♙") + kJump("Aussehen", "Hell, dunkel, Sprache", "appearance", "◈"))
    + kSection("Schutz", kJump("Vertrauensperson", "Begleitung bei Änderungen", "trusted", "♡") + kJump("Mitteilungen", "Fokus und Geschenke", "notifications", "◔"))
    + kSection("Geräte & Daten", kJump("Geräte & Konto", "verbinden und abgleichen", "", "▯", 'data-k-alt="speicherort"') + kJump("Daten & Export", "Export und Sicherung", "export", "↗") + kJump("Berechtigungen", window.CockpitApp ? "Rechte dieses Handys" : "Rechte dieses Computers", "permissions", "✓") + kJump("Systemcheck", "Schutz und Verbindung", "", "✳", 'data-k-alt="status"'))
    + kSection("BlockEm", (pro ? kJump("BlockEm Pro", "Status und Abo", "pro", "✦") : "") + kJump("Datenschutz", "Was dein Gerät verlässt", "", "⌑", 'data-k-alt="datenweg"') + `<p class="small" style="margin-top:calc(12px*var(--k))">BlockEm ${kEsc(K.tr?.version || (typeof APP_VERSION !== "undefined" ? APP_VERSION : ""))}${window.CockpitApp?.version ? " · App " + kEsc(CockpitApp.version()) : ""}</p>`));
}
function kProfile(){
  return kMain("EINSTELLUNGEN", "Profil", `<label class="form-label">Name<input type="text" data-k-feld="name" maxlength="40" value="${kEsc(S?.plan?.profil?.name || K.tr?.name || "")}"></label><label class="form-label">Anrede<select data-k-anrede>${["Keine Anrede","Du","Sie"].map(n => `<option ${n === (store("kern.anrede") || "Keine Anrede") ? "selected" : ""}>${n}</option>`).join("")}</select></label><button class="action full" data-k-name>Speichern</button>` + kJump("Farbe der App", (typeof STILE !== "undefined" && STILE.find(x => x.k === kStilAktiv())?.t) || "Kern", "colors", "◈") + (K.hinweis ? `<p class="k-fehler">${kEsc(K.hinweis)}</p>` : ""));
}
function kAppearance(){
  const t = store("kern.thema") || "System";
  const sp = store("kern.sprache") || "";   // 24.11.: Deutsch/Englisch, leer = Systemsprache
  return kMain("EINSTELLUNGEN", "Aussehen", kSection("Darstellung", `<div class="chip-wrap">${["System","Hell","Dunkel"].map(n => kChip((n === t ? "✓ " : "") + n, n === t, `data-k-thema="${n}"`)).join("")}</div>`)
    + kSection("Sprache", `<div class="chip-wrap">${[["", "System"], ["de", "Deutsch"], ["en", "English"]].map(([k, n]) => kChip((k === sp ? "✓ " : "") + n, k === sp, `data-k-sprache="${k}" translate="no"`)).join("")}</div>`) + kJump("Farbe der App", (typeof STILE !== "undefined" && STILE.find(x => x.k === kStilAktiv())?.t) || "Kern", "colors", "◈"));
}
function kNotifications(){
  const h = S?.plan?.automatik?.hinweise !== false, m = store("tue.morgen") !== false;
  return kMain("EINSTELLUNGEN", "Mitteilungen", `<label class="k-switch"><span>Hinweise<small>Fokus-Ende, Limits und Erinnerungen</small></span><input type="checkbox" data-k-hinweise ${h ? "checked" : ""}></label>`
    + (window.CockpitApp?.tuerchenMorgen ? `<label class="k-switch"><span>Morgens Bescheid sagen<small>wenn ein neues Geschenk da ist</small></span><input type="checkbox" data-k-morgen ${m ? "checked" : ""}></label>` : ""));
}
function kExport(){
  return kMain("EINSTELLUNGEN", "Daten & Export", kNote("Export", "Alle Regeln, Werte und Einstellungen als ZIP-Datei, zum Beispiel für ein neues Gerät.") + `<button class="action full" data-k-export>Daten exportieren</button>`
    + kNote("Automatische Sicherung", "BlockEm sichert jede Nacht von selbst. Du musst nichts tun.") + (K.hinweis ? `<p class="k-fehler">${kEsc(K.hinweis)}</p>` : ""));
}
function kTrusted(){
  if (window.CockpitApp?.begAnfrage && typeof vpOeffnen === "function") { setTimeout(() => { kZurueck(); vpOeffnen(); }, 0); return ""; }
  return kMain("SCHUTZ", "Vertrauensperson", kNote("Am Handy einrichten", "Die Vertrauensperson verbindest du in der BlockEm-App am Handy. Sie erfährt nur, wenn der Schutz abgeschaltet wird, nie was du ansiehst."));
}
function kPro(){
  if (typeof kaOeffnen === "function" && window.CockpitApp?.kasse) { setTimeout(() => { kZurueck(); kaOeffnen(); }, 0); return ""; }
  return kMain("EINSTELLUNGEN", "BlockEm Pro", kNote("Diese Fassung", "In dieser Fassung sind alle Funktionen frei. BlockEm Pro kaufst du in der Play-Store-App."));
}
const K_SEITEN = {today:kToday, attempts:kAttempts, panic:kPanik, focus:kFocus, focusDevices:kFocusDevices, active:kActive, result:kResult, picker:kPicker,
  lock:kLock, schedule:kSchedule, timeRule:kTimeRule, limits:kLimitsSeite, limitsHeute:kLimitsSeite, limitEdit:kLimitEdit, groups:kGroupsSeite, groupEdit:kGroupEdit,
  binding:kBinding, newBinding:kNewBinding, shorts:kShorts, protection:kProtection, schutzDetail:kSchutzDetail, devices:kDevices, permissions:kPermissions, uninstall:kUninstall,
  values:kValues, valuesWeek:kValuesWeek, valuesReview:kValuesReview, journey:kJourney, gifts:kGifts, colors:kColors, why:kWhy, donations:kDonations, community:kCommunity,
  badges:kBadges, settings:kSettings, profile:kProfile, appearance:kAppearance, notifications:kNotifications, export:kExport, trusted:kTrusted, pro:kPro};

/* ---------- Bedienung ---------- */
const K_ALT = {   // ältere Detailseiten
  speicherort:["Geräte & Konto", () => { showTab("einstellungen"); esOeffnen("speicherort"); }],
  status:["Systemcheck", () => { showTab("einstellungen"); esOeffnen("status"); }],
  datenweg:["Datenschutz", () => { showTab("einstellungen"); esOeffnen("datenweg"); }],
  innehalten:["Pause vor dem Öffnen", () => { showTab("locker"); }],
  muster:["Wiederkehrende Zeiten", () => { showTab("werte"); try { wtZeigen("woche"); } catch {} setTimeout(() => document.querySelector(".mu-karte,.muster,[class*=muster]")?.scrollIntoView(), 300); }],
  schutzpc:["Schutz vor Deinstallieren", () => { if (typeof spOeffnen === "function") { document.documentElement.classList.remove("kern-alt"); spOeffnen(); } }]};
async function kKlick(e){
  const b = e.target.closest("[data-k],[data-k-nav],[data-k-zurueck],[data-k-alt],[data-k-alt-zu],[data-k-panik],[data-k-panik-fertig],[data-k-neu],[data-k-min],[data-k-art],[data-k-ger],[data-k-wahl],[data-k-fokus-start],[data-k-fger],[data-k-fger-ok],[data-k-menue],[data-k-ansicht],[data-k-app],[data-k-neu-app],[data-k-alle],[data-k-keine],[data-k-wahl-ab],[data-k-wahl-ok],[data-k-regel],[data-k-tag],[data-k-tage],[data-k-wer],[data-k-gsel],[data-k-auf],[data-k-weiter],[data-k-gedit],[data-k-geplant-ab],[data-k-zvor],[data-k-lmin],[data-k-gruppe-neu],[data-k-lkteil],[data-k-kreis],[data-k-pause-aus],[data-k-update],[data-k-play-upd],[data-k-neu-apps],[data-k-gregel],[data-k-rger],[data-k-regel-speichern],[data-k-regel-loeschen],[data-k-lk],[data-k-limit],[data-k-lger],[data-k-limit-speichern],[data-k-limit-loeschen],[data-k-gruppe],[data-k-gruppe-ab],[data-k-gruppe-speichern],[data-k-bis-weg],[data-k-bis-ab],[data-k-bis-ok],[data-k-bschnell],[data-k-schutzd],[data-k-rechte],[data-k-schutzan],[data-k-periode],[data-k-wger],[data-k-umstufen],[data-k-kat],[data-k-wtag],[data-k-rbart],[data-k-rb],[data-k-rb-neu],[data-k-stil],[data-k-warum],[data-k-gm],[data-k-stimme],[data-k-thema],[data-k-sprache],[data-k-name],[data-k-export]");
  if (!b || !(b.closest("#kern") || b.closest("#kernAltBar"))) return;
  if (b.tagName === "A") return;
  e.preventDefault(); e.stopPropagation(); const ds = b.dataset;
  if ("kAltZu" in ds){ document.documentElement.classList.remove("kern-alt"); kLaden(true); return; }
  if ("kNav" in ds){ kGeh(ds.kNav); kLaden(); if (ds.kNav === "values") kHole("day", "api/today", 60000).then(kZeichnen); return; }
  if ("kZurueck" in ds){ K.hinweis = ""; kSystemZurueck(); return; }
  if ("kAlt" in ds){ const a = K_ALT[ds.kAlt]; if (a) kAlt(a[0], a[1]); return; }
  if ("k" in ds){ if (ds.k) kGeh(ds.k); return; }
  if ("kNeu" in ds){ K.zeit = {}; K.fehlt = {}; K.tagFehlt = {}; await kLaden(true); if (K.v === "valuesWeek") kWocheLaden(); return; }
  if ("kPanik" in ds) return kPanikStart();
  if ("kPanikFertig" in ds){ const fertig = Date.now() - (K.panik?.start || 0) >= 120000; if (fertig) api("api/panik", {was:"geschafft"}).then(r => { if (r?.panik && K.tr) K.tr.panik = r.panik; }).catch(() => {}); K.panik = null; kGeh("today"); return; }
  if (ds.kMin){ K.fokusMin = +ds.kMin; store("cockpit.fokusMin", K.fokusMin); kZeichnen(); return; }
  if (ds.kArt){ let a = ds.kArt;   // „Alles“ allein, die drei Kategorien an/aus und kombinierbar
    if (a !== "Alles"){ const w = new Set(kFokusArten()); w.has(a) ? w.delete(a) : w.add(a); a = K_FOKUS_KAT.filter(x => w.has(x)).join("+"); }
    K.fokusArt = a; store("kern.fokusArt", a); kZeichnen(); return; }
  if (ds.kGer){ K.fokusGeraete = ds.kGer; store("kern.fokusGeraete", ds.kGer); kZeichnen(); return; }
  if (ds.kFger !== undefined){ const w = new Set(Array.isArray(K.fokusGeraete) ? K.fokusGeraete : []); w.has(ds.kFger) ? w.delete(ds.kFger) : w.add(ds.kFger); K.fokusGeraete = [...w]; kZeichnen(); return; }
  if ("kFgerOk" in ds){ store("kern.fokusGeraete", K.fokusGeraete); kZurueck(); return; }
  if ("kFokusStart" in ds){ b.disabled = true; return kFokusStarten(); }
  if (ds.kWahl){ const ctx = ds.kWahl, start = ctx === "focus" ? K.fokusApps : ctx === "rule" ? K.regel?.apps : ctx === "binding" ? K.bindung?.apps : ctx === "group" ? K.gruppe?.apps : K.limit?.apps;
    if (ctx === "focus" && K.fokusArt !== "Apps" && !K.fokusApps.length) return kWahlStart(ctx, [], K.v);
    return kWahlStart(ctx, start || [], K.v); }
  if ("kMenue" in ds){ K.wahl.menue = !K.wahl.menue; kZeichnen(); return; }
  if (ds.kAnsicht){ K.wahl.ansicht = ds.kAnsicht; K.wahl.menue = false; kZeichnen(); return; }
  if (ds.kApp){ const d = K.wahl.draft; d.has(ds.kApp) ? d.delete(ds.kApp) : d.add(ds.kApp); kZeichnen(); return; }
  if (ds.kNeuApp){ K.wahl.dazu.push(ds.kNeuApp); K.wahl.draft.add(ds.kNeuApp); K.wahl.such = ""; kZeichnen(); return; }
  if ("kAlle" in ds){ kTreffer().forEach(a => K.wahl.draft.add(a.name)); kZeichnen(); return; }
  if ("kKeine" in ds){ kTreffer().forEach(a => K.wahl.draft.delete(a.name)); kZeichnen(); return; }
  if ("kWahlAb" in ds) return kWahlFertig(false);
  if ("kWahlOk" in ds) return kWahlFertig(true);
  if (ds.kRegel){ return kRegelOeffnen(ds.kRegel === "neu" ? null : ds.kRegel); }
  const ziel = K.v === "limitEdit" ? K.limit : K.regel;   // Sperrzeit- oder Tageslimit-Editor
  if (ds.kTag && ziel){ const t = +ds.kTag; ziel.tage = ziel.tage.includes(t) ? ziel.tage.filter(x => x !== t) : [...ziel.tage, t]; kZeichnen(); return; }
  if (ds.kTage && ziel){ if (ds.kTage === "eigen") ziel.tageEigen = true; else { ziel.tageEigen = false; ziel.tage = ds.kTage.split(",").map(Number); } kZeichnen(); return; }
  if (ds.kWer && ziel){ ziel.wer = ds.kWer; if (ds.kWer === "gruppe" && !ziel.gwahl.length && !kBenannt().length) ziel.gwahl = ["+neu"]; K.hinweis = ""; kZeichnen(); return; }
  if (ds.kGsel && ziel){ const w = ziel.gwahl; ziel.gwahl = w.includes(ds.kGsel) ? w.filter(x => x !== ds.kGsel) : [...w, ds.kGsel]; K.hinweis = ""; kZeichnen(); return; }
  if (ds.kAuf && ziel){ const teile = kEdTeile(ziel, K.v === "limitEdit" ? "l" : "r").map(x => x[0]), i = teile.indexOf(ds.kAuf);
    if (ziel.id) ziel.auf = ziel.auf === ds.kAuf ? "" : ds.kAuf; else if (i >= 0 && i < ziel.schritt) ziel.schritt = i;
    K.hinweis = ""; kZeichnen(); return; }
  if ("kWeiter" in ds && ziel){ const k = kEdTeile(ziel, K.v === "limitEdit" ? "l" : "r")[ziel.schritt]?.[0], w = k === "wer" ? kWerListe(ziel) : null;
    K.hinweis = typeof w === "string" ? w : k === "tage" && !ziel.tage.length ? "Wähle mindestens einen Tag." : k === "wann" && ziel.von === ziel.bis ? "Von und Bis dürfen nicht gleich sein." : "";
    if (!K.hinweis) ziel.schritt++; kZeichnen(); return; }
  if (ds.kGedit){ const g = kGruppen().find(x => x.key === "g:" + ds.kGedit); if (!g) return;   // Mitglieder direkt aus dem Editor ändern, danach zurück hierher
    K.gruppe = {...g, apps:[...g.apps], start:[...g.apps]}; K.hinweis = ""; kGeh("groupEdit"); return kWahlStart("group", g.apps, "groupEdit"); }
  if (ds.kGeplantAb){ const x = await kPost("api/locker", {geplantAbbrechen:ds.kGeplantAb}, "Antrag abgebrochen."); if (x){ K.lk = x; K.zeit.lk = Date.now(); kZeichnen(); } return; }
  if (ds.kZvor && K.regel){ if (ds.kZvor === "eigen") K.regel.zeitEigen = true; else { K.regel.zeitEigen = false; [K.regel.von, K.regel.bis] = ds.kZvor.split("|"); } kZeichnen(); return; }
  if (ds.kLmin && K.limit){ if (ds.kLmin === "andere") K.limit.minEigen = true; else { K.limit.minEigen = false; K.limit.minuten = +ds.kLmin; } kZeichnen(); return; }
  if ("kPauseAus" in ds){ b.disabled = true;   // Entwicklerversion (john 20.11.): Pause per Knopf beenden; Server nimmt pauseBis nur mit ENTWICKLER an
    try { K.lk = await api("api/locker", {pauseBis:0}); K.zeit.lk = Date.now(); if (typeof vbSperreAbgleich === "function") vbSperreAbgleich().catch(() => {}); toast("Pause beendet, deine Regeln gelten wieder."); }
    catch (e){ toast(e.message || String(e)); }
    await kLaden(true); return; }
  if ("kUpdate" in ds){ if (typeof updateSuchen === "function") updateSuchen(); return; }
  if ("kPlayUpd" in ds){ const p = kPlayUpd(), A = window.CockpitApp;
    if (p?.stufe === "da") A.playUpdateLaden?.(); else if (p?.stufe === "fertig") A.playUpdateNeustart?.(); return; }
  if (ds.kKreis){ K.kreis = K.kreis === ds.kKreis ? "" : ds.kKreis; kZeichnen(); return; }
  if (ds.kLkteil){ K.lkTeil = ds.kLkteil; store("kern.lkTeil", ds.kLkteil); kZeichnen(); return; }
  if (ds.kNeuApps) return ds.kNeuApps === "zeit" ? kRegelOeffnen(null, {wer:"apps"}) : kLimitOeffnen(null, {wer:"apps"});
  if ("kGruppeNeu" in ds){ K.gruppe = {neu:true, key:"", name:"", apps:[], start:[], regeln:[]}; K.hinweis = ""; kGeh("groupEdit"); return; }
  if (ds.kGregel && K.gruppe){ const g = K.gruppe, n = (g.name || "").trim();
    if (g.neu && (!n || !g.apps.length)){ K.hinweis = !n ? "Gib der Gruppe einen Namen." : "Wähle die Apps für die Gruppe."; kZeichnen(); return; }
    const v = g.neu ? {wer:"gruppe", gwahl:["+neu"], gneu:n, apps:[...g.apps]} : g.key.startsWith("g:") ? {wer:"gruppe", gwahl:[g.name], g0:g.name} : {wer:"apps", apps:[...g.apps]};
    return ds.kGregel === "zeit" ? kRegelOeffnen(null, v) : kLimitOeffnen(null, v); }
  if (ds.kRger !== undefined){ const r = K.regel; r.geraete = !ds.kRger ? [] : r.geraete.includes(ds.kRger) ? r.geraete.filter(x => x !== ds.kRger) : [...r.geraete, ds.kRger]; kZeichnen(); return; }
  if ("kRegelSpeichern" in ds) return kRegelSpeichern();
  if ("kRegelLoeschen" in ds){ if (!b.dataset.sicher){ b.dataset.sicher = 1; b.textContent = "Wirklich entfernen? Nochmal tippen ›"; return; } const x = await kPost("api/locker", {loeschen:K.regel.id}, "Die Regel wird in 24 Std entfernt."); if (x){ K.lk = x; kZeichnen(); } return; }
  if (ds.kLk){ const x = await kPost("api/locker", {[ds.kLk]:true}); if (x){ K.lk = x; K.zeit.lk = Date.now(); K.hinweis = ds.kLk === "warten" ? `Beantragt. Lockern geht ${x.freiAbText || "nach der Wartezeit"}.` : ""; kZeichnen(); } return; }
  if (ds.kLimit){ return kLimitOeffnen(ds.kLimit === "neu" ? null : ds.kLimit); }
  if (ds.kLger !== undefined){ const l = K.limit; l.geraete = !ds.kLger ? [] : l.geraete.includes(ds.kLger) ? l.geraete.filter(x => x !== ds.kLger) : [...l.geraete, ds.kLger]; kZeichnen(); return; }
  if ("kLimitSpeichern" in ds) return kLimitSpeichern();
  if ("kLimitLoeschen" in ds){ if (!b.dataset.sicher){ b.dataset.sicher = 1; b.textContent = "Wirklich entfernen? Nochmal tippen ›"; return; } const x = await kPost("api/locker", {loeschen:K.limit.id}, "Das Limit wird in 24 Std entfernt."); if (x){ K.lk = x; kZeichnen(); } return; }
  if (ds.kGruppe){ const g = kGruppen().find(x => x.key === ds.kGruppe); if (g){ K.gruppe = {...g, apps:[...g.apps], start:[...g.apps]}; K.hinweis = ""; kGeh("groupEdit"); } return; }
  if ("kGruppeAb" in ds){ K.gruppe.apps = [...K.gruppe.start]; K.gruppe.dirty = false; K.hinweis = ""; kZeichnen(); return; }
  if ("kGruppeSpeichern" in ds) return kGruppeSpeichern();
  if (ds.kBisWeg){ const x = await kPost("api/locker", {loeschen:ds.kBisWeg}); if (x){ K.lk = x; K.hinweis = ""; kZeichnen(); } return; }
  if (ds.kBisAb){ const x = await kPost("api/locker", {loeschenAbbrechen:ds.kBisAb}); if (x){ K.lk = x; kZeichnen(); } return; }
  if (ds.kBschnell){ const [d, h] = ds.kBschnell.split("|"), z = new Date(); if (d === "so") z.setDate(z.getDate() + ((7 - z.getDay()) % 7 || 7)); else z.setDate(z.getDate() + +d);
    if (h !== "null") z.setHours(+h, 0, 0, 0); K.bindung.ende = z; kZeichnen(); return; }
  if ("kBisOk" in ds){ const x = await kPost("api/locker", {regel:{art:"bis", apps:K.bindung.apps, ende:Math.round(K.bindung.ende.getTime() / 1000)}}, "Feste Sperre gilt.");
    if (x){ K.lk = x; K.bindung = null; try { vbSperreAbgleich?.(); } catch {} kZurueck(); } return; }
  if (ds.kSchutzd){ K.schutzKey = ds.kSchutzd; K.hinweis = ""; kGeh("schutzDetail"); return; }
  if ("kRechte" in ds){ try { CockpitApp.einstellungen(); } catch {} return; }
  if ("kSchutzan" in ds){ try { CockpitApp.schutzAn(); } catch {} return; }
  if (ds.kPeriode){ K.periode = ds.kPeriode; store("kern.werte", ds.kPeriode); K.zurueck = []; K.v = ds.kPeriode; kZeichnen(); return; }
  if (ds.kUmstufen !== undefined){ K.umstufen = K.umstufen === ds.kUmstufen ? "" : ds.kUmstufen; kZeichnen(); return; }
  if (ds.kKat && ds.kKatApp){ const name = ds.kKatApp, t = K_KATS.find(x => x[0] === ds.kKat)?.[1]; b.disabled = true;
    try { const x = await api("api/kategorie", {name, kat:ds.kKat}); K.katGeplant = x.katGeplant || {}; delete x.katGeplant; const h = x.hinweis; delete x.hinweis; K.day = x; if (typeof S !== "undefined" && S) S.day = x; K.tage = {}; K.zeit.week = 0; K.umstufen = ""; toast(h || `„${name}“ zählt jetzt als ${t}.`); }
    catch (e){ toast(e.message || String(e)); }
    kZeichnen(); return; }
  if (ds.kWger !== undefined){ K.geraet = ds.kWger; store("kern.geraet", ds.kWger); kZeichnen(); return; }
  if (ds.kWtag !== undefined){ K.wTag = +ds.kWtag; kZeichnen(); return; }
  if (ds.kRbart){ K.rbArt = ds.kRbart; K.rbVersatz = 0; kZeichnen(); return; }
  if (ds.kRb){ K.rbVersatz = Math.max(0, K.rbVersatz + +ds.kRb); kZeichnen(); return; }
  if ("kRbNeu" in ds){ delete K.rb[K.rbArt + K.rbVersatz]; kZeichnen(); return; }
  if (ds.kStil){ store("stil.wahl", ds.kStil); if (typeof stilSetzen === "function") stilSetzen(ds.kStil); kThema(); kZeichnen(); return; }
  if ("kWarum" in ds){ const t = (document.querySelector('#kern [data-k-feld="warum"]')?.value || "").trim(); if (typeof tueWarumSetzen === "function") tueWarumSetzen(t); else store("tue.warum", t); toast(t ? "Gemerkt. Dein Satz steht beim Panik-Knopf." : "Entfernt."); kZurueck(); return; }
  if ("kGm" in ds){ K.gm = null; K.zeit.gm = 0; kGmLaden(); return; }
  if (ds.kStimme){ try { K.gm = await gmAnfrage("stimme", {org:ds.kStimme}); K.hinweis = ""; } catch (err){ K.hinweis = err.message || String(err); } kZeichnen(); return; }
  if (ds.kThema){ store("kern.thema", ds.kThema); kThema(); kZeichnen(); return; }
  if ("kSprache" in ds){ spracheSetzen(ds.kSprache || null); return; }
  if ("kName" in ds){ const n = (document.querySelector('#kern [data-k-feld="name"]')?.value || "").trim(); const x = await kPost("api/einstellungen", {name:n}, "Gespeichert."); if (x?.heute) S.plan = x; return; }
  if ("kExport" in ds){ if (window.CockpitApp && typeof handyExport === "function") return handyExport(); const a = el("a"); a.href = "api/export" + (typeof CODE !== "undefined" && CODE ? "?code=" + encodeURIComponent(CODE) : ""); a.download = "blockem-export.zip"; document.body.append(a); a.click(); a.remove(); return; }
}
function kEingabe(e){
  const t = e.target; if (!t.closest?.("#kern")) return;
  if (t.dataset.kFeld === "such" && K.wahl){ K.wahl.such = t.value; kZeichnen(); return; }
  if (t.dataset.kR && K.regel){ K.regel[t.dataset.kR] = t.value; return; }
  if (t.dataset.kL && K.limit){ K.limit[t.dataset.kL] = t.value; return; }
  if (t.dataset.kG && K.gruppe){ K.gruppe[t.dataset.kG] = t.value; return; }
}
async function kAenderung(e){
  const t = e.target; if (!t.closest?.("#kern")) return;
  if (t.dataset.kFeld === "min"){ const n = +t.value; K.fokusMin = Math.max(5, Math.min(240, Math.round((Number.isFinite(n) ? n : 60) / 5) * 5)); store("cockpit.fokusMin", K.fokusMin); kZeichnen(); return; }
  if (t.dataset.kR && K.regel){ K.regel[t.dataset.kR] = t.value; return; }   // nicht neu zeichnen: sonst verliert das nächste Feld den Fokus
  if (t.dataset.kB === "ende" && K.bindung){ const d = new Date(t.value); if (!isNaN(d)) K.bindung.ende = d; kZeichnen(); return; }
  if (t.dataset.kSchutz){ const k = t.dataset.kSchutz, an = t.checked; K.hinweis = "";
    try { await api("api/schutz", {[k]:an}); K.zeit.tr = 0; await kHole("tr", "api/tracking", 0); } catch (err){ K.hinweis = err.message || String(err); t.checked = !an; }
    kZeichnen(); return; }
  if ("kWiekunde" in t.dataset){ const x = await kPost("api/locker", {wieKunde:t.checked}); if (x){ K.lk = x; K.zeit.lk = Date.now(); } kZeichnen(); return; }   // 24.11.: nur Entwickler
  if ("kHinweise" in t.dataset){ try { await api("api/automatik", {hinweise:t.checked}); S.plan = await api("api/plan"); } catch (err){ toast(err.message || String(err)); } kZeichnen(); return; }
  if ("kAnrede" in t.dataset){ store("kern.anrede", t.value); return; }   // shortcut: nur gemerkt, die Texte sind überall „du“; wirkt erst, wenn es Sie-Texte gibt
  if ("kMorgen" in t.dataset){ store("tue.morgen", t.checked); try { CockpitApp.tuerchenMorgen(t.checked); } catch {} return; }
}
// Gruppen-Auswahl merkt sich „geändert“, damit Speichern/Abbrechen erscheinen
const kWahlFertigAlt = kWahlFertig;
kWahlFertig = function(ok){ const g = K.wahl?.ctx === "group" && ok; kWahlFertigAlt(ok); if (g && K.gruppe) { K.gruppe.dirty = K.gruppe.apps.join("|") !== K.gruppe.start.join("|"); kZeichnen(); } };

/* ---------- Start: über der alten Oberfläche, nach jedem Laden neu zeichnen ---------- */
(function kStart(){
  if (store("kern.aus") === true) return;   // Notausgang zum Vergleichen: localStorage kern.aus = true
  kThema(); kRahmen();
  const h = location.hash.match(/^#k\/(\w+)/); if (h && K_SEITEN[h[1]] && K_NAV.some(([id]) => id === h[1])) K.v = h[1];
  kZeichnen();
  for (const f of ["renderPlan", "renderDay", "fkLoad"]){
    const alt = window[f]; if (typeof alt !== "function") continue;
    window[f] = function(...a){ const r = alt.apply(this, a); Promise.resolve(r).finally(() => { if (S?.day) K.day = S.day; if (S?.plan) K.plan = S.plan; if (typeof FK !== "undefined" && FK.data) K.fk = FK.data; kZeichnen(); }); return r; };
  }
  setTimeout(() => kLaden(true), 50);
  setInterval(() => { if (!document.hidden && !document.documentElement.classList.contains("kern-alt")) kLaden(); }, 60000);
  document.addEventListener("visibilitychange", () => { if (!document.hidden){ K.zeit = {}; kLaden(true); } });
})();

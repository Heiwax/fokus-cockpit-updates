/* ---------- Tracking-App (01.11.2026): nur Bildschirmzeit, Fokus, Locker und Sperren ----------
   Die Planung (Ziele, Habits, Projekte, Jetzt dran, Mein Tag, Kalender, KI) ist ausgeblendet, nicht gelöscht: sie wird später die Planungs-App.
   Alles wieder zeigen: in der Konsole store("cockpit.ansicht", "alles") und neu laden.
   Dazu (Nachtschicht 01.11.): Kopf-Karte „Sauber seit …“, Innehalten (Atem-Pause vor ausgewählten Apps), Schutz-Schalter fürs Handy,
   (Tailscale-Anleitung seit 3.16 aus.) Daten: GET /api/tracking, POST /api/innehalten, POST /api/schutz. */
const APP_NAME = "BlockEm";   // Name seit 01.11.2026 (john), vorher „Tracking-App“
const NUR_TRACKING = store("cockpit.ansicht") !== "alles";
const PLAN_REITER = ["ziele", "habits", "projekte"];
const TR = {daten:null, geladen:0, laedt:false, startHash:location.hash};

if (NUR_TRACKING){
  document.documentElement.classList.add("nur-tracking");
  // Handy: unten Heute, Fokus, Locker, Werte; unter „Mehr“ nur noch Einstellungen
  HAUPT_REITER.splice(0, HAUPT_REITER.length, "heute", "fokus", "locker", "werte");
  for (let i = MEHR_REITER.length - 1; i >= 0; i--) if (MEHR_REITER[i][0] !== "einstellungen") MEHR_REITER.splice(i, 1);
  MEHR_REITER.forEach(m => { if (m[0] === "einstellungen") m[2] = "Handys, Automatik, Daten"; });
  document.querySelectorAll("#reiter button[data-r]").forEach(b => b.classList.toggle("r-neben", !HAUPT_REITER.includes(b.dataset.r)));
  // Einstellungen ohne KI und Kalender (gehören zur Planung), Schnell-Eingabe ohne Planungsreiter
  // BlockEm (john 01.11.): auch „Daten & Export“ raus, wir exportieren gerade nichts
  ES_GRUPPEN.forEach(g => { for (let i = g[1].length - 1; i >= 0; i--) if (["kalender", "ki", "daten"].includes(g[1][i].k)) g[1].splice(i, 1); });
  for (let i = SN_REITER.length - 1; i >= 0; i--) if (PLAN_REITER.includes(SN_REITER[i][0])) SN_REITER.splice(i, 1);
  // 3.20 (john 01.11.: „Tagesplan und Kalender kann weg“): Planungs-Automatiken gehören in die Planungs-App
  for (let i = AUTOMATIKEN.length - 1; i >= 0; i--)
    if (["tagesplan", "wochenplan", "kalender", "zeitleiste", "planfokus", "googleBloecke", "mehr", "habits", "jetzt", "abend"].includes(AUTOMATIKEN[i].k)) AUTOMATIKEN.splice(i, 1);
  // BlockEm: Rückblick ohne Projekte, Habits, Erledigt, Consistency und KI-Auswertung – nur Zeit, Fokus und größte Ablenkungen
  if (typeof renderRueckblick === "function"){
    const _rbTr = renderRueckblick;
    renderRueckblick = function(...a){
      const r = _rbTr.apply(this, a), box = $("rbInhalt"); if (!box) return r;
      box.querySelectorAll(".rb-l").forEach(l => { const t = l.querySelector("h3")?.deText || ""; if (/^(Zeit pro Projekt|Habits|Erledigt)/.test(t)) l.remove(); });
      box.querySelectorAll(".rb-ki, .rb-top .kpi:nth-child(3), .kon-hint").forEach(x => x.remove());
      return r;
    };
  }
  // BlockEm: Hochrechnung auf die Startseite (john 01.11.: „dass man das sofort sieht“), Werte › Heute ohne Fokus-Score-Ring
  const fc = document.querySelector('.tab[data-r="werte"] section[aria-labelledby="hFc"]'), ablSec = $("ablList")?.closest("section");
  if (fc && ablSec){ fc.classList.add("tr-fc"); fc.classList.remove("wt-aus"); ablSec.before(fc); const wt = WT_TEILE.find(t => t[0] === "woche"); if (wt) wt[2] = wt[2].filter(id => id !== "hFc"); }
  // Planungsreiter führen zu Heute
  const _showTabTr = showTab;
  showTab = function(r){ _showTabTr(PLAN_REITER.includes(r) ? "heute" : r); if (r === "locker") trLockerKarten(); };
  // Name statt „Johns Cockpit“
  const _headerTr = renderHeader;
  renderHeader = function(...a){ const r = _headerTr.apply(this, a); $("kw").textContent = `${APP_NAME} · KW ${isoWeek(NOW)}`; document.title = APP_NAME; return r; };
  // Heute: statt Aufgaben und Mein Tag die Ablenkung und die Bildschirmzeit nach Gerät
  const cols = document.querySelectorAll('.tab[data-r="heute"] .heute-dash > .dash-col');
  const abl = $("ablList")?.closest("section"), ger = $("gerList")?.closest("section");
  if (cols.length === 2 && abl && ger){ cols[0].append(abl); cols[1].prepend(ger); }
  // Kopf-Karte „Sauber seit …“ über den Kacheln
  const heute = document.querySelector('.tab[data-r="heute"]');
  if (heute && !$("trHero")){ const h = el("section","tr-hero"); h.id = "trHero"; h.hidden = true; heute.prepend(h); }
  const _dashTr = renderDash;
  renderDash = function(...a){ const r = _dashTr.apply(this, a); trHero(); return r; };
  document.title = APP_NAME;
  if (PLAN_REITER.includes(store("cockpit.reiter") || "")) store("cockpit.reiter", "heute");
}

async function trLaden(erzwingen){
  if (TR.laedt || (!erzwingen && TR.daten && Date.now() - TR.geladen < 60000)) return TR.daten;
  TR.laedt = true;
  try { TR.daten = await api("api/tracking"); TR.geladen = Date.now(); }
  catch { TR.daten = TR.daten || null; }
  finally { TR.laedt = false; }
  return TR.daten;
}

/* ----- Kopf-Karte auf Heute: Sauber seit X Tagen, Versuche, letzte 5 Wochen, heute am Bildschirm ----- */
function trHero(){
  const h = $("trHero"); if (!h) return;
  if (!TR.daten || Date.now() - TR.geladen > 60000){ trLaden().then(d => { if (d) trHeroZeichnen(h, d); }); }
  if (TR.daten) trHeroZeichnen(h, TR.daten);
}
function trHeroZeichnen(h, d){
  const s = d.sauber || {}, tage = s.tage ?? 0, sum = S.day?.summe;
  const bild = sum ? (sum.produktiv || 0) + (sum.prokrastination || 0) + (sum.neutral || 0) : 0;
  const links = el("div","tr-sauber");
  const schild = el("div","tr-schild"); schild.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.8l7.5 3v5.6c0 4.6-3.1 8.4-7.5 9.8-4.4-1.4-7.5-5.2-7.5-9.8V5.8z"/><path d="M8.6 12.2l2.4 2.4 4.6-4.8"/></svg>';
  const txt = el("div");
  txt.append(el("span","tr-klein","Sauber seit"), el("b","tr-gross", tage === 1 ? "1 Tag" : `${tage} Tagen`),
    el("span","tr-sub", s.heute ? `Heute ${s.heute}× abgeblockt. Stark, dass du hier bist.` : tage >= (s.beste || 0) && tage > 1 ? "Dein bester Lauf bisher." : `Bester Lauf: ${s.beste || tage} ${(s.beste || tage) === 1 ? "Tag" : "Tage"}`));
  links.append(schild, txt);
  // 35 Tage als Punkte: grün = sauber, rot = Versuch abgeblockt
  const punkte = el("div","tr-punkte"), v = s.verlauf || {};
  for (let i = 34; i >= 0; i--){
    const t = new Date(NOW); t.setDate(t.getDate() - i);
    const k = t.toISOString().slice(0, 10), n = v[k] || 0, p = el("i", n ? "rot" : "gruen");
    p.title = `${t.toLocaleDateString("de-DE", {weekday:"short", day:"numeric", month:"numeric"})}: ${n ? n + "× abgeblockt" : "sauber"}`; punkte.append(p);
  }
  const rechts = el("div","tr-heute");
  rechts.append(el("span","tr-klein","Heute am Bildschirm"), el("b","tr-gross", bild ? minText(bild) : "–"),
    el("span","tr-sub", sum ? `davon ${minText(sum.prokrastination || 0)} Ablenkung` : "Noch keine Daten"));
  const mitte = el("div","tr-mitte"); mitte.append(punkte, el("span","tr-sub", `Letzte 5 Wochen · diese Woche ${s.woche || 0}× abgeblockt`));
  // Meilensteine 7 / 30 / 90 / 180 / 365 Tage (einmal kurz feiern)
  const ms = el("div","tr-meilen");
  TR_MEILENSTEINE.forEach(m => { const x = el("span","tr-meilen-p" + (tage >= m ? " da" : ""), (tage >= m ? "✓ " : "") + m + " Tage"); ms.append(x); });
  const naechster = TR_MEILENSTEINE.find(m => m > tage);
  if (naechster) ms.append(el("span","tr-meilen-noch", `noch ${naechster - tage} ${naechster - tage === 1 ? "Tag" : "Tage"} bis ${naechster}`));
  const erreicht = [...TR_MEILENSTEINE].reverse().find(m => tage >= m);
  if (erreicht && store("tracking.meilenstein") !== String(erreicht)){ store("tracking.meilenstein", String(erreicht)); setTimeout(() => toast(`${erreicht} Tage sauber. Das ist ein echter Meilenstein.`), 400); }
  // Wochenrückblick in einem Satz
  const pk = d.panik || {}, wo = s.woche || 0, vw = s.vorwoche || 0;
  const rueck = el("p","tr-rueck",
    `Diese Woche: ${wo}× abgeblockt (Vorwoche ${vw}×)` + (pk.woche ? `, Panik-Knopf ${pk.woche}× gedrückt, ${pk.wocheGeschafft || 0}× geschafft` : "") +
    (wo < vw ? ". Weniger Versuche als letzte Woche, das zeigt Wirkung." : wo > vw ? ". Mehr Versuche als letzte Woche: Was war anders? Der Panik-Knopf hilft im Moment selbst." : "."));
  const panik = el("button","tr-panik","Panik-Knopf"); panik.type = "button"; panik.title = "Bei starkem Drang: 2 Minuten atmen, dann raus";
  panik.addEventListener("click", trPanik);
  const unten = el("div","tr-unten"); unten.append(ms, rueck, panik);
  h.replaceChildren(links, mitte, rechts, unten); h.hidden = false;
}

/* ----- DNS-Filter am Mac fehlt (3.11): der Wächter schickt den Browser hierher (#dns), ein Knopf schaltet ihn ein ----- */
let trDnsStart = location.hash === "#dns";
function trDnsPruefen(){
  if (!trDnsStart && location.hash !== "#dns") return;
  trDnsStart = false;
  history.replaceState(null, "", location.pathname + location.search);
  let d = $("trDns"); if (!d){ d = el("dialog","tr-pause"); d.id = "trDns"; document.body.append(d); }
  const ja = el("button","ask","DNS-Filter jetzt einschalten"), zu = el("button","ghost","Später"); ja.type = zu.type = "button";
  const kn = el("div","tr-pause-knoepfe"); kn.append(ja, zu);
  const win = TR.daten?.pc === "Windows-PC";
  const info = el("p","tr-pause-text", win ? "Ohne den Filter bleibt am PC jeder Browser zu. Ein Tipp, dann fragt Windows einmal, ob du die Änderung erlaubst, fertig."
    : "Ohne den Filter bleibt am Mac jeder Browser zu. Ein Tipp, dann fragt der Mac einmal nach deinem Passwort, fertig.");
  d.replaceChildren(el("span","tr-klein","Schutz"), el("h2", null, "DNS-Filter ist aus"), info, kn); if (!d.open) d.showModal();
  zu.onclick = () => d.close();
  ja.onclick = async () => { ja.disabled = true; ja.textContent = win ? "Windows fragt nach …" : "Mac fragt nach dem Passwort …";
    try { await api("api/mac-dns", {}); info.textContent = "Eingeschaltet. Die Browser gehen in etwa einer Minute wieder auf."; ja.hidden = true; zu.textContent = "Schließen"; }
    catch (e){ info.textContent = e.message || String(e); ja.disabled = false; ja.textContent = "Nochmal versuchen"; } };
}
window.addEventListener("hashchange", trDnsPruefen);
setTimeout(trDnsPruefen, 350);

/* ----- Panik-Knopf (3.11): 2 Min geführtes Atmen, dein Satz, dann Spaziergang. Am Handy die eigene Seite der App. ----- */
function trPanik(){
  if (window.CockpitApp?.panik){ try { CockpitApp.panik(); return; } catch {} }
  api("api/panik", {was:"gedrückt"}).catch(() => {});
  let d = $("trPanik"); if (!d){ d = el("dialog","tr-pause"); d.id = "trPanik"; document.body.append(d); }
  const satz = (TR.daten?.innehalten?.text) || "Du willst frei sein, nicht nur heute. Dieser Drang ist in ein paar Minuten vorbei, die Entscheidung bleibt.";
  const kreis = el("div","tr-atem"), zeit = el("b","tr-zahl", "2:00"), hin = el("span","k-s","einatmen …");
  kreis.append(zeit);
  const ja = el("button","ask","Ich gehe jetzt raus (10 Min)"), zu = el("button","ghost","Schließen"); ja.type = zu.type = "button";
  const kn = el("div","tr-pause-knoepfe"); kn.append(ja, zu);
  d.replaceChildren(el("span","tr-klein","Panik-Knopf · der Drang geht vorbei"), kreis, hin, el("p","tr-pause-text", satz), kn); if (!d.open) d.showModal();
  let rest = 120, timer;
  const fertig = async () => { clearInterval(timer); d.close(); try { const r = await api("api/panik", {was:"geschafft"}); if (TR.daten) TR.daten.panik = r.panik; trHero(); } catch {} toast("Gut gemacht. Das zählt."); };
  const lauf = (sek, tick) => { clearInterval(timer); rest = sek; timer = setInterval(() => { rest--; zeit.textContent = `${Math.floor(rest / 60)}:${String(rest % 60).padStart(2, "0")}`; tick(); if (rest <= 0) clearInterval(timer); }, 1000); };
  lauf(120, () => { hin.textContent = rest <= 0 ? "Zwei Minuten geschafft." : (120 - rest) % 10 < 5 ? "einatmen …" : "langsam ausatmen …"; if (rest <= 0){ zu.textContent = "Geschafft, der Drang ist weg"; zu.onclick = fertig; } });
  zu.onclick = () => { clearInterval(timer); d.close(); };
  d.onclose = () => clearInterval(timer);
  ja.onclick = () => { ja.textContent = "Geschafft, der Drang ist weg"; ja.onclick = fertig; zeit.textContent = "10:00"; hin.textContent = "Spaziergang: Laptop zu, raus, einfach gehen.";
    lauf(600, () => { if (rest <= 0) hin.textContent = "Zehn Minuten draußen. Stark."; }); };
}

/* ----- Innehalten: Atem-Pause, bevor eine ausgewählte App/Seite aufgeht (Mac: der Tab landet hier; Handy: eigene Seite in der App) ----- */
function trInnehaltenPruefen(){
  const hash = TR.startHash.startsWith("#innehalten") ? TR.startHash : location.hash;
  TR.startHash = "";
  if (!hash.startsWith("#innehalten")) return;
  const q = new URLSearchParams(hash.split("?")[1] || ""), w = q.get("w") || "diese App", u = q.get("u") || "";
  trLaden(true).then(d => trInnehalten(w, u, d?.innehalten || {}));
}
function trInnehalten(w, u, x){
  let d = $("trPause");
  if (!d){ d = el("dialog","tr-pause"); d.id = "trPause"; document.body.append(d); }
  const sek = Math.max(3, x.sekunden || 10), kreis = el("div","tr-atem"), zahl = el("b","tr-zahl", String(sek));
  kreis.append(el("span","tr-atem-text","einatmen"), zahl);
  const text = el("p","tr-pause-text", x.text || "Atme einmal tief durch. Brauchst du das gerade wirklich?");
  const weiter = el("button","ghost", `Weiter zu ${w}`); weiter.type = "button"; weiter.disabled = true;
  const nein = el("button","ask","Lieber nicht"); nein.type = "button";
  const knoepfe = el("div","tr-pause-knoepfe"); knoepfe.append(nein, weiter);
  d.replaceChildren(el("span","tr-klein", `Kurz innehalten vor ${w}`), kreis, text, knoepfe);
  if (!d.open) d.showModal();
  let rest = sek, phase = 0;
  const tick = setInterval(() => {
    rest--; zahl.textContent = String(Math.max(0, rest));
    phase = (phase + 1) % 8; kreis.querySelector(".tr-atem-text").textContent = phase < 4 ? "einatmen" : "ausatmen";
    if (rest <= 0){ clearInterval(tick); weiter.disabled = false; zahl.textContent = "✓"; }
  }, 1000);
  const zu = () => { clearInterval(tick); d.close(); try { history.replaceState(null, "", "#heute"); } catch {} showTab("heute"); };
  nein.addEventListener("click", () => { zu(); toast("Stark. Bleib dran."); });
  weiter.addEventListener("click", async () => {
    try { await api("api/innehalten", {weiter:w}); } catch {}
    clearInterval(tick); d.close();
    if (u) location.href = u; else { zu(); toast(`${w} ist für ein paar Minuten frei. Öffne es jetzt noch einmal.`); }
  });
}
window.addEventListener("hashchange", trInnehaltenPruefen);
setTimeout(trInnehaltenPruefen, 300);

/* ----- Locker-Reiter: Karten „Innehalten“ und „Schutz am Handy“ über dem App Locker ----- */
const TR_VORLAGEN = [
  ["Atmen", "Atme einmal tief durch. Brauchst du das gerade wirklich, oder ist es nur ein Impuls?"],
  ["Ziel", "Was wolltest du heute eigentlich schaffen? Bringt dich das gerade näher hin?"],
  ["Gebet", "Halt kurz inne und bete. Bitte um Kraft für das, was jetzt wirklich zählt."],
  ["Dankbar", "Nenne in Gedanken drei Dinge, für die du heute dankbar bist."],
  ["Christlich", "Herr, gib mir Kraft. „Alles ist mir erlaubt, aber nicht alles dient zum Guten.“ (1. Kor 6,12) Was willst du jetzt wirklich?"],
  ["Muslimisch", "Bismillah. Sag zu den gläubigen Männern, sie sollen ihre Blicke senken (Sure 24:30). Sprich ein kurzes Dua und entscheide dann."],
  ["Jüdisch", "Halte inne. „Wer ist stark? Wer seinen Trieb bezwingt.“ (Pirkei Avot 4,1)"],
  ["Achtsam", "Spür kurz deine Füße auf dem Boden. Drei ruhige Atemzüge. Dann entscheide bewusst."],
];
const TR_MEILENSTEINE = [7, 30, 90, 180, 365];
async function trLockerKarten(nurZeichnen){   // nurZeichnen (1.0.37): nach dem Speichern nur neu zeichnen, nicht alles neu laden (Hänger)
  const tab = document.querySelector('.tab[data-r="locker"]'); if (!tab) return;
  let box = $("trLockerKarten");
  if (!box){ box = el("div","tr-karten"); box.id = "trLockerKarten"; tab.prepend(box); }
  const d = nurZeichnen === true && TR.daten ? TR.daten : await trLaden(true); if (!d){ box.hidden = true; return; }
  box.hidden = false;
  box.replaceChildren(trInnehaltenKarte(d.innehalten || {}), trSchutzKarte(d.schutz || {}));
}
function trSchalter(an, fn, label){
  const b = el("button","tr-schalter" + (an ? " an" : "")); b.type = "button"; b.setAttribute("role","switch"); b.setAttribute("aria-checked", String(!!an));
  b.setAttribute("aria-label", label); b.append(el("i"));
  // 1.0.37 (john: „hängt beim An- und Ausschalten“): sofort umlegen, während des Speicherns gesperrt, bei Fehler zurück
  b.addEventListener("click", async () => {
    if (b.dataset.laeuft) return; b.dataset.laeuft = "1"; const neu = b.getAttribute("aria-checked") !== "true";
    b.classList.toggle("an", neu); b.setAttribute("aria-checked", String(neu)); b.classList.add("tr-laeuft");
    let ok; try { ok = await fn(neu); } catch { ok = false; }
    if (ok === false){ b.classList.toggle("an", !neu); b.setAttribute("aria-checked", String(!neu)); }
    delete b.dataset.laeuft; b.classList.remove("tr-laeuft");
  });
  return b;
}
function trInnehaltenKarte(x){
  const k = el("section","hud tr-karte"), kopf = el("div","tr-karte-kopf");
  const speichern = async body => { try { const r = await api("api/innehalten", body); TR.daten.innehalten = r.innehalten; setTimeout(() => trLockerKarten(true), 250); toast("Gespeichert."); } catch (e){ toast(e.message || String(e)); return false; } };
  kopf.append(el("span","tr-ico","🫁"), el("div", null), trSchalter(x.an, v => speichern({an:v}), "Innehalten an oder aus"));
  kopf.children[1].append(el("b", null, "Innehalten"), el("span","k-s","Bevor eine dieser Apps aufgeht: kurz atmen, dann selbst entscheiden."));
  k.append(kopf);
  if (!x.an){ k.append(el("p","k-s", "Aus. Schalte es ein, dann kommt vor " + (x.apps || []).slice(0, 3).join(", ") + " eine kurze Pause.")); return k; }
  const apps = el("input"); apps.value = (x.apps || []).join(", "); apps.setAttribute("aria-label","Apps und Seiten, mit Komma getrennt");
  const sek = el("input"); sek.type = "number"; sek.min = "3"; sek.max = "120"; sek.value = x.sekunden || 10; sek.setAttribute("aria-label","Sekunden Pause");
  const frei = el("input"); frei.type = "number"; frei.min = "1"; frei.max = "120"; frei.value = x.frei || 10; frei.setAttribute("aria-label","Minuten frei danach");
  const text = el("textarea"); text.rows = 2; text.value = x.text || ""; text.setAttribute("aria-label","Dein Satz in der Pause");
  const vorl = el("div","chips");
  TR_VORLAGEN.forEach(([n, t]) => { const b = el("button","chip small", n); b.type = "button"; b.addEventListener("click", () => { text.value = t; }); vorl.append(b); });
  const zeile = (titel, ...inh) => { const z = el("label","tr-zeile"); z.append(el("span","k-s", titel), ...inh); return z; };
  const ok = el("button","ask small","Speichern"); ok.type = "button";
  ok.addEventListener("click", () => speichern({apps:apps.value.split(",").map(s => s.trim()).filter(Boolean), sekunden:Number(sek.value), frei:Number(frei.value), text:text.value}));
  const test = el("button","ghost small","Ausprobieren"); test.type = "button"; test.addEventListener("click", () => trInnehalten("Instagram", "", {...x, text:text.value, sekunden:Number(sek.value)}));
  const kn = el("div","lk-knoepfe"); kn.append(ok, test);
  k.append(zeile("Vor diesen Apps und Seiten", apps), zeile("Pause in Sekunden", sek), zeile("Danach frei für Minuten", frei),
    zeile("Dein Satz in der Pause", text), vorl, kn);
  return k;
}
function trSchutzKarte(x){
  const k = el("section","hud tr-karte"), kopf = el("div","tr-karte-kopf");
  kopf.append(el("span","tr-ico","🛡️"), el("div", null));
  // 1.0.14: am Handy zählt, was bei der Einrichtung gewählt wurde. Nur ein Handy: keine Computer-Schalter und -Texte
  const nurHandy = typeof beNurHandy === "function" && beNurHandy();
  const PC = typeof bePc === "function" ? bePc() : (TR.daten?.pc === "Windows-PC" ? "PC" : TR.daten?.pc || "Mac"), WIN = PC === "PC" || TR.daten?.pc === "Windows-PC";
  kopf.children[1].append(el("b", null, "Inhaltsschutz"), el("span","k-s", "Der Grundschutz ist immer an. " + (TR.daten?.entwickler ? "Entwicklerversion: die übrigen Schalter sind frei." : "Die übrigen Schalter: einschalten sofort, ausschalten nach dem Timer im Locker.")));
  k.append(kopf);
  // Schalter je Gerät (Geräte-Auswahl) ist gebaut, aber auf johns Wunsch (01.11.) erstmal ausgeblendet: Server kann es (schutz.geraete), Stand in sicherung/2026-11-01-vor-3.12-sync/teile/tracking-mit-geraeten.js
  const wahl = "", eigen = {}, istMac = false;
  const speichern = async body => { try { const r = await api("api/schutz", body); TR.daten.schutz = r.schutz; setTimeout(() => trLockerKarten(true), 250); toast("Gespeichert."); } catch (e){ toast(e.message || String(e)); return false; } };
  const TR_IMMER = x.immer || ["suche","vpn","inApps","webcam","nurStore","bilder"], immer = [];   // Server sagt je Profil, was fest an ist
  const WO = {inApps:"handy", bilder:"handy", webcam:"handy", nurStore:"handy", dnsPflicht:"handy", bildSicher:"handy", suche:"beide", browser:"mac", macDns:"mac", vpn:"beide", kurzvideos:"beide", bilderVideo:"beide"};
  [["suche","Erwachsenen-Suchen sperren, SafeSearch erzwingen","Porno-Suchen im Browser gehen nicht auf, Google, Bing und Co. laufen mit SafeSearch. In Apps (Instagram, YouTube, TikTok, Telegram …) darf man suchen, Bilder deckt die Bild-KI ab."],
   ["bilderVideo","Bild-KI auch auf YouTube, Netflix und Twitch (Beta)","Aus: Die KI schaut dort nicht. Netflix zeigt Bildschirmfotos oft schwarz, dann sieht sie dort nichts."],
   ["geschichten","Geschichten und Audio sperren","Erotik-Audio (z. B. Dipsea, Quinn), Erotik-Geschichten, Spicy-Lese-Apps und Erwachsenen-Webtoons."],
   ["texte","Erotische Texte erkennen","Im Browser und in Lese-Apps (Kindle, Wattpad, Play Bücher): „Rating: Explicit“ und eindeutige Sex-Szenen schalten weg. Normale Romane und Aufklärung bleiben offen. Der Text verlässt nie das Gerät."],
   ["zeichnungen","Hentai und explizite Zeichnungen","Die Bild-KI schaltet auch eindeutige Zeichnungen und Anime-Szenen weg."],
   ["kiBegleiter","KI-Begleiter sperren","KI-Rollenspiel- und KI-Partner-Apps wie Character.AI, Janitor AI, Replika, Nomi."],
   ["kurzvideos","Reels, Shorts und Explore sperren","Instagram Reels und Explore, YouTube Shorts, Facebook Reels: in den Apps und im Browser. Der Rest der App bleibt offen (Nachrichten, Profile, normale Videos)."],
   ["vpn","VPN erkennen","Läuft ein VPN, gehen Browser und Social-Apps nicht auf, weil ein VPN den Schutz umgehen kann." + (nurHandy ? "" : " Am " + PC + " zählt ein VPN, über das das ganze Internet läuft.")],
   ["inApps","Erwachsenes in Apps erkennen","Instagram, TikTok, X, Reddit, Snapchat, Telegram: Beiträge mit OnlyFans-Werbung, 18+ oder eindeutigen Wörtern werden abgedeckt."],
   ["bilder","Bild-KI in Social Media" + (TR.daten?.profil?.geschlecht === "w" ? " (Beta)" : ""),"Eine Bild-KI prüft alle paar Sekunden den Bildschirm, auch Bilder ohne Text. " + (nurHandy ? "In Instagram, TikTok und im Browser." : "Am Handy in Instagram, TikTok und im Browser, am " + PC + " nur auf den Seiten und Apps unten.") + " Nichts verlässt das Gerät."],
   // 19.11. (john): keine Wahl „Sicher/Sparsam“ mehr, die Bild-KI prüft immer im Sicher-Takt (1,2 s, unter 20 % Akku 2 s)
   ["webcam","Webcam- und Zufalls-Chat-Apps sperren","Omegle-Nachbauten, Monkey, Azar, Holla, Chamet, LivU und Co. gehen nicht auf."],
   ["nurStore","Nur Apps aus dem Play Store","Apps, die von woanders installiert wurden, sind gesperrt. Ausnahmen unten."],
   ...(WIN || nurHandy ? [] : [["browser","Am Mac nur Browser mit Schutz","Firefox, Opera, Vivaldi, Tor und Co. zeigen dem Schutz keine Adressen und werden ausgeblendet. Erlaubt: Safari, Chrome, Brave, Edge, Arc."]]),
   ...(TR.daten?.entwickler ? [["liste","Erwachsenen-Sperrliste am " + PC + " (nur Entwickler)","Die Liste mit rund 973.000 Seiten. Nur in deiner Entwicklerversion abschaltbar, zum Recherchieren. Für Kunden immer an."]] : []),
   ["dnsPflicht","DNS-Filter am Handy ist Pflicht","Ohne Filter (Privates DNS) gehen am Handy Browser und Social-Apps nicht auf. Ist er an, ist die Einstellung dafür gesperrt."],
   ...(nurHandy ? [] : [["macDns","DNS-Filter am " + PC + " ist Pflicht","Ohne Filter geht am " + PC + " kein Browser auf. Stattdessen kommt BlockEm mit einem Knopf zum Einschalten."]])].forEach(([key, t, u]) => {
    if (wahl && WO[key] !== "beide" && (WO[key] === "mac") !== istMac) return;   // nur Schalter, die auf diesem Gerät wirken
    if (TR_IMMER.includes(key)){ immer.push([t, u]); return; }   // john 05.11.: Grundschutz ohne Schalter
    const z = el("div","tr-schutz-zeile"), tx = el("div"), wert = key in eigen ? eigen[key] : x[key] !== false;
    z.dataset.key = key;   // klar.js sortiert die Schalter nach Schlüssel, nicht nach Titel
    tx.append(el("b", null, t + (key in eigen ? " •" : "")), el("span","k-s", u));
    z.append(tx, trSchalter(wert, v => speichern(wahl ? {geraet:wahl, [key]:v} : {[key]:v}), t)); k.append(z);
  });
  if (immer.length){   // Grundschutz oben, als feste Zeilen ohne Schalter
    const g = el("div","tr-immer"), erste = k.querySelector(".tr-schutz-zeile");
    g.append(el("b","tr-immer-titel","Immer an"));
    immer.forEach(([t, u]) => { const z = el("div","tr-schutz-zeile tr-fest"), tx = el("div"); tx.append(el("b", null, t), el("span","k-s", u)); z.append(tx, el("span","tr-fest-an","An")); g.append(z); });
    if (erste) erste.before(g, el("b","tr-immer-titel","Einstellbar")); else k.append(g);
  }
  if (VB.modus !== "handy" && TR.daten?.entwickler){   // 3.18 (1.0.14: nur Entwickler): Leistung von BlockEm am Computer
    const lz = el("div","tr-schutz-zeile"), lt = el("div"), lb = el("button","ghost small", lsOffen() ? "Ausblenden" : "Anzeigen"); lb.type = "button";
    lt.append(el("b", null, "Leistung (CPU) anzeigen"), el("span","k-s","Kleines Fenster unten rechts: wie viel Prozessor jeder Teil von BlockEm gerade braucht."));
    lb.addEventListener("click", () => { lsUmschalten(); lb.textContent = lsOffen() ? "Ausblenden" : "Anzeigen"; });
    lz.append(lt, lb); k.append(lz);
  }
  // 3.17: Bild-KI am Computer: Seiten und Apps, auf denen sie schaut; Entwicklerversion zeigt das letzte Ergebnis
  if (x.bilder){
    if (!nurHandy){
    const zi = el("input"); zi.value = (x.bilderZiele || []).join(", ");
    zi.setAttribute("aria-label","Seiten und Apps für die Bild-KI am " + PC + ", mit Komma getrennt");
    const zok = el("button","ghost small","Speichern"); zok.type = "button";
    zok.addEventListener("click", () => speichern({bilderZiele: zi.value.split(",").map(v => v.trim()).filter(Boolean)}));
    const zz = el("label","tr-zeile"); zz.append(el("span","k-s","Bild-KI am " + PC + " schaut hier (Seiten wie instagram.com, App-Namen wie Telegram, „bildersuche“ = Google-, Bing- und andere Bildersuchen)"), zi, zok);
    k.append(zz);
    }
    // 18.11. (john: „alles beim ersten, warum sollte irgendwas beim 2. Treffer sein“): Auswahl „Sofort / Beim 2. Treffer“ entfernt, die Bild-KI greift immer beim 1. Treffer (SperrDienst.bildAktion)
    const bk = TR.daten?.bildKi;
    if (TR.daten?.entwickler && bk){
      const l = bk.letzt;
      k.append(el("p","k-s", "Test-Anzeige (nur Entwicklerversion): " + (bk.fehler ? bk.fehler :
        l ? `zuletzt ${l.zeit} auf ${l.wo}: ${l.klasseText || "neutral"} · neutral ${l.neutral} %, anzüglich ${l.anzueglich} %, nackt ${l.nackt} %` +
          (l.bademode != null ? `, Bikini ${l.bademode} %, Unterwäsche ${l.unterwaesche} %, Mann ${l.mann} %` : "") + `, ${l.ms} ms` : "noch keine Prüfung")
        + ` · ${bk.pruefungen || 0} geprüft, ${bk.gespart || 0} übersprungen (Bild gleich)`));
    }
  }
  // DNS am Mac einrichten (1.0.14: am Handy gibt es den Knopf nicht, das richtet der Computer selbst ein)
  const aktion = (titel, text, knopf, pfad, body) => {
    const z = el("div","tr-schutz-zeile"), tx = el("div"), b = el("button","ghost small", knopf); b.type = "button";
    tx.append(el("b", null, titel), el("span","k-s", text));
    b.addEventListener("click", async () => { b.disabled = true; b.textContent = "Läuft …";
      try { await api(pfad, body || {}); toast(body?.aus ? "Ausgeschaltet." : "Eingerichtet."); TR.geladen = 0; trLockerKarten(); } catch (e){ toast(e.message || String(e)); b.disabled = false; b.textContent = knopf; } });
    z.append(tx, b); k.append(z); };
  const dnsMac = TR.daten?.macDns;
  if (VB.modus !== "handy"){
  aktion("DNS-Filter am " + PC + (dnsMac ? " ✓" : dnsMac === false ? ": aus" : ""), WIN ? "Stellt alle Netzwerke des PCs auf den Erwachsenen-Filter von CleanBrowsing. Windows fragt einmal, ob du die Änderung erlaubst." : "Stellt alle Netzwerke des Macs auf den Erwachsenen-Filter von CleanBrowsing. Fragt einmal nach deinem Mac-Passwort.",
    dnsMac ? "Nochmal setzen" : "DNS-Filter am " + PC + " einschalten", "api/mac-dns");
  if (dnsMac) aktion("DNS-Filter am " + PC + " ausschalten", "Stellt die Netzwerke wieder auf automatisch (Router). Schalte vorher „DNS-Filter am " + PC + " ist Pflicht“ aus, sonst gehen die Browser zu.",
    "Ausschalten", "api/mac-dns", {aus:true});
  }
  const aus = el("input"); aus.value = (x.ausnahmen || []).join(", "); aus.placeholder = "z. B. com.beispiel.app";
  aus.setAttribute("aria-label","Ausnahmen: Paketnamen, mit Komma getrennt");
  const ok = el("button","ghost small","Ausnahmen speichern"); ok.type = "button";
  ok.addEventListener("click", () => speichern({ausnahmen:aus.value.split(",").map(s => s.trim()).filter(Boolean)}));
  const z = el("label","tr-zeile"); z.append(el("span","k-s", nurHandy ? "Ausnahmen (Paketname der App)" : "Ausnahmen (Paketname am Handy oder Browser-Name am " + PC + ")"), aus, ok);
  k.append(z);
  return k;
}

/* ----- Einstellungen › Handys & Geräte: unterwegs verbinden (Tailscale) ----- */
async function trUnterwegs(){
  const seite = document.querySelector('.es-page[data-s="geraete"]'); if (!seite || $("trUnterwegs")) return;
  const k = el("section","hud tr-karte"); k.id = "trUnterwegs"; seite.prepend(k);
  const d = await trLaden(true), ip = d?.unterwegs, port = d?.port || 8765;
  const kopf = el("div","tr-karte-kopf"); kopf.append(el("span","tr-ico","🌍"), el("div", null));
  kopf.children[1].append(el("b", null, "Unterwegs verbinden"), el("span","k-s", ip ? `Eingerichtet. Deine Handys erreichen den Mac überall unter http://${ip}:${port}` : "Damit die Handys den Mac auch ohne gleiches WLAN erreichen, über mobile Daten, im Café, überall."));
  const ol = el("ol","tr-schritte");
  ["Tailscale kostenlos installieren: auf dem Mac (tailscale.com/download oder App Store) und auf jedem Handy (Play Store).",
   "Überall mit demselben Konto anmelden (z. B. Google). Dann sind Mac und Handys in deinem eigenen privaten Netz, verschlüsselt, ohne offene Ports.",
   ip ? `In der Handy-App unter Einrichtung als Mac-Adresse eintragen: http://${ip}:${port} (gilt zu Hause und unterwegs).` : "BlockEm neu starten. Hier erscheint dann die Adresse für die Handy-App.",
   "Fertig: Sperren, Limits und Bildschirmzeit gleichen sich jetzt auch unterwegs ab."].forEach(t => ol.append(el("li", null, t)));
  k.append(kopf, ol);
}
if (NUR_TRACKING){
  const _esZeigenTr = typeof esZeigen === "function" ? esZeigen : null;
  // Karte „Unterwegs verbinden“ (Tailscale) auf johns Wunsch raus (01.11.: „das installiert sich keiner“); trUnterwegs bleibt ungenutzt
}

/* Fokus ohne Projekt und Ziel (Tracking-App): nur Dauer wählen und starten */
if (NUR_TRACKING && typeof fkFill === "function"){
  const fkFillAlt = fkFill;
  fkFill = function(){ fkFillAlt(); $("fkProj").value = ""; fkTasks(""); };
  const sub = $("fkSub"); if (sub) sub.textContent = "Dauer wählen und starten. Ablenkende Apps und Seiten sind dann gesperrt.";
}


/* ----- 3.18: Leistungs-Fenster (john 01.11.: „ganz genau anzeigen, wie viel CPU die verschiedenen Dinge brauchen“) -----
   Schwebt unten rechts, alle 5 s neu aus GET /api/leistung. Prozent = Anteil eines Prozessorkerns (wie die Aktivitätsanzeige). */
const LS = {timer: 0};
function lsOffen(){ try { return localStorage.getItem("cockpit.leistung") === "an"; } catch { return false; } }
function lsUmschalten(an){
  an = an ?? !lsOffen();
  try { localStorage.setItem("cockpit.leistung", an ? "an" : "aus"); } catch {}
  lsZeigen();
}
// 3.20 (john 01.11.: „nicht 100 % = ein Kern, sondern Gesamtauslastung“): alles als Anteil am ganzen Computer (alle Kerne)
function lsZahl(p){
  if (p == null || isNaN(p)) return "–";
  return p < 0.005 ? "0 %" : (p < 1 ? p.toFixed(2) : p < 10 ? p.toFixed(1) : Math.round(p).toString()).replace(".", ",") + " %";
}
async function lsLaden(){
  const box = $("lsBox"); if (!box) return;
  let d; try { d = await api("api/leistung"); } catch (e){ box.querySelector(".ls-inhalt").textContent = "Keine Daten: " + (e.message || e); return; }
  const k = d.kerne || 1, ganz = p => p / k, PC = d.pc || (navigator.platform.startsWith("Win") ? "PC" : "Mac");
  const oben = el("div","ls-oben");
  const s1 = el("div","ls-gross"), s2 = el("div","ls-gross");
  s1.append(el("span","ls-wert", lsZahl(d.systemJetzt ?? d.system1)), el("span","k-s", `${PC} gesamt, alle Programme`));
  s2.append(el("span","ls-wert", lsZahl(ganz(d.gesamtJetzt))), el("span","k-s", "davon BlockEm (1 Min)"));
  oben.append(s1, s2);
  const tab = el("table","ls-tab"), kopf = el("tr");
  kopf.append(el("th", null, "Teil von BlockEm"), el("th", null, "1 Min"), el("th", null, "10 Min")); tab.append(kopf);
  for (const t of d.teile){
    const z = el("tr"); z.append(el("td", null, t.name), el("td", ganz(t.jetzt) >= 1 ? "ls-hoch" : null, lsZahl(ganz(t.jetzt))), el("td", null, lsZahl(ganz(t.zehn)))); tab.append(z);
  }
  const sum = el("tr","ls-summe"); sum.append(el("td", null, "BlockEm gesamt"), el("td", ganz(d.gesamtJetzt) >= 2 ? "ls-hoch" : null, lsZahl(ganz(d.gesamtJetzt))), el("td", null, lsZahl(ganz(d.gesamtZehn)))); tab.append(sum);
  const teile = [oben, tab];
  if (d.top?.length){
    const tt = el("table","ls-tab ls-top"), tk = el("tr");
    tk.append(el("th", null, `Was den ${PC} gerade beschäftigt`), el("th", null, "Anteil")); tt.append(tk);
    for (const x of d.top){ const z = el("tr"); z.append(el("td", null, x.name), el("td", null, lsZahl(x.anteil))); tt.append(z); }
    teile.push(tt);
  }
  if (d.handys?.length){
    const ht = el("table","ls-tab ls-top"), hk = el("tr");
    hk.append(el("th", null, "Handy-App (Anteil am ganzen Handy)"), el("th", null, "Anteil")); ht.append(hk);
    for (const h of d.handys){
      const z = el("tr"), info = el("td");
      info.append(el("div", null, h.name), el("span","k-s", `Schnitt über ${h.minuten} Min, gemeldet vor ${h.vorMin} Min` +
        (h.bildGeprueft != null ? ` · Bild-KI ${h.bildGeprueft} geprüft, ${h.bildGespart} gleich${h.bildMs ? `, ${h.bildMs} ms` : ""}` : "")));
      z.append(info, el("td", h.anteil >= 1 ? "ls-hoch" : null, lsZahl(h.anteil))); ht.append(z);
    }
    teile.push(ht);
  }
  const fuss = [`100 % = ganzer ${PC} (alle ${k} Kerne)`];
  if (d.system10 != null) fuss.push(`${PC} gesamt 10 Min: ${lsZahl(d.system10)}`);
  if (d.ramMb) fuss.push(`BlockEm-Speicher ${d.ramMb} MB`);
  if (d.bildKiMs) fuss.push(`Bild-KI ${d.bildKiMs} ms pro Prüfung (${d.bildKiGeprueft} geprüft, ${d.bildKiGespart} übersprungen)`);
  if (d.hinweis) fuss.push(d.hinweis);
  teile.push(el("p","ls-fuss", fuss.join(" · ")));
  if (d.messung){   // 25.11.2026: Messmodus (nur Entwickler) – Watt und vordere App alle 2 s in Dateien, Handys liefern beim Sync mit
    const m = d.messung, mb = el("div","ls-fuss"), knopf = el("button", null, m.an ? "Messmodus stoppen" : "Messmodus starten");
    knopf.type = "button";
    knopf.addEventListener("click", async () => { knopf.disabled = true; try { await api("api/messung", {an: !m.an}); } catch {} lsLaden(); });
    const info = m.an ? `Läuft seit ${(m.seit || "").slice(0, 16).replace("T", " ")}, alle ${m.takt} s, heute ${m.zeilenHeute} Zeilen` +
      (m.powermetrics ? ", mit powermetrics" : ", ohne powermetrics") + `. Handys: ${Object.keys(m.handys).join(", ") || "noch keine Daten (kommen beim nächsten Sync)"}` : "Aus";
    mb.append(knopf);
    if (m.an && !m.powermetrics){   // genauer: CPU/GPU-Watt und Energie je Programm, braucht einmal das Mac-Passwort
      const pmk = el("button", null, "Genauer messen (fragt nach dem Mac-Passwort)"); pmk.type = "button";
      pmk.addEventListener("click", async () => { pmk.disabled = true; try { await api("api/messung", {powermetrics: true}); } catch (e){ pmk.textContent = e.message || String(e); return; } lsLaden(); });
      mb.append(pmk);
    }
    mb.append(el("div", null, info), el("div","k-s", m.ordner));
    teile.push(mb);
  }
  box.querySelector(".ls-inhalt").replaceChildren(...teile);
}
function lsZeigen(){
  let box = $("lsBox");
  if (!lsOffen() || VB.modus === "handy"){ if (box) box.remove(); clearInterval(LS.timer); LS.timer = 0; return; }
  if (!box){
    box = el("div","ls-box"); box.id = "lsBox";
    const kopf = el("div","ls-kopf"), zu = el("button","ls-zu","×"); zu.type = "button"; zu.title = "Schließen"; zu.setAttribute("aria-label","Leistungs-Fenster schließen");
    zu.addEventListener("click", () => lsUmschalten(false));
    kopf.append(el("b", null, "Leistung"), zu);
    box.append(kopf, el("div","ls-inhalt","Lädt …"));
    document.body.append(box);
  }
  lsLaden();
  if (!LS.timer) LS.timer = setInterval(lsLaden, 5000);
}
window.addEventListener("hashchange", () => { if (location.hash === "#leistung") lsUmschalten(true); });
const LS_START = location.hash === "#leistung";
setTimeout(() => { if (LS_START) lsUmschalten(true); else lsZeigen(); }, 600);

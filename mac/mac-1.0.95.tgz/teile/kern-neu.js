/* ---------- BlockEm Kern, Designrunde 03 (21.11.2026, john: „baue das alles ein, auch das Design“) ----------
   ChatGPT-Designübergabe „BlockEm-Designuebergabe-Claude.zip“ (Vorschau/telefon: refine.js, preview.js, stories.js, motion.js, scene-motion.js, gifts.js).
   Liegt nach kern.js und ersetzt dort nur Seiten (K_SEITEN) und das Zeichnen-Nachspiel (Bewegung). Daten, Regeln und Sperrlogik bleiben wie in kern.js.
   Neu: Fokus mit einem Startknopf + „Anpassen“, Sperre mit aktiver Regel oben und wischbaren Reitern Sperren · Schutz · Geräte,
   Schutz-Erklärungen mit kleinen Szenen, Geräte mit 24-Std.-Antrag zum Herausnehmen (Server: locker_geraet_antrag),
   Weg als Landschaft mit Farbgeschenken (Lavendel, Kupfer, alle 30 Tage eine Farbe), lebendes Block-Männchen, Schalter „Animationen“. */
const K2 = {gesehen:new Set(), letzteV:"", letztesGeraet:null, ort:null, reise:null, schutzAuf:store("kern.schutzAuf") || ""};

/* ---------- Farbgeschenke (gifts.js): Tag → [Farbe, Ort, Probe, Schlüssel] ---------- */
const K2_GESCHENKE = {7:["Eisblau","Bergsee","#91c6d4","ozean"], 30:["Smaragd","Moosgrat","#6fa684","smaragd"], 60:["Lavendel","Abendgarten","#ae94c8","lavendel"],
  90:["Kupfer","Klanghöhle","#cc9272","kupfer"], 180:["Bernstein","Sonnensteg","#d7ae61","gold"], 365:["Rosé","Der Abendweg","#cd93a9","rose"]};
[["Schiefer","Schiefergrat","#8194a2"],["Mohn","Mohnwiese","#d68d82"],["Salbei","Waldlichtung","#89a894"],["Perlmutt","Muschelbucht","#ccac9f"],["Morgentau","Taubogen","#8dc4ad"],
 ["Heide","Heidepfad","#b18fa7"],["Mondblau","Mondlichtung","#959bbb"],["Zimt","Herbstpfad","#ab826c"],["Polarlicht","Winterhimmel","#98b6ba"]].forEach((x, i, a) => {
  // shortcut: Katalog endet bei Tag 390 wie die Vorschau; für spätere Etappen hier weitere Farben anhängen
  const tage = [120,150,210,240,270,300,330,360,390]; K2_GESCHENKE[tage[i]] = [...x, "etappe-" + tage[i]]; });
const K2_TAGE = Object.keys(K2_GESCHENKE).map(Number).sort((a, b) => a - b);
// Akzent je Farbe (Vorschau submenus.js colorModes) und Flächen (preview.js materials): [bg, surface2, soft, brown, facet]
const K2_FARBEN = {
  ozean:{hell:"#305fbb", dunkel:"#91b4ff", inkH:"#fff", inkD:"#18243e", m:[["#edf2f5","#e0e8ef","#cadbe8","#49637d","#b9d5e9"],["#191e25","#27323d","#2d4255","#a7bdd6","#637f98"]]},
  smaragd:{hell:"#176f57", dunkel:"#7bc9aa", inkH:"#fff", inkD:"#14271d", m:[["#eef2ec","#e0e8df","#c9ded0","#436a56","#adceba"],["#181e1b","#27332b","#294237","#a3c4af","#698b75"]]},
  gold:{hell:"#946014", dunkel:"#e6b466", inkH:"#fff", inkD:"#31230d", m:[["#f5efe2","#ece2cf","#e6d3af","#785b30","#d8bd8d"],["#211c16","#373024","#483723","#ceb68d","#957852"]]},
  rose:{hell:"#a74c70", dunkel:"#e9a4bc", inkH:"#fff", inkD:"#321c25", m:[["#f5eeec","#ece0df","#e8cfd5","#815565","#ddbbc6"],["#221b20","#372c32","#48313e","#d4abba","#967184"]]}};
for (const t of K2_TAGE){ const [name, , probe, k] = K2_GESCHENKE[t];
  if (typeof STILE !== "undefined" && !STILE.some(s => s.k === k)) STILE.push({k, t:name, ab:t, farbe:probe});
  else if (typeof STILE !== "undefined"){ const s = STILE.find(x => x.k === k); s.ab = t; s.t = name; }
  K2_FARBEN[k] ||= {hell:probe, dunkel:probe, inkH:"#241d21", inkD:"#241d21"}; }   // Galerie: Etappenfarben mit dunkler Schrift
if (typeof STILE !== "undefined"){ STILE.sort((a, b) => a.ab - b.ab); const o = STILE.find(x => x.k === "orange"); if (o) o.t = "Kern"; }

/* Sperren · Schutz · Geräte sind drei Reiter einer Seite: Kopf ohne Zurück-Pfeil wie bei den Hauptbereichen */
const kKopf1 = kKopf;
kKopf = function(){ if (!["protection","devices"].includes(K.v)) return kKopf1(); const v = K.v; K.v = "lock"; try { return kKopf1(); } finally { K.v = v; } };

const kThema1 = kThema;
kThema = function(){
  kThema1();
  const h = document.documentElement, k = document.getElementById("kern"), dunkel = h.classList.contains("k-dark"), f = K2_FARBEN[kStilAktiv()];
  const namen = ["--accent","--accent-ink","--bg","--surface2","--soft","--brown","--facet-tone"];
  for (const el of [h, k]) if (el) namen.forEach(n => el.style.removeProperty(n));
  h.dataset.palette = f ? kStilAktiv() : "orange";
  h.dataset.still = String(!kBewegung());
  if (!f) return;
  const werte = {"--accent":dunkel ? f.dunkel : f.hell, "--accent-ink":dunkel ? f.inkD : f.inkH};
  if (f.m){ const [bg, s2, soft, brown, facet] = f.m[dunkel ? 1 : 0]; Object.assign(werte, {"--bg":bg, "--surface2":s2, "--soft":soft, "--brown":brown, "--facet-tone":facet}); }
  for (const el of [h, k]) if (el) for (const [n, v] of Object.entries(werte)) el.style.setProperty(n, v);
  if (werte["--bg"]){ document.querySelector('meta[name="theme-color"]')?.setAttribute("content", werte["--bg"]); try { window.CockpitApp?.farbe?.(werte["--bg"], !dunkel); } catch {} }
};

/* ---------- Bewegung: Einstellungen › Aussehen › Animationen, Systemoption „Bewegung reduzieren“ ---------- */
const K2_RUHIG = matchMedia("(prefers-reduced-motion: reduce)");
function kBewegung(){ return store("kern.animation") !== false && !K2_RUHIG.matches; }
K2_RUHIG.addEventListener?.("change", () => { document.documentElement.dataset.still = String(!kBewegung()); });
function k2Anim(el, frames, ms, extra = {}){ if (el && kBewegung() && el.animate) return el.animate(frames, {duration:ms, easing:"cubic-bezier(.22,.68,.28,1)", ...extra}); }

/* ---------- lebendes Block-Männchen (scene-motion.js): Augen, Kopf und Körper als eigene Gruppen ---------- */
const K2_FIGUR = '<rect width="100" height="100" rx="23" fill="#231D1C"/><g class="body-sway"><g class="mascot-head"><path d="m18 31 30-14 36 12-5 43-28 13-34-15z" fill="#D94336"/><path d="m18 31 30-14-4 55-27-2z" fill="#F07458"/><path d="m44 72 35 0-28 13-34-15z" fill="#7D2D2A"/><path class="crown-facet" d="m48 17 36 12-21 16-19-11z" fill="#F3A77D"/><g class="mascot-eyes"><path d="m33 49 8-6 8 6-8 6z" fill="#2D1B1A"/><circle cx="64" cy="49" r="6" fill="#2D1B1A"/></g></g></g>';
const k2Figur = (cls = "", style = "") => `<svg class="live-figure ${cls}" ${style ? `style="${style}"` : ""} viewBox="0 0 100 100" role="img" aria-label="Block-Männchen">${K2_FIGUR}</svg>`;
function k2FigurenLeben(k){   // Bilder des Männchens in Heute, Fokus, Sitzung und Weg durch die bewegliche Zeichnung ersetzen (Kopfzeile bleibt Bild)
  k.querySelectorAll('.facet img[alt="BlockEm"], .mini-facet img[alt="BlockEm"], .journey-map img[alt="BlockEm"]').forEach(img => {
    const t = document.createElement("template"); t.innerHTML = k2Figur(img.className, img.getAttribute("style") || ""); img.replaceWith(t.content.firstChild); });
}

/* ---------- Hilfen im Galerie-Stil (preview.js) ---------- */
const k2Titel = (s, ueber = "") => `<div class="page-title">${ueber ? `<div class="overline">${ueber}</div>` : ""}<h2>${s}</h2></div>`;
const k2Link = (text, attrs, sub = "") => `<button class="line-link" ${attrs}>${text}${sub ? ` <small>${sub}</small>` : ""} <span>›</span></button>`;
const k2Cta = (text, attrs) => `<button class="panic-btn design-action" ${attrs}>${text}</button>`;
const K2_REITER = [["lock","Sperren"],["protection","Schutz"],["devices","Geräte"]];
const k2Reiter = a => `<div class="slide-tabs" role="tablist" aria-label="Sperransicht">${K2_REITER.map(([id, n]) => `<button role="tab" data-k="${id}" aria-pressed="${a === id}" aria-selected="${a === id}">${n}</button>`).join("")}</div>`;
const k2Kopf = a => k2Titel("Sperre", "Dein Schutz") + k2Reiter(a);
const K2_SCHLOSS = '<svg class="etched-lock" viewBox="0 0 72 80" aria-hidden="true"><path d="M22 36V23a14 14 0 0 1 28 0v12" stroke="var(--brown)" stroke-width="6" fill="none"/><path d="m10 36 12-9 40 6v33l-13 9-39-8z" fill="var(--accent)"/><path d="m10 36 12-9 40 6-13 9z" fill="var(--ink)" opacity=".14"/><path d="m49 42 13-9v33l-13 9z" fill="var(--ink)" opacity=".23"/><path d="m29 46 5 5-3 4v6l-4-1v-6l-3-4z" fill="var(--accent-ink)"/></svg>';
const K2_SCHLOSS_OFFEN = K2_SCHLOSS.replace('class="etched-lock"', 'class="etched-lock offen"').replace('M22 36V23a14 14 0 0 1 28 0v12', 'M22 28V15a14 14 0 0 1 28 0v3');   // alles frei: Bügel offen
const k2Tag = () => new Date().toLocaleDateString("de-DE", {weekday:"short"}).replace(".", "");

/* ---------- Fokus: ein Startknopf, „Anpassen“ trennt Dauer, Auswahl und Geräte ---------- */
const kFocus1 = kFocus;
function kFocus2(){
  if (K.fk?.aktiv) return kActive();
  const m = K.fokusMin, liste = kFokusListe(), lauf = K.lk?.fokus;
  const was = K.fokusArt === "Apps" ? `${liste.length} ${liste.length === 1 ? "App" : "Apps"}` : K.fokusArt;
  return `<div class="focus">${k2Titel("Fokus", "Deine Sitzung")}<div class="focus-stage"><div class="duration">${m}<small>Minuten</small></div><div class="facet">${kFigur()}</div></div>
   ${K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>` : ""}
   ${k2Cta(`Fokus für ${m} Minuten starten`, `data-k-fokus-start ${!liste.length || lauf ? "disabled" : ""}`)}
   <div class="config"><span>${liste.length ? `${kEsc(was)} gesperrt · ${kEsc(kFokusGeraeteText())}` : "Noch keine App gewählt"}</span><button data-k="adjust">Anpassen</button></div>
   ${K.fk?.sessions?.length ? k2Link("Letzte Sitzung", 'data-k="result"', kEsc(kSitzungText(K.fk.sessions[0]))) : ""}</div>`;
}
function kAdjust(){   // bisherige Fokus-Felder ohne Kopf und Startknopf, dazu „Übernehmen“
  const alt = kFocus1().replace(/<div class="focus-head">[\s\S]*?<\/div><img[^>]*><\/div>/, "").replace(/<button class="action full" data-k-fokus-start[\s\S]*$/, "");
  return alt.replace('<div class="focus">', '<div class="focus">' + k2Titel("Fokus anpassen")) + k2Cta("Übernehmen", "data-k2-uebernehmen") + "</div>";
}

/* ---------- Sperre: aktive Regel zuerst, dann die übrigen; leer → „Erste Sperre anlegen“ ---------- */
const kLock1 = kLock;
function k2RegelName(r){ return r.gruppe || kAppsKurz(kRegelApps(r)) || "Konsum-Apps"; }
function k2Fuehrend(regeln){   // was gerade sperrt: Sperrzeit vor fester Sperre vor aufgebrauchtem Limit
  const zu = regeln.filter(r => r.gesperrt && !r.pausiert), rang = {zeit:0, bis:1, limit:2};
  return zu.sort((a, b) => (rang[a.art] ?? 3) - (rang[b.art] ?? 3))[0];
}
function k2Oeffnen(r){ return r.art === "zeit" ? `data-k-regel="${kEsc(r.id)}"` : r.art === "limit" ? `data-k-limit="${kEsc(r.id)}"` : r.art === "bis" ? 'data-k="binding"' : `data-k-gruppe="${kEsc(r.gruppe ? "g:" + r.gruppe : "r:" + r.id)}"`; }
function k2Satz(r){
  if (r.art === "zeit") return `${k2RegelName(r)} ist bis ${r.bis} Uhr gesperrt.`;
  if (r.art === "bis") return r.satz || `${k2RegelName(r)} ist bis ${kZeitpunkt(r.ende * 1000)} gesperrt.`;
  if (r.art === "limit") return `${k2RegelName(r)}: Tageslimit für heute aufgebraucht.`;
  return `${k2RegelName(r)} ist gerade gesperrt.`;
}
function k2RegelZeile(r){
  const apps = kRegelApps(r), rechts = r.art === "zeit" ? `${kEsc(r.von)}–${kEsc(r.bis)}` : r.art === "limit" ? (r.gesperrt ? "aufgebraucht" : `noch ${Math.max(0, r.minuten - Math.round(r.verbraucht || 0))} Min`) : "";
  const unter = r.art === "zeit" ? `${kTageText(r.tage)} · ${apps.slice(0, 3).join(" · ") || "Konsum-Apps"}` : r.art === "limit" ? `Tageslimit ${r.minuten} Min` + (apps.length > 1 ? " · " + apps.slice(0, 3).join(" · ") : "") : kRegelSatz(r);
  return `<button class="flat-app rule-row" ${k2Oeffnen(r)}>${kernIcon(apps[0] || "")}<span><b>${kEsc(k2RegelName(r))}</b><small>${kEsc(unter)}${K.lk?.entfernen?.[r.id] ? " · wird entfernt" : ""}</small></span><strong>${rechts}</strong> ›</button>`;
}
function kLock2(){
  const d = K.lk || {}, regeln = (d.regeln || []).filter(r => r.art !== "bis" || r.gesperrt), geladen = Array.isArray(d.regeln);
  const pause = !!d.sofort && (d.pauseBis || 0) * 1000 > Date.now(), jetzt = new Date();
  let kopf = k2Kopf("lock")
    + (d.offline ? kNote("Offline", "Die Regeln wirken auf dem Gerät weiter. Ändern geht, sobald die Verbindung zurück ist.") : "")
    + (d.fokus ? kNote("Fokus läuft", "Während des Fokus bleiben alle Regeln, wie sie sind. Ändern geht nach dem Fokus.") : "")
    + (pause ? kNote("Regeln pausiert", `Entwickler-Pause bis ${kEsc(kZeitpunkt(d.pauseBis * 1000))}. Deine Regeln bleiben gespeichert und gelten danach wieder.`) + `<button class="action full k-neu" data-k-pause-aus>Pause beenden, Regeln gelten sofort</button>` : "");
  if (!geladen) return `<div class="lock">${kopf}<p class="k-leer">${K.fehlt.lk ? "Regeln ließen sich gerade nicht laden." : "Regeln werden geladen …"}</p></div>`;
  const lead = pause ? null : k2Fuehrend([...regeln]), apps = lead ? kRegelApps(lead) : [];
  const hero = lead ? `<button class="lock-now" ${k2Oeffnen(lead)} data-k2-regel-id="${kEsc(lead.id)}"><small>Jetzt aktiv · ${k2Tag()}, ${kUhr(jetzt)}</small><strong>${kEsc(k2Satz(lead))}</strong>${K2_SCHLOSS}
      <div class="approach" aria-hidden="true"><i>${kernIcon(apps[0] || "")}</i><em></em></div><span class="marks">${apps.slice(0, 4).map(kernIcon).join("")}<span>Regel öffnen ›</span></span></button>`
    : `<div class="free-now"><small>${jetzt.toLocaleDateString("de-DE", {weekday:"long"})} · ${kUhr(jetzt)}</small><h3>${pause ? "Regeln sind pausiert." : "Gerade ist alles frei."}</h3>${K2_SCHLOSS_OFFEN}</div>`;
  const rest = regeln.filter(r => r !== lead && ["zeit","limit"].includes(r.art)).sort((a, b) => (a.art === "zeit" ? 0 : 1) - (b.art === "zeit" ? 0 : 1) || String(a.von || "").localeCompare(String(b.von || "")));
  const leer = !(d.regeln || []).length;
  return `<div class="lock">${kopf}${hero}${rest.map(k2RegelZeile).join("")}
   ${leer ? k2Cta("Erste Sperre anlegen", 'data-k="createRule"') : k2Link("Sperre anlegen", 'data-k="createRule"')}
   ${kLockerKarte()}
   <details class="device-fold k2-verwalten"><summary>Regeln verwalten</summary>${k2Link("Sperrzeiten, Gruppen & Apps", 'data-k="rules"')}${k2Link("Tageslimits", 'data-k="limits"')}${k2Link("Reels, Shorts und Explore", 'data-k="shorts"', K.tr?.schutz?.kurzvideos ? "gesperrt" : "")}${k2Link("Feste Sperren", 'data-k="binding"', (d.regeln || []).filter(r => r.art === "bis" && r.gesperrt).length ? "aktiv" : "")}</details></div>`;
}
function kRules(){   // die bisherige Übersicht (Sperrzeit-Kreise, Gruppen, Apps) als Unterseite, john 20.11.
  const t = document.createElement("template"); t.innerHTML = kLock1();
  const b = t.content.querySelector(".k-lkteil"); if (b) b.querySelector("h3")?.remove();
  return kMain("SPERRE", "Regeln verwalten", b ? b.outerHTML : `<p class="k-leer">Regeln werden geladen …</p>`);
}
function kCreateRule(){
  return '<div class="detail-view">' + k2Titel("Sperre anlegen") + `<button class="choice" data-k-regel="neu"><strong>Zu bestimmten Uhrzeiten sperren</strong><small>Zum Beispiel jeden Abend ab 21 Uhr</small></button>
   <button class="choice" data-k-limit="neu"><strong>Nutzung pro Tag begrenzen</strong><small>Zum Beispiel 30 Minuten Instagram</small></button>
   <button class="choice" data-k="newBinding"><strong>Bis zu einem Zeitpunkt sperren</strong><small>Zum Beispiel bis Freitag, 18 Uhr</small></button>` + k2Link("Gruppen & Apps verwalten", 'data-k="groups"') + "</div>";
}

/* ---------- Schutz: Erklärung klappt unter der Zeile auf, der Schalter bleibt davon unabhängig (stories.js) ---------- */
const K2_SZENE = {bilder:"imageAI", texte:"texts", zeichnungen:"drawings", kiBegleiter:"companions", geschichten:"stories", vpn:"vpn", inApps:"inApps", webcam:"webcam", nurStore:"onlyStore"};
const K2_ERKL = {
  bilder:"Prüft Bilder in Social-Media-Apps auf diesem Gerät. Erkennt sie ein freizügiges Bild, liegt eine Abdeckung darüber, die beim Scrollen mit dem Beitrag mitwandert.",
  texte:"Erkennt einschlägige sichtbare Texte, etwa in einer Lese-App. Bei einem Treffer unterbricht der Schutz die Ansicht.",
  zeichnungen:"Prüft auch gezeichnete sexuelle Inhalte. Ein normales Comic bleibt nach den übrigen Regeln zugänglich.",
  kiBegleiter:"Erfasst erotische KI-Begleiter. Andere Chats unterliegen den normalen App- und Textregeln.",
  geschichten:"Schützt vor bekannten Angeboten für erotische Geschichten und Audio. Ein gewöhnlicher Podcast bleibt nach den übrigen Regeln zugänglich.",
  vpn:"Erkennt VPN-Nutzung als möglichen Umgehungsversuch. Der genaue Eingriff hängt vom Gerät ab.",
  inApps:"Erfasst Erwachsenenbereiche innerhalb von Apps, auch wenn die App selbst erlaubt ist.",
  webcam:"Schützt vor Angeboten mit zufälligen Chatpartnern. Normale Kontakte bleiben nach den übrigen Regeln erreichbar.",
  nurStore:"Beschränkt unter Android den Bezug von Apps auf den Play Store. Eine Installation aus einer anderen Quelle fällt unter diese Regel."};
function k2Szene(key){   // kleine wiederholbare Szene: Auslöser, Eingriff, Ergebnis (Vorschau stories.js storyPreview)
  const art = '<svg class="post-art" viewBox="0 0 200 56" preserveAspectRatio="none" aria-hidden="true"><rect width="200" height="56" fill="#c5c8b5"/><circle cx="146" cy="15" r="9" fill="#ffdfa6"/><path d="m0 50 41-32 36 25 36-31 64 40 23-16v20H0z" fill="#707d71"/><path d="m0 53 80-15 59 6 61-12v24H0z" fill="#40665f"/></svg>';
  const post = (n, weg) => `<article class="mini-post"><b>${n}</b><div class="post-picture">${art}${weg ? '<span class="picture-mask reveal">Inhalt ausgeblendet</span>' : ""}</div></article>`;
  const panel = (t, c) => `<section class="story-panel reveal"><strong>${t}</strong>${c}</section>`, e = (h, b) => `<small class="mini-heading">${h}</small>${b}`;
  const s = {
    imageAI:["Bild im Feed ausgeblendet", `<div class="feed-roll">${post("Mara · Unterwegs")}${post("Atelier Nord", true)}${post("Lin · Heute")}</div>`],
    texts:["Leseansicht unterbrochen", e("Bibliothek / Kapitel 4", '<div class="reading-roll">Am Ufer war es still. Ein Boot zog langsam vorbei.<p>Sie blätterte weiter.</p><span>▧ ▧ ▧</span></div>') + panel("Lesen unterbrochen", "<small>BlockEm · Textschutz</small>")],
    pause:["Nach der Pause entscheiden", e("Startbildschirm", '<span class="launch-app">◎</span><i class="tap-dot"></i>') + panel("Einen Moment", '<svg class="pause-clock" viewBox="0 0 32 32"><circle cx="16" cy="16" r="12"/><circle class="elapsed" cx="16" cy="16" r="12" pathLength="1"/></svg><b class="ready">Jetzt öffnen ›</b>')],
    shorts:["Kurzvideos gesperrt · Feed erreichbar", e("Beiträge", art + "<small>Start　 ·　 Kurzvideos</small>") + '<div class="shorts-visit"><b>▸ Kurzvideos</b><span class="reel-frame">▷</span><strong class="reel-stop">Kurzvideos gesperrt</strong><small>‹ Zurück zum Feed</small></div>'],
    drawings:["Zeichnung geschützt", e("Comic / Seite 8", '<div class="comic-strip"><i>✦</i><i>◇<b class="picture-mask reveal">Geschützt</b></i></div>')],
    stories:["Audioangebot gesperrt", e("Audiothek", "<strong>▷　Geschichte abspielen</strong><span class=\"waveform\">▁▃▆▄▇▃▂▆▄▂</span>") + panel("Wiedergabe gesperrt", "<small>Dieses Angebot ist geschützt.</small>")],
    companions:["KI-Begleiter geschützt", e("Chats", "<small>●　Freundeskreis</small><strong>✧　KI-Begleiter öffnen</strong>") + panel("Chat geschützt", "<small>‹ Zur Chatliste</small>")],
    inApps:["Bereich innerhalb der App geschützt", e("Entdecken", "<small>Sammlungen　 ›</small><strong>Erwachsenenbereich　 ›</strong>") + panel("Bereich geschützt", "<small>‹ Zur Übersicht</small>")],
    vpn:["VPN-Verbindung erkannt", e("Netzwerk", '<strong>VPN verbinden</strong><div class="network-line">◉ ┄ ┄ ◇ ┄ ┄ ◎</div>') + '<b class="notice reveal">BlockEm · VPN erkannt</b>'],
    webcam:["Zufalls-Chat geschützt", e("Videochat", '<div class="call-pair">◉　│　?</div><small>Zufälligen Kontakt suchen</small>') + panel("Zufalls-Chat gesperrt", "<small>‹ Zu meinen Kontakten</small>")],
    onlyStore:["Externe Installation gesperrt", e("Downloads", "<strong>↓　Anwendung.apk</strong><small>Installation starten　 ›</small>") + panel("Quelle gesperrt", "<small>Apps über den Play Store beziehen</small>")],
    trusted:["Verbundene Person benachrichtigt", e("Schutzstatus", "<strong>Schutz ausgeschaltet</strong>") + '<div class="notice reveal">✉　Nachricht an Vertrauensperson<br><small>Der Schutz wurde abgeschaltet.</small></div>'],
    porn:["Grundschutz im Profil aktiv", e("Profil auswählen", "<strong>◇　Porno-Schutz</strong>") + panel("Grundschutz aktiv", "<small>Textschutz　·　Inhaltsschutz</small>")]}[key];
  if (!s) return "";
  return `<figure class="demo-scene device-story"><div class="story-window"><div class="story-chrome" aria-hidden="true"><i></i><span>•••</span></div><div class="story-display">${s[1]}</div></div><figcaption>${s[0]}</figcaption><button type="button" data-k2-szene aria-label="Szene wiederholen">↻</button></figure>`;
}
function k2Erklaerung(id, titel, status, text, szene, schalter = "", extra = ""){
  return `<div class="k2-schutz ${schalter ? "mit-schalter" : ""}"><details class="device-fold explanation" data-k2-auf="${id}" ${K2.schutzAuf === id ? "open" : ""}><summary><span><b>${kEsc(titel)}</b><small>${kEsc(status)}</small></span></summary>${k2Szene(szene)}<p>${text}</p>${extra}</details>${schalter}</div>`;
}
function kProtection2(){
  const s = K.tr?.schutz || {}, fest = s.immer || [], porno = K.tr?.profil?.pornoSchutz !== false, an = K_SCHUTZ.filter(([k]) => s[k]).length;
  const sw = (k, t) => `<label class="k2-sw" aria-label="${kEsc(t)}"><input type="checkbox" role="switch" data-k-schutz="${k}" ${s[k] ? "checked" : ""} ${fest.includes(k) ? "disabled" : ""}><i></i></label>`;
  // 24.11. (john): Bild-KI auf YouTube/Netflix gab es nur im alten Schutz-Menü. Eigene Zeile direkt unter „Bild-KI“, Schalter bilderVideo (Beta, jederzeit an/aus).
  const video = () => k2Erklaerung("bilderVideo", "Bild-KI auf YouTube und Netflix", (s.bilderVideo ? "an" : "aus") + " · Beta",
    "Die Bild-KI schaut auch in YouTube und Netflix. Ein Treffer deckt das Bild ab, drei Treffer in 10 Sekunden sperren das Video und die App 1 Minute. Wirkt nur, wenn die Bild-KI an ist. Netflix zeigt Bildschirmfotos oft schwarz, dann sieht sie dort nichts. Ausschalten geht jederzeit.",
    K2_SZENE.bilder, sw("bilderVideo", "Bild-KI auf YouTube und Netflix"));
  const zeile = ([k, t]) => k2Erklaerung(k, t, fest.includes(k) ? "fest an" : s[k] ? "an" : "aus", K2_ERKL[k] || "", K2_SZENE[k], sw(k, t)) + (k === "bilder" ? video() : "");
  const grund = K_SCHUTZ.filter(([k]) => fest.includes(k)), weitere = K_SCHUTZ.filter(([k]) => !fest.includes(k));
  return `<div class="lock">${k2Kopf("protection")}
   <div class="safety-hero"><div><div class="overline">${window.CockpitApp ? "Dieses Handy" : "Dieser Computer"}</div><h3>${S.rechteFehlen?.length ? "Schutz eingeschränkt" : s.liste !== false ? "Grundschutz aktiv" : "Schutz ist aus"}</h3><p>${S.rechteFehlen?.length ? kEsc(S.rechteFehlen[0]) : `${an} von ${K_SCHUTZ.length} Bereichen an${porno ? "" : " · Porno-Schutz zählt nur"}`}</p></div></div>
   ${K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>${/Wartezeit|lockern/i.test(K.hinweis) && !(K.lk?.wartet > 0) ? `<button class="sub-chip" data-k-lk="warten">Lockern beantragen · frühestens ${kFrühestens()}</button>` : ""}` : ""}
   ${grund.length ? kSection("Grundschutz", grund.map(zeile).join("")) : ""}
   ${kSection(grund.length ? "Weitere Schutzfunktionen" : "Was geschützt wird", weitere.map(zeile).join("")
     + k2Erklaerung("_kurz", "Reels und Shorts", s.kurzvideos ? "gesperrt" : "aus", "Der Kurzvideo-Bereich wird gesperrt: Reels, Shorts, Explore und Für dich. Feed und Nachrichten bleiben erreichbar.", "shorts", "", k2Link("Einstellung öffnen", 'data-k="shorts"'))
     + k2Erklaerung("_pause", "Pause vor dem Öffnen", K.tr?.innehalten?.an ? "an" : "aus", "Vor ausgewählten Apps kommt eine kurze Pause. Läuft der Ring ab, entscheidest du, ob du die App öffnest.", "pause", "", k2Link("Einstellung öffnen", 'data-k-alt="innehalten"'))
     + k2Erklaerung("_porno", "Porno-Schutz", porno ? "an" : "zählt nur", porno ? "Porno-Seiten und -Apps sind auf allen Geräten gesperrt. Einmal eingeschaltet, bleibt der Porno-Schutz an." : "Porno-Seiten werden gezählt, aber nicht gesperrt. Einschalten wirkt sofort und bleibt dann an.", "porn", "", porno ? "" : `<button class="sub-chip" data-k2-porno>Porno-Schutz einschalten</button>`)
     + k2Erklaerung("_vp", "Vertrauensperson", "Begleitung", "Wird der Schutz abgeschaltet, bekommt deine Vertrauensperson eine Nachricht. Was du ansiehst, erfährt sie nie.", "trusted", "", k2Link("Vertrauensperson öffnen", 'data-k="trusted"')))}
   ${k2Link("Schutz vor Deinstallieren", 'data-k="uninstall"', window.CockpitApp ? "Löschen erschweren" : "Mac und Windows-PC")}</div>`;
}

/* ---------- Geräte: jede Regel je Gerät, Herausnehmen erst nach 24 Std. (Server locker_geraet_antrag) ---------- */
function k2GeraeteListe(){   // wie kDevices: Server-Geräte, Konto-Geräte (nur ohne Mac-Zentrale), dieses Gerät
  const info = K.info || {}, hier = kGeraetHier(), liste = [...(info.geraete || [])];
  if (info.modus === "handy") (typeof SYNC !== "undefined" && SYNC.konto?.geraete || []).forEach(x => { if (x.name && !x.dieses && !liste.some(g => g.name === x.name)) liste.push({name:x.name, letzterSync:x.zuletzt}); });
  if (info.modus && info.modus !== "handy" && !liste.some(g => g.name === "Mac")) liste.unshift({name:"Mac", zentrale:true, label:info.modus === "mac" ? K.tr?.pc || "Mac" : "BlockEm-Server"});
  if (!liste.some(g => g.name === hier)) liste.unshift({name:hier, hier:true});
  (K.lk?.geraete || []).forEach(n => { if (n && !liste.some(g => g.name === n)) liste.push({name:n}); });
  return liste;
}
const k2Offen = r => Object.fromEntries(Object.entries(r.geraetWeg || {}).filter(([, ab]) => +ab * 1000 > Date.now()));
const k2GiltAuf = (r, g) => !(r.geraete || []).length || r.geraete.some(x => kLow(x) === kLow(g));
function k2GeraetRegel(r, g){
  const weg = k2Offen(r)[g], nur = (r.geraete || []).filter(x => !k2Offen(r)[x]).length <= 1 && (r.geraete || []).length > 0 && !weg;
  const status = weg ? `<p role="status" class="pending-removal">Entfernung beantragt · gilt hier noch bis ${kEsc(kZeitpunkt(+weg * 1000))}</p><button class="sub-chip" data-k2-weg-ab="${kEsc(r.id)}|${kEsc(g)}">Doch behalten</button>`
    : nur ? `<p class="small k2-nur">Gilt nur auf diesem Gerät. Ganz beenden geht über „Regel öffnen“ (24 Std).</p>`
    : `<button class="sub-chip" data-k2-weg="${kEsc(r.id)}|${kEsc(g)}">Entfernung in ${K.lk?.geraetWegStd || 24} Stunden beantragen</button>`;
  return k2RegelZeile(r) + status;
}
function kDevices2(){
  if (!K.laedt.info && Date.now() - (K.zeit.info || 0) > 30000) setTimeout(() => kHole("info", "api/handy-info").then(() => K.v === "devices" && kZeichnen()), 0);
  const hier = kGeraetHier(), regeln = (K.lk?.regeln || []).filter(r => ["zeit","limit"].includes(r.art)), liste = k2GeraeteListe();
  const fold = g => { const name = g.name, auf = regeln.filter(r => k2GiltAuf(r, name)), nicht = regeln.filter(r => !k2GiltAuf(r, name));
    const alt = g.letzterSync ? (Date.now() - new Date(g.letzterSync)) / 6e4 : null, stale = alt != null && alt > 120;
    const sub = g.zentrale ? "Zentrale" : g.letzterSync ? `Abgleich ${kZeitpunkt(new Date(g.letzterSync).getTime())}` : name === hier ? "dieses Gerät" : "";
    return `<details class="device-fold" data-device-name="${kEsc(name)}" ${K2.geraetAuf === name ? "open" : ""}><summary><b>${kEsc(g.label || kGeraetText(name))}${name === hier ? " · dieses Gerät" : ""}</b><small>${auf.length} ${auf.length === 1 ? "Regel" : "Regeln"}${stale ? " · prüfen" : ""}</small>${sub ? `<em>${kEsc(sub)}</em>` : ""}</summary>
      ${auf.map(r => k2GeraetRegel(r, name)).join("") || `<p class="small">Keine Regeln auf diesem Gerät.</p>`}
      ${nicht.length ? `<div class="k2-dazu"><small>Hier noch nicht aktiv</small>${nicht.map(r => `<button class="sub-chip" data-k2-dazu="${kEsc(r.id)}|${kEsc(name)}">＋ ${kEsc(k2RegelName(r))} zuschalten</button>`).join("")}</div>` : ""}</details>`; };
  return `<div class="lock">${k2Kopf("devices")}
   ${K.hinweis ? `<p class="k-fehler" role="alert">${kEsc(K.hinweis)}</p>` : ""}
   ${liste.map(fold).join("")}
   ${liste.some(g => g.letzterSync && (Date.now() - new Date(g.letzterSync)) / 6e4 > 120) ? kNote("Abgleich unterbrochen", "Ein Gerät hat sich länger nicht gemeldet. Es sperrt mit dem letzten Stand weiter. Öffne BlockEm dort einmal, dann gleicht es ab.", "warn") : ""}
   <p class="small k2-regel-hinweis">Zuschalten wirkt sofort. Ein Gerät aus einer Regel herausnehmen dauert ${K.lk?.geraetWegStd || 24} Stunden, bis dahin gilt die Regel dort weiter. Ein Tageslimit teilen sich alle Geräte der Regel.</p>
   ${k2Link("Gerät verbinden", 'data-k-alt="speicherort"')}
   <details class="device-fold"><summary>Einrichtung & System</summary>${k2Link("Berechtigungen", 'data-k="permissions"')}${k2Link("Systemcheck", 'data-k-alt="status"')}${k2Link("Schutz vor Deinstallieren", 'data-k="uninstall"')}</details></div>`;
}

/* ---------- Weg: Landschaft, Pfad, Farbgeschenke (gifts.js) ---------- */
function k2SeeKunst(box = "0 0 300 210"){   // Bergsee (stories.js lakeArt); box = Ausschnitt der breiten Landschaft (740 × 248)
  const baeume = [[16,165],[29,161],[67,128],[77,132],[164,111],[176,107],[269,118],[289,111],[303,100],[391,144],[410,138],[439,132],[553,131],[583,112],[636,95],[678,89]];
  return `<svg class="lake-art" viewBox="${box}" preserveAspectRatio="none" aria-hidden="true"><rect width="740" height="248" fill="var(--soft)"/><path fill="var(--surface)" d="M0 109 63 42 99 81 161 14 212 80 247 38 316 102 394 21 446 71 522 9 610 89 673 18 740 84V248H0Z"/><path fill="var(--bar)" opacity=".55" d="m63 42 8 52 28-13zm98-28-13 74 64-8zm86 24-16 63 85 1zm147-17-9 75 61-25zm128-12-11 75 99 5zm151 9-8 69 75-3z"/><path fill="var(--brown)" opacity=".32" d="M0 126 79 88 142 102 211 69 298 99 380 80 462 105 551 53 641 92 740 66v182H0z"/><path fill="#83aeb9" d="m133 136 48-37 55-9 42 6-28 19-51 9-14 12z"/><path class="water-light" fill="#d6edeb" d="m175 119 36-13 29-3-20 7z"/><path fill="var(--surface2)" d="m0 184 86-35 62-7 48 4 53-25 93-17 75 20 99-18 83-13 141 14v141H0z"/>`
    + baeume.map(([x, y]) => `<path fill="var(--brown)" opacity=".7" d="m${x} ${y} -4 8h3l-5 7h13l-5-7h3z"/>`).join("") + "</svg>";
}
function k2Stand(){ const tage = K.tr?.sauber?.tage || 0; return {tage, max:Math.max(+(store("stil.max") || 0), tage)}; }
// Weg-Karte (stories.js atlas): Straße in Koordinaten der breiten Landschaft, Etappen liegen auf Ecken der Straße
const K2_STRASSE = [[0,177],[53,177],[119,111],[157,111],[209,59],[255,59],[310,112],[361,112],[410,152],[454,152],[508,98],[558,98],[600,131],[633,131],[684,75],[699,75]];
const K2_HALTE = [[1,1,"Erster Schritt"],[7,5,"Eisblau"],[30,7,"Smaragd"],[60,8,"Lavendel"],[90,9,"Kupfer · Spendenetappe"],[180,11,"Bernstein · Spendenetappe"],[270,13,"Spendenetappe"],[365,15,"Rosé · Spendenetappe"]];
function k2Ort(tage){   // Punkt auf der Straße für einen Tag; dazu die Straße bis dorthin
  const t = Math.max(1, tage), i = K2_HALTE.findIndex(h => h[0] > t);
  if (i < 0) return {x:699, y:75, teil:K2_STRASSE};
  const [d0, a] = K2_HALTE[i - 1], [d1, b] = K2_HALTE[i], q = (t - d0) / (d1 - d0), punkte = K2_STRASSE.slice(a, b + 1);
  const laengen = punkte.slice(1).map((p, j) => Math.hypot(p[0] - punkte[j][0], p[1] - punkte[j][1])), ziel = q * laengen.reduce((s, l) => s + l, 0);
  let weg = 0, j = 0; while (j < laengen.length - 1 && weg + laengen[j] < ziel){ weg += laengen[j]; j++; }
  const f = laengen[j] ? (ziel - weg) / laengen[j] : 0, p = punkte[j], n = punkte[j + 1] || p, x = p[0] + (n[0] - p[0]) * f, y = p[1] + (n[1] - p[1]) * f;
  return {x, y, teil:[...K2_STRASSE.slice(0, a + j + 1), [x, y]]};
}
const k2Linie = pts => "M" + pts.map(([x, y]) => `${+x.toFixed(1)} ${+y.toFixed(1)}`).join(" L");
function kJourney2(){
  const {tage} = k2Stand(), n = K2_TAGE.find(d => d > tage), mon = new Date().toLocaleDateString("de-DE", {month:"long"});
  const ort = k2Ort(tage), ox = Math.max(0, Math.min(440, ort.x - 150));   // Fenster (300 breit) folgt dem Standort
  const sp = [90,180,270,365].find(x => x > tage) || 365, g = K.gm; setTimeout(kGmLaden, 0);
  const zeile = (name, text, wert, maxW, auf) => `<button class="progress-row" data-k="${auf}" data-view="${auf}"><b>${name} ›</b><small>${text}</small><progress value="${wert}" max="${maxW}"></progress></button>`;
  const naechst = K2_HALTE.find(h => h[0] > tage), marke = naechst ? K2_STRASSE[naechst[1]] : null;
  const karte = `<svg class="terrain" viewBox="${ox} 0 300 210" preserveAspectRatio="none" aria-hidden="true"><g fill="none" stroke="currentColor" opacity=".17">${Array.from({length:9}, (_, i) => `<path d="M-50 ${100 + i * 12} L70 ${99 + i * 12} 118 ${50 + i * 12} 177 ${67 + i * 12} 244 ${7 + i * 12} 360 ${32 + i * 12} 470 ${60 + i * 12} 560 ${20 + i * 12} 760 ${50 + i * 12}"/>`).join("")}</g>`
    + `<path d="${k2Linie(K2_STRASSE)}" fill="none" stroke="var(--bar)" stroke-width="3"/><path class="k2-gegangen" d="${k2Linie([[-10, 177], ...ort.teil.slice(1)])}" fill="none" stroke="var(--accent)" stroke-width="5"/><circle cx="53" cy="177" r="6" fill="var(--brown)"/>`
    + (marke ? `<path class="k2-marke" d="m${marke[0] - 10} ${marke[1]} 10-10 10 10-10 10z" fill="${n ? K2_GESCHENKE[n]?.[2] || "#b3dce1" : "#b3dce1"}" stroke="#617d83"/>` : "") + "</svg>";
  const ziel = n ? `<button class="next-ice" data-k="colors"><small>Tag ${n}</small><b>Noch ${n - tage} ${n - tage === 1 ? "Tag" : "Tage"} bis ${kEsc(K2_GESCHENKE[n][0])} ›</b></button>` : `<button class="next-ice" data-k="badges"><small>Tag ${tage}</small><b>Alle Etappen erreicht ›</b></button>`;
  const weiter = K2_TAGE.find(d => d > (n || 0));
  return '<div class="detail-view">' + k2Titel("Dein Weg", "Deine Etappen")
    + `<div class="land journey-map" data-tag="${tage}"><b>Tag ${tage}</b>${k2SeeKunst(`${ox} 0 300 210`)}${karte}`
    + `<img src="${K_ICON}" alt="BlockEm" class="walker" style="left:calc(${((ort.x - ox) / 3).toFixed(1)}% - 24px*var(--k));top:calc(${(ort.y / 2.1).toFixed(1)}% - 46px*var(--k))">`
    + `<button class="earned" data-k="badges"><i>✦</i> Erster Schritt</button>${ziel}<button class="open-atlas" data-k2-atlas>Karte öffnen ↗</button></div>`
    + `<div class="why"><small>Dein Warum</small><button data-k="why">${store("tue.warum") ? `„${kEsc(store("tue.warum"))}“` : "Deinen Satz festhalten"} <span>›</span></button></div>`
    + zeile("Deine Spendenetappe", `${Math.min(tage, sp)} von ${sp} Tagen`, Math.min(tage, sp), sp, "donations")
    + (g ? zeile(`Gemeinsam im ${mon}`, `${Math.max(0, Math.round(+g.summe || 0))} von ${Math.max(0, Math.round(+g.ziel || 0))} Tagen`, +g.summe || 0, Math.max(1, +g.ziel || 1), "community") : k2Link(`Gemeinsam im ${mon}`, 'data-k="community"', "Monatsziel"))
    + k2Link(`Weitere Etappen${weiter ? ` · ab Tag ${weiter}` : ""}`, 'data-k="colors"')
    + (!tage && K.tr?.sauber?.gesamt ? kNote("Neuer Anfang", `Insgesamt ${K.tr.sauber.gesamt} saubere Tage. Freigeschaltete Farben bleiben.`) : "") + "</div>";
}
function k2Atlas(map){   // große Karte (stories.js showAtlas): wischbar, Etappen antippen, „Mein Standort“
  const tage = +map.dataset.tag || 0, ort = k2Ort(tage), k = document.getElementById("kern"); if (!k) return;
  const d = document.createElement("dialog"); d.className = "trail-dialog"; k.append(d);
  const px = v => `calc(${(+v).toFixed(1)}px*var(--k))`;
  d.innerHTML = `<header><b>Dein Weg</b><button data-zu>Karte schließen ×</button></header><div class="atlas-pan"><div class="atlas-world">${k2SeeKunst("0 0 740 248")}<svg class="atlas-road" viewBox="0 0 740 248" preserveAspectRatio="none"><path d="${k2Linie(K2_STRASSE)}"/><path class="passed" d="${k2Linie(ort.teil)}"/></svg>`
    + K2_HALTE.map(([t, i, name]) => `<button class="atlas-pin${t === 30 || t === 60 ? " oben" : ""}" style="left:${px(K2_STRASSE[i][0])};top:${px(K2_STRASSE[i][1])}" data-halt="${t}">${kEsc(name.split(" · ")[0])}</button>`).join("")
    + `<img class="atlas-hero" src="${K_ICON}" alt="Dein Standort" style="left:${px(ort.x)};top:${px(ort.y)}"></div></div><footer><div aria-live="polite"><small>Dein Standort</small><h3>Tag ${tage}</h3></div><button data-hier>Mein Standort</button></footer>`;
  d.showModal(); const pan = d.querySelector(".atlas-pan"), welt = pan.firstChild, fuss = d.querySelector("footer div");
  const hier = () => { pan.scrollLeft = Math.max(0, ort.x * (welt.offsetWidth / 740) - pan.clientWidth * .45); fuss.innerHTML = `<small>Dein Standort</small><h3>Tag ${tage}</h3>`; };
  hier();
  const a = map.getBoundingClientRect(), b = d.getBoundingClientRect(), pose = `translate(${a.x - b.x}px,${a.y - b.y}px) scale(${a.width / b.width},${a.height / b.height})`;
  k2Anim(d, [{transform:pose}, {transform:"none"}], 380); k2Anim(welt, [{transform:"scale(1.18)"}, {transform:"none"}], 420);
  let zu = false;
  const schliessen = () => { if (zu) return; zu = true; const weg = () => { d.close(); d.remove(); map.querySelector("[data-k2-atlas]")?.focus({preventScroll:true}); };
    const an = k2Anim(d, [{transform:"none"}, {transform:pose}], 260); an ? an.finished.then(weg, weg) : weg(); };
  d.addEventListener("cancel", e => { e.preventDefault(); schliessen(); });
  d.onclick = e => { const btn = e.target.closest("button"); if (!btn) return;
    if ("zu" in btn.dataset) schliessen(); else if ("hier" in btn.dataset) hier();
    else { const h = K2_HALTE.find(x => x[0] === +btn.dataset.halt); if (h) fuss.innerHTML = `<small>Tag ${h[0]} · ${h[0] <= tage ? "erreicht" : "vor dir"}</small><h3>${kEsc(h[2])}</h3>`; } };
  let zug = null;
  pan.onpointerdown = e => { if (e.pointerType === "mouse" && !e.target.closest("button")){ zug = [e.clientX, pan.scrollLeft]; pan.setPointerCapture(e.pointerId); } };
  pan.onpointermove = e => { if (zug) pan.scrollLeft = zug[1] + zug[0] - e.clientX; };
  pan.onpointerup = pan.onpointercancel = () => { zug = null; };
}
function kColors2(){
  const {max} = k2Stand(), akt = kStilAktiv(), probe = k => k === "orange" ? "#d43e30" : (K2_TAGE.map(t => K2_GESCHENKE[t]).find(x => x[3] === k) || [])[2];
  return kMain("WEG", "Farbe der App", `<div class="k-swatches">${STILE.map(x => { const frei = x.ab <= max;
    return `<button class="k-swatch" data-k-stil="${x.k}" aria-pressed="${akt === x.k}" ${frei ? "" : "disabled"}><i style="background:${probe(x.k) || x.farbe}"></i><span>${x.k === "orange" ? "Kern" : x.t}<small>${x.ab ? (frei ? `frei seit Tag ${x.ab}` : `frei ab Tag ${x.ab}`) : "Standard"}</small></span></button>`; }).join("")}</div>`
    + kNote("Bleibt frei", "Eine freigeschaltete Farbe bleibt auch nach einem Neuanfang. Ab Tag 30 kommt alle 30 Tage eine neue Farbe dazu."));
}

/* ---------- Heute: Geschenk-Zeile führt zum Weg, am Etappentag „freigeschaltet“ ---------- */
const kToday1 = kToday;
function kToday2(){
  const t = K.tr?.sauber?.tage || 0, h = kToday1().replace(/data-k="colors"/, 'data-k="journey"');
  return K2_GESCHENKE[t] ? h.replace(/✦ Geschenk in \d+ Tag(en)?/, `✦ ${K2_GESCHENKE[t][0]} freigeschaltet`) : h;
}

/* ---------- Aussehen: Schalter „Animationen“ ---------- */
const kAppearance1 = kAppearance;
function kAppearance2(){
  return kAppearance1().replace(/<\/div>$/, `<div class="motion-setting"><span>Animationen</span><label class="k2-sw" aria-label="Animationen"><input type="checkbox" role="switch" data-k2-bewegung ${store("kern.animation") !== false ? "checked" : ""}><i></i></label></div>${K2_RUHIG.matches ? `<p class="small">Dein Gerät hat „Bewegung reduzieren“ an. Alle Wege bleiben gleich, nur ohne Bewegung.</p>` : ""}</div>`);
}

// Editor: Geräte mit laufendem Antrag nicht als gewählt zeigen, sonst bräche Speichern den Antrag ab (wieder antippen = behalten)
const kRegelOeffnen1 = kRegelOeffnen, kLimitOeffnen1 = kLimitOeffnen;
const k2OhneAntrag = x => { if (x?.alt && Object.keys(k2Offen(x.alt)).length) x.geraete = (x.geraete || []).filter(g => !k2Offen(x.alt)[g]); };
kRegelOeffnen = function(...a){ const r = kRegelOeffnen1(...a); k2OhneAntrag(K.regel); kZeichnen(); return r; };
kLimitOeffnen = function(...a){ const r = kLimitOeffnen1(...a); k2OhneAntrag(K.limit); kZeichnen(); return r; };

Object.assign(K_SEITEN, {focus:kFocus2, adjust:kAdjust, lock:kLock2, rules:kRules, createRule:kCreateRule, protection:kProtection2, devices:kDevices2,
  journey:kJourney2, colors:kColors2, today:kToday2, appearance:kAppearance2});
Object.assign(K_ELTERN, {adjust:"focus", rules:"lock", createRule:"lock"});
Object.assign(K_TITEL, {adjust:"Anpassen", rules:"Regeln verwalten", createRule:"Sperre anlegen"});

/* ---------- Klicks der neuen Teile (kKlick kennt nur seine data-k-…; was er nicht nimmt, landet hier) ---------- */
document.addEventListener("click", async e => {
  const b = e.target.closest("[data-k2-uebernehmen],[data-k2-szene],[data-k2-weg],[data-k2-weg-ab],[data-k2-dazu],[data-k2-atlas],[data-k2-porno]");
  if (!b || !b.closest("#kern")) return;
  e.preventDefault(); const ds = b.dataset;
  if ("k2Uebernehmen" in ds){ K.zurueck = []; kGeh("focus"); return; }
  if ("k2Szene" in ds){ for (const a of b.closest("figure").getAnimations({subtree:true})){ a.currentTime = 0; a.play(); } return; }
  if ("k2Atlas" in ds){ k2Atlas(b.closest(".journey-map")); return; }
  if ("k2Porno" in ds){ b.disabled = true; try { await api("api/profil", {ziel:"beides"}); toast("Porno-Schutz ist an."); K.zeit.tr = 0; await kHole("tr", "api/tracking", 0); } catch (err){ K.hinweis = err.message || String(err); } kZeichnen(); return; }
  const [id, geraet] = String(ds.k2Weg || ds.k2WegAb || ds.k2Dazu || "").split("|"), art = ds.k2Weg ? "geraetWeg" : ds.k2WegAb ? "geraetWegAb" : "geraetDazu";
  K2.geraetAuf = geraet; K.hinweis = ""; b.disabled = true;
  const x = await kPost("api/locker", {[art]:{id, geraet}}, art === "geraetWeg" ? "Beantragt. Die Regel gilt dort noch 24 Stunden." : art === "geraetDazu" ? `Gilt jetzt auch auf ${geraet}.` : `Bleibt auf ${geraet}.`);
  if (x){ K.lk = x; K.zeit.lk = Date.now(); try { if (typeof vbSperreAbgleich === "function") vbSperreAbgleich(); } catch {} kZeichnen(); }
}, true);
document.addEventListener("toggle", e => {   // offene Erklärung/Gerät merken, damit Neuzeichnen sie nicht zuklappt
  const d = e.target; if (!d.closest?.("#kern")) return;
  if (d.dataset?.k2Auf){ if (d.open){ K2.schutzAuf = d.dataset.k2Auf; } else if (K2.schutzAuf === d.dataset.k2Auf) K2.schutzAuf = ""; store("kern.schutzAuf", K2.schutzAuf); }
  if (d.dataset?.deviceName) K2.geraetAuf = d.open ? d.dataset.deviceName : K2.geraetAuf === d.dataset.deviceName ? "" : K2.geraetAuf;
}, true);
document.addEventListener("change", e => {
  if (!e.target.matches?.("#kern [data-k2-bewegung]")) return;
  store("kern.animation", e.target.checked); document.documentElement.dataset.still = String(!kBewegung());
  if (!kBewegung()) document.getAnimations?.().forEach(a => a.cancel());
});
// Fokus-Start: Startpose merken, damit die Figur in einem Bogen zum Countdown wandert (motion.js travel)
document.addEventListener("click", e => {
  if (!e.target.closest?.("#kern .design-action[data-k-fokus-start]")) return;
  const f = document.querySelector("#kern .focus-stage .facet .live-figure"), d = document.querySelector("#kern .focus-stage .duration");
  K2.reise = {fig:f?.getBoundingClientRect(), dauer:d?.getBoundingClientRect(), t:Date.now()};
}, true);

/* ---------- Wischen zwischen Sperren · Schutz · Geräte (scene-motion.js, vereinfacht: Inhalt folgt dem Finger, dann Seitenwechsel) ---------- */
(function k2Wischen(){
  let g = null;
  document.addEventListener("pointerdown", e => {
    const s = e.target.closest?.("#kern .screen"); const i = K2_REITER.findIndex(([id]) => id === K.v);
    if (!s || i < 0 || !e.isPrimary || e.button > 0 || e.target.closest("input,select,textarea,.trend-scroll,.story-window")) return;
    g = {id:e.pointerId, x:e.clientX, y:e.clientY, s, i, dx:0, zieht:false};
  }, true);
  document.addEventListener("pointermove", e => {
    if (!g || e.pointerId !== g.id) return;
    const dx = e.clientX - g.x, dy = e.clientY - g.y;
    if (!g.zieht){ if (Math.abs(dy) > 10 && Math.abs(dy) > Math.abs(dx)){ g = null; return; } if (Math.abs(dx) < 12 || Math.abs(dx) < Math.abs(dy) * 1.3) return; g.zieht = true; }
    const ziel = K2_REITER[g.i + (dx < 0 ? 1 : -1)]; g.dx = ziel ? dx : dx / 4;
    const inhalt = g.s.querySelector(".lock"); if (inhalt && kBewegung()) inhalt.style.transform = `translateX(${g.dx}px)`;
  }, {passive:true});
  const ende = e => {
    if (!g || e.pointerId !== g.id) return; const x = g; g = null;
    const inhalt = x.s.querySelector(".lock"); if (!x.zieht){ return; }
    const w = x.s.clientWidth || 1, ziel = K2_REITER[x.i + (x.dx < 0 ? 1 : -1)];
    K2.klickSperre = Date.now() + 250;
    if (ziel && Math.abs(x.dx) > w * .22 && e.type !== "pointercancel"){ K2.wischVon = x.dx; kGeh(ziel[0]); return; }
    if (inhalt){ const t = inhalt.style.transform; inhalt.style.transform = ""; if (t) k2Anim(inhalt, [{transform:t}, {transform:"none"}], 170); }
  };
  document.addEventListener("pointerup", ende, true); document.addEventListener("pointercancel", ende, true);
  addEventListener("click", e => { if (K2.klickSperre > Date.now() && e.target.closest?.("#kern .screen")){ e.stopImmediatePropagation(); e.preventDefault(); } }, true);
})();

/* ---------- Bewegungen nach jedem Zeichnen (motion.js / scene-motion.js) ---------- */
let k2Timer = 0, k2Laeufe = [], k2Links = true;
function k2Ruhe(){ clearTimeout(k2Timer); k2Laeufe.forEach(a => a?.cancel()); k2Laeufe = []; }
function k2Pose(el, posen, ms){ if (el && kBewegung()) k2Laeufe.push(el.animate(posen.map(([offset, transform]) => ({offset, transform, easing:"cubic-bezier(.44,0,.28,1)"})), {duration:ms})); }
const K2_BUEHNE = {today:".today .facet .live-figure", focus:".focus-stage .facet .live-figure", lock:".etched-lock", journey:".journey-map .walker", active:".mini-facet .live-figure"};
function k2Spiel(){   // scene-motion.js: Heute Blick + Blinzeln, Fokus Blick zum Startknopf, Sperre Schloss wippt, Weg Blick zum nächsten Geschenk
  k2Timer = 0;
  const k = document.getElementById("kern"), fig = K2_BUEHNE[K.v] && k?.querySelector(K2_BUEHNE[K.v]);
  if (!fig || !kBewegung() || document.hidden || document.querySelector("dialog[open]")) return k2Plan();
  const r = fig.getBoundingClientRect(); if (!r.width || r.bottom < 0 || r.top > innerHeight) return k2Plan();
  const augen = fig.querySelector(".mascot-eyes"), kopf = fig.querySelector(".mascot-head");
  if (K.v === "lock") k2Laeufe.push(k2Anim(fig, [{transform:"rotate(5deg)"}, {transform:"rotate(10deg)", offset:.38}, {transform:"rotate(3deg)", offset:.76}, {transform:"rotate(5deg)"}], 680));
  else if (K.v === "today") return k2Leben();   // Heute: dauernd lebendig wie in der Übergabe-Aufnahme (szenen-*.mp4)
  else {
    const ziel = k.querySelector(K.v === "journey" ? ".next-ice" : K.v === "active" ? ".session-clock" : ".design-action")?.getBoundingClientRect(); if (!ziel) return k2Plan();
    const dx = ziel.x + ziel.width / 2 - r.x - r.width / 2, dy = ziel.y + ziel.height / 2 - r.y - r.height / 2, l = Math.hypot(dx, dy) || 1, w = K.v === "journey" ? 9 : 3.5, blick = `translate(${w * dx / l}px,${w * dy / l}px)`;
    if (K.v === "journey"){
      const halten = p => [{transform:"none"}, {transform:p, offset:.24}, {transform:p, offset:.76}, {transform:"none"}];
      k2Laeufe.push(k2Anim(augen, halten(blick), 1050), k2Anim(kopf, halten("rotate(-4deg)"), 1050));
      const m = k.querySelector(".journey-map .k2-marke"), f = m?.getAttribute("fill"); if (m) k2Laeufe.push(k2Anim(m, [{fill:f}, {fill:f, offset:.35}, {fill:"#fff", offset:.62}, {fill:f}], 1050));
    } else {
      const neig = dx < 0 ? -1.6 : 1.6;
      k2Pose(augen, [[0,"none"],[.34,blick],[.57,blick],[1,"none"]], 3000);
      k2Pose(kopf, [[0,"none"],[.1,"none"],[.45,`rotate(${neig}deg)`],[.6,`rotate(${neig}deg)`],[1,"none"]], 3250);
    }
  }
  const jetzt = k2Laeufe.filter(Boolean); Promise.allSettled(jetzt.map(a => a.finished)).then(() => { k2Laeufe = k2Laeufe.filter(a => a && !jetzt.includes(a)); if (!k2Laeufe.length) k2Plan(); });
}
/* Heute-Männchen wie in der Übergabe-Aufnahme: der Blick führt, der Körper dreht sich verzögert hinterher (Würfel-Kante wandert mit),
   dazu ruhiges Atmen und Blinzeln alle paar Sekunden; ab und zu kehrt die Figur weich in die Ruhe zurück. Ein Lauf je Seite, endet beim Verlassen. */
const K2_KOERPER = [[18,31,48,17,44,72,17,70], [48,17,84,29,63,45,44,34], [44,72,79,72,51,85,17,70]];   // Ruhe-Ecken: linke Fläche, Krone, Boden (K2_FIGUR)
let k2LebtSeit = 0;
function k2Leben(){
  if (k2LebtSeit) return;
  const z = {t:0, gx:0, gy:0, ex:0, ey:0, y1:0, y2:0, wechsel:900, blinz:2600, lid:1}; let vorher = 0, fig = null; k2LebtSeit = performance.now();
  const setz = (f, s) => { const p = f.querySelectorAll(".mascot-head path"), k = K2_KOERPER.map(e => e.slice());
    k[0][2] += s; k[0][4] += s; k[1][0] += s; k[1][6] += s; k[1][4] += s * .6; k[2][0] += s;   // innere Kante (Licht/Front) wandert = Würfel dreht sich
    [1, 3, 2].forEach((n, i) => p[n]?.setAttribute("d", "M" + k[i].join(" ") + "z")); };
  const ruhe = f => { if (!f) return; f.querySelector(".body-sway").style.transform = ""; f.querySelector(".mascot-eyes").style.transform = ""; setz(f, 0); };
  const schritt = jetzt => {
    const neuFig = document.querySelector("#kern .today .facet .live-figure");
    if (K.v !== "today" || !neuFig || !kBewegung()){ ruhe(fig); ruhe(neuFig); k2LebtSeit = 0; return; }
    if (neuFig !== fig){ ruhe(fig); fig = neuFig; }
    const dt = Math.min(64, vorher ? jetzt - vorher : 16); vorher = jetzt; z.t += dt;
    const r = fig.getBoundingClientRect(), still = document.hidden || !r.width || r.bottom < 0 || r.top > innerHeight || document.querySelector("dialog[open]");
    if ((z.wechsel -= dt) <= 0){ const ruhig = still || Math.random() < .3; z.gx = ruhig ? 0 : (Math.random() * 2 - 1); z.gy = ruhig ? 0 : (Math.random() - .5) * .8; z.wechsel = 1400 + Math.random() * 1800; }
    if ((z.blinz -= dt) <= 0){ z.lid = 0; z.blinz = (Math.random() < .15 ? 380 : 3500 + Math.random() * 4000); }
    const glatt = (a, b, tau) => a + (b - a) * (1 - Math.exp(-dt / tau));
    z.ex = glatt(z.ex, z.gx, 140); z.ey = glatt(z.ey, z.gy, 140);   // Augen führen
    z.y1 = glatt(z.y1, z.ex, 320); z.y2 = glatt(z.y2, z.y1, 320);   // Körper folgt verzögert und weich
    z.lid = Math.min(1, z.lid + dt / 115); const lid = z.lid < .5 ? 1 - z.lid * 1.72 : .14 + (z.lid - .5) * 1.72;   // Blinzeln 0,23 s auf 14 % (face-blink.svg)
    const atem = Math.sin(z.t / 4200 * 2 * Math.PI), y = z.y2;
    fig.querySelector(".body-sway").style.transform = `translate(${(y * 2.5).toFixed(2)}px,${(atem * -.8 - Math.abs(y)).toFixed(2)}px) rotate(${(y * 8 + atem * 1.2).toFixed(2)}deg)`;
    fig.querySelector(".mascot-eyes").style.transform = `translate(${(z.ex * 4).toFixed(2)}px,${(z.ey * 2.5).toFixed(2)}px) scaleY(${lid.toFixed(3)})`;
    setz(fig, +(y * 4.5).toFixed(2));
    requestAnimationFrame(schritt);
  };
  requestAnimationFrame(schritt);
}
function k2Plan(erst){ clearTimeout(k2Timer); k2Timer = 0; if (K2_BUEHNE[K.v] && kBewegung()) k2Timer = setTimeout(k2Spiel, erst ? 1250 : 4400 + Math.random() * 2600); }
document.addEventListener("visibilitychange", () => { if (document.hidden) k2Ruhe(); else k2Plan(true); });
function k2Wippen(fig){   // Antippen: Männchen wippt (motion.js balance)
  if (!fig || !kBewegung()) return; fig.getAnimations().forEach(a => a.cancel());
  k2Anim(fig, fig.closest(".today") ? [{transform:"none"}, {transform:"rotate(2deg)", offset:.47}, {transform:"none"}] : [{transform:"none"}, {transform:"rotate(8deg) translateY(-2px)", offset:.38}, {transform:"rotate(-3deg)", offset:.73}, {transform:"none"}], 900);
}
document.addEventListener("click", e => { const f = e.target.closest?.("#kern .facet .live-figure, #kern .journey-map .walker"); if (f) return k2Wippen(f);
  const m = e.target.closest?.("#kern .journey-map"); if (m && !e.target.closest("button")) k2Atlas(m); });   // Karte antippen öffnet sie groß (stories.js)

const kZeichnen1 = kZeichnen;
kZeichnen = function(){
  const k = document.getElementById("kern"), von = K2.letzteV, alt = k?.querySelectorAll(".rank .mini-track>i, .daypart .mix>i") || [];
  const breiten = [...alt].map(x => x.getBoundingClientRect().width), geraetVorher = K2.letztesGeraet;
  const gleich = !!k && von === K.v, altFig = gleich && K2_BUEHNE[K.v] ? k.querySelector(K2_BUEHNE[K.v]) : null;
  if (!gleich) k2Ruhe();
  kZeichnen1(); if (!k) return;
  K2.letzteV = K.v; K2.letztesGeraet = K.geraet;
  document.documentElement.dataset.still = String(!kBewegung());
  k2FigurenLeben(k);
  // Daten laden nach und zeichnen neu: dieselbe Figur bleibt stehen, damit Blick und Atmen nicht neu anfangen (sonst ruckelt es bzw. kommt nie dran)
  if (altFig){ const neu = k.querySelector(K2_BUEHNE[K.v]); if (neu && neu !== altFig && neu.getAttribute("class") === altFig.getAttribute("class") && neu.getAttribute("style") === altFig.getAttribute("style")) neu.replaceWith(altFig); }
  k.querySelectorAll(".body-sway").forEach(x => { x.style.animationDelay = `${-Math.round(performance.now())}ms`; });   // Atmen läuft über Neuzeichnen hinweg im selben Takt
  if (K.v === "today" && !gleich && kBewegung() && store("kern.gruss") !== new Date().toDateString()){ store("kern.gruss", new Date().toDateString()); setTimeout(() => k2Wippen(k.querySelector(K2_BUEHNE.today)), 400); }   // einmal am Tag kurz grüßen (motion.js)
  const s = k.querySelector(".screen");
  if (s) s.classList.toggle("k2-wisch", K2_REITER.some(([id]) => id === K.v));
  // Reiterwechsel: Inhalt gleitet von der Seite herein
  const a = K2_REITER.findIndex(([id]) => id === von), b = K2_REITER.findIndex(([id]) => id === K.v);
  if (a >= 0 && b >= 0 && a !== b){ const inhalt = s?.querySelector(".lock"), w = s?.clientWidth || 300, start = K2.wischVon != null ? K2.wischVon + Math.sign(b - a) * w : Math.sign(b - a) * 24;
    k2Anim(inhalt, [{transform:`translateX(${start}px)`}, {transform:"none"}], 190); }
  K2.wischVon = null;
  // Schloss rastet ein, wenn eine Regel zum ersten Mal aktiv gesehen wird
  const lead = k.querySelector(".lock-now[data-k2-regel-id]");
  if (lead && !K2.gesehen.has(lead.dataset.k2RegelId)){ K2.gesehen.add(lead.dataset.k2RegelId); const p = lead.querySelectorAll(".etched-lock path");
    k2Anim(p[0], [{transform:"translateY(-7px)"}, {transform:"none"}], 175); [...p].slice(1).forEach(x => k2Anim(x, [{transform:"none"}, {transform:"translateY(1.5px)", offset:.65}, {transform:"none"}], 210)); }
  // Werte: bei Gerätewechsel wachsen die Balken; Woche: alle sieben Säulen füllen sich von unten neu
  if (["values","valuesWeek","valuesReview"].includes(K.v) && von === K.v && geraetVorher !== K.geraet)
    k.querySelectorAll(".rank .mini-track>i, .daypart .mix>i").forEach((x, i) => { const e = x.getBoundingClientRect().width; if (e && Math.abs(e - (breiten[i] || 0)) > .5){ x.style.transformOrigin = "left"; k2Anim(x, [{transform:`scaleX(${Math.min(4, (breiten[i] || 0) / e)})`}, {transform:"none"}], 175); } });
  if (K.v === "valuesWeek" && (von !== K.v || geraetVorher !== K.geraet) && kBewegung())
    k.querySelectorAll(".stacked .trend-day>span").forEach((st, i) => { const voll = [...st.children].reduce((h, x) => h + x.offsetHeight, 0);
      st.animate([{clipPath:"inset(100% 0 0 0)"}, {clipPath:`inset(${Math.max(0, st.offsetHeight - voll - 2)}px 0 0 0)`}], {duration:395, delay:i * 14, fill:"backwards", easing:"cubic-bezier(.2,.72,.26,1)"}); });
  // Fokus gestartet: Figur wandert im Bogen vom Startbereich zum Countdown, die Zeit gleitet von der Dauer zur Uhr
  if (K.v === "active" && K2.reise && Date.now() - K2.reise.t < 15000){
    const r = K2.reise; K2.reise = null; const ziel = k.querySelector(".mini-facet .live-figure"), uhr = k.querySelector(".session-clock");
    if (ziel && r.fig?.width){ const e = ziel.getBoundingClientRect(), dx = r.fig.x - e.x, dy = r.fig.y - e.y, q = r.fig.width / (e.width || 1);
      ziel.closest(".mini-facet")?.classList.add("travelling"); ziel.style.transformOrigin = "top left";
      const an = k2Anim(ziel, [{transform:`translate(${dx}px,${dy}px) scale(${q})`}, {transform:`translate(${.52 * dx - 7}px,${.52 * dy - 12}px) scale(${1 + .5 * (q - 1)}) rotate(-4deg)`, offset:.48}, {transform:"none"}], 480);
      const fertig = () => ziel.closest(".mini-facet")?.classList.remove("travelling"); an ? an.finished.then(fertig, fertig) : fertig(); }
    if (uhr && r.dauer?.width){ const e = uhr.getBoundingClientRect(); uhr.style.transformOrigin = "left top"; k2Anim(uhr, [{transform:`translate(${r.dauer.x - e.x}px,${r.dauer.y - e.y}px) scale(.78)`}, {transform:"none"}], 440); }
  }
  if (!gleich) k2Plan(true); else if (!k2Timer && !k2Laeufe.some(a => a?.playState === "running")) k2Plan();
};
kThema(); kZeichnen();
